library flutter_package_test;

class AA {
  void test() {
    print("AAAAAAAAAAAAAAAAAAA");
  }
}
