package com.kedacom.flutter_sxtapp.manager;

import android.content.Context;
import android.text.TextUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.kedacom.basic.common.util.StringUtil;
import com.kedacom.flutter_sxtapp.R;
import com.kedacom.flutter_sxtapp.model.Contact;
import com.kedacom.flutter_sxtapp.util.FileUtils;
import com.kedacom.util.AppUtil;

import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SxtDataLoader {
    private final static Logger logger = LoggerFactory.getLogger(SxtDataLoader.class);

    public static void loadUserInfo(String userCode, TextView tvName, ImageView ivHead, boolean isRound) {
        Context context = AppUtil.getApp();
        Contact contactInfo = DataManager.getInstance().getContact(userCode);
        if (null != contactInfo && (tvName != null && !TextUtils.isEmpty(contactInfo.getName()))) {
            if (null != tvName) {
                tvName.setText(contactInfo.getName());
            }
            Glide.with(context)
                    .load(FileUtils.getAvatarUrl(contactInfo))
                    .dontAnimate()
                    .placeholder(isRound ? R.mipmap.ic_avatar_default_flutter : R.mipmap.ic_avatar_default_rect_flutter)
                    .error(isRound ? R.mipmap.ic_avatar_default_flutter : R.mipmap.ic_avatar_default_rect_flutter)
                    .into(ivHead);
            return;
        } else {
            Glide.with(context)
                    .load(isRound ? R.mipmap.ic_avatar_default_flutter : R.mipmap.ic_avatar_default_rect_flutter)
                    .dontAnimate()
                    .into(ivHead);
        }

        FlutterManager.Companion.getInstance().getContact(userCode, new FlutterDataListener<Contact>() {
            @Override
            public void onSuccess(Contact userInfo) {
                DataManager.getInstance().addContactCache(userCode, userInfo);

                int headRes = isRound ? R.mipmap.ic_avatar_default_flutter : R.mipmap.ic_avatar_default_rect_flutter;
                if (null != tvName) {
                    if (StringUtil.isEmpty(userInfo.getName())) {
                        tvName.setText(userInfo.getPoliceNo());
                    } else {
                        tvName.setText(userInfo.getName());
                    }
                }

                Glide.with(context)
                        .load(FileUtils.getAvatarUrl(userInfo))
                        .error(headRes)
                        .placeholder(headRes)
                        .dontAnimate()
                        .into(ivHead);
            }

            @Override
            public void onError(@NotNull Throwable e) {
                if (null != tvName) {
                    tvName.setText(userCode);
                }
                Glide.with(context)
                        .load(isRound ? R.mipmap.ic_avatar_default_flutter : R.mipmap.ic_avatar_default_rect_flutter)
                        .dontAnimate()
                        .into(ivHead);
            }
        });
    }

    public static void loadUserInfo(String userCode, TextView tvName, ImageView ivHead) {
        loadUserInfo(userCode, tvName, ivHead, true);
    }
}
