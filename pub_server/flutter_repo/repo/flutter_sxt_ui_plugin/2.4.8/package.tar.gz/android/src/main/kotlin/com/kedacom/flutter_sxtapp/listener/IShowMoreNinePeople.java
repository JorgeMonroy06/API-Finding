package com.kedacom.flutter_sxtapp.listener;

/**
 * 选择框超过固定人数
 */
public interface IShowMoreNinePeople {
    void showWaringDialog();
}
