package com.kedacom.flutter_sxtapp.widget

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import androidx.annotation.CallSuper
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import com.kedacom.util.LegoLog

abstract class BaseDialogFragment : DialogFragment() {
    private var nIsCanceledOnTouchOutside = false
    private var nIsShowing: Boolean = false

    companion object {
        private val FRAGMENT_TAG_PRE = "Lib_widgets_"
    }

    private var nOnViewCreatedListener: OnViewCreatedListener? = null;

    override fun onAttach(context: Context) {
        super.onAttach(context)
    }


    fun isShowing(): Boolean {
        return nIsShowing
    }


    override fun onStart() {
        super.onStart()
        val dialog = dialog
        if (dialog != null) {
            //            //在5.0以下的版本会出现白色背景边框，若在5.0以上设置则会造成文字部分的背景也变成透明
            //            if(Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            //                //目前只有这两个dialog会出现边框
            //                if(dialog instanceof ProgressDialog || dialog instanceof DatePickerDialog) {
            //                    getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            //                }
            //            }
            getDialog()?.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setCanceledOnTouchOutside(nIsCanceledOnTouchOutside)
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return super.onCreateDialog(savedInstanceState)
    }

    @CallSuper
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        nOnViewCreatedListener?.onViewCreated(view, this)
    }

    open fun setOnViewCreatedListener(onViewCreatedListener: OnViewCreatedListener?) {
        this.nOnViewCreatedListener = onViewCreatedListener;
    }

    open fun setCanceledOnTouchOutside(cancel: Boolean): BaseDialogFragment {
        nIsCanceledOnTouchOutside = cancel

        val dialog = dialog
        dialog?.setCanceledOnTouchOutside(cancel)
        return this
    }

    open fun show(activity: AppCompatActivity) {
        if (nIsShowing) {
            return
        }
        try {
            super.show(activity.supportFragmentManager, FRAGMENT_TAG_PRE + this.javaClass.simpleName)
        } catch (e: IllegalStateException) {
            LegoLog.d("BaseDialog-show IllegalStateException" + e.message)
            val ft = activity.supportFragmentManager.beginTransaction()
            ft.add(this, "LEGO-" + this.javaClass.simpleName)
            ft.commitAllowingStateLoss()
        }

        nIsShowing = true
    }

    open fun show(fragment: Fragment) {
        if (nIsShowing) {
            return
        }
        try {
            super.show(fragment.requireFragmentManager(), FRAGMENT_TAG_PRE + this.javaClass.simpleName)
        } catch (e: IllegalStateException) {
            LegoLog.d("BaseDialog-show IllegalStateException" + e.message)
            val ft = fragment.requireFragmentManager().beginTransaction()
            ft.add(this, "LEGO-" + this.javaClass.simpleName)
            ft.commitAllowingStateLoss()
        }

        nIsShowing = true
    }


    open fun showNow(activity: AppCompatActivity) {
        if (nIsShowing) {
            return
        }
        try {
            super.showNow(activity.supportFragmentManager, "LEGO-" + this.javaClass.simpleName)
        } catch (e: IllegalStateException) {
            LegoLog.d("BaseDialog-showNow IllegalStateException" + e.message)
            val ft = activity.supportFragmentManager.beginTransaction()
            ft.add(this, "LEGO-" + this.javaClass.simpleName)
            ft.commitNowAllowingStateLoss()
        }

        nIsShowing = true
    }

    override fun dismiss() {
        if (nIsShowing) {
            super.dismissAllowingStateLoss()
            nIsShowing = false
        }


    }

    override fun dismissAllowingStateLoss() {
        if (nIsShowing) {
            super.dismissAllowingStateLoss()
            nIsShowing = false
        }

    }

    interface OnViewCreatedListener {
        fun onViewCreated(rootView: View, dialog: DialogFragment);
    }
}