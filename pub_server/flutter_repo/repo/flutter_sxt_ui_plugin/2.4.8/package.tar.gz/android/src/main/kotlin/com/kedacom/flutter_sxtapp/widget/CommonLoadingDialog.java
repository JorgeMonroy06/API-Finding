package com.kedacom.flutter_sxtapp.widget;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.StringRes;
import androidx.annotation.StyleRes;

import com.kedacom.flutter_sxtapp.R;
import com.wang.avi.AVLoadingIndicatorView;


/**
 * @author : yuanbingbing
 * @since : 2018/9/6 16:32
 */
public class CommonLoadingDialog extends Dialog {

    private CharSequence message;
    private AVLoadingIndicatorView avi;

    private CommonLoadingDialog(Context context, String message, int theme, boolean cancelable, OnCancelListener cancelListener) {
        super(context, theme);
        this.message = message;
        setCancelable(cancelable);
        if (cancelListener != null) setOnCancelListener(cancelListener);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_common_loading_flutter);
        avi = findViewById(R.id.avi);
//        setCustomTitle(null);
        setCanceledOnTouchOutside(false);
        initMessage();
    }

    public void setMessage(CharSequence message) {
        this.message = message;
        if (isShowing()) initMessage();
    }

    private void initMessage() {
        if (message != null && message.length() > 0) {
            ((TextView) findViewById(R.id.waiting_spots_title)).setText(message);
        }
    }

    public static class Builder {

        private Context context;
        private String message;
        private int messageId;
        private int themeId;
        private int loadingType;
        private boolean cancelable = true; // default dialog behaviour
        private OnCancelListener cancelListener;

        public CommonLoadingDialog.Builder setContext(Context context) {
            this.context = context;
            return this;
        }

        public CommonLoadingDialog.Builder setMessage(String message) {
            this.message = message;
            return this;
        }

        public CommonLoadingDialog.Builder setMessage(@StringRes int messageId) {
            this.messageId = messageId;
            return this;
        }

        public CommonLoadingDialog.Builder setTheme(@StyleRes int themeId) {
            this.themeId = themeId;
            return this;
        }

        public CommonLoadingDialog.Builder setCancelable(boolean cancelable) {
            this.cancelable = cancelable;
            return this;
        }

        public CommonLoadingDialog.Builder setCancelListener(OnCancelListener cancelListener) {
            this.cancelListener = cancelListener;
            return this;
        }

        public CommonLoadingDialog build() {
            return new CommonLoadingDialog(
                    context,
                    messageId != 0 ? context.getString(messageId) : message,
                    themeId != 0 ? themeId : R.style.loading_dialog_style1,
                    cancelable,
                    cancelListener
            );
        }
    }


/*    @Override
    public void show() {
        super.show();
        if (null != avi && View.VISIBLE != avi.getVisibility()) {
            avi.show();
        }
    }

    @Override
    public void dismiss() {
        super.dismiss();
        if (null != avi && View.VISIBLE == avi.getVisibility()) {
            avi.hide();
        }
    }*/

}
