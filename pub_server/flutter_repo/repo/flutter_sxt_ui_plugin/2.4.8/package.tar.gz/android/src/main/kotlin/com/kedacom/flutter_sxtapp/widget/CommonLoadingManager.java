package com.kedacom.flutter_sxtapp.widget;

import android.content.Context;

import androidx.lifecycle.LifecycleObserver;


public class CommonLoadingManager implements LifecycleObserver {
    private CommonLoadingDialog loadingDialog;
    private Context context;

    public CommonLoadingManager(Context context) {
        this.context = context;
    }

    public void showWaitingDialog(String message, boolean isCancelable) {
        if (loadingDialog == null) {
            loadingDialog = new CommonLoadingDialog.Builder()
                    .setCancelable(isCancelable)
                    .setContext(context)
                    .setMessage(message)
                    .build();
        } else {
            loadingDialog.setMessage(message);
            loadingDialog.setCancelable(isCancelable);
        }
        if (!loadingDialog.isShowing()) {
            loadingDialog.show();
        }
    }

    public void showWaitingDialog(String message) {
        showWaitingDialog(message, true);
    }

    public synchronized void hideWaitingDialog() {
        if (loadingDialog != null) {
            loadingDialog.dismiss();
            loadingDialog = null;
        }
    }
}