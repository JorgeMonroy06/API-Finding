package com.kedacom.flutter_sxtapp.activity;

import android.os.Bundle;
import android.view.View;

import com.kedacom.android.library.pemissionguide.PermissionGuideHelper;
import com.kedacom.flutter_sxtapp.R;
import com.kedacom.flutter_sxtapp.databinding.ActivityPermissionGuideFlutterBinding;
import com.kedacom.flutter_sxtapp.util.ScreenUtils;
import com.kedacom.flutter_sxtapp.viewmodel.PermissionGuideViewModel;
import com.kedacom.widget.common.StatusBarUtil;


public class PermissionGuideActivity extends BaseActivity<ActivityPermissionGuideFlutterBinding, PermissionGuideViewModel> {

    @Override
    public int getContentViewId() {
        return R.layout.activity_permission_guide_flutter;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StatusBarUtil.statusBarImmersion(this);

        nViewDataBinding.viewStatusBar.setPadding(0, ScreenUtils.getStatusHeight(this), 0, 0);
        nViewDataBinding.viewStatusBar.getLayoutParams().height = ScreenUtils.getStatusHeight(this) + ScreenUtils.dp2px(56);

        nViewDataBinding.llContainer.addView(PermissionGuideHelper.getPermissionGuideView(this));

        nViewDataBinding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


}
