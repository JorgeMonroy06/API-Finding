package com.kedacom.flutter_sxtapp.adapter;


import com.kedacom.flutter_sxtapp.databinding.ItemGroupLiveDanmuFlutterBinding;
import com.kedacom.flutter_sxtapp.manager.SxtDataLoader;
import com.kedacom.flutter_sxtapp.model.GroupLiveBarrageBean;
import com.kedacom.lego.adapter.recyclerview.LegoBaseRecyclerViewAdapter;
import com.kedacom.lego.adapter.recyclerview.LegoBaseRecyclerViewBindingHolder;

import java.util.List;

public class GroupLiveBarrageAdapter extends LegoBaseRecyclerViewAdapter<GroupLiveBarrageBean> {
    public GroupLiveBarrageAdapter(int layoutId, List<GroupLiveBarrageBean> data) {
        super(layoutId, data);
    }


    @Override
    public void onBindViewHolder(LegoBaseRecyclerViewBindingHolder holder, int position) {
        super.onBindViewHolder(holder, position);
        ItemGroupLiveDanmuFlutterBinding itemGroupLiveDanmuBinding = (ItemGroupLiveDanmuFlutterBinding) holder.getBinding();
        GroupLiveBarrageBean bean = nData.get(position);

        SxtDataLoader.loadUserInfo(bean.getUserCode(), itemGroupLiveDanmuBinding.tvName, itemGroupLiveDanmuBinding.iconHead);
        if (bean.getBarrageType() == 1) {
            itemGroupLiveDanmuBinding.tvMessage.setText(":" + bean.getContent());
        } else {
            itemGroupLiveDanmuBinding.tvMessage.setText(bean.getContent());
        }

    }
}
