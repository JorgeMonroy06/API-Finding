package com.kedacom.flutter_sxtapp.activity;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.kedacom.basic.common.resource.util.ViewUtil;
import com.kedacom.basic.common.util.ListUtil;
import com.kedacom.basic.common.util.ObjectUtil;
import com.kedacom.basic.common.util.Optional;
import com.kedacom.basic.common.util.StringUtil;
import com.kedacom.basic.common.util.WakeLockUtil;
import com.kedacom.flutter_sxtapp.R;
import com.kedacom.flutter_sxtapp.databinding.ActivityGroupVideoCallFlutterBinding;
import com.kedacom.flutter_sxtapp.manager.FlutterDataListener;
import com.kedacom.flutter_sxtapp.manager.FlutterManager;
import com.kedacom.flutter_sxtapp.manager.SxtDataLoader;
import com.kedacom.flutter_sxtapp.model.Contact;
import com.kedacom.flutter_sxtapp.service.FloatGroupVideoWindowService;
import com.kedacom.flutter_sxtapp.service.FloatVideoWindowService;
import com.kedacom.flutter_sxtapp.util.ClickEventUtils;
import com.kedacom.flutter_sxtapp.util.FastBlur;
import com.kedacom.flutter_sxtapp.util.FileUtils;
import com.kedacom.flutter_sxtapp.util.VibratorUtil;
import com.kedacom.flutter_sxtapp.viewmodel.MultiVideoCallViewModel;
import com.kedacom.flutter_sxtapp.widget.BlurTransformation;
import com.kedacom.flutter_sxtapp.widget.MultiVideoChatLayout;
import com.kedacom.flutter_sxtapp.widget.RoundedImageView;
import com.kedacom.lego.annotation.Extra;
import com.kedacom.lego.annotation.OnMessage;
import com.kedacom.lego.annotation.ViewModel;
import com.kedacom.lego.fast.util.ToastUtil;
import com.kedacom.lego.fast.widget.dialog.ConfirmDialog;
import com.kedacom.lego.fast.widget.dialog.DialogFragmentHelper;
import com.kedacom.lego.message.LegoEventBus;
import com.kedacom.sxt_flutter_plugin.manager.SxtDataManager;
import com.kedacom.uc.ptt.video.media.DefaultCameraCapture;
import com.kedacom.uc.ptt.video.media.DefaultMultiVideoRender;
import com.kedacom.uc.sdk.RequestCallback;
import com.kedacom.uc.sdk.auth.model.IAccount;
import com.kedacom.uc.sdk.bean.common.DeviceType;
import com.kedacom.uc.sdk.group.GroupService;
import com.kedacom.uc.sdk.group.model.IUserMember;
import com.kedacom.uc.sdk.impl.SdkImpl;
import com.kedacom.uc.sdk.util.DomainIdUtil;
import com.kedacom.uc.sdk.vchat.constant.VideoChatEventType;
import com.kedacom.uc.sdk.vchat.constant.VideoRoomUserState;
import com.kedacom.uc.sdk.vchat.model.VideoCallType;
import com.kedacom.uc.sdk.vchat.model.VideoChatEvent;
import com.kedacom.uc.sdk.vchat.model.VideoChatRoom;
import com.kedacom.uc.sdk.vchat.model.VideoChatRoomUser;
import com.kedacom.util.AppUtil;
import com.kedacom.util.LegoLog;
import com.kedacom.webrtcsdk.sdkmanager.kedamedia;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by wangbaoshun on 2020/10/29 14:10.
 */
@ViewModel(MultiVideoCallViewModel.class)
public class GroupVideoCallActivity extends BaseActivity<ActivityGroupVideoCallFlutterBinding, MultiVideoCallViewModel> {


    private static final int NORMAL = -1;
    private static final int BUSY = 0;
    private static final int REFUSED = 1;
    private static final int AWAY = 2;

    private DefaultMultiVideoRender multiVideoRender;
    private MultiVideoChatLayout videoGridLayout;
    @Extra("VideoChatRoom")
    private VideoChatRoom room;
    private VideoChatEvent currentEvent;
    private boolean isCloseCamera = true;
    @Extra("isVideo")
    private boolean isVideo = false;
    private String currentUserCode = SdkImpl.getInstance().getUserSession().get().getUser().getUserCodeForDomain();
    private boolean otherCameraIsClose = false;//对方摄像头状态
    private boolean isEstablished;
    private DeviceType curDevType;
    private boolean isCameraFront = true;
    private int cameraId = 1;
    private boolean isMicMute = false;
    private boolean isSpeakOn = true;
    private AudioManager nAudioMager = null;
    @Extra("groupName")
    private String groupName;
    @Extra("codeForDomain")
    private String groupDomianCode;
    @Extra("groupCode")
    private String groupCode;
    @Extra("userCodesForDomain")
    private ArrayList<String> userCodesForDomainList;

    private long startTime = 0;//通话时长
    /**
     * 检测是否有悬浮框权限
     */
    private boolean nOverlyPermission;
    private boolean isFinish = false;
    private FloatGroupVideoWindowService floatGroupVideoWindowService;
    private int conversationType = 1;
    /**
     * 开启缩小服务匡
     */
    private boolean isConnectService = false;

    /**
     * 检测是否存在后台
     */
    private boolean isBackFront = false;

    private boolean isSender;
    private Ringtone nRingTone;
    //有没有点击挂断按钮
    private boolean handUpClicked = false;
    //是否已经是挂断状态
    private boolean isHandUpState = false;
    /**
     * 本地进行计时
     */
    private Timer nTimer = new Timer();

    private Handler videoHander = new Handler();
    private Observer<VideoChatEvent> mutiVideoStateObserver;
    private Observer<String> closeWindowsObserver;
    private ConfirmDialog reCallConfirmDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FlutterManager.Companion.getInstance().startVideoCalling();
        initData();

        registerMutiVideoState();
        initView();
        closeWindows();
    }

    private void initVideoCallGaoSiBack() {
        FlutterManager.Companion.getInstance().getContact(currentEvent.getSrcUserCode(), new FlutterDataListener<Contact>() {
            @Override
            public void onSuccess(Contact contact) {
                if (contact != null) {
                    if (TextUtils.isEmpty(FileUtils.getAvatarUrl(contact))) {
                        BitmapFactory.Options options = new BitmapFactory.Options();
                        //基于options设置新建Bitmap资源
                        Bitmap bitmap1 = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_avatar_default_rect_big_flutter, options);
                        //获取经虚化的Bitmap资源
                        Bitmap rsBitmap = FastBlur.doBlur(bitmap1, 10, false);
                        BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), rsBitmap);
                        mBinding.layoutGroupVideoInvite.llLayoutInvite.setBackground(bitmapDrawable);
                    } else {
                        Glide.with(GroupVideoCallActivity.this).download(FileUtils.getAvatarUrl(contact)).addListener(new RequestListener<File>() {
                            @Override
                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<File> target, boolean isFirstResource) {
                                BitmapFactory.Options options = new BitmapFactory.Options();
                                //基于options设置新建Bitmap资源
                                Bitmap bitmap1 = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_avatar_default_rect_big_flutter, options);
                                //获取经虚化的Bitmap资源
                                Bitmap rsBitmap = FastBlur.doBlur(bitmap1, 10, false);
                                BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), rsBitmap);
                                mBinding.layoutGroupVideoInvite.llLayoutInvite.setBackground(bitmapDrawable);
                                return false;
                            }

                            @Override
                            public boolean onResourceReady(File resource, Object model, Target<File> target, DataSource dataSource, boolean isFirstResource) {
                                BitmapFactory.Options options = new BitmapFactory.Options();
                                //基于options设置新建Bitmap资源
                                Bitmap bitmap1 = BitmapFactory.decodeFile(resource.getAbsolutePath(), options);
                                //  Bitmap bitmap1 = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_default_avatar_female, options);
                                //获取经虚化的Bitmap资源
                                Bitmap rsBitmap = FastBlur.doBlur(bitmap1, 10, false);
                                BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), rsBitmap);
                                mBinding.layoutGroupVideoInvite.llLayoutInvite.setBackground(bitmapDrawable);
                                return false;
                            }
                        });
                    }
                }
            }

            @Override
            public void onError(@NotNull Throwable e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * 多方会议事件监听
     */

    private void registerMutiVideoState() {
        mutiVideoStateObserver = new Observer<VideoChatEvent>() {
            @Override
            public void onChanged(@Nullable VideoChatEvent videoChatEvent) {
                if (room != null && videoChatEvent != null && videoChatEvent.get() != null && StringUtil.isEquals(room.getRoomId(), videoChatEvent.get().getRoomId())) {
                    listenVideoEventResult(videoChatEvent);
                }
            }
        };
        LegoEventBus.use("groupMutivideoRoomStateCall", VideoChatEvent.class).observeForever(mutiVideoStateObserver);
    }

    @Override
    public int getContentViewId() {
        return R.layout.activity_group_video_call_flutter;
    }

    private Ringtone initRingtone(Activity context) {
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALL);
        Ringtone tone = RingtoneManager.getRingtone(context, notification);
        setRingtoneRepeat(tone);
        return tone;
    }

    private void setRingtoneRepeat(Ringtone ringtone) {
        Class<Ringtone> clazz = Ringtone.class;
        try {
            Field audio = clazz.getDeclaredField("mAudio");
            audio.setAccessible(true);
            MediaPlayer target = (MediaPlayer) audio.get(ringtone);
            target.setLooping(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void closeWindows() {
        closeWindowsObserver = new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                if (room != null && StringUtil.isEquals(s, room.getRoomId())) {
                    quitMulite();
                    mViewModel.quitChatRoomTrigger(s);
                    if (floatGroupVideoWindowService != null) {
                        floatGroupVideoWindowService.closeFloatWindow();
                    }
                    delayFinish();
                }
            }
        };
        LegoEventBus.use("closeGroupMutiVideoCall", String.class).observeForever(closeWindowsObserver);
    }

    private void initVideoView() {
        videoGridLayout = mBinding.layoutVideoCall.videoGroupMemberGv;
        IAccount curUser = SdkImpl.getInstance().getUserSession().orNull();
        if (null != curUser) {
            curDevType = DeviceType.valueOf(curUser.getDeviceType());
        }
        setViewStatus(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        loadRenderView(videoGridLayout, currentUserCode, VideoRoomUserState.INVITING, NORMAL, true);
        mBinding.layoutVideoCall.imgOpenCamera.toggle(true);
        if (isVideo) {  //视频聊天
            //l_multivideo_camerastatus.setVisibility(View.VISIBLE);
            isCloseCamera = false;
            mBinding.layoutVideoCall.imgOpenCamera.toggle(isCloseCamera);
            mBinding.layoutVideoCall.videoTalkTvCamerastatus.setText(getResources().getText(R.string.ptt_video_talk_camerastatus));
            mBinding.layoutVideoCall.videoGroupTalkSwithcCamera.setVisibility(View.VISIBLE);
            //l_multivideo_talk_switchcamera.setVisibility(View.VISIBLE);
        } else {  //语音聊天
            isCloseCamera = true;
            //l_multivideo_camerastatus.setVisibility(View.GONE);
            //videoGroupTalk_camerastatus_iv.setBackgroundResource(R.drawable.bid_video_camera_close);
            mBinding.layoutVideoCall.imgOpenCamera.toggle(isCloseCamera);
            mBinding.layoutVideoCall.videoTalkTvCamerastatus.setText(getResources().getText(R.string.ptt_video_talk_camerastatus_close));
            mBinding.layoutVideoCall.imgOpenCamera.setClickable(false);
            mBinding.layoutVideoCall.imgOpenCamera.setEnabled(false);
            mBinding.layoutVideoCall.llMultivideoOpenCamera.setClickable(false);
            mBinding.layoutVideoCall.videoGroupTalkSwithcCamera.setVisibility(View.INVISIBLE);
        }

        mViewModel.getMultiVideRoom(room.getContactCodeForDomain(), room.getSessionType());
    }

    /**
     * 锁屏显示 设置窗体的样式
     */
    private void keyBoardScreen() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON);
    }

    private void initView() {
        keyBoardScreen();
        isSender = getIntent().getBooleanExtra("isSender", true);
        if (isSender) {
            mBinding.layoutGroupVideoInvite.llLayoutInvite.setVisibility(View.GONE);
            mBinding.layoutVideoCall.reVideoCall.setVisibility(View.VISIBLE);
            initVideoView();
        } else {
            mBinding.layoutGroupVideoInvite.llLayoutInvite.setVisibility(View.VISIBLE);
            mBinding.layoutVideoCall.reVideoCall.setVisibility(View.GONE);
            initInviteData();
        }
    }

    /**
     * 初始化数据
     */
    private void initData() {
        if (userCodesForDomainList == null) {
            userCodesForDomainList = new ArrayList<String>();
        }
        SxtDataManager.Companion.getInstance().setCalling(true);//是否进行双向视频。用来判断不可进行ptt对讲
        FlutterManager.Companion.getInstance().updateMultiMeeting();
        nAudioMager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        multiVideoRender = new DefaultMultiVideoRender(this);
        isSender = getIntent().getBooleanExtra("isSender", true);
        currentEvent = (VideoChatEvent) getIntent().getSerializableExtra("event");
        if (room == null) {
            room = currentEvent.get();
        }
        String otherUserCode;
        if (currentEvent != null) {
            otherUserCode = DomainIdUtil.getCode(currentEvent.getSrcUserCodeForDomain());
        } else {
            otherUserCode = DomainIdUtil.getCode(room.getContactCodeForDomain());
        }
        kedamedia.getInstance(GroupVideoCallActivity.this, null).setHandsFree(isSpeakOn);
    }

    /**
     * 初始化邀请界面的UI
     */
    private void initInviteData() {
        nRingTone = initRingtone(GroupVideoCallActivity.this);
        startTip();
        mBinding.layoutGroupVideoInvite.tvContent.setVisibility(View.VISIBLE);
        loadMenbersView();
        //mBinding.layoutGroupVideoInvite.tvContent.setText(getString(R.string.invite_multi_talk));
        if (currentEvent != null) {
            mBinding.layoutGroupVideoInvite.videotalkUsernameTv.setText(currentEvent.getSrcUserCode());
            mViewModel.getUserHeadImagePath(currentEvent.getSrcUserCode(), mBinding.layoutGroupVideoInvite.videotalkUserIv, mBinding.layoutGroupVideoInvite.videotalkUsernameTv);
            FlutterManager.Companion.getInstance().getContact(currentEvent.getSrcUserCode(), new FlutterDataListener<Contact>() {
                @Override
                public void onError(@NotNull Throwable e) {
                    e.printStackTrace();
                }

                @Override
                public void onSuccess(Contact contact) {
                    if (contact != null) {
                        if (TextUtils.isEmpty(FileUtils.getAvatarUrl(contact))) {
                            BitmapFactory.Options options = new BitmapFactory.Options();
                            //基于options设置新建Bitmap资源
                            Bitmap bitmap1 = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_avatar_default_flutter, options);
                            //获取经虚化的Bitmap资源
                            Bitmap rsBitmap = FastBlur.doBlur(bitmap1, 10, false);
                            BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), rsBitmap);
                            mBinding.ivBackground.setImageDrawable(bitmapDrawable);
                        } else {
                            Glide.with(AppUtil.getApp())
                                    .load(FileUtils.getAvatarUrl(contact))
                                    .placeholder(R.mipmap.ic_avatar_default_flutter)
                                    .error(R.mipmap.ic_avatar_default_flutter)
                                    .dontAnimate()
                                    .apply(RequestOptions.bitmapTransform(new BlurTransformation(GroupVideoCallActivity.this, 25, 3)))
                                    .into(mBinding.ivBackground);
                        }
                    }
                }
            });

            if (currentEvent.getEvent() == VideoChatEventType.VOICE_INCOMING) {
                mBinding.layoutGroupVideoInvite.tvContent.setText(getResources().getText(R.string.ptt_voice_invite_tile));
            } else {
                mBinding.layoutGroupVideoInvite.tvContent.setText(getResources().getText(R.string.ptt_video_invite_tile));
            }

            initVideoCallGaoSiBack();
            //屏幕亮
            WakeLockUtil.acquireScreenDim(GroupVideoCallActivity.this, 10000, ObjectUtil.getInstanceTag(GroupVideoCallActivity.this));
            //play ringtone

            com.kedacom.basic.common.resource.util.VibratorUtil.vibrate(GroupVideoCallActivity.this, new long[]

                    {
                            1000, 1000, 1000, 1000
                    }, true);
        }
    }

    private void loadMenbersView() {
        if (room != null) {
            List<VideoChatRoomUser> roomChatUsers = room.getAllRoomUsers();
            logger.info("GroupVideoCallActivity aaa loadMenbersView roomChatUsers size: {}", roomChatUsers.size());
            List<VideoChatRoomUser> newUsers = new ArrayList<>();
            for (VideoChatRoomUser user : roomChatUsers) {
                logger.info("GroupVideoCallActivity aaa roomUser  user: {}", user.getUserCodeForDomain());
                IAccount iAccount = SdkImpl.getInstance().getUserSession().orNull();
                if (user.getState() != VideoRoomUserState.REFUSED && user.getState() != VideoRoomUserState.QUITED && !user.getUserCodeForDomain().equals(currentEvent.getSrcUserCodeForDomain()) && !StringUtil.isEquals(user.getUserCode(), iAccount.getUserCode())) {
                    newUsers.add(user);
                    logger.info("GroupVideoCallActivity aaa loadMenbersView add user: {}", user.getUserCodeForDomain());
                }
            }

            if (newUsers.size() > 0) {
                mBinding.layoutGroupVideoInvite.llVideoJoinMenbers.removeAllViews();
                getViewDataBinding().layoutGroupVideoInvite.tvInviteTitle.setVisibility(View.VISIBLE);
                for (VideoChatRoomUser user : newUsers) {
                    loadMenberView(user.getUserCode());
                }
                mBinding.layoutGroupVideoInvite.tvInviteTitle.setText(String.format(getString(R.string.video_all_people), newUsers.size() + ""));
            } else {
                getViewDataBinding().layoutGroupVideoInvite.tvInviteTitle.setVisibility(View.GONE);
            }
        }
    }

    /**
     * 加载邀请界面头像
     *
     * @param userCode
     */
    public void loadMenberView(final String userCode) {

        View view = LayoutInflater.from(this).inflate(R.layout.item_multie_video_invite_menber_flutter, mBinding.layoutGroupVideoInvite.llVideoJoinMenbers, false);
        LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        param.setMargins(10, 10, 10, 10);
        param.gravity = Gravity.CENTER_HORIZONTAL;
        view.setLayoutParams(param);
        view.setTag(userCode);
        RoundedImageView headImage = view.findViewById(R.id.item_head_img);
        TextView tv_name = (TextView) view.findViewById(R.id.item_name);
        SxtDataLoader.loadUserInfo(userCode, tv_name, headImage, true);

        mBinding.layoutGroupVideoInvite.llVideoJoinMenbers.addView(view, param);
        handler.sendEmptyMessageDelayed(0, 100);

    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 0) {
                mBinding.layoutGroupVideoInvite.horizontalView.fullScroll(HorizontalScrollView.FOCUS_RIGHT);
            }
        }
    };

    /**
     * 开始计算事件
     */
    private void startTip() {
        if (nRingTone != null) {
            nRingTone.play();
        }
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                VibratorUtil.Vibrate(GroupVideoCallActivity.this, 1500L);
            }
        };
        try {
            nTimer.schedule(timerTask, 0L, 2000L);
        } catch (Exception e) {
            LegoLog.e("stop media timer error", e);
        }
    }

    @OnMessage
    public void getMulitVideoRoomResult(VideoChatRoom videoRoom) {
        if (videoRoom != null) {
            this.room = videoRoom;
            //采集之前 设置 voice
            logger.info("loadChatRoomResult room ={}", videoRoom);
            getIntent().putExtra("room", videoRoom);
            DefaultCameraCapture capture = new DefaultCameraCapture();
            //listen view event
            // mViewModel.registerEventsTrigger(room, capture, multiVideoRender);
            //presenter.registerEventsTrigger(capture, multiVideoRender, null);

            //bind capture and render
            mViewModel.bindCaptureAndRender(room.getRoomId(), capture, multiVideoRender);
            //presenter.bindCaptureAndRenderTrigger(capture, multiVideoRender, null);
        }


    }

    @OnMessage
    public void bindCaptureAndRenderResult() {
        //join or start video
        logger.info("bindCaptureAndRenderResult  hasActiveMembers = {}  roomisCalling ={} room={}", room.hasActiveMembers(), room.isCalling(), room);
        if (room.hasActiveMembers()) {
            //multiVideoRender.buildMultiRender(that, room);
            if (room.isCalling()) {
                mViewModel.acceptInviteTrigger(room.getRoomId(), isVideo);
            } else {
                logger.info("bindCaptureAndRenderResult  currentUserCode ={}  getAllRoomUsers() = {}", currentUserCode, room.getAllRoomUsers());
                VideoChatRoomUser vchatRoomUser = room.getRoomUser(currentUserCode);
                logger.info("bindCaptureAndRenderResult  curDevType ={} videoChatRoom = {}", curDevType, vchatRoomUser);
                if (vchatRoomUser != null) {
                    if (room.isInitial()) {
                        mViewModel.joinBidChatRoomTrigger(room.getRoomId(), isVideo);

                        return;
                    } else if (null != curDevType && vchatRoomUser.getLoginDeviceType() != curDevType) {
                        showToast(getString(R.string.had_join_by_other_device));
                        finish();
                        return;
                    }
                }
                showToast("加入多方失败");
                finish();


            }
        } else {
            if (StringUtil.isEmpty(room.getUserCodeForDomain())) {
                logger.info("begin startVideoChatTrigger failure. userCodesForDomain is null.");
                quitMulite();
                mViewModel.quitChatRoomTrigger(room.getRoomId());
                finish();
                return;
            }
            mViewModel.startVideoChatTrigger(userCodesForDomainList, room.getRoomId(), isVideo);
            mBinding.layoutVideoCall.tvTime.setText("正在呼叫");
        }
    }

    @OnMessage
    public void joinChatRoomResult() {
        reloadLocalRenderInEstablished();
        conversationType = 2;
        startTime();
        for (VideoChatRoomUser entry : room.getAllRoomUsers()) {
            logger.info("acceptInviteResult userCode ={}  ", entry.getUserCodeForDomain());
            if (!StringUtil.isEquals(currentUserCode, entry.getUserCodeForDomain())) {
                userCodesForDomainList.add(entry.getUserCodeForDomain());
                loadRenderView(videoGridLayout, entry.getUserCodeForDomain(), entry.getState(), NORMAL, false);
            }
        }
    }

    /**
     *
     */
    @OnMessage
    public void acceptInviteResult() {
        conversationType = 2;
        reloadLocalRenderInEstablished();
        startTime();
        for (VideoChatRoomUser entry : room.getAllRoomUsers()) {
            logger.info("acceptInviteResult userCode ={} ", entry.getUserCodeForDomain());
            if (!StringUtil.isEquals(currentUserCode, entry.getUserCodeForDomain())) {
                userCodesForDomainList.add(entry.getUserCodeForDomain());
                loadRenderView(videoGridLayout, entry.getUserCodeForDomain(), entry.getState(), NORMAL, false);
            }
        }
    }

    @OnMessage
    public void startVideoChatResult() {
        logger.info("GropVideoCallStartVideoSuccess startVideoChatResult room ={}", room);

        //这里需要刷新窗口
        for (VideoChatRoomUser entry : room.getAllRoomUsers()) {
            if (!StringUtil.isEquals(currentUserCode, entry.getUserCodeForDomain())) {
                loadRenderView(videoGridLayout, entry.getUserCodeForDomain(), entry.getState(), NORMAL, false);
            }
        }
    }

    /**
     * 监听多方会议状态
     *
     * @param videoChatEvent
     */

    private void listenVideoEventResult(final VideoChatEvent videoChatEvent) {
        if (videoChatEvent == null) {
            return;
        }
        VideoChatEventType type = videoChatEvent.getType();
        String currentUserCode = DomainIdUtil.getCode((videoChatEvent.getData()).getUserCodeForDomain());
        String currentUserCodeForDomain = (videoChatEvent.getData()).getUserCodeForDomain();
        String srcUserCodeForDomain = videoChatEvent.getSrcUserCodeForDomain();

        logger.info("listenVideoEventResult  videoChatEvent = {}  ", videoChatEvent);

        logger.info("listenVideoEventResult  videoChatRoom  = {}  ", videoChatEvent.get());
        logger.info("listenVideoEventResult type ={}   currentUserCode= {} ", type, currentUserCode);

        if (videoChatEvent.get().getRoomType() != VideoCallType.MULTI_VIDEO) {
            logger.info("listenVideoEventResult error  videoChatRoom  = {}  ", videoChatEvent.get());
            return;
        }
        room = videoChatEvent.get();

        switch (type) {
            case ADJUST_VIDEO_QUALITY:
                showToast("当前网络不流畅，已自动调整视频码率.");
                break;

            case VIDEO_RECOVERY_START:
                showToast("当前网络不稳定，请稍后");
                setBidVideoFuncIsEnable(false);
                break;

            case VIDEO_RECOVERY_SUCCESS:
                showToast("网络连接正常...");
                setBidVideoFuncIsEnable(true);
                break;
            case VIDEO_RECOVERY_TIMEOUT:
                showToast("重连超时");
                mViewModel.quitChatRoomTrigger(room.getRoomId());
                break;

            case CALLEE_ACK_QUIT:
                initShowUserNameToast(videoChatEvent.getSrcUserCode(), "已退出");
                loadRenderView(videoGridLayout, srcUserCodeForDomain, VideoRoomUserState.QUITED, NORMAL, false);

                logger.info("CALLEE_ACK_QUIT room ={}", videoChatEvent.get());
                if ((videoChatEvent.get().getRoomActivityUsers() != null && videoChatEvent.get().getRoomActivityUsers().size() <= 1) || videoChatEvent.get().isInitial()) {
                    logger.info("CALLEE_ACK_QUIT getRoomActivityUsers ={}", videoChatEvent.get().getRoomActivityUsers().size());
                    mViewModel.quitChatRoomTrigger(room.getRoomId());
                    quitMulite();
                    //finish();
                }
                break;
            case CALLEE_ACK_AGREE:
                startTime();
                conversationType = 2;
                initShowUserNameToast(videoChatEvent.getSrcUserCode(), "已接受");
                reloadLocalRenderInEstablished();
                loadRenderView(videoGridLayout, srcUserCodeForDomain, VideoRoomUserState.ACCEPTED, NORMAL, false);
                logger.info("MULTI_ACK_AGREE  activityUser ={} ", videoChatEvent.get().getRoomActivityUsers());

                break;
            case CALLEE_AWAY:
                if (ListUtil.contains(videoChatEvent.getCodesForDomain(), currentUserCodeForDomain)) {
                    initShowUserNameToast(videoChatEvent.getSrcUserCode(), "未接听");
                }
                loadRenderView(videoGridLayout, srcUserCodeForDomain, VideoRoomUserState.REFUSED, AWAY, false);
                break;
            case VIDEO_NOTIFY_SELF_OTHER_ISBUSY:
                if (ListUtil.contains(videoChatEvent.getCodesForDomain(), currentUserCodeForDomain)) {
                    initShowUserNameToast(videoChatEvent.getSrcUserCode(), "忙线中");
                }
                loadRenderView(videoGridLayout, srcUserCodeForDomain, VideoRoomUserState.REFUSED, BUSY, false);
                break;
            case CALLEE_ACK_REJECT:
                if (ListUtil.contains(videoChatEvent.getCodesForDomain(), currentUserCodeForDomain)) {
                    initShowUserNameToast(videoChatEvent.getSrcUserCode(), "已拒绝");
                }
                if (ListUtil.contains(userCodesForDomainList, srcUserCodeForDomain)) {
                    loadRenderView(videoGridLayout, srcUserCodeForDomain, VideoRoomUserState.REFUSED, REFUSED, false);
                }
                break;
            case VIDEO_ALONE_TERMINATE:
                // showToast("结束通话...");
                quitMulite();
                //  presenter.quitChatRoomTrigger(this);
                mViewModel.quitChatRoomTrigger(room.getRoomId());
                if (floatGroupVideoWindowService != null) {
                    floatGroupVideoWindowService.closeFloatWindow();
                }
                delayFinish();
                break;
            case VIDEO_SELF_REFUSE:
                mBinding.layoutGroupVideoInvite.tvInviteType.setVisibility(View.VISIBLE);
                mBinding.layoutGroupVideoInvite.tvInviteType.setText("已拒绝");
                break;
            case VIDEO_CMD_OPS_OPEN:
                showToast("对方摄像头已开");
                //changeCameraStatus(true, DomainIdUtil.getCode(srcUserCodeForDomain), currentUserCode);
                logger.info("srcUserCode VIDEO_CMD_OPS_OPEN ={}", srcUserCodeForDomain);
                otherCameraIsClose = false;
                openCameraViewStatus(srcUserCodeForDomain);
                break;

            case VIDEO_CMD_OPS_CLOSE:
                showToast("对方摄像头已关");
                //  changeCameraStatus(false, DomainIdUtil.getCode(srcUserCodeForDomain), currentUserCode);
                otherCameraIsClose = true;
                logger.info("srcUserCode VIDEO_CMD_OPS_CLOSE ={}", srcUserCodeForDomain);
                closeCameraViewStatus(srcUserCodeForDomain);
                break;

            case CALLEE_ACK_BUSY:
                showToast("对方忙...");
                break;
            case CALLEE_JOIN: //通知更新成员
                initShowUserNameToast(videoChatEvent.getSrcUserCode(), "加入多方会议");
                reloadLocalRenderInEstablished();
                loadRenderView(videoGridLayout, srcUserCodeForDomain, VideoRoomUserState.ACCEPTED, NORMAL, false);
                break;
            case VIDEO_SHARE_INVITE_CALL:  // inviting event for other caller
                if (videoChatEvent != null && ListUtil.isEmpty(videoChatEvent.getCodesForDomain())) {
                    logger.info("videoChatEvent.getCodesForDomain() is value  ={}", videoChatEvent.getCodesForDomain());
                    break;
                }
                for (String userCodeForDomain : videoChatEvent.getCodesForDomain()) {
                    loadRenderView(videoGridLayout, userCodeForDomain, VideoRoomUserState.INVITING, NORMAL, false);
                }
                break;

            case INCOMING_TIMEOUT:
                if (videoChatEvent == null || null == videoChatEvent.getCodesForDomain()) {
                    return;
                }
                for (String userCodeForDomain : videoChatEvent.getCodesForDomain()) {
                    loadRenderView(videoGridLayout, userCodeForDomain, VideoRoomUserState.TIMEDOUT, NORMAL, false);
                }
                break;

            case CALLEE_ACK_CANCEL:
                showToast("已取消通话");
                finish();
                break;
            case OTHER_DEVICE_ACK_REFUSE:
                showToast(getString(R.string.videotalk_other_device_refuse));//已在其它端拒绝

                if (floatGroupVideoWindowService != null) {
                    floatGroupVideoWindowService.closeFloatWindow();
                }
                finish();
                break;
            case OTHER_DEVICE_ACK_AGREE:
                showToast(getString(R.string.videotalk_other_device_agree));//已在其它端拒绝
                if (floatGroupVideoWindowService != null) {
                    floatGroupVideoWindowService.closeFloatWindow();
                }
                finish();
                break;
        }


    }

    /**
     * 根据userCode 获取姓名 进行提示
     *
     * @param userCode
     * @param tip
     */

    private void initShowUserNameToast(String userCode, String tip) {
        FlutterManager.Companion.getInstance().getContact(userCode, new FlutterDataListener<Contact>() {
            @Override
            public void onSuccess(Contact contact) {
                if (contact != null) {
                    showToast(contact.getName() + "" + tip);
                }
            }

            @Override
            public void onError(@NotNull Throwable e) {
                showToast("获取用户信息失败：" + e.getMessage());
            }
        });
    }

    @OnMessage
    public void addMenberResultSuccess() {
        for (String userCodeForDomain : userCodesForDomainList) {
            logger.info("addMultiVideoMemberResult userCode ={} ", userCodeForDomain);
            if (!StringUtil.isEquals(currentUserCode, userCodeForDomain)) {
                loadRenderView(videoGridLayout, userCodeForDomain, VideoRoomUserState.INVITING, NORMAL, false);
            }
        }
    }

    @OnMessage
    public void quitChatRoomResult() {
        finish();
    }

    private void closeCameraViewStatus(String userCodeForDomain) {
        View itemView = videoGridLayout.findViewWithTag(userCodeForDomain);
        if (itemView != null) {
            RelativeLayout relativeLayout = (RelativeLayout) itemView.findViewById(R.id.rl_multivideo_view);
            ImageView defaultBg = (ImageView) itemView.findViewById(R.id.rl_multivideo_view_defaultbg);
            if (relativeLayout != null && defaultBg != null) {

                TextView tv_name = (TextView) itemView.findViewById(R.id.tv_multivideo_name);
                //videoGridLayout.removeView(itemView);
                relativeLayout.setVisibility(View.GONE);
                /**
                 * resolve surface last frame by hiding the surfaceView when layout changed
                 */
                ViewUtil.setVisibility(relativeLayout.findViewWithTag(userCodeForDomain), View.GONE);
                defaultBg.setVisibility(View.VISIBLE);
                mViewModel.getUserHeadImagePath(DomainIdUtil.getCode(userCodeForDomain), defaultBg, tv_name);
                if (tv_name != null) {
                    tv_name.bringToFront();
                }

                //videoRender.<SurfaceView>getView2().getHolder().setFormat(PixelFormat.TRANSLUCENT);
                //videoGridLayout.addView(itemView);
            }
        }
    }

    private void openCameraViewStatus(String userCodeForDomain) {
        View itemView = videoGridLayout.findViewWithTag(userCodeForDomain);
        if (itemView != null) {
            RelativeLayout relativeLayout = (RelativeLayout) itemView.findViewById(R.id.rl_multivideo_view);
            ImageView defaultBg = (ImageView) itemView.findViewById(R.id.rl_multivideo_view_defaultbg);

            if (relativeLayout != null && defaultBg != null) {
                relativeLayout.setVisibility(View.VISIBLE);
                ViewUtil.setVisibility(relativeLayout.findViewWithTag(userCodeForDomain), View.VISIBLE);
                defaultBg.setVisibility(View.GONE);
                //videoRender.<SurfaceView>getView2().getHolder().setFormat(PixelFormat.OPAQUE);
            }
        }
    }

    private void reloadLocalRenderInEstablished() {
        if (!isEstablished) {
            this.isEstablished = true;
            setViewStatus(true);
            loadRenderView(videoGridLayout, currentUserCode, VideoRoomUserState.ACCEPTED, NORMAL, true);
        }

        mBinding.layoutVideoCall.videoGroupTalkVline.setVisibility(View.GONE);
    }

    private void setBidVideoFuncIsEnable(boolean isEnable) {
        logger.info("setBidVideoFuncIsEnable  isEnable = {} ", isEnable);

        //   mBinding.videoGroupTalkMuteIv.setEnabled(isEnable);

//        mBinding.videoGroupTalkCamerastatusIv.setEnabled(isEnable);
//        mBinding.videoGroupTalkSwitchcameraIv.setEnabled(isEnable);
    }

    private void setViewStatus(boolean isVisible) {
        logger.info("setViewStatus  isVisible= {}", isVisible);
        int visible = View.GONE;
        //video_group_talk_vline.setVisibility(View.VISIBLE);
        if (isVisible) {
            visible = View.VISIBLE;
            // video_group_talk_vline.setVisibility(View.GONE);
        }

        mBinding.layoutVideoCall.llHandFree.setVisibility(visible);

        mBinding.layoutVideoCall.llMultivideoOpenCamera.setVisibility(visible);

        mBinding.layoutVideoCall.llSetSlient.setVisibility(visible);

        // mBinding.llTopFun.setVisibility(visible);
    }

    public void getVideoRoom(VideoChatRoom room) {

    }

    /**
     * render grid item view
     *
     * @param multiVideoChatLayout
     * @param userCodeDomain
     * @param state
     * @param isCapture
     */
    private void loadRenderView(MultiVideoChatLayout multiVideoChatLayout, String userCodeDomain, VideoRoomUserState state, int customState, boolean isCapture) {
        logger.info("call loadRenderView(userCodeDomain = [{}], state = [{}], isCapture = [{}])", new Object[]{userCodeDomain, state, isCapture});
        /**
         * fetch grid view item
         */

        View view = mBinding.layoutVideoCall.videoGroupMemberGv.findViewWithTag(userCodeDomain);
        if (view == null) {
            view = LayoutInflater.from(this).inflate(R.layout.item_layout_multi_video_flutter, multiVideoChatLayout, false);

            view.setTag(userCodeDomain);
            if (multiVideoChatLayout != null) {
                multiVideoChatLayout.addView(view);
            }

        } else {
            logger.info("loadRenderView:  reuse view. ");
        }

        /**
         * get field view
         */
        //ImageView headImage = (ImageView) view.findViewById(R.id.crvheadimage);
        TextView tv_name = (TextView) view.findViewById(R.id.tv_multivideo_name);
        TextView tv_state = view.findViewById(R.id.tv_state);
        ImageView item_default_bg = (ImageView) view.findViewById(R.id.item_default_bg);//  person state background
        RelativeLayout renderViewContainer = (RelativeLayout) view.findViewById(R.id.rl_multivideo_view);
        ImageView defaultBg = (ImageView) view.findViewById(R.id.rl_multivideo_view_defaultbg); // person head background

        /**
         * fill data and state
         */
        View renderView;
        switch (state) {
            case ACCEPTED:
                item_default_bg.setOnClickListener(null);
                defaultBg.setVisibility(View.GONE);
                item_default_bg.setVisibility(View.GONE);
                if (item_default_bg.getBackground() instanceof AnimationDrawable) {
                    ((AnimationDrawable) item_default_bg.getBackground()).stop();
                }
                if (isCapture) {
                    renderView = multiVideoRender.getLocalView();
                } else {
                    renderView = multiVideoRender.getRemoteView(userCodeDomain);
                }
                if (isVideo) {
                    renderViewContainer.setVisibility(View.VISIBLE);
                    renderView.setVisibility(View.VISIBLE);
                    defaultBg.setVisibility(View.GONE);
                } else {
                    defaultBg.setVisibility(View.VISIBLE);
                    renderViewContainer.setVisibility(View.GONE);
                    renderView.setVisibility(View.GONE);
                }
                // avoid disappearance when closing camera by callee
                // avoid adding view repeatedly
                ViewGroup parent = (ViewGroup) renderView.getParent();
                if (parent == null || parent != renderViewContainer) {
                    if (parent != null) {
                        parent.removeView(renderView);
                    }

                    RelativeLayout.LayoutParams renderViewParam = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                    renderView.setLayoutParams(renderViewParam);
                    renderViewContainer.addView(renderView);
                }
                break;
            case QUITED:
                renderView = renderViewContainer.findViewWithTag(userCodeDomain);
                if (renderView != null) {
                    renderViewContainer.removeView(renderView);
                }
            case REFUSED:
            case TIMEDOUT:
                item_default_bg.setOnClickListener(new ViewItemClick(userCodeDomain));
                if (item_default_bg.getBackground() instanceof AnimationDrawable) {
                    ((AnimationDrawable) item_default_bg.getBackground()).stop();
                }
                item_default_bg.setBackgroundResource(R.mipmap.multivideo_item_quit_flutter);
                defaultBg.setVisibility(View.VISIBLE);
                item_default_bg.setVisibility(View.VISIBLE);
                break;
            case INVITING:
                item_default_bg.setOnClickListener(null);
                item_default_bg.setBackgroundResource(R.drawable.multivideo_item_default_flutter);
                ((AnimationDrawable) item_default_bg.getBackground()).start();
                defaultBg.setVisibility(View.VISIBLE);
                item_default_bg.setVisibility(View.VISIBLE);
                break;
        }
        switch (customState) {
            case BUSY:
                tv_state.setText("对方通话中");
                tv_state.setVisibility(View.VISIBLE);
                item_default_bg.setOnClickListener(null);
                item_default_bg.setVisibility(View.GONE);
                break;
            case REFUSED:
                tv_state.setText("对方已拒绝");
                tv_state.setVisibility(View.VISIBLE);
//                item_default_bg.setOnClickListener(null);
                item_default_bg.setVisibility(View.GONE);
                break;
            case AWAY:
                tv_state.setText("对方未接通");
                tv_state.setVisibility(View.VISIBLE);
                item_default_bg.setVisibility(View.GONE);
                view.setOnClickListener(new ViewItemClick(userCodeDomain));
                break;
            default:
                view.setOnClickListener(null);
                tv_state.setVisibility(View.GONE);
                break;
        }
        SxtDataLoader.loadUserInfo(DomainIdUtil.getCode(userCodeDomain), tv_name, defaultBg, false);
        tv_name.bringToFront();
    }

    @Override
    protected void onResume() {
        super.onResume();
        isBackFront = false;
    }

    class ViewItemClick implements View.OnClickListener {

        private String userCode;

        ViewItemClick(String userCode) {
            this.userCode = userCode;
        }

        @Override
        public void onClick(View v) {

            ArrayList<String> userCodeList = new ArrayList<>();
            userCodeList.add(userCode);
            mViewModel.addMultiVideoMember(room.getRoomId(), userCodeList);
            // presenter.addMultiVideoMember(room.getRoomId(), userCodeList, userCodeList);
        }
    }

    /**
     * 免提
     *
     * @param view
     */
    public void handFree(View view) {
        if (ClickEventUtils.needRaiseClickEvent(1000)) {
            ToastUtil.showDefaultToast("免提状态切换中,请勿频繁点击");
            return;
        }
        isSpeakOn = !isSpeakOn;

        logger.info("GroupVideoCallActivity handFree isSpeakOn: {}", isSpeakOn);
        mBinding.layoutVideoCall.imgHandFree.toggle(!isSpeakOn);
        kedamedia.getInstance(GroupVideoCallActivity.this, null).setHandsFree(isSpeakOn);
    }

    /**
     * 挂断
     *
     * @param view
     */
    public void handUp(View view) {
        handUpClicked = true;
        isHandUpState = true;
        quitMulite();
        mViewModel.quitChatRoomTrigger(room.getRoomId());
    }

    /**
     * 设置静音
     *
     * @param view
     */
    public void setSlient(View view) {
        if (isMicMute) {
            isMicMute = false;
            showToast("取消静音");//哑音
        } else {
            isMicMute = true;
            showToast("静音");//哑音
        }
        mBinding.layoutVideoCall.imgSetSlient.toggle(isMicMute);
        mViewModel.onQuiet(room.getRoomId(), isMicMute);

    }

    private static Handler mHandler = new Handler();

    /**
     * 切换到听筒
     */
    public void changeToReceiver() {
        logger.info("GroupVideoCallActivity changeToReceiver");
        mHandler.removeCallbacksAndMessages(null);
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                logger.info("GroupVideoCallActivity 222");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                    logger.info("GroupVideoCallActivity 333");
                    nAudioMager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                } else {
                    logger.info("GroupVideoCallActivity 444");
                    nAudioMager.setMode(AudioManager.MODE_IN_CALL);
                }
                logger.info("GroupVideoCallActivity 555");
                nAudioMager.setSpeakerphoneOn(false);
            }
        }, 200);
    }

    /**
     * 切换到扬声器
     */
    public void changeToSpeaker() {
        logger.info("GroupVideoCallActivity changeToSpeaker");
        mHandler.removeCallbacksAndMessages(null);
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                logger.info("GroupVideoCallActivity 111");
                nAudioMager.setMode(AudioManager.MODE_NORMAL);
                logger.info("GroupVideoCallActivity 222");
                nAudioMager.setSpeakerphoneOn(true);
                logger.info("GroupVideoCallActivity 333");
            }
        }, 200);
    }

    @OnMessage
    public void setQuitResult(boolean isMute) {
        mBinding.layoutVideoCall.imgSetSlient.toggle(isMute);
    }

    /**
     * 切换摄像头
     *
     * @param view
     */
    public void switchCamera(View view) {
        //切换摄像头
        if (isCameraFront) {
            cameraId = 0;
            isCameraFront = false;
        } else {
            cameraId = 1;
            isCameraFront = true;
        }
        mViewModel.switchCamera(room.getRoomId(), cameraId);

    }

    @OnMessage
    public void switchCameraResult() {

    }

    @OnMessage
    public void quitMultiRoomSuccess() {
        delayFinish();
    }

    private void delayFinish() {
        //如果没有按挂断按钮，是自己发起的并且还在等待界面的时
        if (!handUpClicked && isSender && conversationType == 1) return;

        isHandUpState = true;
        logger.info("GroupVideoCallActivity delayFinish conversationType : {} , isSender : {}", conversationType, isSender);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isFinishing()) return;
                finish();
            }
        }, 1000);
    }

    private void quitMulite() {
        if (!handUpClicked && isSender && conversationType == 1 && null == reCallConfirmDialog) {
            //这里需要弹出重播对话框
            ConfirmDialog.ConfirmDialogConfig reCallConfirmDialogConfig = new ConfirmDialog.ConfirmDialogConfig();
            reCallConfirmDialogConfig.setPositiveBtnTextColor(getResources().getColor(R.color.colorAccent));
            reCallConfirmDialogConfig.setMsg("通话未接通，是否重拨？");
            reCallConfirmDialogConfig.setNegativeBtnText("取消");
            reCallConfirmDialogConfig.setPositiveBtnText("重播");
            reCallConfirmDialogConfig.setPositiveClick(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    reCallConfirmDialog = null;
                    initView();
                }
            });
            reCallConfirmDialogConfig.setNegativeClick(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    reCallConfirmDialog = null;
                    finish();
                }
            });
            reCallConfirmDialog = DialogFragmentHelper.getConfirmDialog(reCallConfirmDialogConfig);
            reCallConfirmDialog.setCanceledOnTouchOutside(false);
            reCallConfirmDialog.setCancelable(false);
            reCallConfirmDialog.show(GroupVideoCallActivity.this);
        }

        videoHander.removeCallbacksAndMessages(null);
        if (conversationType == 1) {
            mBinding.layoutVideoCall.tvTime.setText(handUpClicked ? "已取消通话" : "通话未接通");
        } else {
            if (isVideo) {
                mBinding.layoutVideoCall.tvTime.setText(getString(R.string.video_mulite_over));
            } else {
                mBinding.layoutVideoCall.tvTime.setText(getString(R.string.audio_multi_over));
            }
        }
    }

    @OnMessage
    public void quitMultiRoomFailed(String throwMsg) {
        showToast("视信通:" + throwMsg);
        finish();

    }

    @OnMessage
    public void getMultiRoomFailed(String throwMsg) {
        showToast("视信通:" + throwMsg);
        finish();

    }


    /**
     * 开启或关闭摄像头
     *
     * @param view
     */
    public void closeOrOpenCamara(View view) {
        IAccount iAccount = SdkImpl.getInstance().getUserSession().orNull();
        if (isCloseCamera) {//  改为打开摄像头
            isCloseCamera = false;
            mBinding.layoutVideoCall.videoGroupTalkSwithcCamera.setVisibility(View.VISIBLE);

            openCameraViewStatus(iAccount.getUser().getUserCodeForDomain());
        } else {    //关闭摄像头
            isCloseCamera = true;
            closeCameraViewStatus(iAccount.getUser().getUserCodeForDomain());
            mBinding.layoutVideoCall.videoGroupTalkSwithcCamera.setVisibility(View.INVISIBLE);
        }
        mBinding.layoutVideoCall.imgOpenCamera.toggle(isCloseCamera);
        mViewModel.rxSetVideoCameraStatus(room.getRoomId(), isCloseCamera);

    }

    /**
     * 添加与会人员
     *
     * @param view
     */
    public void addMenberClick(View view) {
        GroupService groupService = SdkImpl.getInstance().getService(GroupService.class);
        groupService.getGroupMembers(groupCode, 10000).setCallback(new RequestCallback<Optional<List<IUserMember>>>() {
            @Override
            public void onSuccess(Optional<List<IUserMember>> listOptional) {
                FlutterManager.Companion.getInstance().multiMeetingSelectContactPage(groupCode, userCodesForDomainList);

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        moveTaskToBack(true);
                        overridePendingTransition(R.anim.fadein_flutter, R.anim.fadeout_flutter);
                    }
                }, 200);
            }

            @Override
            public void onFailed(Throwable throwable) {

            }
        });

//        LegoIntent intent = new LegoIntent(GroupVideoCallActivity.this, GroupTalkSelectMenberActivity.class);
//        intent.putStringArrayListExtra("selectedCode", userCodesForDomainList);
//        intent.putExtra("codeForDomain", groupDomianCode);
//        intent.putExtra("groupCode", groupCode);
//        intent.putExtra("groupName", groupName);
//        intent.putExtra("multiTalk", true);
//        intent.putExtra("select", true);
//        startActivityForResult(intent, 100);
    }

    /**
     * 在来电画面的 拒绝
     *
     * @param view
     */
    public void refuseVideo(View view) {
        mBinding.layoutGroupVideoInvite.videotalkAcceptIv.setEnabled(false);
        mBinding.layoutGroupVideoInvite.videotalkAcceptIv.setClickable(false);
        mViewModel.refuseBidVideoInviteTrigger(room.getRoomId());

        mBinding.layoutGroupVideoInvite.tvInviteType.setVisibility(View.VISIBLE);
        mBinding.layoutGroupVideoInvite.tvInviteType.setText("已拒绝");
        delayFinish();
    }

    public void accept(View view) {
        mBinding.layoutVideoCall.reVideoCall.setVisibility(View.VISIBLE);
        mBinding.layoutGroupVideoInvite.llLayoutInvite.setVisibility(View.GONE);


        initVideoView();
        stopMedia();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == 101) {
            ArrayList<String> userCodeDomainList = data.getStringArrayListExtra("userCodesForDomain");
            if (userCodeDomainList != null && !userCodeDomainList.isEmpty()) {
                userCodesForDomainList = userCodeDomainList;
                mViewModel.addMultiVideoMember(room.getRoomId(), userCodesForDomainList);
            }
        }

    }

    private void startTime() {
        if (startTime == 0) {
            startTime = System.currentTimeMillis();
        }
        videoHander = new Handler();
        videoHander.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!GroupVideoCallActivity.this.isFinish) {
                    String time = GroupVideoCallActivity.this.getFormatTime(GroupVideoCallActivity.this.startTime);
                    mBinding.layoutVideoCall.tvTime.setText(time);
                    if (GroupVideoCallActivity.this.floatGroupVideoWindowService != null) {
                        GroupVideoCallActivity.this.floatGroupVideoWindowService.setTime(time);
                    }
                    GroupVideoCallActivity.this.startTime();
                }
            }
        }, 1000);

    }

    ServiceConnection mVideoServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            logger.info("VideoCallActivity  onServiceConnected  name : " + name);
            FloatGroupVideoWindowService.MyBinder binder = (FloatGroupVideoWindowService.MyBinder) service;
            floatGroupVideoWindowService = binder.getService();
            if (conversationType == 1) {
                if (GroupVideoCallActivity.this.startTime == 0L) {
                    GroupVideoCallActivity.this.floatGroupVideoWindowService.setTime(getString(R.string.wait_answer));
                }

            } else {
                floatGroupVideoWindowService.setTime(getFormatTime(startTime));
            }

            floatGroupVideoWindowService.switchToAudio();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            logger.info("VideoCallActivity  onServiceDisconnected  name : " + name);
        }
    };

    //开启悬浮框
    private void openFloatWindowsView() {
        Intent intent = new Intent(this, FloatGroupVideoWindowService.class);
        intent.putExtra("isVideo", isVideo);
        isConnectService = this.bindService(intent, this.mVideoServiceConnection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 判断当前应用内部是否拥有悬浮框权限
     */
    private void checkOveralayPermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            nOverlyPermission = Settings.canDrawOverlays(GroupVideoCallActivity.this);
        }
    }

    public String getFormatTime(long startTime) {
        long diff = System.currentTimeMillis() - startTime;
        StringBuffer timeStr = new StringBuffer();
        diff = diff / 1000;
        long h = 0;
        long m = 0;
        long s = 0;
        if (diff >= 60 * 60) {
            h = diff / (60 * 60);
            m = diff % (60 * 60) / 60;
            s = diff % (60 * 60) % 60;
        } else if (diff >= 60) {
            m = diff % (60 * 60) / 60;
            s = diff % (60 * 60) % 60;
        } else {
            s = diff % (60 * 60) % 60;
        }

        DecimalFormat decimalFormat = new DecimalFormat("00");
        String format = decimalFormat.format(m);

        String format2 = decimalFormat.format(s);
        if (h > 0) {
            timeStr.append(h).append(":");
        }
        timeStr.append(format).append(":");
        timeStr.append(format2);
        return timeStr.toString();
    }

    /**
     * 缩小框
     *
     * @param view
     */
    public void shrinkButton(View view) {
        checkOveralayPermission();
        moveTaskToBack(true);
    }

    private void overlayFloatWindows() {
        checkOveralayPermission();
        if (!nOverlyPermission) {
            showToast("暂无悬浮窗权限，请在设置中手动打开该权限");
            return;
        }

        if (isBackFront || !isRunningForeground(GroupVideoCallActivity.this)) {
            Intent intent = new Intent(this, FloatGroupVideoWindowService.class);
            intent.putExtra("isVideo", isVideo);
            if (this.isServiceExisted(FloatVideoWindowService.class.getName()) && isConnectService) {
                this.unbindService(this.mVideoServiceConnection);
            }
            isConnectService = this.bindService(intent, this.mVideoServiceConnection, Context.BIND_AUTO_CREATE);
            logger.info("connectServcice:{}", isConnectService);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        logger.info("onNewIntent");
        super.onNewIntent(intent);
        if (this.floatGroupVideoWindowService != null) {
            this.floatGroupVideoWindowService.closeFloatWindow();
            logger.info("onNewIntent isConnectServier:{}", isConnectService);
            if (this.isServiceExisted(FloatGroupVideoWindowService.class.getName()) && isConnectService) {
                this.unbindService(this.mVideoServiceConnection);
            }

        }
        ArrayList<String> userCodeDomainList = intent.getStringArrayListExtra("userCodesForDomain");
        if (userCodeDomainList != null && !userCodeDomainList.isEmpty()) {
            userCodesForDomainList.addAll(userCodeDomainList);
            mViewModel.addMultiVideoMember(room.getRoomId(), userCodeDomainList);
        }
    }

    public boolean isRunningForeground(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> appProcessInfos = activityManager.getRunningAppProcesses();
        // 枚举进程
        for (ActivityManager.RunningAppProcessInfo appProcessInfo : appProcessInfos) {
            if (appProcessInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                if (appProcessInfo.processName.equals(context.getApplicationInfo().processName)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 判断Service是否存在
     *
     * @param className
     * @return
     */
    public boolean isServiceExisted(String className) {
        ActivityManager activityManager = (ActivityManager) this.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> serviceList = activityManager.getRunningServices(2147483647);
        if (serviceList.size() <= 0) {
            return false;
        } else {
            for (int i = 0; i < serviceList.size(); ++i) {
                ActivityManager.RunningServiceInfo serviceInfo = (ActivityManager.RunningServiceInfo) serviceList.get(i);
                ComponentName serviceName = serviceInfo.service;
                if (serviceName.getClassName().equals(className)) {
                    return true;
                }
            }
            return false;
        }
    }

    @OnMessage
    public void refuseInviteResult() {
        delayFinish();
    }

    /**
     * 停止声音和震动
     */
    private void stopMedia() {
        if (nRingTone != null) {
            nRingTone.stop();
            nRingTone = null;
        }
        VibratorUtil.VibrateCancel(GroupVideoCallActivity.this);
        nTimer.cancel();
    }

    @Override
    protected void onStop() {
        super.onStop();
        isBackFront = true;
        if (!handUpClicked && !isHandUpState) {
            overlayFloatWindows();
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (this.floatGroupVideoWindowService != null) {
            this.floatGroupVideoWindowService.closeFloatWindow();
            logger.info("onNewIntent isConnectServier:{}", isConnectService);
            if (this.isServiceExisted(FloatVideoWindowService.class.getName()) && isConnectService) {
                this.unbindService(this.mVideoServiceConnection);
            }

            kedamedia.getInstance(GroupVideoCallActivity.this, null).startVideoSources();
        }
    }

    /**
     * @param keyCode
     * @param event
     * @return
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        FlutterManager.Companion.getInstance().endVideoCalling();
        isFinish = true;
        stopMedia();
        SxtDataManager.Companion.getInstance().setCalling(false);
        FlutterManager.Companion.getInstance().updateMultiMeeting();
        logger.info("GroupVideoCallActivity onDestory");
        LegoEventBus.use("closeSelectMenbers", String.class).postValue("close");
        LegoEventBus.use("closeGroupMutiVideoCall", String.class).removeObserver(closeWindowsObserver);
        if (mutiVideoStateObserver != null) {
            LegoEventBus.use("groupMutivideoRoomStateCall", VideoChatEvent.class).removeObserver(mutiVideoStateObserver);
        }
        try {
            unbindService(mVideoServiceConnection);
        } catch (Exception e) {
            e.printStackTrace();
        }
        mViewModel.unregister();
        videoHander.removeCallbacksAndMessages(null);
    }
}
