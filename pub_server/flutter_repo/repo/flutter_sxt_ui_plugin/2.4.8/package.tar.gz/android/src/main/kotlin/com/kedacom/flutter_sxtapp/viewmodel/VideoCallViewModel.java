package com.kedacom.flutter_sxtapp.viewmodel;


import com.kedacom.basic.common.util.Optional;
import com.kedacom.uc.sdk.Abortable;
import com.kedacom.uc.sdk.AbortableFuture;
import com.kedacom.uc.sdk.RequestCallback;
import com.kedacom.uc.sdk.impl.SdkImpl;
import com.kedacom.uc.sdk.vchat.VideoTalkService;
import com.kedacom.uc.sdk.vchat.model.VideoChatRoom;

import java.util.ArrayList;
import java.util.List;

public class VideoCallViewModel extends BaseViewModel {

    private VideoTalkService nVideoService = null;
    private List<Abortable> abortables = new ArrayList<>();
    private int cameraId = 1;

    public VideoCallViewModel() {
        nVideoService = SdkImpl.getInstance().getService(VideoTalkService.class);
    }

    //切换相机
    public void switchCamera(VideoChatRoom videoChatRoom) {
        final int linkCamerId = Math.abs(cameraId - 1);
        AbortableFuture<Optional<Void>> future = nVideoService.switchCamera(videoChatRoom.getRoomId(), linkCamerId);
        future.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                showToast("摄像头切换成功");
                cameraId = linkCamerId;
            }

            @Override
            public void onFailed(Throwable throwable) {
                showToast("摄像头切换失败");

            }
        });
        abortables.add(future);
    }

    public void unregister() {
        if (abortables != null) {
            for (Abortable a : abortables) {
                a.abort();
                a = null;
            }
        }
    }
}
