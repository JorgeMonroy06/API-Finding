package com.kedacom.flutter_sxtapp.widget;

/**
 * 长按用户头像
 */
public interface OnLongClickImageCallBack {
    /**
     * @param userDomainCode 用户域Code
     * @param userName       用户名称
     * @param isGroup        是否在群组
     */
    void setEditTextContent(String userDomainCode, String userName, boolean isGroup);


}
