package com.kedacom.flutter_sxtapp.activity;


import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.Observer;

import com.kedacom.flutter_sxtapp.BR;
import com.kedacom.flutter_sxtapp.R;
import com.kedacom.flutter_sxtapp.manager.DataManager;
import com.kedacom.flutter_sxtapp.manager.SxtUIManager;
import com.kedacom.flutter_sxtapp.util.KeyboardUtil;
import com.kedacom.flutter_sxtapp.widget.CommonLoadingManager;
import com.kedacom.lego.fast.util.ToastUtil;
import com.kedacom.lego.fast.view.LegoFastActivity;
import com.kedacom.lego.fast.view.LegoFastViewModel;
import com.kedacom.lego.message.LegoEventBus;
import com.kedacom.util.SystemUtil;
import com.zackratos.ultimatebarx.ultimatebarx.UltimateBarX;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 所有Activity基类
 */
public abstract class BaseActivity<V extends ViewDataBinding, VM extends LegoFastViewModel> extends LegoFastActivity<V, VM> {

    protected Logger logger = LoggerFactory.getLogger(this.getClass());
    protected CommonLoadingManager loadingManager = new CommonLoadingManager(this);
    protected V mBinding;
    protected VM mViewModel;
    Observer<String> applyPermissionObser;


    @Override
    public int getBindingVariableId() {
        return BR.viewModel;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SxtUIManager.getInstance().addActivity(this);
        UltimateBarX.with(this)
                .transparent()
                .applyStatusBar();
        mBinding = getViewDataBinding();
        mViewModel = getViewModel();
        ActivityStack.getInstance().addVideoCallActivity(BaseActivity.this);
        addPermissionCallBack();
        // 初始化
//        initFastObserver();
    }


    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
        KeyboardUtil.hideSoftKeyboard(BaseActivity.this, findViewById(android.R.id.content));
    }

    @Override
    protected void onDestroy() {
        if (loadingManager != null) {
            loadingManager.hideWaitingDialog();
            loadingManager = null;
        }
        super.onDestroy();
        SxtUIManager.getInstance().removeActivity(this);
        if (applyPermissionObser != null) {
            LegoEventBus.use("applyPermission", String.class).removeObserver(applyPermissionObser);
        }
        ActivityStack.getInstance().findishVideoActivity(BaseActivity.this);
    }


    public void startActivity(Class<? extends Activity> activityClass) {
        Intent intent = new Intent(this, activityClass);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        logger.debug("onResume");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        logger.debug("onRestart");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        logger.debug("onNewIntent");
    }

    protected void setTitleBarHeight(View view) {
        int statusBarHeight = SystemUtil.INSTANCE.getStatusBarHeight(this);
        int topBarHeight = (int) getResources().getDimension(R.dimen.top_bar_height);
        int height = topBarHeight - statusBarHeight;
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height);
        view.setLayoutParams(layoutParams);
    }

    public void addPermissionCallBack() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (!Settings.canDrawOverlays(BaseActivity.this)) {
                DataManager.getInstance().setShowOverlayPermission(false);
            }
        }
        applyPermissionObser = new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                int stackSize = ActivityStack.getInstance().getVideoStatckCount();
                Activity tempActivity;
                if (stackSize >= 2 && !DataManager.getInstance().isnShowOverlayPermission()) {
                    DataManager.getInstance().setShowOverlayPermission(true);
                    tempActivity = ActivityStack.getInstance().getVideoActityStackes().get(stackSize - 2);
                    applyPermisionDialog(tempActivity);
                }

            }
        };
        LegoEventBus.use("applyPermission", String.class).observeForever(applyPermissionObser);
    }

    private final int nPermissionResult = 10002;

    /**
     * 双向音视频聊天时，如果浮窗权限未获取。在当前的Activity弹出来。提示用户进行选择，手动开启权限
     *
     * @param targetActivity 目标Activity
     */
    public void applyPermisionDialog(Activity targetActivity) {
        AlertDialog permissionDialog = new AlertDialog.Builder(targetActivity).setTitle("浮框权限未获取").setMessage("你的手机尚未授权应用获取弹出视窗,视讯通话最小化不能正常使用").setPositiveButton("开启", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent permissionIntent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                permissionIntent.setData(Uri.parse("package:" + getApplication().getPackageName()));
                startActivityForResult(permissionIntent, nPermissionResult);
            }
        }).show();
        permissionDialog.setCancelable(false);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        logger.debug("requestCode:{}", requestCode);
        if (requestCode == nPermissionResult) {
            LegoEventBus.use("openFloatWindows", String.class).postValue("openFloatWindows");
        }
    }

    @Override
    public void showLoading() {
        showLoading(getString(R.string.do_action_please_wait));
    }

    @Override
    public void showLoading(String message) {
        if (loadingManager == null) {
            return;
        }
        loadingManager.showWaitingDialog(message);
    }

    @Override
    public void hideLoading() {
        if (loadingManager == null) {
            return;
        }
        loadingManager.hideWaitingDialog();
    }

    public void showLoadingNotCancelable(String message) {
        if (loadingManager == null) {
            return;
        }
        loadingManager.showWaitingDialog(message, false);
    }

    @Override
    public void showToast(String message) {
        ToastUtil.showDefaultToast(message);
    }

    @Override
    public void showToast(String message, int toastType) {
        ToastUtil.showDefaultToast(message, toastType);
    }
}
