package com.kedacom.flutter_sxt_ui_plugin

import androidx.annotation.NonNull
import com.kedacom.flutter_sxtapp.manager.FlutterManager
import io.flutter.embedding.engine.plugins.FlutterPlugin

class FlutterSxtUIPlugin : FlutterPlugin {


    override fun onAttachedToEngine(@NonNull flutterPluginBinding: FlutterPlugin.FlutterPluginBinding) {
        FlutterManager.instance.bindMethodChannel(flutterPluginBinding)
    }

    override fun onDetachedFromEngine(@NonNull binding: FlutterPlugin.FlutterPluginBinding) {
        FlutterManager.instance.dispose()

    }
}
