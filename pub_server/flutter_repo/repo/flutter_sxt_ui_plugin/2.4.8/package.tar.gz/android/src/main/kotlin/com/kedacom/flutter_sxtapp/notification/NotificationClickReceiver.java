package com.kedacom.flutter_sxtapp.notification;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.kedacom.flutter_sxtapp.Constants;
import com.kedacom.flutter_sxtapp.activity.GroupVideoCallActivity;
import com.kedacom.flutter_sxtapp.activity.MeetingActivity;
import com.kedacom.flutter_sxtapp.activity.VideoCallActivity;
import com.kedacom.flutter_sxtapp.manager.FlutterManager;
import com.kedacom.flutter_sxtapp.manager.SxtUIManager;
import com.kedacom.sxt_flutter_plugin.Constant;
import com.kedacom.uc.sdk.generic.model.SessionEntity;
import com.kedacom.util.LegoLog;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 维修点击通知
 */

public class NotificationClickReceiver extends BroadcastReceiver {

    private Logger logger = LoggerFactory.getLogger(NotificationClickReceiver.class);

    private void onNoticeClick(Context context, Intent pendingIntent) {
        int turnFlag = pendingIntent.getIntExtra("turnFlag", -1);
        switch (turnFlag) {
            case Constants.PUSH_SOURCE_MEETING_INVITING:
                logger.info("Constants.PUSH_SOURCE_MEETING_INVITING");
                String linkId = pendingIntent.getStringExtra(NotificationDict.NOTICE_CONTENT);
                boolean isLinkId = pendingIntent.getBooleanExtra(NotificationDict.NOTICE_ISLINKID, false);

                Intent intent = new Intent(SxtUIManager.getInstance().getCurrentActivity(), MeetingActivity.class);
                intent.putExtra("linkId", linkId);
                intent.putExtra("isLinkId", isLinkId);
                SxtUIManager.getInstance().getCurrentActivity().startActivity(intent);
                break;
            case Constants.PUSH_GROUP_VIDEO_CALL_INVITING:
                logger.info("Constants.PUSH_GROUP_VIDEO_CALL_INVITING");
                Intent intent2 = new Intent(SxtUIManager.getInstance().getCurrentActivity(), GroupVideoCallActivity.class);
                intent2.putExtra("event", pendingIntent.getSerializableExtra("event"));
                intent2.putExtra("isSender", pendingIntent.getBooleanExtra("isSender", false));
                intent2.putExtra("isVideo", pendingIntent.getBooleanExtra("isVideo", false));
                intent2.putExtra("codeForDomain", pendingIntent.getStringExtra("codeForDomain"));
                intent2.putExtra("groupCode", pendingIntent.getStringExtra("groupCode"));
                intent2.putExtra("VideoChatRoom", pendingIntent.getSerializableExtra("VideoChatRoom"));
                SxtUIManager.getInstance().getCurrentActivity().startActivity(intent2);

                NotificationManager mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                mNotificationManager.cancel(NotificationHelper.VIDEO_CALL_NOTIFICATION_ID.hashCode());
                break;
            case Constants.PUSH_VIDEO_CALL_INVITING:
                logger.info("Constants.PUSH_VIDEO_CALL_INVITING");
                Intent intent3 = new Intent(SxtUIManager.getInstance().getCurrentActivity(), VideoCallActivity.class);
                intent3.putExtra("callType", pendingIntent.getStringExtra("callType"));
                intent3.putExtra("userCodeForDomain", pendingIntent.getStringExtra("userCodeForDomain"));
                intent3.putExtra("userCode", pendingIntent.getStringExtra("userCode"));
                intent3.putExtra("isSender", pendingIntent.getBooleanExtra("isSender", false));
                intent3.putExtra("videoRoom", pendingIntent.getSerializableExtra("videoRoom"));
                intent3.putExtra("meetingId", pendingIntent.getStringExtra("meetingId"));
                SxtUIManager.getInstance().getCurrentActivity().startActivity(intent3);

                NotificationManager mNotificationManager2 = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                mNotificationManager2.cancel(NotificationHelper.VIDEO_CALL_NOTIFICATION_ID.hashCode());
                break;
            case Constants.PUSH_MESSAGE_CLICK:
                SessionEntity sessionEntity = (SessionEntity) pendingIntent.getSerializableExtra("sessionEntity");
                com.kedacom.sxt_flutter_plugin.model.message.SessionEntity newEntity = new com.kedacom.sxt_flutter_plugin.model.message.SessionEntity();
                newEntity.setSessionType(Constant.INSTANCE.getSDK_TO_FLUTTER_SESSION_TYPE_MAP().get(sessionEntity.getSessionType()));
                newEntity.setCode(sessionEntity.getCodeForDomain());
                FlutterManager.Companion.getInstance().goToChatPage(newEntity);
                break;
            default:
                break;
        }
    }


    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        LegoLog.d("action:" + action);
        if (!TextUtils.isEmpty(action)
                && NotificationDict.NOTICE_CLICK.equals(action)
                && context.getPackageName().equals(intent.getStringExtra(NotificationDict.PACKAGE_NAME))) {
            onNoticeClick(context, intent);
        }
    }
}
