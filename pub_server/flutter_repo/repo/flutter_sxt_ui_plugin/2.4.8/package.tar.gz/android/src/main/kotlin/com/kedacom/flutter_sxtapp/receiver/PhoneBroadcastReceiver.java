package com.kedacom.flutter_sxtapp.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;

import com.kedacom.flutter_sxtapp.util.NetUtil;
import com.kedacom.lego.message.LegoEventBus;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PhoneBroadcastReceiver extends BroadcastReceiver {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public void onReceive(Context context, Intent intent) {
        logger.info("PhoneBroadcastReceiver onReceive");
        TelephonyManager nTelMager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        ConnectivityManager conManger = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = conManger.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        switch (nTelMager.getCallState()) {
            //来电
            case TelephonyManager.CALL_STATE_RINGING:
                logger.info("PhoneBroadcastReceiver TelephonyManager.CALL_STATE_RINGING");
                LegoEventBus.use("TelephonyManager", Integer.class).postValue(TelephonyManager.CALL_STATE_RINGING);
                break;
            //响铃
            case TelephonyManager.CALL_STATE_OFFHOOK:
                logger.info("PhoneBroadcastReceiver TelephonyManager.CALL_STATE_OFFHOOK");
                LegoEventBus.use("TelephonyManager", Integer.class).postValue(TelephonyManager.CALL_STATE_OFFHOOK);
                break;
            //挂断
            case TelephonyManager.CALL_STATE_IDLE:
                logger.info("PhoneBroadcastReceiver TelephonyManager.CALL_STATE_IDLE");
                LegoEventBus.use("TelephonyManager", Integer.class).postValue(TelephonyManager.CALL_STATE_IDLE);
                break;
        }
    }


    private void endCall(NetworkInfo networkInfo, Context context) {
        if (!NetUtil.getNetworkTypeWifi(context) && (networkInfo == null || (networkInfo != null && !networkInfo.isConnected()))) {
            logger.info("PhoneBroadcastReceiver endCall 非 WIFI網絡情況下PhoneBroadcastReceiver 電話來了 被掛斷");
            LegoEventBus.use("closeVideoCall", String.class).postValue("phoneInterruption");
        } else {
            logger.info("PhoneBroadcastReceiver endCall WIFI網絡情況下PhoneBroadcastReceiver 電話來了不掛斷");
        }
    }
}
