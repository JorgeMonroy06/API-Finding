package com.kedacom.flutter_sxtapp.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.kedacom.basic.common.resource.audio.AudioContext;
import com.kedacom.basic.common.resource.audio.AudioPlayType;
import com.kedacom.basic.common.resource.util.VibratorUtil;
import com.kedacom.basic.common.util.Optional;
import com.kedacom.basic.common.util.StringUtil;
import com.kedacom.basic.media.exception.AVRecorderException;
import com.kedacom.flutter_sxtapp.R;
import com.kedacom.lego.fast.util.ToastUtil;
import com.kedacom.uc.common.rx.ScheduleTransformer;
import com.kedacom.uc.sdk.bean.basic.ResultCode;
import com.kedacom.uc.sdk.exception.ResponseException;
import com.kedacom.uc.sdk.generic.model.SessionIdentity;
import com.kedacom.uc.sdk.impl.SdkImpl;
import com.kedacom.uc.sdk.ptt.RxPttTalkService;
import com.kedacom.uc.sdk.ptt.model.AudioChatRoom;
import com.kedacom.uc.sdk.rx.ResponseFunc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Semaphore;

import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;

/**
 * PTT对讲的广播接收器
 */
public class PttAudioReceiver extends BroadcastReceiver {

    private Logger logger = LoggerFactory.getLogger(PttAudioReceiver.class);
    private Context appContext;                                         // 上下文
    private RxPttTalkService talkService;                               // 对讲服务
    private LocalBroadcastManager lbManager;                            // 本地广播管理
    private AudioContext audioContext;
    private Semaphore roomSem = new Semaphore(1);                // 规避开始讲话和结束讲话时间间隔果断，导致结束讲话比开始讲话先获取房间的问题

    public PttAudioReceiver(Context context) {
        appContext = context;
        talkService = SdkImpl.getInstance().getService(RxPttTalkService.class);
        lbManager = LocalBroadcastManager.getInstance(context);
        audioContext = AudioContext.getInstance(context);
    }

    /**
     * 注册广播接收器
     */
    public void registerPttAudioReceiver() {
        logger.debug("registerPttAudioReceiver");
        IntentFilter iFilter = new IntentFilter();
        iFilter.addAction(BroadcastAction.START_SPEAK.getAction());
        iFilter.addAction(BroadcastAction.END_SPEAK.getAction());
        // 注册广播
        lbManager.registerReceiver(this, iFilter);
    }

    /**
     * 取消注册广播接收器
     */
    public void unregisterPttAudioReceiver() {
        logger.debug("unregisterPttAudioReceiver");
        // 取消广播注册
        lbManager.unregisterReceiver(this);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        logger.debug("receive broadcast : {}", action);
        if (StringUtil.isEquals(action, BroadcastAction.START_SPEAK.getAction())) {
            // 开始讲话广播
            SessionIdentity talker = (SessionIdentity) intent.getSerializableExtra("talker");
            startSpeak(talker);
        } else if (StringUtil.isEquals(action, BroadcastAction.END_SPEAK.getAction())) {
            // 结束讲话广播
            SessionIdentity talker = (SessionIdentity) intent.getSerializableExtra("talker");
            stopSpeak(talker);
        }
    }

    /**
     * 停止讲话
     *
     * @param talker 会话对象
     */
    private void stopSpeak(SessionIdentity talker) {
        logger.debug("stop speak in receiver talker : {}", talker);
        if (null != talkService && null != talker) {
            logger.debug("###############################stop speak ###########################");
            try {
                roomSem.acquire();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            talkService.rxGetRoom(talker.getCodeForDomain(), talker.getType())
                    .onErrorResumeNext(new ResponseFunc<Optional<AudioChatRoom>>() {
                        @Override
                        public Observable<Optional<AudioChatRoom>> apply(Throwable throwable) throws Exception {
                            roomSem.release();
                            return super.apply(throwable);
                        }
                    })
                    .flatMap(new Function<Optional<AudioChatRoom>, ObservableSource<Optional<Void>>>() {
                        @Override
                        public ObservableSource<Optional<Void>> apply(Optional<AudioChatRoom> audioChatRoomOptional) throws Exception {
                            roomSem.release();
                            if (audioChatRoomOptional.isPresent()) {
                                return talkService.rxStopSpeak(audioChatRoomOptional.get().getRoomCode());
                            }
                            return Observable.error(new ResponseException(ResultCode.L_FAILURE));
                        }
                    })
                    .onErrorResumeNext(new ResponseFunc<Optional<Void>>())
                    .compose(ScheduleTransformer.<Optional<Void>>get())
                    .subscribe(new Observer<Optional<Void>>() {
                        @Override
                        public void onSubscribe(Disposable d) {

                        }

                        @Override
                        public void onNext(Optional<Void> voidOptional) {
                            logger.debug("stop speak success .");
                            sendLocalBroadCast(BroadcastAction.END_SPEAK_SUCCESS, null);
                        }

                        @Override
                        public void onError(Throwable e) {
                            logger.debug("stop speak faile : {}", e);
                            Bundle bundle = new Bundle();
                            bundle.putSerializable("errInfo", e);
                            sendLocalBroadCast(BroadcastAction.END_SPEAK_ERR, bundle);
                        }

                        @Override
                        public void onComplete() {

                        }
                    });
        }
    }

    /**
     * 开始讲话
     *
     * @param talker
     */
    private void startSpeak(SessionIdentity talker) {
        logger.debug("start speak in receiver : {}", talker);
        if (null == talker || StringUtil.isEmpty(talker.getCode())) {
            ToastUtil.showDefaultToast(appContext.getString(R.string.active_group_user_is_null));
            return;
        }
        if (null != talkService && null != talker) {
            logger.debug("******************************start speak *************************");
            try {
                roomSem.acquire();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            talkService.rxGetRoom(talker.getCodeForDomain(), talker.getType())
                    .onErrorResumeNext(new ResponseFunc<Optional<AudioChatRoom>>() {
                        @Override
                        public Observable<Optional<AudioChatRoom>> apply(Throwable throwable) throws Exception {
                            roomSem.release();
                            return super.apply(throwable);
                        }
                    })
                    .flatMap(new Function<Optional<AudioChatRoom>, ObservableSource<Optional<Void>>>() {
                        @Override
                        public ObservableSource<Optional<Void>> apply(Optional<AudioChatRoom> audioChatRoomOptional) throws Exception {
                            logger.debug("get speak room is null : {}", audioChatRoomOptional.isPresent());
                            roomSem.release();
                            if (audioChatRoomOptional.isPresent()) {
                                return talkService.rxStartSpeak(audioChatRoomOptional.get().getRoomCode());
                            }
                            return Observable.error(new ResponseException(ResultCode.APPLY_AUDIO_FAILURE));
                        }
                    })
                    .onErrorResumeNext(new ResponseFunc<Optional<Void>>())
                    .compose(ScheduleTransformer.<Optional<Void>>get())
                    .subscribe(new Observer<Optional<Void>>() {
                        @Override
                        public void onSubscribe(Disposable d) {

                        }

                        @Override
                        public void onNext(Optional<Void> voidOptional) {
                            //说话成功声音
                            audioContext.play(R.raw.press_tone_success_flutter, 1, AudioPlayType.MP);
                            sendLocalBroadCast(BroadcastAction.SPEAK_SUCCESS, null);
                        }

                        @Override
                        public void onError(Throwable e) {
                            //说话失败声音
                            VibratorUtil.vibrate(appContext, 200);
                            audioContext.play(R.raw.press_tone_fail_flutter, 1, AudioPlayType.MP);

                            if (e instanceof AVRecorderException) {
                                ToastUtil.showDefaultToast(appContext.getString(R.string.get_audio_failed));
                            }
                            Bundle bundle = new Bundle();
                            bundle.putSerializable("errInfo", e);
                            sendLocalBroadCast(BroadcastAction.SPEAK_FAIL, bundle);
                        }

                        @Override
                        public void onComplete() {

                        }
                    });
        }
    }

    /**
     * 发送应用内广播
     */
    private void sendLocalBroadCast(BroadcastAction action, Bundle bundle) {
        Intent intent = new Intent();
        intent.setAction(action.getAction());
        if (null != bundle) {
            intent.putExtras(bundle);
        }
        lbManager.sendBroadcast(intent);
    }
}
