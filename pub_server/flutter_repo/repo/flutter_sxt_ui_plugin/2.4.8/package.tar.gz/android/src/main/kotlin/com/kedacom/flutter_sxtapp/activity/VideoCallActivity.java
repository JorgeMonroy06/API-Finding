package com.kedacom.flutter_sxtapp.activity;

import android.app.Activity;
import android.app.ActivityManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothHeadset;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.transition.TransitionManager;

import com.bumptech.glide.Glide;
import com.kedacom.basic.common.util.Optional;
import com.kedacom.basic.common.util.StringUtil;
import com.kedacom.flutter_sxtapp.Constants;
import com.kedacom.flutter_sxtapp.R;
import com.kedacom.flutter_sxtapp.databinding.ActivityVideoCallFlutterBinding;
import com.kedacom.flutter_sxtapp.manager.FlutterDataListener;
import com.kedacom.flutter_sxtapp.manager.FlutterManager;
import com.kedacom.flutter_sxtapp.manager.SxtDataLoader;
import com.kedacom.flutter_sxtapp.model.Contact;
import com.kedacom.flutter_sxtapp.model.VideoParam;
import com.kedacom.flutter_sxtapp.receiver.PowerKeyObserver;
import com.kedacom.flutter_sxtapp.service.FloatVideoWindowService;
import com.kedacom.flutter_sxtapp.util.ApkInfoUtils;
import com.kedacom.flutter_sxtapp.util.ClickEventUtils;
import com.kedacom.flutter_sxtapp.util.FastBlur;
import com.kedacom.flutter_sxtapp.util.FileUtils;
import com.kedacom.flutter_sxtapp.util.NetUtil;
import com.kedacom.flutter_sxtapp.util.ScreenUtils;
import com.kedacom.flutter_sxtapp.util.VibratorUtil;
import com.kedacom.flutter_sxtapp.viewmodel.VideoCallViewModel;
import com.kedacom.flutter_sxtapp.widget.BlurTransformation;
import com.kedacom.flutter_sxtapp.widget.SelectImageView;
import com.kedacom.lego.annotation.Extra;
import com.kedacom.lego.annotation.ViewModel;
import com.kedacom.lego.fast.util.ToastUtil;
import com.kedacom.lego.message.LegoEventBus;
import com.kedacom.lego.util.LegoLog;
import com.kedacom.sxt_flutter_plugin.manager.SxtDataManager;
import com.kedacom.uc.ptt.video.media.DefaultCameraCapture;
import com.kedacom.uc.ptt.video.media.DefaultVideoRender;
import com.kedacom.uc.sdk.Abortable;
import com.kedacom.uc.sdk.AbortableFuture;
import com.kedacom.uc.sdk.RequestCallback;
import com.kedacom.uc.sdk.auth.model.IAccount;
import com.kedacom.uc.sdk.bean.basic.ResultCode;
import com.kedacom.uc.sdk.exception.ResponseException;
import com.kedacom.uc.sdk.generic.attachment.PromptTAttachment;
import com.kedacom.uc.sdk.generic.constant.PromptType;
import com.kedacom.uc.sdk.generic.constant.SessionType;
import com.kedacom.uc.sdk.impl.SdkImpl;
import com.kedacom.uc.sdk.message.MessageService;
import com.kedacom.uc.sdk.vchat.VideoTalkService;
import com.kedacom.uc.sdk.vchat.constant.VideoChatEventType;
import com.kedacom.uc.sdk.vchat.model.VideoChatRoom;
import com.kedacom.webrtc.RendererCommon;
import com.kedacom.webrtc.SurfaceViewRenderer;
import com.kedacom.webrtcsdk.component.Constantsdef;
import com.kedacom.webrtcsdk.sdkmanager.kedamedia;
import com.kedacom.webrtcsdk.struct.SsrcReport;

import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import static android.util.TypedValue.COMPLEX_UNIT_SP;


@ViewModel(VideoCallViewModel.class)
public class VideoCallActivity extends BaseActivity<ActivityVideoCallFlutterBinding, VideoCallViewModel> {

    protected Logger logger = LoggerFactory.getLogger("SmartCity" + this.getClass());
    private ConstraintLayout layout_main;
    private ConstraintLayout layout_bottom;
    private RelativeLayout selfView;
    private RelativeLayout otherView;
    /**
     * 本地采集的ViewRender
     */
    private SurfaceViewRenderer nSelfSurfaceView;
    /**
     * 大屏回显的ViewRender
     */
    private SurfaceViewRenderer nOtherSurfaceView;
    /**
     * 获取本地采集和大屏回显的view句柄
     */
    private DefaultVideoRender videoRender;
    private DefaultCameraCapture videoCapture;
    private boolean isMute = false;
    @Extra("userCode")
    private String userCode;
    @Extra("usreName")
    private String userName;//用户昵称
    private String userIconUrl;//用户头像url
    @Extra("userCodeForDomain")
    private String talkerCodeForDomain;
    @Extra("meetingId")
    private String meetingId;
    @Extra("isStart")
    private boolean isStart;

    private SessionType talkerType = SessionType.USER;
    /**
     * 视频聊天房间
     */
    private VideoChatRoom videoRoom;
    /**
     * 最下方的按钮，静音 挂断 拒绝，切换摄像头，头像，缩小
     */
    private ImageView iv_suoxiao;

    private SelectImageView iv_right, iv_left;

    private SelectImageView iv_mute_land, iv_hand_free_land;
    /**
     * 最下方的按钮，静音 挂断 拒绝，切换摄像头， 名称
     */
    private TextView tv_right, tv_middle, tv_left, tv_name, tv_time, tv_state, tv_time_land;
    /**
     * 切换大小摄像头布局，中间布局，
     */
    private View layout_switch, layout_left, layout_middle, layout_right;
    /**
     * 头像布局
     */
    private ConstraintLayout layout_head;//头像姓名接听状态布局
    /**
     * 约束限定
     */
    private ConstraintSet audioSet, videoSet;//语音通话的布局和视频通话的布局

    private VideoTalkService nVideoService = SdkImpl.getInstance().getService(VideoTalkService.class);
    /**
     * 话筒管理器
     */
    private AudioManager audioManager = null;
    private boolean isClicked = false;
    private boolean isHeadset = false;
    private long startTime = 0;//通话时长
    /**
     * RECEIVE_AUDIO 接收音频聊天
     * RECEIVE_VEDIO  接收视频聊天
     * SENDER_AUDIO  发送音频聊天
     * SENDER_VEDIO  发送视频聊天
     */
    private final int RECEIVE_AUDIO = 1, RECEIVE_VEDIO = 2, SENDER_AUDIO = 3, SENDER_VEDIO = 4;//各个状态决定视图：RECEIVE_AUDIO：语音通话接收者，视频通话接收者，语音通话发起者，视频通话发起者
    /**
     * 用来记录上面的几个状态
     */
    private int callType = 0;
    /**
     * 记录通话状态.默认等待状态
     */
    private int conversationType = 1;//
    /**
     * 通话状态：`1.等待， 2. 通话中
     */
    private final int WAITING = 1, CALLING = 2;
    private MediaPlayer nMediaPlayer;
    private int cameraId = 1;

    /**
     * 切换摄像头，标识
     */
    private boolean isShowCloseCamera = true;

    /**
     * 本地进行计时
     */
    private Timer nTimer = new Timer();
    /**
     * 获取铃声
     */
    private Ringtone nRingTone = null;
    private Abortable nAble = null;

    /**
     * 开启缩小服务匡
     */
    private boolean isConnectService = false;
    private boolean isInVideoRoom = false;
    private String nFirstcallTypeStr = Constants.VIDEOCHAT;
    private boolean isFirstInitVideoUpdate = true;
    AbortableFuture getRoomFuture;
    /**
     * 断网重连后重新加入音视频
     */
    Observer<String> videoTalkJoinObserver;
    /**
     * 是否关闭界面 。聊天结束
     */
    Observer<String> closeVideoCallObserver;
    /**
     * 第一帧数据的调整
     */
    Observer<VideoParam> adjustVideoParamObserver;
    /**
     * ICE连接状态的
     */
    private Observer<Integer> iceConnectStateObserver;
    private Observer<Integer> telephonyManagerObserver;
    private Observer<VideoChatEventType> videoStateObserver;
    /**
     * 打开悬浮框的通知
     */
    private Observer<String> openFloatWindowsServiceObserver;
    /**
     * ssrc码流信息的打印
     */
    private Observer<SsrcReport> ssrcReportObserver;
    /***
     * 悬浮框服务
     */
    private FloatVideoWindowService floatVideoWindowService;

    /**
     * 检测是否存在后台
     */
    private boolean isBackFront = false;

    /**
     * 检测是否有悬浮框权限
     */
    private boolean nOverlyPermission;

    private String projectFlag;
    /**
     * 头像与右边的间距
     */
    private int iconRightSpace = 10;


    private PowerKeyObserver nPowerKeyObserver;

    private AudioManager nAudioManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        logger.info("VideoCallActivity onCreate");
        FlutterManager.Companion.getInstance().startVideoCalling();
        Intent intent = getIntent();
        loginValite();
        nAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (intent != null) {
            boolean thirdForm = intent.getBooleanExtra(Constants.THIRD_PLATFORM, false);
            if (thirdForm) {
                userCode = intent.getStringExtra("dstNum");
                logger.info("policNum is  ", userCode);
                if (!StringUtil.isEmpty(userCode)) {
                    initThirdPlatForm(userCode);
                }
            } else {
                initVideoCallData();
            }
        }

    }

    @Override
    public int getContentViewId() {
        return R.layout.activity_video_call_flutter;
    }


    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        logger.info("VideoCallActivity onConfigurationChanged");
        if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            getViewDataBinding().llLand.setVisibility(View.GONE);
            tv_time_land.setVisibility(View.GONE);

            getViewDataBinding().layoutSwich.setVisibility(View.VISIBLE);
            tv_time.setVisibility(View.VISIBLE);
            getViewDataBinding().viewBottom.setVisibility(View.VISIBLE);
        } else if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            getViewDataBinding().llLand.setVisibility(View.VISIBLE);
            tv_time_land.setVisibility(View.VISIBLE);

            getViewDataBinding().layoutSwich.setVisibility(View.GONE);
            tv_time.setVisibility(View.GONE);
            getViewDataBinding().viewBottom.setVisibility(View.GONE);
        }
    }

    /**
     * 监听电源键
     */
    private void initPowerKeyListener() {
        nPowerKeyObserver = new PowerKeyObserver(VideoCallActivity.this);
        nPowerKeyObserver.setHomeKeyListener(new PowerKeyObserver.OnPowerKeyListener() {
            @Override
            public void onPowerKeyPressed() {
                stopMusic();
            }
        });
        nPowerKeyObserver.startListen();

    }

    private void loginValite() {
        IAccount iAccount = SdkImpl.getInstance().getUserSession().orNull();
        if (null == iAccount || (iAccount != null && !iAccount.isOnline())) {
            showToast(getString(R.string.login_sxt_first));
        }
    }

    private void initVideoCallData() {
        initPostData();
        initAudio();
        initView();
        initVideoRoom();
        SxtDataManager.Companion.getInstance().setCalling(true);//是否进行双向视频。用来判断不可进行ptt对讲
        logger.debug("isVideoCalling{}", SxtDataManager.Companion.getInstance().isCalling());
        acceptVideoParamEvetBus();
        keyBoardScreen();
        nRingTone = initRingtone(VideoCallActivity.this);
        closeVideCallEventBus();
        addVideoTalkJoinObserver();
        addTelephonyManagerObserver();
        iceConnectState();
        videoRoomSateCallBack();
        checkOveralayPermission();
        openFloatWindows();
        ssrcReport();

        initPowerKeyListener();
    }


    ServiceConnection mVideoServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            logger.info("FloatVideoWindowService onServiceConnected conversationType {} , startTime {}", conversationType, startTime);
            FloatVideoWindowService.MyBinder binder = (FloatVideoWindowService.MyBinder) service;
            floatVideoWindowService = binder.getService();
            if (conversationType == 1) {
                if (VideoCallActivity.this.startTime == 0L) {
                    VideoCallActivity.this.floatVideoWindowService.setTime(getString(R.string.wait_answer));
                } else {
                    VideoCallActivity.this.floatVideoWindowService.setTime(VideoCallActivity.this.getFormatTime(VideoCallActivity.this.startTime));
                }
                VideoCallActivity.this.floatVideoWindowService.switchToAudio();
            } else if (VideoCallActivity.this.callType != 4 && VideoCallActivity.this.callType != 2) {
                if (VideoCallActivity.this.startTime == 0L) {
                    VideoCallActivity.this.floatVideoWindowService.setTime(getString(R.string.wait_answer));
                } else {
                    VideoCallActivity.this.floatVideoWindowService.setTime(VideoCallActivity.this.getFormatTime(VideoCallActivity.this.startTime));
                }
            } else if (VideoCallActivity.this.layout_main != null) {
                otherView.removeAllViews();
                selfView.removeAllViews();
                VideoCallActivity.this.floatVideoWindowService.initVideoWindow(nSelfSurfaceView, nOtherSurfaceView);
            }

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            logger.info("FloatVideoWindowService onServiceDisconnected ");
        }
    };

    /**
     * 锁屏显示 设置窗体的样式
     */
    private void keyBoardScreen() {
        final Window win = getWindow();
        win.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON);

    }

    /**
     * 判断当前应用内部是否拥有悬浮框权限
     */
    private void checkOveralayPermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (Settings.canDrawOverlays(VideoCallActivity.this)) {
                nOverlyPermission = true;
            } else {
                nOverlyPermission = false;
            }
        }
    }

    //外部事件收到通知 关闭界面
    public void closeVideCallEventBus() {
        closeVideoCallObserver = new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                logger.info("closeVideCallEventBus current videoRoom:{},s:{}", videoRoom, s);
                if (StringUtil.isEquals(s, "phoneInterruption")) {
                    logger.info(getString(R.string.call_interrupt_re_dial));

                    PromptTAttachment attachment = new PromptTAttachment();
                    attachment.setMsgType(PromptType.VIDEO.getValue());
                    attachment.setMsgCatg(PromptType.VIDEO.getValue());
                    attachment.setContent("重新拨打");
                    MessageService nMsgService = SdkImpl.getInstance().getService(MessageService.class);
                    nMsgService.sendMsg(userCode, SessionType.USER, (PromptTAttachment) attachment).setCallback(new RequestCallback<Optional<Void>>() {
                        @Override
                        public void onSuccess(Optional<Void> voidOptional) {

                        }

                        @Override
                        public void onFailed(Throwable throwable) {

                        }
                    });
                }
                if (videoRoom == null || (videoRoom != null && StringUtil.isEquals(s, videoRoom.getRoomId())) || StringUtil.isEquals("disconnect", s) || StringUtil.isEquals(s, "phoneInterruption")) {
                    if (!isFinishing()) {
                        logger.info("callFinish closeVideoCallEventBus {}", s);

                        if (conversationType == WAITING) {
                            mBinding.llInviteType.setVisibility(View.VISIBLE);
                            mBinding.tvInviteType.setText("已挂断");
                        } else if (conversationType == CALLING) {
                            mBinding.llInviteType.setVisibility(View.VISIBLE);
                            mBinding.tvInviteType.setText("通话结束");
                        }
                        delayFinish("");
                    }
                }
            }
        };
        LegoEventBus.use("closeVideoCall", String.class).observeForever(closeVideoCallObserver);
    }

    private void addVideoTalkJoinObserver() {
        videoTalkJoinObserver = new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                logger.info("VideoCallActivity VIDEO_TALK_JOIN_SUCCESS current videoRoom:{},s:{}", videoRoom, s);
                if (isMute) {
                    isMute = false;
                    setCloseVoice();
                }
            }
        };
        LegoEventBus.use("VIDEO_TALK_JOIN_SUCCESS", String.class).observeForever(videoTalkJoinObserver);
    }

    private void addTelephonyManagerObserver() {
        telephonyManagerObserver = new Observer<Integer>() {
            @Override
            public void onChanged(@Nullable Integer s) {
                logger.info("VideoCallActivity TelephonyManager  onChanged");
                ConnectivityManager conManger = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo networkInfo = conManger.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
                logger.info("VideoCallActivity addTelephonyManagerObserver state :{}", s);
                switch (s) {
                    //来电
                    case TelephonyManager.CALL_STATE_RINGING:
                        logger.info("VideoCallActivity TelephonyManager.CALL_STATE_RINGING");
                        if (!NetUtil.getNetworkTypeWifi(VideoCallActivity.this) && (networkInfo == null || (networkInfo != null && !networkInfo.isConnected()))) {
                            logger.info("VideoCallActivity endCall 非 WIFI網絡情況下PhoneBroadcastReceiver 電話來了 被掛斷");
                            callFinish("");
                        } else {
                            if (!isServiceExisted(FloatVideoWindowService.class.getName()) && isConnectService && !ApkInfoUtils.isForeground(VideoCallActivity.this, VideoCallActivity.class.getName())) {
                                logger.info("FloatVideoWindowService overlayFloatWindows unbindService");
                                openFloatWindowsView();
                            }
                            logger.info("VideoCallActivity endCall WIFI網絡情況下PhoneBroadcastReceiver 電話來了不掛斷");
                        }
//                        isMute = false;
//                        setCloseVoice();
                        break;
                    //响铃
                    case TelephonyManager.CALL_STATE_OFFHOOK:
                        logger.info("VideoCallActivity TelephonyManager.CALL_STATE_OFFHOOK");
                        if (!NetUtil.getNetworkTypeWifi(VideoCallActivity.this) && (networkInfo == null || (networkInfo != null && !networkInfo.isConnected()))) {
                            logger.info("VideoCallActivity endCall 非 WIFI網絡情況下PhoneBroadcastReceiver 電話來了 被掛斷");
                            callFinish("");
                        } else {
                            if (!isServiceExisted(FloatVideoWindowService.class.getName()) && isConnectService && !ApkInfoUtils.isForeground(VideoCallActivity.this, VideoCallActivity.class.getName())) {
                                logger.info("FloatVideoWindowService overlayFloatWindows unbindService");
                                openFloatWindowsView();
                            }
                            logger.info("VideoCallActivity endCall WIFI網絡情況下PhoneBroadcastReceiver 電話來了不掛斷");
                        }
                        break;
                    //挂断
                    case TelephonyManager.CALL_STATE_IDLE:
                        logger.info("VideoCallActivity TelephonyManager.CALL_STATE_IDLE");
                        if (isSpeakOn) {
                            changeToSpeaker();
                        } else {
                            changeToReceiver();
                        }
                        if (!NetUtil.getNetworkTypeWifi(VideoCallActivity.this) && (networkInfo == null || (networkInfo != null && !networkInfo.isConnected()))) {
                        } else {
                            if (!isServiceExisted(FloatVideoWindowService.class.getName()) && isConnectService && !ApkInfoUtils.isForeground(VideoCallActivity.this, VideoCallActivity.class.getName())) {
                                logger.info("VideoCallActivity CALL_STATE_IDLE FloatVideoWindowService overlayFloatWindows ");
                                openFloatWindowsView();
                            }
                        }
//                        isMute = true;
//                        setCloseVoice();
                        break;
                }
            }
        };
        LegoEventBus.use("TelephonyManager", Integer.class).observeForever(telephonyManagerObserver);
    }

    /**
     * 开启悬浮框
     */
    private void openFloatWindows() {
        openFloatWindowsServiceObserver = new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                logger.info("FloatVideoWindowService openFloatWindowsServiceObserver ");
                overlayFloatWindows();
            }
        };
        LegoEventBus.use("openFloatWindows", String.class).observeForever(openFloatWindowsServiceObserver);
    }

    /**
     * 打印码流信息 在屏幕上
     */
    private void ssrcReport() {
        ssrcReportObserver = new Observer<SsrcReport>() {
            @Override
            public void onChanged(@Nullable SsrcReport ssrcReport) {
                mBinding.setSsrcReport(ssrcReport);

            }
        };
        LegoEventBus.use("SsrcReport", SsrcReport.class).observeForever(ssrcReportObserver);
    }

    private void initAudio() {
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        logger.info("VideoCallActivity setMode 111 ");
        audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
        registerHeadsetPlugReceiver();
    }

    //第一帧码流回调分辨率 主要是针对 手机和web 执法记录仪 入会调度
    private void acceptVideoParamEvetBus() {
        adjustVideoParamObserver = new Observer<VideoParam>() {
            @Override
            public void onChanged(@Nullable VideoParam videoParam) {
                logger.debug("acceptVideoParamEvetBus {}", videoParam);
                listenResolutionChangeResult(videoParam);
            }
        };
        LegoEventBus.use("videoParam", VideoParam.class).observeForever(adjustVideoParamObserver);
    }

    /**
     * 房间状态的的变化
     */
    private void videoRoomSateCallBack() {

        videoStateObserver = new Observer<VideoChatEventType>() {
            @Override
            public void onChanged(@Nullable VideoChatEventType eventType) {
                switch (eventType) {
                    case ADJUST_VIDEO_QUALITY:
                    case VIDEO_RECOVERY_START:
                    case VIDEO_RECOVERY_SUCCESS:
                        break;
                    case VIDEO_RECOVERY_TIMEOUT:
                        ToastUtil.showDefaultToast("网络异常，通话重连失败...");
                        hangUp();
                        break;
                    case CALLEE_ACK_AGREE:
                        conversationType = CALLING;
                        updateUI();
                        startTime();
                        if (!isHeadset) {
                            initSpeaker();
                        } else {
                            iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                            iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                        }
                        if (layout_main != null && floatVideoWindowService != null) {
                            floatVideoWindowService.initVideoWindow(nSelfSurfaceView, nOtherSurfaceView);
                            floatVideoWindowService.switchToVideo();
                        }
                        break;
                    case CALLEE_ACK_REJECT:
                    case VIDEO_ALONE_TERMINATE:
                    case CALLEE_ACK_CANCEL:
                        //    finish();
                        break;
                    case CALLEE_OFFLINE:
                        logger.debug(getString(R.string.opposite_offline));
                        break;
                    case CALLEE_ACK_QUIT://双向视频或语音 退出操作
                        // callFinish("");
                        break;
                    case CALLEE_JOIN://通知更新成员
                        break;
                    case VIDEO_CMD_OPS_OPEN:
                        showToast(getString(R.string.opposite_open_camera));
                        conversationType = CALLING;
                        switchVideoUI(true);
                        if (layout_main != null && floatVideoWindowService != null && isBackFront) {
                            //layout_main.removeAllViews();
                            otherView.removeAllViews();
                            selfView.removeAllViews();
                            floatVideoWindowService.initVideoWindow(nSelfSurfaceView, nOtherSurfaceView);
                            floatVideoWindowService.switchToVideo();
                        }
                        break;
                    case VIDEO_CMD_OPS_CLOSE:
                        if (callType == 4 || callType == 2) {
                            switchVideoUI(false);
                        }
                        if (isShowCloseCamera) {
                            isShowCloseCamera = false;
                            showToast(getString(R.string.opposite_close_camera));
                        }
                        if (floatVideoWindowService != null) {
                            floatVideoWindowService.switchToAudio();
                        }
                        break;
                    case INCOMING_TIMEOUT:
                        //  callFinish("");
                        break;
                    default:
                        break;
                }
            }
        };
        LegoEventBus.use("videoRoomStateCall", VideoChatEventType.class).observeForever(videoStateObserver);
    }

    /**
     * ICE状态监听
     */
    private void iceConnectState() {
        iceConnectStateObserver = new Observer<Integer>() {
            @Override
            public void onChanged(@Nullable Integer iceConnectState) {
                switch (iceConnectState) {
                    case Constantsdef.ICE_STATUS.ICE_CONNECT_SUCCESS:
                        logger.info(getString(R.string.ice_connect_successful));
                        break;
                    case Constantsdef.ICE_STATUS
                            .ICE_CONNECT_DISCONNECT:
                        logger.info(getString(R.string.ice_disconnect));
                        break;
                    case Constantsdef.ICE_STATUS
                            .ICE_CONNECT_FAILED:
                        logger.info(getString(R.string.ice_connection_fail));
                        logger.debug("callFinish ice连接失败");
                        callFinish("");
                        break;
                }
            }
        };
        LegoEventBus.use("iceConnectState", Integer.class).observeForever(iceConnectStateObserver);
    }

    public void listenResolutionChangeResult(VideoParam videoParam) {
        if (videoParam == null) {
            return;
        }
        if (videoParam.getnVideoHeight() < videoParam.getnVideoWidht()) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            logger.trace("listenResolutionChangeResult  resolution.height ={}  resolution.width = {} ", videoParam.getnVideoHeight(), videoParam.getnVideoWidht());
//            Display display = ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
//            Point point = new Point();
//            display.getSize(point);
//            logger.trace("listenResolutionChangeResult  display.height ={}  display.width = {} ", point.y, point.x);
//
//            ViewGroup.LayoutParams layoutParams = otherView.getLayoutParams();
//            int height = (int) (point.x / (videoParam.getnVideoWidht() / (float) videoParam.getnVideoHeight()));
//            layoutParams.height = height;
//
//            logger.trace("listenResolutionChangeResult  layoutParams.height ={}  layoutParams width ={}", layoutParams.height, layoutParams.width);
//            otherView.setLayoutParams(layoutParams);
//            ConstraintSet otherConset = new ConstraintSet();
//            otherConset.clone(layout_main);
//
//            otherConset.setMargin(R.id.other_view, ConstraintSet.BOTTOM, height / 2);
//            otherConset.connect(R.id.other_view, ConstraintSet.TOP, R.id.self_view, ConstraintSet.BOTTOM);
//
//            otherConset.applyTo(layout_main);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }

    /**
     * 音频聊天和视频聊天的切换
     *
     * @param flag true 视频聊天，false 音频聊天
     */
    private void switchVideoUI(boolean flag) {//切换到视频视图（等待中）
        logger.debug("switchVideoUI{} ", flag);
        if (flag) {
            mBinding.tvName.setTextSize(ScreenUtils.dp2px(this, 7));
            if (videoSet == null) {

                videoSet = new ConstraintSet();
                videoSet.clone(layout_head);
                videoSet.clear(R.id.iv_icon);
                videoSet.clear(R.id.tv_state);
                videoSet.clear(R.id.tv_name);
//                videoSet.clear(R.id.deparment_rl);

//                RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
//                lp.setMargins(0, 0, ScreenUtils.dp2px(0), 0);
//                lp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
//                lp.addRule(RelativeLayout.ALIGN_PARENT_TOP);
//                mBinding.deparmentIv.setLayoutParams(lp);

//                RelativeLayout.LayoutParams tvDepartmentLp = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
//                tvDepartmentLp.setMargins(ScreenUtils.dp2px(22), 0, ScreenUtils.dp2px(16), 0);
//                tvDepartmentLp.addRule(RelativeLayout.ALIGN_TOP, R.id.deparment_iv);
//                tvDepartmentLp.addRule(RelativeLayout.ALIGN_START, R.id.deparment_iv);
//                mBinding.tvDepartment.setLayoutParams(tvDepartmentLp);

//                mBinding.deparmentIv.requestLayout();
//                mBinding.tvDepartment.requestLayout();

                videoSet.constrainWidth(R.id.iv_icon, ScreenUtils.dp2px(this, 72));
                videoSet.constrainHeight(R.id.iv_icon, ScreenUtils.dp2px(this, 72));
                videoSet.constrainWidth(R.id.tv_state, ConstraintSet.WRAP_CONTENT);
                videoSet.constrainHeight(R.id.tv_state, ConstraintSet.WRAP_CONTENT);
                videoSet.constrainWidth(R.id.tv_name, ConstraintSet.WRAP_CONTENT);
                videoSet.constrainHeight(R.id.tv_name, ConstraintSet.WRAP_CONTENT);
//                videoSet.constrainWidth(R.id.deparment_rl, ConstraintSet.MATCH_CONSTRAINT);
//                videoSet.constrainHeight(R.id.deparment_rl, ConstraintSet.WRAP_CONTENT);

                int barHeight = ScreenUtils.getStatusHeight(VideoCallActivity.this);

                videoSet.connect(R.id.iv_icon, ConstraintSet.RIGHT, ConstraintSet.PARENT_ID, ConstraintSet.RIGHT, ScreenUtils.dp2px(16));
                videoSet.connect(R.id.iv_icon, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP, barHeight + ScreenUtils.dp2px(20));

                videoSet.connect(R.id.tv_state, ConstraintSet.RIGHT, R.id.iv_icon, ConstraintSet.LEFT, ScreenUtils.dp2px(iconRightSpace));
                videoSet.connect(R.id.tv_state, ConstraintSet.BOTTOM, R.id.iv_icon, ConstraintSet.BOTTOM, ScreenUtils.dp2px(6));

                videoSet.connect(R.id.tv_name, ConstraintSet.BOTTOM, R.id.tv_state, ConstraintSet.TOP, 0);
                videoSet.connect(R.id.tv_name, ConstraintSet.RIGHT, R.id.iv_icon, ConstraintSet.LEFT, ScreenUtils.dp2px(iconRightSpace));

//                videoSet.connect(R.id.deparment_rl, ConstraintSet.LEFT, R.id.iv_icon, ConstraintSet.RIGHT, ScreenUtils.dp2px(iconRightSpace - 3));
//                videoSet.connect(R.id.deparment_rl, ConstraintSet.RIGHT, ConstraintSet.PARENT_ID, ConstraintSet.RIGHT, ScreenUtils.dp2px(16));
//                videoSet.connect(R.id.deparment_rl, ConstraintSet.TOP, R.id.tv_name, ConstraintSet.BOTTOM, ScreenUtils.dp2px(1));

                mBinding.tvName.setTextSize(COMPLEX_UNIT_SP, 28);
//                mBinding.tvDepartment.setTextSize(COMPLEX_UNIT_SP, 14);
//                mBinding.tvDepartment.setTextColor(Color.parseColor("#FEFEFE"));
                mBinding.tvState.setTextSize(COMPLEX_UNIT_SP, 14);

                mBinding.tvName.requestLayout();
//                mBinding.tvDepartment.requestLayout();
                mBinding.tvState.requestLayout();
            }
            TransitionManager.beginDelayedTransition(this.layout_head);
            if (this.callType != 3 && this.callType != 1) {
                this.videoSet.applyTo(this.layout_head);
            } else {
                this.setCloseCamera(false);
            }

        } else {
            TransitionManager.beginDelayedTransition(this.layout_head);
            if (this.callType == 4 || this.callType == 2) {
                this.setCloseCamera(true);
            }
        }

    }

    /**
     * 判断是否当前音频聊天，且是第一次聊天
     */
    private void judgeSwitchVideo() {
        if (StringUtil.isEquals(nFirstcallTypeStr, Constants.LANGUAGE) && isFirstInitVideoUpdate) {
            layout_switch.setVisibility(View.GONE);
        } else {
            layout_switch.setVisibility(View.GONE);
        }
    }

    /**
     * 初始化组件
     */
    private void initView() {
        layout_main = mBinding.layoutMain;
        layout_bottom = mBinding.viewBottom;
        otherView = mBinding.otherView;
        selfView = mBinding.selfView;
        iv_left = mBinding.ivLeft;
        iv_mute_land = mBinding.ivMuteLand;
        iv_right = mBinding.ivRight;
        iv_hand_free_land = mBinding.ivHandFreeLand;
        tv_right = mBinding.tvRight;
        tv_middle = mBinding.tvMiddle;
        tv_left = mBinding.tvLeft;
        tv_name = mBinding.tvName;
        tv_time = mBinding.tvTime;
        tv_time_land = mBinding.tvTimeLand;
        tv_state = mBinding.tvState;
        iv_suoxiao = mBinding.ivSuoxiao;
        layout_switch = mBinding.layoutSwich;
        layout_left = mBinding.layoutLeft;
        layout_middle = mBinding.layoutMiddle;
        layout_right = mBinding.layoutRight;
        layout_head = mBinding.layoutHead;
        audioSet = new ConstraintSet();
        audioSet.clone(layout_head);
        if (callType == SENDER_VEDIO || callType == RECEIVE_VEDIO) {//如果是视频通话，则切换到视频通话视图
            switchVideoUI(true);
        }

        videoRender = new DefaultVideoRender(this);
        videoCapture = new DefaultCameraCapture();

        nSelfSurfaceView = videoRender.getView2();
        nOtherSurfaceView = videoRender.getView();
        selfView.addView(nSelfSurfaceView);
        otherView.addView(nOtherSurfaceView);


        initWebRtcView();
        updateUI();

        if (talkerType == SessionType.USER) {
            getUserName(userCode, tv_name, getViewDataBinding().ivIcon);
        }
        tv_name.setText(userName);
        initSpeaker();

    }


    /**
     * 第三方平台的优化
     *
     * @param policeNum
     */
    private void initThirdPlatForm(String policeNum) {
        FlutterManager.Companion.getInstance().getContact(userCode, new FlutterDataListener<Contact>() {
            @Override
            public void onSuccess(Contact contact) {
                if (contact != null) {
                    userCode = contact.getCode();
                    talkerCodeForDomain = userCode + "@" + contact.getOriginCode();
                    initVideoCallData();
                }
            }

            @Override
            public void onError(@NotNull Throwable e) {
                logger.error("getUserInfo error {}", e.getMessage());
            }
        });
    }

    /**
     * 获取人员信息
     *
     * @param userCode
     * @param userImg
     */

    private void getUserName(String userCode, TextView namTv, ImageView userImg) {
        SxtDataLoader.loadUserInfo(userCode, namTv, userImg);
//        mBinding.tvDepartment.setMaxLines(2);
//        mBinding.tvDepartment.setEllipsize(TextUtils.TruncateAt.START);
        FlutterManager.Companion.getInstance().getContact(userCode, new FlutterDataListener<Contact>() {
            @Override
            public void onSuccess(Contact contact) {
                if (contact != null) {
//                    mBinding.tvDepartment.setText(contact.getDeptId_name());
                    userName = contact.getName();
                    if (StringUtil.isEmpty(talkerCodeForDomain)) {
                        talkerCodeForDomain = userCode + "@" + contact.getOriginCode();
                    }
                    updateUI();
                    if (TextUtils.isEmpty(FileUtils.getAvatarUrl(contact))) {
                        BitmapFactory.Options options = new BitmapFactory.Options();
                        //基于options设置新建Bitmap资源
                        Bitmap bitmap1 = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_avatar_default_rect_big_flutter, options);
                        //获取经虚化的Bitmap资源
                        Bitmap rsBitmap = FastBlur.doBlur(bitmap1, 10, false);
                        BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), rsBitmap);
                        mBinding.ivBackground.setImageDrawable(bitmapDrawable);
                    } else {
                        Glide.with(VideoCallActivity.this)
                                .load(FileUtils.getAvatarUrl(contact))
                                .dontAnimate()
                                .transform(new BlurTransformation(VideoCallActivity.this))
                                .placeholder(R.mipmap.ic_avatar_default_rect_big_flutter)
                                .error(R.mipmap.ic_avatar_default_rect_big_flutter)
                                .into(mBinding.ivBackground);
                    }
                }
            }

            @Override
            public void onError(@NotNull Throwable e) {
                logger.error("getUserInfo error {}", e.getMessage());
            }
        });

    }


    /**
     * 切换窗口，selfFullScreen：显示自己的视频是否全屏
     */
    private void switchWindows() {
        ConstraintSet set = new ConstraintSet();
        set.clone(layout_main);
        set.constrainWidth(R.id.self_view, ScreenUtils.getPhoneWidth() / 4);
        set.constrainHeight(R.id.self_view, ScreenUtils.getPhoneHeight() / 4);
        set.applyTo(layout_main);
    }

    private boolean isShowSelf = true;

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
    }

    //点击小窗口，进行大小屏幕切换
    @RequiresApi(21)
    public void switchSelfOther(View view) {
        if (ClickEventUtils.needRaiseClickEvent(3000)) {
            ToastUtil.showDefaultToast("窗口切换中,请勿频繁点击");
            return;
        }

        if (isShowSelf) {
            selfView.removeAllViews();
            otherView.removeAllViews();
            nSelfSurfaceView.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
            nSelfSurfaceView.setZOrderMediaOverlay(false);
            nOtherSurfaceView.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
            nOtherSurfaceView.setZOrderMediaOverlay(true);
            nSelfSurfaceView.setEnableHardwareScaler(false);
            nOtherSurfaceView.setEnableHardwareScaler(true);
            selfView.setZ(otherView.getZ() + 1000);
            otherView.addView(nSelfSurfaceView);
            selfView.addView(nOtherSurfaceView);
        } else {
            selfView.removeAllViews();
            otherView.removeAllViews();
            nSelfSurfaceView.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
            nSelfSurfaceView.setZOrderMediaOverlay(true);
            nOtherSurfaceView.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
            nOtherSurfaceView.setZOrderMediaOverlay(false);
            nSelfSurfaceView.setEnableHardwareScaler(true);
            nOtherSurfaceView.setEnableHardwareScaler(false);

            selfView.setZ(otherView.getZ() + 1000);
            otherView.addView(nOtherSurfaceView);
            selfView.addView(nSelfSurfaceView);
        }
        isShowSelf = !isShowSelf;
    }

    private Ringtone initRingtone(Activity context) {
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALL);
        Ringtone tone = RingtoneManager.getRingtone(context, notification);
        setRingtoneRepeat(tone);
        return tone;
    }

    private void setRingtoneRepeat(Ringtone ringtone) {
        Class<Ringtone> clazz = Ringtone.class;
        try {
            Field audio = clazz.getDeclaredField("mAudio");
            audio.setAccessible(true);
            MediaPlayer target = (MediaPlayer) audio.get(ringtone);
            target.setLooping(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean isSpeakOn = false;

    private void initSpeaker() {
        logger.info("VideoCallActivity initSpeaker 111");
        if (callType == SENDER_AUDIO || callType == RECEIVE_AUDIO) {
            isSpeakOn = false;
        } else if (callType == SENDER_VEDIO || callType == RECEIVE_VEDIO) {
            isSpeakOn = true;
        }
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        int state = adapter.getProfileConnectionState(BluetoothProfile.HEADSET);
        if (BluetoothProfile.STATE_CONNECTED == state) {
            logger.info("VideoCallActivity initSpeaker BluetoothProfile.STATE_CONNECTED");
            isHeadset = true;
            iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
            iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
        } else if (audioManager.isWiredHeadsetOn()) {
            logger.info("VideoCallActivity initSpeaker audioManager.isWiredHeadsetOn()");
            isHeadset = true;
            changeToReceiver();
            iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
            iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
        } else {
            logger.info("VideoCallActivity initSpeaker 222");
            if (callType == SENDER_AUDIO || callType == RECEIVE_AUDIO) {
                isSpeakOn = false;
                if (conversationType == WAITING) {
                    iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.answer_flutter));
                    iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.answer_flutter));
                } else {
                    iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                    iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                }
                changeToReceiver();
            } else if (callType == SENDER_VEDIO || callType == RECEIVE_VEDIO) {
                isSpeakOn = true;
                if (conversationType == WAITING) {
                    iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.answer_flutter));
                    iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.answer_flutter));
                } else {
                    iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_do_flutter));
                    iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_do_flutter));
                }
                changeToSpeaker();
            }
        }
//        else {
//            kedamedia.getInstance(VideoCallActivity.this, null).setHandsFree(isSpeakOn);
//        }
    }

    //初始化传递过来的数据
    private void initPostData() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        nMediaPlayer = MediaPlayer.create(this, R.raw.call_wait_flutter);

        nMediaPlayer.setLooping(true);
        boolean isSender = getIntent().getBooleanExtra("isSender", true);
        String TempCallType = getIntent().getStringExtra("callType");

        videoRoom = (VideoChatRoom) getIntent().getSerializableExtra("videoRoom");
        logger.info("userCode:{},talkerCodeForDomain:{},isSender:{},the video room is {}", userCode, talkerCodeForDomain, isSender, videoRoom);
        if (videoRoom == null) {
            getVideoRoomInfo();
        }
        boolean cameraIsOpen = false;
        if (TempCallType != null && TempCallType.equals(Constants.VIDEOCHAT)) {
            cameraIsOpen = true;
        } else {
            nFirstcallTypeStr = Constants.LANGUAGE;
        }
        if (isSender) {
            if (cameraIsOpen) {
                callType = SENDER_VEDIO;
            } else {
                callType = SENDER_AUDIO;
            }
        } else {
            if (cameraIsOpen) {
                callType = RECEIVE_VEDIO;
            } else {
                callType = RECEIVE_AUDIO;
            }
        }

    }

    //方式上个界面传过来时 界面获取为空
    private void getVideoRoomInfo() {
        VideoTalkService talkService = SdkImpl.getInstance().getService(VideoTalkService.class);
        if (talkService != null && userCode != null) {
            talkService.getRoom(talkerCodeForDomain, SessionType.USER).setCallback(new RequestCallback<Optional<VideoChatRoom>>() {
                @Override
                public void onSuccess(Optional<VideoChatRoom> videoChatRoomOptional) {
                    videoRoom = videoChatRoomOptional.get();
                }

                @Override
                public void onFailed(Throwable throwable) {
                    logger.info("getRoomInfo failed {}", throwable.getMessage());
                }
            });
        }
    }

    private void updateUI() {//更新UI
        logger.info("updateUI{} ,{}", conversationType, callType);
        if (conversationType == WAITING) {
            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) mBinding.viewBottom.getLayoutParams();
            layoutParams.bottomMargin = ScreenUtils.dp2px(48);
            if (callType == SENDER_AUDIO) {
                layout_main.setVisibility(View.GONE);
                iv_suoxiao.setVisibility(View.GONE);
                tv_time.setVisibility(View.GONE);
                tv_time_land.setVisibility(View.GONE);
                layout_switch.setVisibility(View.GONE);
                judgeSwitchVideo();
                layout_left.setVisibility(View.GONE);
                layout_right.setVisibility(View.GONE);
                otherView.setVisibility(View.GONE);
                selfView.setVisibility(View.GONE);
                tv_name.setVisibility(View.VISIBLE);
                tv_name.setText(userName == null ? userCode : userName);
            } else if (callType == SENDER_VEDIO) {
                layout_main.setVisibility(View.VISIBLE);
                iv_suoxiao.setVisibility(View.GONE);
                tv_time.setVisibility(View.GONE);
                tv_time_land.setVisibility(View.GONE);
                layout_switch.setVisibility(View.GONE);
                layout_left.setVisibility(View.GONE);
                layout_right.setVisibility(View.GONE);
                selfView.setVisibility(View.GONE);
                tv_name.setVisibility(View.VISIBLE);
                tv_name.setText(userName == null ? userCode : userName);
            } else if (callType == RECEIVE_AUDIO) {
                layout_main.setVisibility(View.GONE);
                iv_suoxiao.setVisibility(View.GONE);
                tv_time.setVisibility(View.GONE);
                tv_time_land.setVisibility(View.GONE);
                judgeSwitchVideo();
                layout_left.setVisibility(View.GONE);
                layout_switch.setVisibility(View.GONE);
                layout_right.setVisibility(View.VISIBLE);
                otherView.setVisibility(View.GONE);
                selfView.setVisibility(View.GONE);

                iv_right.setImageDrawable(ContextCompat.getDrawable(this, R.mipmap.answer_flutter));
                iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(this, R.mipmap.answer_flutter));
                tv_right.setText(getString(R.string.answer_calls));
                tv_middle.setText(getString(R.string.refuse_answer));
                tv_state.setText(getString(R.string.invite_you_voice_call));
                startTip();
                tv_name.setVisibility(View.VISIBLE);
                tv_name.setText(userName == null ? userCode : userName);
            } else if (callType == RECEIVE_VEDIO) {
                layout_main.setVisibility(View.VISIBLE);
                iv_suoxiao.setVisibility(View.GONE);
                tv_time.setVisibility(View.GONE);
                tv_time_land.setVisibility(View.GONE);
                layout_switch.setVisibility(View.GONE);
                layout_left.setVisibility(View.GONE);
                layout_right.setVisibility(View.VISIBLE);

//                iv_right.setImageDrawable(ContextCompat.getDrawable(this, R.mipmap.answer_video));
//                iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(this, R.mipmap.answer_video));
                iv_right.setImageDrawable(ContextCompat.getDrawable(this, R.mipmap.answer_flutter));
                iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(this, R.mipmap.answer_flutter));
                tv_right.setText(getString(R.string.answer_calls));
                tv_middle.setText(getString(R.string.refuse_answer));
                tv_state.setText(getString(R.string.invite_you_vedio_call));
                tv_name.setVisibility(View.VISIBLE);
                tv_name.setText(userName == null ? userCode : userName);
                startTip();
            }
        } else if (conversationType == CALLING) {
            ConstraintLayout.LayoutParams viewBottomlayoutParams = (ConstraintLayout.LayoutParams) mBinding.viewBottom.getLayoutParams();
            viewBottomlayoutParams.bottomMargin = ScreenUtils.dp2px(0);
            if (!TextUtils.isEmpty(meetingId)) {
                getViewDataBinding().llSwitch.setVisibility(View.GONE);
                getViewDataBinding().llSwitchLand.setVisibility(View.GONE);

                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) getViewDataBinding().llSwichCamera.getLayoutParams();
                layoutParams.leftMargin = 0;
                layoutParams.bottomMargin = 16;
            }

            if (callType == SENDER_AUDIO || callType == RECEIVE_AUDIO) {
                iv_suoxiao.setVisibility(View.VISIBLE);
                if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                    //竖屏
                    tv_time.setVisibility(View.VISIBLE);
                } else {
                    //横屏
                    tv_time_land.setVisibility(View.VISIBLE);
                }
                layout_switch.setVisibility(View.GONE);
                judgeSwitchVideo();
                layout_left.setVisibility(View.VISIBLE);
                layout_right.setVisibility(View.VISIBLE);
                layout_head.setVisibility(View.VISIBLE);
                otherView.setVisibility(View.GONE);
                selfView.setVisibility(View.GONE);
                tv_left.setText(getString(R.string.mute));
                tv_middle.setText(getString(R.string.hang_up));
                tv_right.setText(getString(R.string.freehand));
                tv_state.setVisibility(View.GONE);
                initVideoButtonState();
                tv_name.setVisibility(View.VISIBLE);
                tv_name.setText(userName == null ? userCode : userName);

            } else if (callType == SENDER_VEDIO || callType == RECEIVE_VEDIO) {
                iv_suoxiao.setVisibility(View.VISIBLE);
                selfView.setVisibility(View.VISIBLE);
                otherView.setVisibility(View.VISIBLE);
                layout_main.setVisibility(View.VISIBLE);
                if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                    //竖屏
                    tv_time.setVisibility(View.VISIBLE);
                } else {
                    //横屏
                    tv_time_land.setVisibility(View.VISIBLE);
                }
                layout_switch.setVisibility(View.VISIBLE);
                layout_left.setVisibility(View.VISIBLE);
                layout_right.setVisibility(View.VISIBLE);
                layout_head.setVisibility(View.GONE);
                tv_left.setText(getString(R.string.mute));
                tv_middle.setText(getString(R.string.hang_up));
                tv_right.setText(getString(R.string.freehand));
                iv_left.setImageDrawable(ContextCompat.getDrawable(this, R.mipmap.mute_flutter));
                iv_mute_land.setImageDrawable(ContextCompat.getDrawable(this, R.mipmap.mute_flutter));
                iv_right.setImageDrawable(ContextCompat.getDrawable(this, R.mipmap.hand_free_do_flutter));
                iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(this, R.mipmap.hand_free_do_flutter));
                tv_name.setVisibility(View.VISIBLE);
                tv_name.setText(userName == null ? userCode : userName);
                switchWindows();
                addVideoRenderView();
            }

        }
    }

    //双向语音和视频切换，保持原来静音和免提的状态
    private void initVideoButtonState() {
        if (isMute) {
            iv_left.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.mute_do_flutter));
            iv_mute_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.mute_do_flutter));
        } else {
            iv_left.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.mute_flutter));
            iv_mute_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.mute_flutter));
        }
    }

    private void startTip() {
        if (nRingTone != null) {
            nRingTone.play();
        }
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                VibratorUtil.Vibrate(VideoCallActivity.this, 1500L);
            }
        };
        try {
            nTimer.schedule(timerTask, 0L, 2000L);
        } catch (Exception e) {
            LegoLog.e("stop media timer error", e);
        }
    }

    /**
     * 设置开关摄像头
     */
    private void setCloseCamera(boolean cameraIsClose) {
        nVideoService.setVideoCameraStatus(videoRoom.getRoomId(), cameraIsClose).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                logger.info("setVideoCameraStatus onSuccess {} ");
                isFirstInitVideoUpdate = false;
                if (cameraIsClose) {
                    audioSet.applyTo(layout_head);
                } else {
                    videoSet.applyTo(layout_head);
                }
                switch (callType) {
                    case RECEIVE_AUDIO:
                        callType = RECEIVE_VEDIO;
                        break;
                    case RECEIVE_VEDIO:
                        callType = RECEIVE_AUDIO;
                        iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, (!isSpeakOn || isHeadset) ? R.mipmap.hand_free_flutter : R.mipmap.hand_free_do_flutter));
                        iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, (!isSpeakOn || isHeadset) ? R.mipmap.hand_free_flutter : R.mipmap.hand_free_do_flutter));
                        break;
                    case SENDER_AUDIO:
                        callType = SENDER_VEDIO;
                        break;
                    case SENDER_VEDIO:
                        callType = SENDER_AUDIO;
                        iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, (!isSpeakOn || isHeadset) ? R.mipmap.hand_free_flutter : R.mipmap.hand_free_do_flutter));
                        iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, (!isSpeakOn || isHeadset) ? R.mipmap.hand_free_flutter : R.mipmap.hand_free_do_flutter));
                        break;
                }
                updateUI();
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.info("setVideoCameraStatus onFailed {}", throwable.getMessage());
                showToast(FileUtils.getErrMsg(throwable.getMessage()));
            }
        });
    }

    /**
     * 绑定视频对讲组件
     */
    private void bindCaptureAndRender(VideoChatRoom room) {
        nVideoService.bindCaptureAndRender(room.getRoomId(), videoCapture, videoRender).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                logger.info("bindCaptureAndRender onSuccess {},room={}", videoRoom);
                if (callType == SENDER_AUDIO || callType == SENDER_VEDIO) {
                    logger.debug("VideoChatRoom Romm{}", room);
                    if (room.hasActiveMembers()) {
                        logger.info("bindCaptureAndRender joinVideoRoom");
                        // 已经存在激活成员，标识聊天房间中有人已发起聊天
                        joinVideoRoom();
                    } else {
                        logger.info("bindCaptureAndRender startVideoTalk");
                        startVideoTalk(room);
                    }
                } else {
//                    if (SxtUIManager.getInstance().getUiOptions().autoAccept) {
//                        acceptCalling();
//                        stopMedia();
//                    }
                }
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.info("bindCaptureAndRender onFailed {}", throwable.getMessage());
                showToast(FileUtils.getErrMsg(throwable.getMessage()));
            }
        });

    }

    //最右边的按钮
    public void setUpLouderSpeaker(View view) {
        logger.info("setUpLouderSpeaker");
        if (conversationType == WAITING) {
            stopMedia();
            if (videoRoom != null && videoRoom.isCalling()) {
                acceptCalling();
            } else {
                joinVideoRoom();
            }
        } else {
            onSpeakerClicked(view);
        }
    }

    //中间按钮的按钮
    public void chatHandUpClick(View view) {
        stopMedia();

        if (ClickEventUtils.needRaiseClickEvent()) {
            return;
        }
        if (conversationType == WAITING && (callType == RECEIVE_VEDIO || callType == RECEIVE_AUDIO)) {
            refuseInvatation();
        } else {
            hangUp();
        }
    }

    //最左边的按钮
    public void setMriSilent(View view) {
        if (ClickEventUtils.needRaiseClickEvent()) {
            showToast("静音状态切换中,请勿频繁点击");
            return;
        }
        setCloseVoice();
    }

    //缩小按钮
    public void shrinkButton(View view) {
        checkOveralayPermission();
        if (nOverlyPermission) {
            openFloatWindowsView();
        } else {
            LegoEventBus.use("applyPermission", String.class).postValue("applyPermission");
            LegoLog.d("applyPermission");
        }

        moveTaskToBack(true);
    }

    //开启悬浮框
    private void openFloatWindowsView() {
        logger.info("FloatVideoWindowService openFloatWindowsView");
        Intent intent = new Intent(this, FloatVideoWindowService.class);
        if (this.callType != 4 && this.callType != 2) {
            intent.putExtra("isVideo", false);
        } else {
            otherView.removeAllViews();
            selfView.removeAllViews();
            intent.putExtra("isVideo", true);
        }

        isConnectService = this.bindService(intent, this.mVideoServiceConnection, Context.BIND_AUTO_CREATE);
    }

    //webRtc初始化
    private void initWebRtcView() {
        SurfaceViewRenderer nSelfSurfaceView = videoRender.getView2();
        nSelfSurfaceView.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
        SurfaceViewRenderer nOtherSurfaceView = videoRender.getView();
        nOtherSurfaceView.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);

        nSelfSurfaceView.setZOrderMediaOverlay(true);
        nSelfSurfaceView.setEnableHardwareScaler(true);
        nOtherSurfaceView.setEnableHardwareScaler(false);
    }

    public void switchVideoToLanguge(View view) {
        if (ClickEventUtils.needRaiseClickEvent())
            return;
        setCloseCamera(true);
    }

    /**
     * 发起邀请
     */
    private void startVideoTalk(VideoChatRoom room) {
        List<String> memberList = new ArrayList<>();
        memberList.add(talkerCodeForDomain);

        nVideoService.startBidVideoChat(room.getRoomId(), memberList, callType == RECEIVE_VEDIO || callType == SENDER_VEDIO).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                if (mBluetoothAdapter != null && mBluetoothAdapter.isEnabled()) {
                    // 耳机模式
                    int headset = mBluetoothAdapter.getProfileConnectionState(BluetoothProfile.HEADSET);
                    if (headset == BluetoothProfile.STATE_CONNECTED) {
                        changeToHeadset();
                        iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                        iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                        isHeadset = true;
                    } else {
                        initSpeaker();
                    }
                } else {
                    initSpeaker();
                }
                logger.info("VideoCallActivity startBidVideoChat onSuccess ");
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.error("VideoCallActivity startBidVideoChat onFailed  ", throwable);

                if (throwable != null && (throwable instanceof ResponseException)) {
                    ResponseException error = (ResponseException) throwable;
                    if (error.getCode() == ResultCode.REPEAT_INVITE) {
                        acceptCalling();
                        return;
                    }
                }

                if (isIgnoreResult(throwable)) {
                    return;
                }

                showToast(FileUtils.getErrMsg(throwable.getMessage()));
                finish();
            }
        });

    }

    /**
     * 加入对讲
     */
    private void joinVideoRoom() {
        nVideoService.joinVideoRoom(videoRoom.getRoomId(), true).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                logger.info("VideoCallActivity joinVideoRoom onSuccess {}", videoRoom.getRoomId());
                conversationType = CALLING;
                initSpeaker();
                isInVideoRoom = true;
                startTime();
                updateUI();
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.error("VideoCallActivity joinVideoRoom onFailed {}", throwable.getMessage());
                conversationType = WAITING;
                logger.info("VideoCallActivity joinVideoRoom converstaionType {}", conversationType);
                if (isIgnoreResult(throwable)) {
                }
            }
        });

    }

    private boolean isIgnoreResult(Throwable throwable) {
        if (throwable != null && (throwable instanceof ResponseException)) {
            ResponseException error = (ResponseException) throwable;
            if (error.getCode() == ResultCode.UNSUPPORTED_OPERATION_EXCEPTION) {
                showToast(FileUtils.getErrMsg(throwable.getMessage()));
                callFinish("UNSUPPORTED_OPERATION_EXCEPTION");
                return true;
            } else {
                showToast(FileUtils.getErrMsg(throwable.getMessage()));
                finish();
            }
        }
        return false;
    }

    /**
     * 接收邀请
     */
    private void acceptCalling() {
        nVideoService.acceptBidVideoInvite(videoRoom.getRoomId(), callType == RECEIVE_VEDIO || callType == SENDER_VEDIO).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                startTime();
                logger.info("VideoCallActivity acceptBidVideoInvite onSuccess {}", talkerCodeForDomain);
                conversationType = CALLING;
                isInVideoRoom = true;
                updateUI();

                BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                if (mBluetoothAdapter != null && mBluetoothAdapter.isEnabled()) {
                    // 耳机模式
                    int headset = mBluetoothAdapter.getProfileConnectionState(BluetoothProfile.HEADSET);
                    if (headset == BluetoothProfile.STATE_CONNECTED) {
                        changeToHeadset();
                        iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                        iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                        isHeadset = true;
                    } else {
                        initSpeaker();
                    }
                } else {
                    initSpeaker();
                }
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.info("VideoCallActivity acceptBidVideoInvite onFailed {}", throwable.getMessage());
                if (isIgnoreResult(throwable)) {
                    return;
                }
                showToast(FileUtils.getErrMsg(throwable.getMessage()));
            }
        });

    }

    /**
     * 拒绝邀请
     */
    private void refuseInvatation() {
        nVideoService.refuseBidVideoInvite(videoRoom.getRoomId()).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                logger.info("refuseInvatation onSuccess {}");
                finish();
            }

            @Override
            public void onFailed(Throwable throwable) {

                logger.info("refuseBidVideoInvite onFailed {}", throwable.getMessage());
                showToast(FileUtils.getErrMsg(throwable.getMessage()));
                finish();
            }
        });

    }

    private void initVideoRoom() {
        getRoomInfo();
    }

    private void getRoomInfo() {
        if (videoRoom == null) {
            return;
        }
        getRoomFuture = nVideoService.getRoom(videoRoom.getContactCodeForDomain(), videoRoom.getSessionType());
        getRoomFuture.setCallback(new RequestCallback<Optional<VideoChatRoom>>() {
            @Override
            public void onSuccess(Optional<VideoChatRoom> videoChatRoomOptional) {
                logger.info("getRoom onSuccess: {}", videoChatRoomOptional);
                if (videoChatRoomOptional.isPresent()) {
                    bindCaptureAndRender(videoChatRoomOptional.get());
                } else {
                    finish();
                }
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.info("getRoom onFailed", throwable);
                finish();
            }
        });
    }

    private void startTime() {
        if (startTime == 0) {
            startTime = System.currentTimeMillis();
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!VideoCallActivity.this.isFinish) {
                    String time = VideoCallActivity.this.getFormatTime(VideoCallActivity.this.startTime);
                    tv_time.setText(time);
                    tv_time_land.setText(time);
                    if (VideoCallActivity.this.floatVideoWindowService != null && (VideoCallActivity.this.callType == 3 || VideoCallActivity.this.callType == 1)) {
                        VideoCallActivity.this.floatVideoWindowService.setTime(time);
                    }
                    VideoCallActivity.this.startTime();
                }
            }
        }, 1000);

    }

    public String getFormatTime(long startTime) {
        long diff = System.currentTimeMillis() - startTime;
        StringBuffer timeStr = new StringBuffer();
        diff = diff / 1000;
        long h = 0;
        long m = 0;
        long s = 0;
        if (diff >= 60 * 60) {
            h = diff / (60 * 60);
            m = diff % (60 * 60) / 60;
            s = diff % (60 * 60) % 60;
        } else if (diff >= 60) {
            m = diff % (60 * 60) / 60;
            s = diff % (60 * 60) % 60;
        } else {
            s = diff % (60 * 60) % 60;
        }

        DecimalFormat decimalFormat = new DecimalFormat("00");
        String format = decimalFormat.format(m);

        String format2 = decimalFormat.format(s);
        if (h > 0) {
            timeStr.append(h).append(":");
        }
        timeStr.append(format).append(":");
        timeStr.append(format2);
        return timeStr.toString();
    }

    @Override
    protected void onUserLeaveHint() {
        logger.debug("onUserLeaveHint");
    }

    /**
     * 判断Service是否存在
     *
     * @param className
     * @return
     */
    public boolean isServiceExisted(String className) {
        ActivityManager activityManager = (ActivityManager) this.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> serviceList = activityManager.getRunningServices(2147483647);
        if (serviceList.size() <= 0) {
            return false;
        } else {
            for (int i = 0; i < serviceList.size(); ++i) {
                ActivityManager.RunningServiceInfo serviceInfo = (ActivityManager.RunningServiceInfo) serviceList.get(i);
                ComponentName serviceName = serviceInfo.service;
                if (serviceName.getClassName().equals(className)) {
                    return true;
                }
            }
            return false;
        }
    }

    /**
     * 挂断
     */
    private void hangUp() {
        logger.info(" hangUp");
        if (videoRoom == null) {
            callFinish("");
            return;
        }

        logger.info("hangUp quitBidVideoRoom");

        nVideoService.quitBidVideoRoom(videoRoom.getRoomId()).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                //puMnSwitchAudMode(false);
                logger.info("hangUp  quitBidVideoRoom success");
                if (!isFinishing()) {
                    finish();
                }
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.error("hangUp quitBidVideoRoom onFailed {}", throwable);
                if (isIgnoreResult(throwable)) {
                    return;
                }
                if (!isFinishing()) {
                    finish();
                }
            }
        });

    }

    /**
     * 动画进入 显示按钮
     */
    private void operateViewIn() {
        Animation viewInAnim = AnimationUtils.loadAnimation(this, R.anim.actionsheet_dialog_in_flutter);
        if (conversationType == CALLING) {
            if (StringUtil.isEquals(nFirstcallTypeStr, Constants.LANGUAGE) && isFirstInitVideoUpdate) {
                layout_switch.setVisibility(View.GONE);
            } else {
                if (callType == RECEIVE_AUDIO || callType == SENDER_AUDIO) {
                    layout_switch.startAnimation(viewInAnim);
                    layout_switch.setVisibility(View.GONE);
                }
            }

            layout_bottom.startAnimation(viewInAnim);
            if (callType == RECEIVE_VEDIO || callType == SENDER_VEDIO) {
                layout_switch.setVisibility(View.VISIBLE);
                layout_switch.startAnimation(viewInAnim);
            } else {
                layout_switch.setVisibility(View.GONE);
            }
            tv_time.setVisibility(View.VISIBLE);
            tv_time.startAnimation(viewInAnim);

            layout_bottom.setVisibility(View.VISIBLE);
        }

    }

    /**
     * 动画退出 隐藏按钮
     */
    private void operatViewOut() {
        Animation viewOutAnim = AnimationUtils.loadAnimation(this, R.anim.actionsheet_dialog_out_flutter);
        if (conversationType == CALLING) {
            if (callType == RECEIVE_VEDIO || callType == SENDER_VEDIO) {
                layout_switch.setVisibility(View.VISIBLE);
            } else {
                layout_switch.startAnimation(viewOutAnim);
                layout_switch.setVisibility(View.GONE);
            }

            if (callType == RECEIVE_VEDIO || callType == SENDER_VEDIO) {
                layout_switch.setVisibility(View.GONE);
                layout_switch.startAnimation(viewOutAnim);
            } else {
                layout_switch.setVisibility(View.GONE);
            }
            tv_time.setVisibility(View.GONE);
            tv_time.startAnimation(viewOutAnim);

            layout_bottom.setVisibility(View.GONE);
            layout_bottom.startAnimation(viewOutAnim);
        }
    }

    /**
     * 动画进入 显示按钮
     */
    private void operateLandViewIn() {
//        Animation viewInAnim = AnimationUtils.loadAnimation(this, R.anim.slide_anim_x_in);
//        Animation viewOutAnim = AnimationUtils.loadAnimation(this, R.anim.slide_amin_x_out);
        if (conversationType == CALLING) {
            if (callType == RECEIVE_VEDIO || callType == SENDER_VEDIO) {
                getViewDataBinding().llLand.setVisibility(View.VISIBLE);
//                getViewDataBinding().llLand.startAnimation(viewInAnim);
            } else {
                getViewDataBinding().llLand.setVisibility(View.GONE);
            }
            tv_time_land.setVisibility(View.VISIBLE);
//            tv_time_land.startAnimation(viewOutAnim);
        }
    }

    /**
     * 动画退出 隐藏按钮
     */
    private void operatLandViewOut() {
//        Animation viewInAnim = AnimationUtils.loadAnimation(this, R.anim.slide_anim_x_in);
//        Animation viewOutAnim = AnimationUtils.loadAnimation(this, R.anim.slide_amin_x_out);
        if (conversationType == CALLING) {
            if (callType == RECEIVE_VEDIO || callType == SENDER_VEDIO) {
                getViewDataBinding().llLand.setVisibility(View.GONE);
//                getViewDataBinding().llLand.startAnimation(viewInAnim);
            } else {
                getViewDataBinding().llLand.setVisibility(View.GONE);
            }
            tv_time_land.setVisibility(View.GONE);
//            tv_time_land.startAnimation(viewOutAnim);
        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            return true;
        } else {
            return super.dispatchKeyEvent(event);
        }
    }

    /**
     * 停止声音和震动
     */
    private void stopMedia() {
        if (nRingTone != null) {
            nRingTone.stop();
            nTimer.cancel();
            nRingTone = null;
        }
    }

    /**
     * 停止铃声
     */
    private void stopMusic() {
        if (nRingTone != null) {
            nRingTone.stop();
            nRingTone = null;
        }
    }

    /**
     * 设置开关静音
     */
    private void setCloseVoice() {
        iv_left.toggle(!isMute);
        iv_mute_land.toggle(!isMute);
        logger.info("setCloseVoice isMute : {} , roomId : {}", isMute, videoRoom.getRoomId());
        AbortableFuture<Optional<Void>> future = nVideoService.setMicMute(videoRoom.getRoomId(), !isMute);
        future.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                isMute = !isMute;
                logger.info("videoCall onSetMicMute onSuccess isMute:" + isMute);
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.info("videoCall onSetMicMute {} ,isMute: {}", throwable.getMessage(), isMute);
                if (!isMute) {
                    showToast("设置静音失败");
                } else {
                    showToast("取消静音失败");
                }
            }
        });
    }

    private static Handler mHandler = new Handler();

    //点击扬声器切换视图发生视图变化
    private void onSpeakerClicked(View view) {
        if (ClickEventUtils.needRaiseClickEvent(1000)) {
            ToastUtil.showDefaultToast("免提状态切换中,请勿频繁点击");
            return;
        }
        if (isHeadset) {
            logger.info("onSpeakerClicked isHeadset: " + isHeadset);
            return;
        }

        isSpeakOn = !isSpeakOn;
        iv_right.toggle(!isSpeakOn);
        iv_hand_free_land.toggle(!isSpeakOn);
        logger.info("onSpeakerClicked {}", isSpeakOn);
        kedamedia.getInstance(VideoCallActivity.this, null).setHandsFree(isSpeakOn);
        if (isSpeakOn) {
//            changeToSpeaker();
            logger.info("onSpeakerClicked {}", "hand_free_do");
        } else {
//            changeToReceiver();
            logger.info("onSpeakerClicked {}", "hand_free");
        }
    }


    //点击屏幕时，隐藏或者显示下面的操作按钮
    public void videoCallClick(View view) {
        if (isClicked) {
            if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                //竖屏
                operateViewIn();
            } else {
                //横屏
                operateLandViewIn();
            }
        } else {
            if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                //竖屏
                operatViewOut();
            } else {
                //横屏
                operatLandViewOut();
            }
        }
        isClicked = !isClicked;
    }

    @Override
    protected void onPause() {
        super.onPause();
        logger.info("VideoCallActivity onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        logger.info("VideoCallActivity onStop");
        isBackFront = true;
        checkOveralayPermission();
        if (nOverlyPermission) {
            logger.info("FloatVideoWindowService onStop overlayFloatWindows");
            overlayFloatWindows();
        } else {
            moveTaskToBack(true);
            LegoEventBus.use("applyPermission", String.class).postValue("applyPermission");
        }


    }

    private void overlayFloatWindows() {
        if (isBackFront || !isRunningForeground(VideoCallActivity.this)) {
            logger.info("FloatVideoWindowService overlayFloatWindows ");
            if (this.callType == 4 || this.callType == 2) {
                //this.layout_main.removeAllViews();
                logger.info("VideoCallActivity overlayFloatWindows removeAllViews");
                otherView.removeAllViews();
                selfView.removeAllViews();
            }

            Intent intent = new Intent(this, FloatVideoWindowService.class);
            if (this.conversationType == 1) {
                intent.putExtra("isVideo", false);
            } else if (this.callType != 4 && this.callType != 2) {
                intent.putExtra("isVideo", false);
            } else {
                //this.layout_main.removeAllViews();
                otherView.removeAllViews();
                selfView.removeAllViews();
                intent.putExtra("isVideo", true);
            }

            if (this.isServiceExisted(FloatVideoWindowService.class.getName()) && isConnectService) {
                logger.info("FloatVideoWindowService overlayFloatWindows unbindService");
                this.unbindService(this.mVideoServiceConnection);
            }
            logger.info("FloatVideoWindowService overlayFloatWindows bindService");
            isConnectService = this.bindService(intent, this.mVideoServiceConnection, Context.BIND_AUTO_CREATE);
            logger.info("connectServcice:{}", isConnectService);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        logger.info("VideoCallActivity onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        logger.info("VideoCallActivity onResume");
        isBackFront = false;
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        logger.info("VideoCallActivity onRestart");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                logger.info("VideoCallActivity onRestart Handler");
                if (VideoCallActivity.this.floatVideoWindowService != null) {
                    VideoCallActivity.this.floatVideoWindowService.closeFloatWindow();
                    logger.info("VideoCallActivity onRestart isConnectService:{}", isConnectService);
                    if (VideoCallActivity.this.isServiceExisted(FloatVideoWindowService.class.getName()) && isConnectService) {
                        logger.info("VideoCallActivity onRestart unbindService");
                        VideoCallActivity.this.unbindService(VideoCallActivity.this.mVideoServiceConnection);
                    }
                }
            }
        }, 500);

        addVideoRenderView();
        kedamedia.getInstance(VideoCallActivity.this, null).startVideoSources();
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
    }


    private boolean isFinish = false;

    @Override
    protected void onDestroy() {
        super.onDestroy();
        logger.info("VideoCallActivity onDestroy");
        FlutterManager.Companion.getInstance().endVideoCalling();
        nAudioManager.setMode(AudioManager.MODE_NORMAL);
        mViewModel.unregister();
        //forceQuitChatRoom(videoRoom);
        nTimer.cancel();
        SxtDataManager.Companion.getInstance().setCalling(false);
        logger.info("isVideoCalling{}", SxtDataManager.Companion.getInstance().isCalling());
        stopMedia();

        isFinish = true;
        if (videoRender != null) {
            videoRender.recycle();
        }
        if (nAble != null) {
            nAble.abort();
            nAble = null;
        }
        if (null != getRoomFuture) {
            getRoomFuture.abort();
        }
        if (null != closeVideoCallObserver) {
            LegoEventBus.use("closeVideoCall", String.class).removeObserver(closeVideoCallObserver);
        }
        if (null != videoTalkJoinObserver) {
            LegoEventBus.use("VIDEO_TALK_JOIN_SUCCESS", String.class).removeObserver(videoTalkJoinObserver);
        }
        if (null != telephonyManagerObserver) {
            LegoEventBus.use("TelephonyManager", Integer.class).removeObserver(telephonyManagerObserver);
        }
        if (null != adjustVideoParamObserver) {
            LegoEventBus.use("videoParam", VideoParam.class).removeObserver(adjustVideoParamObserver);
        }
        if (null != iceConnectStateObserver) {
            LegoEventBus.use("iceConnectState", Integer.class).removeObserver(iceConnectStateObserver);
        }
        if (null != videoStateObserver) {
            LegoEventBus.use("videoRoomStateCall", VideoChatEventType.class).removeObserver(videoStateObserver);
        }
        if (null != ssrcReportObserver) {
            LegoEventBus.use("SsrcReport", SsrcReport.class).removeObserver(ssrcReportObserver);
        }
        mHandler.removeCallbacksAndMessages(null);
        unregisterReceiver(headsetPlugReceiver);
        if (nPowerKeyObserver != null) {
            nPowerKeyObserver.stopListen();
        }
    }

    private void callFinish(String quitReasom) {//通话结束
        logger.info("callFinish：{}", quitReasom);
        if (videoRoom == null) {
            if (!isFinishing()) {
                finish();
            }
            return;
        }
        logger.info("callFinish quitBidVideoRoom");
        nVideoService.quitBidVideoRoom(videoRoom.getRoomId()).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                logger.info("VideoCall callFinish quitBidVideoRoom  onSuccess ");
                if (!isFinishing()) {
                    finish();
                }
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.info("callFinish quitVideoRomm onFailed {}", throwable.getMessage());
                if (!isFinishing()) {
                    finish();
                }
            }
        });

    }

    private void delayFinish(String quitReasom) {
        logger.info("delayFinish：{}", quitReasom);
        if (videoRoom == null) {
            if (!isFinishing()) {
                finish();
            }
            return;
        }
        logger.info("delayFinish quitBidVideoRoom");
        nVideoService.quitBidVideoRoom(videoRoom.getRoomId()).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                logger.info("VideoCall delayFinish quitBidVideoRoom  onSuccess ");
                if (!isFinishing()) {
                    finish();
                }
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.info("delayFinish quitVideoRomm onFailed {}", throwable.getMessage());
                if (!isFinishing()) {
                    finish();
                }
            }
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        logger.debug("onNewIntent");
        super.onNewIntent(intent);
        if (this.floatVideoWindowService != null) {
            this.floatVideoWindowService.closeFloatWindow();
            logger.debug("onNewIntent isConnectServier:{}", isConnectService);
            if (this.isServiceExisted(FloatVideoWindowService.class.getName()) && isConnectService) {
                this.unbindService(this.mVideoServiceConnection);
                logger.info("FloatVideoWindowService onNewIntent unbindService ");
            }
            addVideoRenderView();
        }

    }

    private void addVideoRenderView() {
        if (!SxtDataManager.Companion.getInstance().isCalling()) {
            logger.debug("callFinish isVideoCalling");
            callFinish("");
        }
        if (this.callType == 4 || this.callType == 2) {
            if (otherView.getChildCount() == 0 || selfView.getChildCount() == 0) {
                try {
                    selfView.removeAllViews();
                    otherView.removeAllViews();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {
                    ((ViewGroup) nSelfSurfaceView.getParent()).removeAllViews();
                    ((ViewGroup) nOtherSurfaceView.getParent()).removeAllViews();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                selfView.addView(nSelfSurfaceView);
                otherView.addView(nOtherSurfaceView);
            }

        }
    }

    public boolean isRunningForeground(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> appProcessInfos = activityManager.getRunningAppProcesses();
        // 枚举进程
        for (ActivityManager.RunningAppProcessInfo appProcessInfo : appProcessInfos) {
            if (appProcessInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                if (appProcessInfo.processName.equals(context.getApplicationInfo().processName)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 双向视频界面 切换语音聊天
     *
     * @param view
     */
    public void videoVideoToLanguage(View view) {
        if (ClickEventUtils.needRaiseClickEvent()) {
            return;
        }
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getViewDataBinding().llLand.setVisibility(View.GONE);
        tv_time_land.setVisibility(View.GONE);

        getViewDataBinding().layoutSwich.setVisibility(View.VISIBLE);
        tv_time.setVisibility(View.VISIBLE);
        getViewDataBinding().viewBottom.setVisibility(View.VISIBLE);

        setCloseCamera(true);
    }

    /**
     * 双向视频界面 切换摄像头
     *
     * @param view
     */
    public void videoSwitchCamera(View view) {
        if (videoRoom == null) {
            return;
        }

        mViewModel.switchCamera(videoRoom);
    }

    /**
     * 监听耳机和蓝牙耳机插拔的广播监听
     */
    private void registerHeadsetPlugReceiver() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(AudioManager.ACTION_HEADSET_PLUG);
        intentFilter.addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED);
        registerReceiver(headsetPlugReceiver, intentFilter);
    }

    private BroadcastReceiver headsetPlugReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            logger.debug("VideoCallActivity headsetReciver " + intent.getAction() + "state:" + intent.getIntExtra("state", 0));
            String action = intent.getAction();
            if (BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED.equals(action)) {
                mHandler.removeCallbacksAndMessages(null);
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                        int state = adapter.getProfileConnectionState(BluetoothProfile.HEADSET);
                        logger.info("VideoCallActivity headsetPlugReceiver 111 state：" + state);
                        if (BluetoothProfile.STATE_DISCONNECTED == state) {
                            //Bluetooth headset is now disconnected
                            if (isSpeakOn) {
                                logger.info("VideoCallActivity headsetPlugReceiver 222");
                                changeToSpeaker();
                                iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_do_flutter));
                                iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_do_flutter));
                            } else {
                                logger.info("VideoCallActivity headsetPlugReceiver 333");
                                changeToReceiver();
                                iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                                iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                            }
                            isHeadset = false;
                        } else if (BluetoothProfile.STATE_CONNECTED == state) {
                            iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                            iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                            logger.info("VideoCallActivity headsetPlugReceiver 444");
                            changeToHeadset();
                            isHeadset = true;
                        }
                    }
                }, 500);
            } else if (AudioManager.ACTION_HEADSET_PLUG.equals(action)) {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                int state = adapter.getProfileConnectionState(BluetoothProfile.HEADSET);
                if (BluetoothProfile.STATE_CONNECTED == state) {
                    logger.info("VideoCallActivity headsetPlugReceiver 999 state：" + state);
                    return;
                }
                if (intent.hasExtra("state")) {
                    if (intent.getIntExtra("state", 0) == 0) {
                        isHeadset = false;
                        if (nAudioManager != null) {
                            logger.info("VideoCallActivity headsetPlugReceiver 555");
                            if (isSpeakOn) {
                                logger.info("VideoCallActivity headsetPlugReceiver 666");
                                changeToSpeaker();
                                iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_do_flutter));
                                iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_do_flutter));
                            } else {
                                logger.info("VideoCallActivity headsetPlugReceiver 777");
                                changeToReceiver();
                                iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                                iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                            }
                        }
                    } else if (intent.getIntExtra("state", 0) == 1) {
                        isHeadset = true;
                        if (nAudioManager != null) {
                            logger.info("VideoCallActivity headsetPlugReceiver 888");
                            changeToReceiver();
                            iv_right.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                            iv_hand_free_land.setImageDrawable(ContextCompat.getDrawable(VideoCallActivity.this, R.mipmap.hand_free_flutter));
                        }
                    }
                }
            }
        }
    };

    /**
     * 切换到耳机
     */
    private void changeToHeadset() {
        logger.info("VideoCallActivity changeToHeadset");
        mHandler.removeCallbacksAndMessages(null);
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                logger.info("VideoCallActivity changeToHeadset 222");
                logger.info("VideoCallActivity changeToHeadset setMode ");
                nAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                nAudioManager.setSpeakerphoneOn(false);
                nAudioManager.startBluetoothSco();
                nAudioManager.setBluetoothScoOn(true);
            }
        }, 1500);
    }

    /**
     * 切换到扬声器
     */
    private void changeToSpeaker() {
        logger.info("VideoCallActivity changeToSpeaker");
        mHandler.removeCallbacksAndMessages(null);
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                logger.info("VideoCallActivity changeToSpeaker 222");
                logger.info("VideoCallActivity changeToSpeaker setMode ");
                nAudioManager.stopBluetoothSco();
                nAudioManager.setBluetoothScoOn(false);
                nAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                nAudioManager.setSpeakerphoneOn(true);
            }
        }, 1500);
    }

    /**
     * 切换到听筒
     */
    public void changeToReceiver() {
        logger.info("VideoCallActivity changeToReceiver");
        mHandler.removeCallbacksAndMessages(null);
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                logger.info("VideoCallActivity changeToReceiver 222");
                logger.info("VideoCallActivity changeToReceiver setMode ");
                nAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                nAudioManager.setSpeakerphoneOn(false);
            }
        }, 1500);
    }

    /**
     * @param keyCode
     * @param event
     * @return
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_DOWN:
            case KeyEvent.KEYCODE_VOLUME_UP:
            case KeyEvent.KEYCODE_VOLUME_MUTE:
                stopMusic();
            default:
                break;

        }
        return super.onKeyDown(keyCode, event);
    }

    public boolean isMeStart() {
        return isStart;
    }

    public String getTalkerCode() {
        return talkerCodeForDomain;
    }
}
