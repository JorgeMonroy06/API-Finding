package com.kedacom.flutter_sxtapp.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.SpannedString;
import android.text.style.AbsoluteSizeSpan;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.PopupWindow;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kedacom.basic.common.util.StringUtil;
import com.kedacom.flutter_sxtapp.Constants;
import com.kedacom.flutter_sxtapp.R;
import com.kedacom.flutter_sxtapp.adapter.GroupLiveBarrageAdapter;
import com.kedacom.flutter_sxtapp.adapter.GroupUserMenberAdapter;
import com.kedacom.flutter_sxtapp.databinding.ActivityGroupTalkFlutterBinding;
import com.kedacom.flutter_sxtapp.manager.DataManager;
import com.kedacom.flutter_sxtapp.manager.FlutterDataListener;
import com.kedacom.flutter_sxtapp.manager.FlutterManager;
import com.kedacom.flutter_sxtapp.manager.SxtDataLoader;
import com.kedacom.flutter_sxtapp.model.Contact;
import com.kedacom.flutter_sxtapp.model.GroupLiveBarrageBean;
import com.kedacom.flutter_sxtapp.util.ScreenUtils;
import com.kedacom.flutter_sxtapp.viewmodel.GroupTalkViewModel;
import com.kedacom.flutter_sxtapp.widget.CircleImageView;
import com.kedacom.flutter_sxtapp.widget.MsgEditText;
import com.kedacom.flutter_sxtapp.widget.SoftKeyBoardListener;
import com.kedacom.lego.annotation.Extra;
import com.kedacom.lego.annotation.OnMessage;
import com.kedacom.lego.annotation.ViewModel;
import com.kedacom.lego.fast.widget.dialog.ConfirmDialog;
import com.kedacom.lego.fast.widget.dialog.DialogFragmentHelper;
import com.kedacom.uc.ptt.video.media.DefaultCameraCapture;
import com.kedacom.uc.ptt.video.media.DefaultVideoRender;
import com.kedacom.uc.sdk.generic.constant.SessionType;
import com.kedacom.uc.sdk.group.model.IUserMember;
import com.kedacom.uc.sdk.impl.SdkImpl;
import com.kedacom.uc.sdk.ptt.model.MonitorPttTalkStatusEvent;
import com.kedacom.uc.sdk.uinfo.model.IUser;
import com.kedacom.uc.sdk.vchat.constant.VideoChatEventType;
import com.kedacom.uc.sdk.vchat.model.VideoChatEvent;
import com.kedacom.uc.sdk.vchat.model.VideoChatRoom;
import com.kedacom.uc.sdk.vchat.model.VideoChatRoomUser;

import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@ViewModel(GroupTalkViewModel.class)
public class GroupLiveTalkActivity extends BaseActivity<ActivityGroupTalkFlutterBinding, GroupTalkViewModel> {

    private final Logger logger = LoggerFactory.getLogger(Constants.LOGGERTAG_ANDROID_SXT);

    @Extra("groupCode")
    private String nGroupCode;
    @Extra("sessionType")
    private SessionType nSessionType = SessionType.GROUP;
    @Extra("codeForDomain")
    private String nCodeForDomain;

    @Extra("selectChatCode")
    private List<String> userMenberCode = new ArrayList<String>();
    private ArrayList<String> userCodeList = new ArrayList<String>();
    // 视频对讲组件
    private DefaultVideoRender nVideoRender;
    private DefaultCameraCapture nVideoCapture;
    // 群组成员
    private List<IUserMember> members = new ArrayList<>();
    private Map<String, IUser> memberMap = new HashMap<>();
    private int nScreenWidth;
    private int nScreenHeight;
    private VideoChatRoom videoRoom;
    // 成员状态显示内容
    private StringBuffer memberInfoBuffer = new StringBuffer();
    private boolean isMasterRecording = false;
    private boolean isMemberRecording = false;
    private int handleType;                 // 0发起，1加入
    private long lastMsgTime;
    @Extra("isIncoming")
    private boolean isIncomming = false;
    private long startTime = 0;//通话时长
    private long vieoSnapTime = 0L;//
    private boolean nStopVideoSnap = false;
    //组员静音
    private boolean menbserSlient = false;
    //直播主静音
    private boolean masterSilent = false;
    // private ImageView pttChatVoiceAmin;
    //private AnimationDrawable nVoiceAnim;
    private ArrayList<String> nSelectedCode = new ArrayList<String>();
    Observer<GroupLiveBarrageBean> messageCallBackBeanObserver;
    private GroupLiveBarrageAdapter barrageAdapter;
    private List<GroupLiveBarrageBean> groupLiveBarrageBeanList = new ArrayList<GroupLiveBarrageBean>();
    private PopupWindow popupWindow = null;
    private MsgEditText barrageEdit = null;

    @Override
    public int getContentViewId() {
        return R.layout.activity_group_talk_flutter;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        keyBoardScreen();
        initData();
        mViewModel.setGroupCode(nGroupCode);
        initBarrageView();
        addMessageCallBack();
        initPopWindows();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    /**
     * 初始化Popwindows
     */
    private void initPopWindows() {
        View view = LayoutInflater.from(GroupLiveTalkActivity.this).inflate(R.layout.barrage_edit_bottom_flutter, null);
        popupWindow = new PopupWindow();
        popupWindow.setContentView(view);
        popupWindow.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight(ScreenUtils.dp2px(48));
        popupWindow.setOutsideTouchable(true);
        popupWindow.setTouchable(true);
        popupWindow.setFocusable(true);
        popupWindow.setInputMethodMode(PopupWindow.INPUT_METHOD_NEEDED);
        popupWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        barrageEdit = view.findViewById(R.id.et_chat_input);
        SpannableString ss = new SpannableString("发布你的弹幕");//定义hint的值
        AbsoluteSizeSpan ass = new AbsoluteSizeSpan(10, true);//设置字体大小 true表示单位是sp
        ss.setSpan(ass, 0, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        barrageEdit.setHint(new SpannedString(ss));
        barrageEdit.requestFocus();
    }

    private void addMessageCallBack() {
        messageCallBackBeanObserver = new Observer<GroupLiveBarrageBean>() {
            @Override
            public void onChanged(@Nullable GroupLiveBarrageBean groupLiveBarrageBean) {
                groupLiveBarrageBean.setBarrageType(1);
                groupLiveBarrageBeanList.add(0, groupLiveBarrageBean);
                barrageAdapter.notifyItemInserted(0);
            }
        };
        mViewModel.getMessageCallBackBean().observeForever(messageCallBackBeanObserver);
    }

    /**
     * 弹幕view 初始化
     */
    private void initBarrageView() {
        barrageAdapter = new GroupLiveBarrageAdapter(R.layout.item_group_live_danmu_flutter, groupLiveBarrageBeanList);
        RecyclerView barrageView = mBinding.noticeTxt;
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(GroupLiveTalkActivity.this, LinearLayoutManager.VERTICAL, true);
        barrageView.setLayoutManager(linearLayoutManager);
        barrageView.setAdapter(barrageAdapter);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            hideSoftKeyboard(mBinding.frameLayout);
        }
        return super.onTouchEvent(event);
    }

    /*

     * 锁屏显示 设置窗体的样式
     */
    private void keyBoardScreen() {
        final Window win = getWindow();
        win.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON);

    }

    private void initData() {
        userCodeList = (ArrayList<String>) DataManager.getInstance().getSelectTalkChatCodes();
        nVideoRender = new DefaultVideoRender(this);
        nVideoCapture = new DefaultCameraCapture();
        mBinding.frameLayout.addView(nVideoRender.getView());
        mBinding.frameLayout.addView(nVideoRender.getView2());
        WindowManager wm = (WindowManager) this.getSystemService(Context.WINDOW_SERVICE);
        nScreenWidth = wm.getDefaultDisplay().getWidth();
        nScreenHeight = wm.getDefaultDisplay().getHeight();
        // pttChatVoiceAmin = mBinding.chattingVisitorTitle.pttChatVoice1;
        //nVoiceAnim = (AnimationDrawable) pttChatVoiceAmin.getBackground();
        // mMediaService.setAudioCaptureChannel(true);
        String cacheFilePath = "/sdcard/kedacom/sdk/ptt";
        File cacheDir = new File(cacheFilePath);
        if (!cacheDir.exists()) {
            cacheDir.mkdirs();
        }
        mViewModel.getGroupMembers(nGroupCode);
        startTime();
        pttTalkAddListener();

    }

    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    // 显示消息
                    String notice = (String) msg.obj;
                    //  mBinding.messageTxt.setText(notice);
                    // 定时清掉消息
                    handler.removeMessages(1);
                    Message clearMsg = handler.obtainMessage();
                    clearMsg.what = 1;
                    handler.sendMessageDelayed(clearMsg, 3000);
                    return true;
                case 1:
                    // mBinding.messageTxt.setText("");
                    return true;
            }
            return false;
        }
    });

    /**
     * 发送事件通知消息
     *
     * @param msg
     */
    private void postNoticeMsg(String msg, String userCode) {
        if (StringUtil.isEmpty(userCode)) {
            showToast(msg);
            return;
        }
        FlutterManager.Companion.getInstance().getContact(userCode, new FlutterDataListener<Contact>() {
            @Override
            public void onSuccess(Contact contact) {
                if (contact != null) {
                    showToast(contact.getName() + msg);
                }
            }

            @Override
            public void onError(@NotNull Throwable e) {
                showToast("获取用户信息失败：" + e.getMessage());
            }
        });
    }

    /**
     * 修改界面，变更为成员界面
     */
    private void beMember() {
        if (!videoRoom.isAnchorOfSelf()) {
            mBinding.menberLayout.setVisibility(View.VISIBLE);
            mBinding.masterLayout.setVisibility(View.GONE);
            mBinding.pttTalk.setVisibility(View.VISIBLE);
            mBinding.imgSwitchCamera.setVisibility(View.GONE);
            userMenberCode = new ArrayList<String>();
            addUserMenber();
            String anchorDomainCode = videoRoom.getAnchorUserCodeForDomain();
            if (anchorDomainCode != null && anchorDomainCode.contains("@")) {
                String anchorCode = anchorDomainCode.split("@")[0];
                SxtDataLoader.loadUserInfo(anchorCode, mBinding.tvMenberName, mBinding.imgDiscussion);
            }
            handleType = 1;
        }
    }

    private void addUserMenber() {
        nSelectedCode.clear();
        mBinding.llMenberIcon.removeAllViews();
        for (VideoChatRoomUser videoChatRoomUser : videoRoom.getRoomActivityUsers()) {
            nSelectedCode.add(videoChatRoomUser.getUserCode());
            addMenberImageIcon(videoChatRoomUser.getUserCode());
        }

    }

    /**
     * 添加成员头像
     *
     * @param userCode
     */
    private void addMenberImageIcon(String userCode) {
        View headView = LayoutInflater.from(GroupLiveTalkActivity.this).inflate(R.layout.item_head_image_live_flutter, null);
        CircleImageView imageView = headView.findViewById(R.id.head_image);
        TextView textView = new TextView(GroupLiveTalkActivity.this);
        SxtDataLoader.loadUserInfo(userCode, textView, imageView);
        mBinding.llMenberIcon.addView(headView);

    }

    private void startTime() {
        if (startTime == 0)
            startTime = System.currentTimeMillis();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                mBinding.groupTime.setText(getFormatTime(startTime));
                mBinding.groupTime1.setText(getFormatTime(startTime));
                startTime();
            }
        }, 1000);

    }

    private void videoTape() {
        if (vieoSnapTime == 0)
            vieoSnapTime = System.currentTimeMillis();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                if (nStopVideoSnap)
                    return;
                // mBinding.recoderTime.setText(getFormatTime(vieoSnapTime));

                videoTape();
            }
        }, 1000);
    }

    public String getFormatTime(long startTime) {
        long diff = System.currentTimeMillis() - startTime;
        StringBuffer timeStr = new StringBuffer();
        diff = diff / 1000;
        long h = 0;
        long m = 0;
        long s = 0;
        if (diff >= 60 * 60) {

            h = diff / (60 * 60);
            m = diff % (60 * 60) / 60;
            s = diff % (60 * 60) % 60;

        } else if (diff >= 60) {


            m = diff % (60 * 60) / 60;
            s = diff % (60 * 60) % 60;


        } else {

            s = diff % (60 * 60) % 60;

        }


        DecimalFormat decimalFormat = new DecimalFormat("00");
        String format = decimalFormat.format(m);

        String format2 = decimalFormat.format(s);
        if (h > 0)
            timeStr.append(h).append(":");
        timeStr.append(format).append(":");
        timeStr.append(format2);
        return timeStr.toString();
    }

    /**
     * 修改界面，变更为主播界面
     */
    private void beMaster() {
        if (videoRoom.isAnchorOfSelf()) {
            addUserMenber();
            mBinding.menberLayout.setVisibility(View.GONE);
            mBinding.masterLayout.setVisibility(View.VISIBLE);
            mBinding.pttTalk.setVisibility(View.GONE);
            mBinding.imgSwitchCamera.setVisibility(View.VISIBLE);
            handleType = 0;
        }
    }

    /**
     * 格式化要显示的成员信息
     */
    private void formatMemberInfo() {
        if (null != videoRoom) {
            List<VideoChatRoomUser> roomUsers = videoRoom.getRoomActivityUsers();
            mBinding.tvLiveLengthMenber.setText(roomUsers.size() + "个观看");
            mBinding.tvNums.setText(roomUsers.size() + "个观看");

            // 清空
            memberInfoBuffer.setLength(0);
            if (null != roomUsers && !roomUsers.isEmpty()) {
                for (VideoChatRoomUser roomUser : roomUsers) {
                    IUser user = memberMap.get(roomUser.getUserCodeForDomain());
                    if (null == user) {
                        continue;
                    }
                    if (memberInfoBuffer.length() > 0) {
                        memberInfoBuffer.append("\n");
                    }
//                    memberInfoBuffer.append("(")
//                            .append(roomUser.getState() == VideoRoomUserState.ACTIVE ? "在" : "离")
//                            .append(")")
//                            .append(user.getUserName());
                }
            }
            //   mBinding.noticeTxt.setText(memberInfoBuffer.toString());
        } else {
            logger.error("the videoRoom is null");
        }
    }

    private void showPopWindow() {
        View view = LayoutInflater.from(GroupLiveTalkActivity.this).inflate(R.layout.layout_group_talk_menber_flutter, null, false);
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams
                .MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        view.setLayoutParams(params);
        RecyclerView menberRecycle = view.findViewById(R.id.recy_menber);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(GroupLiveTalkActivity.this, LinearLayoutManager.VERTICAL, false);
        menberRecycle.setLayoutManager(linearLayoutManager);
        GroupUserMenberAdapter groupTalkMenber = new GroupUserMenberAdapter(R.layout.item_group_talk_menber_flutter, nSelectedCode);
        menberRecycle.setAdapter(groupTalkMenber);
        final PopupWindow window = new PopupWindow(view,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT);
        window.setContentView(view);
        // 设置popWindow弹出窗体可点击，这句话必须添加，并且是true
        window.setFocusable(true);
        // 实例化一个ColorDrawable颜色为半透明
        ColorDrawable dw = new ColorDrawable(0xb0000000);
        window.setBackgroundDrawable(dw);

        // 设置popWindow的显示和消失动画
        window.setAnimationStyle(R.style.mypopwindow_anim_style);
        // 在底部显示
        window.showAtLocation(view, Gravity.BOTTOM, 0, 0);

        window.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {

            }
        });
    }

    /**
     * 改变背景透明度
     */
    private void darkenBackground(Float bgcolor) {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = bgcolor;

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        getWindow().setAttributes(lp);
    }

    @OnMessage
    public void getGroupMenberSuccess(List<IUserMember> memberList) {
        members.addAll(memberList);
        for (IUserMember user : memberList) {
            memberMap.put(user.getUser().getUserCodeForDomain(), user.getUser());
        }
        mViewModel.getVideoRoom(false, nCodeForDomain, SessionType.GROUP);
    }

    @OnMessage
    public void getRoomSuccess(VideoChatRoom videoRoom) {
        this.videoRoom = videoRoom;
        for (VideoChatRoomUser videoChatRoomUser : videoRoom.getRoomUsers()) {
            nSelectedCode.add(videoChatRoomUser.getUserCode());
        }
        mViewModel.registerObserver();
        mViewModel.bindComm(nVideoCapture, nVideoRender);
    }

    @OnMessage
    public void getRoomFailed(String msgStr) {

        showToast(msgStr);
        finish();
    }

    @OnMessage
    public void onApplySpeak() {
        mBinding.llTalkPpt.setVisibility(View.VISIBLE);
//        nVoiceAnim.start();
//
        String speakerName = SdkImpl.getInstance().getUserSession().get().getUser().getUserName();//如果是发起者
//
//
        mBinding.tvPttTalkName.setText(speakerName + "在说话");

    }

    @OnMessage
    public void onPttSpeakerApply(MonitorPttTalkStatusEvent monitorPttTalkStatusEvent) {
        mBinding.llTalkPpt.setVisibility(View.VISIBLE);
        ;
        String speakerName;
        if (monitorPttTalkStatusEvent == null)
            speakerName = SdkImpl.getInstance().getUserSession().get().getUserCode();//如果是发起者

        else speakerName = monitorPttTalkStatusEvent.getRoom().getSpeaker().getCode();
        if (speakerName == null)
            speakerName = "";
        if (speakerName != null) {
            mBinding.tvPttTalkName.setText(speakerName + "在说话");
        }
        // nVoiceAnim.start();
        //getUserNameByCode1(speakerName, mBinding.chattingVisitorTitle.tvChattingVisitorInfo);
    }


    @OnMessage
    public void stopPttSpeak() {
        mBinding.llTalkPpt.setVisibility(View.GONE);
        //nVoiceAnim.stop();
    }

    private void pttTalkAddListener() {
        mBinding.pttTalk.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        onApplySpeak();
                        mViewModel.startSpeak();
                        mBinding.llTalkPpt.setVisibility(View.VISIBLE);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        mViewModel.stopSpeak();
                        mBinding.llTalkPpt.setVisibility(View.GONE);
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    @OnMessage
    public void onSpeakerQutiChat() {

        finish();
    }

    @OnMessage
    public void getVideoChatRoom(List<VideoChatRoomUser> videoChatRoomUserList) {

        // 清空
        memberInfoBuffer.setLength(0);
        if (null != videoChatRoomUserList && !videoChatRoomUserList.isEmpty()) {
            for (VideoChatRoomUser roomUser : videoChatRoomUserList) {
                IUser user = memberMap.get(roomUser.getUserCodeForDomain());
                if (null == user) {
                    continue;
                }
                if (memberInfoBuffer.length() > 0) {
                    memberInfoBuffer.append("\n");
                }
//                memberInfoBuffer.append("(")
//                        .append(roomUser.getState() == VideoRoomUserState.ACTIVE ? "在" : "离")
//                        .append(")")
//                        .append(user.getUserName());
            }
        }
        // mBinding.noticeTxt.setText(memberInfoBuffer.toString());
    }

    private boolean isFirstShow = true;

    @OnMessage
    public void registerEvent(VideoChatEvent videoChatEvent) {
        formatMemberInfo();
        VideoChatEventType eventType = videoChatEvent.getType();
        switch (eventType) {
            case VIDEO_RECOVERY_START:
                showToast(getString(R.string.network_instability));
                break;
            case VIDEO_RECOVERY_TIMEOUT:
                showToast(getString(R.string.video_reconnect_timeout));
                mViewModel.quitChat();
                break;
            case CALLEE_ACK_AGREE:
                addMsgToBarrage(getString(R.string.video_call_accepted), videoChatEvent.getSrcUserCode());
                postNoticeMsg(getString(R.string.video_call_accepted), videoChatEvent.getSrcUserCode());
                formatMemberInfo();

                break;
            case CALLEE_ACK_REJECT:
                addMsgToBarrage(getString(R.string.video_call_rejected), videoChatEvent.getSrcUserCode());
                postNoticeMsg(getString(R.string.video_call_rejected), videoChatEvent.getSrcUserCode());

                break;
            case CALLEE_OFFLINE:

                postNoticeMsg(getString(R.string.exception_quit_video_call), videoChatEvent.getSrcUserCode());
                formatMemberInfo();
                break;
            case CALLEE_ACK_QUIT:
                addMsgToBarrage(getString(R.string.quit_video_call), videoChatEvent.getSrcUserCode());
                postNoticeMsg(getString(R.string.quit_video_call), videoChatEvent.getSrcUserCode());
                formatMemberInfo();
                break;
            case CALLEE_JOIN:
                postNoticeMsg(getString(R.string.video_call_invite), videoChatEvent.getSrcUserCode());
                addMsgToBarrage(getString(R.string.video_call_invite), videoChatEvent.getSrcUserCode());
                formatMemberInfo();
                break;
            case VIDEO_ALONE_TERMINATE:
                showToast(getString(R.string.end_ptt_call));
                finish();
                break;
            case SWITCH_ACK_AGREE:
                addMsgToBarrage(getString(R.string.accept_switch_anchor), videoChatEvent.getSrcUserCode());
                postNoticeMsg(getString(R.string.accept_switch_anchor), videoChatEvent.getSrcUserCode());
                break;
            case SWITCH_ACK_REJECT:
                addMsgToBarrage(getString(R.string.reject_apply_for_switch_anchor), videoChatEvent.getSrcUserCode());
                postNoticeMsg(getString(R.string.reject_apply_for_switch_anchor), videoChatEvent.getSrcUserCode());
                mViewModel.stopMemberPlay();
                break;
            case SWITCH_INCOMING_TIMEOUT:
                postNoticeMsg(getString(R.string.apply_timeout), "");

                break;
            case SWITCH_INCOMING_BREAK:
                postNoticeMsg(getString(R.string.apply_ended), "");
                break;
            case VIDEO_ANCHOR_CHANGED:
                postNoticeMsg(getString(R.string.anchor_changed), "");
                break;
            case SWITCH_INCOMING:
                if (isFirstShow) {
                    isFirstShow = false;
                    addMsgToBarrage(getString(R.string.anchor_apply), videoChatEvent.getSrcUserCode());
                    FlutterManager.Companion.getInstance().getContact(videoChatEvent.getSrcUserCode(), new FlutterDataListener<Contact>() {
                        @Override
                        public void onSuccess(Contact contact) {
                            if (contact != null) {
                                applyHost(contact.getName() + getString(R.string.anchor_apply));
                            }
                        }

                        @Override
                        public void onError(@NotNull Throwable e) {
                            showToast("获取用户信息失败：" + e.getMessage());
                        }
                    });
                }

                break;
        }
        if (videoRoom.isAnchorOfSelf()) {
            beMaster();
        } else {
            beMember();
        }
    }

    private void addMsgToBarrage(String msg, String userCode) {
        GroupLiveBarrageBean barrageBean = new GroupLiveBarrageBean();
        barrageBean.setUserCode(userCode);
        barrageBean.setBarrageType(0);
        barrageBean.setContent(msg);
        groupLiveBarrageBeanList.add(0, barrageBean);
        barrageAdapter.notifyItemInserted(0);
    }

    /**
     * 选择群组成员（邀请或添加）
     *
     * @param type : 0发起，1邀请
     */
    private void selectGroupMember(final int type) {
        List<VideoChatRoomUser> roomUsers = videoRoom.getRoomUsers();
        if (!members.isEmpty()) {
            final List<IUserMember> showUsers = new ArrayList<>(members);
            if (null != roomUsers && !roomUsers.isEmpty()) {
                for (int i = 0; i < showUsers.size(); i++) {
                    for (int j = 0; j < roomUsers.size(); j++) {
                        IUserMember user = showUsers.get(i);
                        VideoChatRoomUser roomUser = roomUsers.get(j);
                        if (StringUtil.isEquals(user.getUser().getUserCodeForDomain(), roomUser.getUserCodeForDomain())) {
                            showUsers.remove(i);
                            i--;
                            break;
                        }
                    }
                }
            }
            if (showUsers.isEmpty()) {
                showToast(getString(R.string.no_avaliable_member));
                return;
            }
            // 列表展示名字
            String[] userArr = new String[showUsers.size()];
            // 选中状态
            final boolean[] stateArr = new boolean[showUsers.size()];
            // 选中code结果
            final List<String> codeList = new ArrayList<>();
            for (int i = 0; i < stateArr.length; i++) {
                stateArr[i] = false;
                userArr[i] = showUsers.get(i).getUser().getUserName();
            }
            AlertDialog.Builder multiChooseDialog = new AlertDialog.Builder(this);
            multiChooseDialog.setTitle(R.string.invite);
            multiChooseDialog.setMultiChoiceItems(userArr, stateArr, new DialogInterface.OnMultiChoiceClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                    if (which >= showUsers.size()) {
                        return;
                    }
                    stateArr[which] = isChecked;
                    IUserMember user = showUsers.get(which);
                    if (isChecked) {
                        if (!codeList.contains(user.getUser().getUserCodeForDomain())) {
                            codeList.add(user.getUser().getUserCodeForDomain());
                        }
                    } else {
                        codeList.remove(user.getUser().getUserCodeForDomain());
                    }
                }
            });
            multiChooseDialog.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (type == 0) {
                        // 发起
                        mViewModel.startVideoChat(codeList);
                    } else {
                        // 邀请
                        mViewModel.addMember(codeList);
                    }
                }
            }).setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (type == 0) {
                        // 发起取消，则直接退出
                        finish();
                    }
                }
            });
            multiChooseDialog.show();
        }
    }

    @OnMessage
    public void addMasterrSuccess() {
        beMaster();
        formatMemberInfo();
    }

    @OnMessage
    public void addMenberSuccess() {
        beMember();
        formatMemberInfo();
    }

    private void applyHost(String msgStr) {
        ConfirmDialog.ConfirmDialogConfig confirmDialogConfig = new ConfirmDialog.ConfirmDialogConfig();
        confirmDialogConfig.setPositiveBtnTextColor(getResources().getColor(R.color.colorAccent));
        confirmDialogConfig.setTitle(getString(R.string.notification));
        confirmDialogConfig.setMsg(msgStr);
        confirmDialogConfig.setNegativeBtnText(getString(R.string.reject));
        confirmDialogConfig.setPositiveBtnText(getString(R.string.accept));
        confirmDialogConfig.setPositiveClick(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isFirstShow = true;
                if (handleType == 0) {
                    if (isMasterRecording) {

                        mViewModel.masterStopRecord();
                    }
                } else {
                    if (isMemberRecording) {

                        mViewModel.memberStopRecord();
                    }
                }

                mViewModel.acceptApply();
            }
        });
        confirmDialogConfig.setNegativeClick(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isFirstShow = true;
                mViewModel.refuseApply();

            }
        });
        DialogFragmentHelper.getConfirmDialog(confirmDialogConfig).show(GroupLiveTalkActivity.this);


    }

    //绑定控件成功
    @OnMessage
    public void bindCommSuccess() {

        if (videoRoom.hasActiveMembers()) {
            // 已经存在激活成员，标识聊天房间中有人已发起聊天
            if (videoRoom.isCalling()) {
                mViewModel.acceptCalling();
            } else {
                mViewModel.joinVideoRoom();
            }
        } else {
            if (userCodeList != null && !userCodeList.isEmpty()) {
                mViewModel.startVideoChat(userCodeList);
                // mBinding.menberNum.setText(userCodeList.size() + "");
            } else {
                selectGroupMember(0);
            }

        }

    }

    //绑定控件失败
    @OnMessage
    public void bindCommFailed(String str) {
        showToast(str);
    }

    //接收成功
    @OnMessage

    public void acceptSuccess() {
        beMember();
        formatMemberInfo();

    }

    //接受失败
    @OnMessage
    public void accpetFailed() {
        finish();
    }

    //假如成功
    @OnMessage
    public void joinRoomSuccess() {
        beMember();
        formatMemberInfo();

    }

    //假如失败
    @OnMessage
    public void joinRoomFailed(String msg) {
        showToast(msg);
    }

    //切换主播成功
    @OnMessage
    public void acceptHostExchage() {
        showToast(getString(R.string.agree_change_anchor));
        beMember();
        if (isMasterRecording) {

            mViewModel.masterStopRecord();
        }

    }

    //开始发起直播
    @OnMessage
    public void startVideoChat() {
        beMaster();
        formatMemberInfo();

    }

    //异常信息打印 前台提示
    @OnMessage
    public void failedMsg(String str) {
        showToast(str);
    }

    //异常信息打印 前台提示  并退出
    @OnMessage
    public void failedMsgFinish(String str) {
        showToast(str);
        mViewModel.quitChat();
    }

    //设置主播录制
    @OnMessage
    public void setMaterRcorder(boolean isMasterRecorder) {
        this.isMasterRecording = isMasterRecorder;

    }

    //设置成员在录像
    @OnMessage
    public void setMenberRecoder(boolean isMeneberRecoder) {
        this.isMemberRecording = isMeneberRecoder;
    }

    //根据当前处理人，进行 处理
    @OnMessage
    public void failedMsgComplete() {
        if (handleType == 0) {

            mViewModel.stopMasterRecord();
        } else {

            mViewModel.stopMemberPlay();
        }
    }

    //群主切换摄像头
    public void masterSwitchCamera(View view) {
        mViewModel.switchCamera(isMasterRecording);
    }

    //群主添加人员
    public void addMenberClick(View view) {
        // selectGroupMember(1);
//        LegoIntent intent = new LegoIntent(GroupLiveTalkActivity.this, GroupTalkSelectMenberActivity.class);
//        intent.putExtra("selectedCode", nSelectedCode);
//        intent.putExtra("select", true);
//        intent.putExtra("groupCode", nGroupCode);
//        intent.putExtra("groupCodeForDomain", nCodeForDomain);
//        startActivityForResult(intent, 1001);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001 && resultCode == 1002) {
            List<String> codeList = data.getStringArrayListExtra("addUserCodeList");
            mViewModel.addMember(codeList);
        }
    }

    //显示或隐藏提示消息
    public void displayMessage(View view) {
        if (mBinding.noticeTxt.getVisibility() == View.GONE) {
            mBinding.noticeTxt.setVisibility(View.VISIBLE);
        } else {
            mBinding.noticeTxt.setVisibility(View.GONE);
        }
    }

    //设置静音或
    public void setSilent(View view) {
        masterSilent = !masterSilent;
        //int imgId = masterSilent ? R.drawable.share_video_volum_press : R.drawable.share_video_volum_normal;
        //mBinding.speakLouderImg.setImageDrawable(ContextCompat.getDrawable(this, imgId));
        mViewModel.setMute(masterSilent);

    }

    public void setGroupmenberSilent(View view) {
        menbserSlient = !menbserSlient;
        int imgId = menbserSlient ? R.drawable.share_video_mute_press_flutter : R.drawable.share_video_mute_normal_flutter;
        //   mBinding.muteGroup.setImageDrawable(ContextCompat.getDrawable(this, imgId));

        mViewModel.setMute(menbserSlient);
    }

    //抓拍视频
    public void snapVideo(View view) {

        if (isIncomming) {
            if (!isMemberRecording) {
                mViewModel.memberStartRecord();
                // videoTape();
                nStopVideoSnap = false;
                vieoSnapTime = 0;
                // mBinding.shotScreen.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.share_video_record_press));
                // mBinding.relTimeRecorder.setVisibility(View.VISIBLE);

            } else {
                mViewModel.memberStopRecord();
                nStopVideoSnap = true;
                //   mBinding.shotScreen.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.share_video_record_normal));
                //  mBinding.relTimeRecorder.setVisibility(View.INVISIBLE);
            }

        } else {
            if (!isMasterRecording) {
                mViewModel.masterStartRecord();
                //videoTape();
                nStopVideoSnap = false;
                vieoSnapTime = 0;
                // mBinding.shotScreen.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.share_video_record_press));
                //  mBinding.relTimeRecorder.setVisibility(View.VISIBLE);
            } else {
                mViewModel.masterStopRecord();
                nStopVideoSnap = true;
                vieoSnapTime = 0;
                //  mBinding.shotScreen.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.share_video_record_normal));
                //  mBinding.relTimeRecorder.setVisibility(View.INVISIBLE);
            }

        }
    }

    //截屏
    public void shotSceen(View view) {

        mViewModel.snap(nScreenWidth, nScreenHeight);
    }

    //成员ptt对讲  播主不可以进行ptt对讲
    public void pttTalk(View view) {

    }

    /**
     * 展示更多人
     *
     * @param view
     */
    public void morePeopleClick(View view) {
        showPopWindow();
    }

    //申请成为主播
    public void applyHostRequest(View view) {
        mViewModel.applyMaster();

    }

    public void quitChatVideo(View view) {
        nVideoRender.recycle();
        mViewModel.quitChat();
        mViewModel.quitRoom();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        return;

    }

    public void jumpSoftBoard(View view) {
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).toggleSoftInput(0, 2);
        showDropwindows(825);
        barrageEdit.setFocusable(true);
        barrageEdit.requestFocus();
        barrageEdit.setFocusableInTouchMode(true);
        SoftKeyBoardListener.setListener(this, new SoftKeyBoardListener.OnSoftKeyBoardChangeListener() {
            @Override
            public void keyBoardShow(int height) {

            }

            @Override
            public void keyBoardHide(int height) {
                popupWindow.dismiss();

            }
        });
    }

    /**
     * @param view
     */
    public void sendBrageMsg(View view) {
        String msg = barrageEdit.getText().toString();
        if (!StringUtil.isEmpty(msg)) {
            mViewModel.sendMsg(msg);
        }
        barrageEdit.setText("");
        hideSoftKeyboard(barrageEdit);

    }

    public void hideSoftKeyboard(View v) {

        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(v.getWindowToken(), 0);
        getWindow().setSoftInputMode(2);

    }

    private void showDropwindows(int height) {
        popupWindow.showAtLocation(mBinding.noticeTxt, Gravity.LEFT, 100, 100);


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        nVideoRender.recycle();
        mViewModel.quitChat();
        //mMediaService.setAudioCaptureChannel(false);
        mViewModel.quitRoom();
        mViewModel.unRegisterAbort();
        DataManager.getInstance().getSelectTalkChatCodes().clear();
    }
}
