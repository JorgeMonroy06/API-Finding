package com.kedacom.flutter_sxtapp.viewmodel;

import com.kedacom.basic.common.util.Optional;
import com.kedacom.flutter_sxtapp.util.FileUtils;
import com.kedacom.lego.MR;
import com.kedacom.uc.sdk.Abortable;
import com.kedacom.uc.sdk.AbortableFuture;
import com.kedacom.uc.sdk.RequestCallback;
import com.kedacom.uc.sdk.bean.basic.ResultCode;
import com.kedacom.uc.sdk.exception.ResponseException;
import com.kedacom.uc.sdk.generic.constant.SessionType;
import com.kedacom.uc.sdk.impl.SdkImpl;
import com.kedacom.uc.sdk.meeting.MeetingService;
import com.kedacom.uc.sdk.meeting.model.IMeeting;
import com.kedacom.uc.sdk.vchat.VideoTalkService;
import com.kedacom.uc.sdk.vchat.model.VideoCapture;
import com.kedacom.uc.sdk.vchat.model.VideoChatRoom;
import com.kedacom.uc.sdk.vchat.model.VideoRender;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
public class MeetingViewModel extends BaseViewModel {

    private List<Abortable> abortables = new ArrayList<>();
    public IMeeting iMeeting;
    public VideoChatRoom videoChatRoom;
    private int cameraId = 1;
    private boolean isJoinMeetingSuccess;

    public void getMeeting(String meetingId) {
        MeetingService meetingService = SdkImpl.getInstance().getService(MeetingService.class);
        AbortableFuture<Optional<IMeeting>> queryMeetingFuture = meetingService.queryMeetingStateFromServer(meetingId);
        queryMeetingFuture.setCallback(new RequestCallback<Optional<IMeeting>>() {
            @Override
            public void onSuccess(Optional<IMeeting> iMeetingOptional) {
                if (iMeetingOptional.isPresent()) {
                    iMeeting = iMeetingOptional.get();
                    logger.info("MeetingViewModel getMeeting success , {}", iMeeting);
                    sendMessage(MR.MeetingActivity_queryMeetingSuccess, iMeeting);
                } else {
                    logger.info("MeetingViewModel getMeeting is null");
                    sendMessage(MR.MeetingActivity_queryMeetingFailed, "未查询到会议信息");
                }
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.error("MeetingViewModel getMeeting failed", throwable);
                sendMessage(MR.MeetingActivity_queryMeetingFailed, "查询会议信息失败 " + throwable.getMessage());
            }
        });
        abortables.add(queryMeetingFuture);
    }

    public void getMeetingByLinkId(String linkId) {
        MeetingService meetingService = SdkImpl.getInstance().getService(MeetingService.class);
        AbortableFuture<Optional<IMeeting>> queryMeetingFuture = meetingService.queryMeetingFromServerByLinkId(linkId);
        queryMeetingFuture.setCallback(new RequestCallback<Optional<IMeeting>>() {
            @Override
            public void onSuccess(Optional<IMeeting> iMeetingOptional) {
                if (iMeetingOptional.isPresent()) {
                    iMeeting = iMeetingOptional.get();
                    logger.info("MeetingViewModel getMeetingByLinkId success , {}", iMeeting);
                    sendMessage(MR.MeetingActivity_queryMeetingSuccess, iMeeting);
                } else {
                    logger.info("MeetingViewModel getMeetingByLinkId is null");
                    sendMessage(MR.MeetingActivity_queryMeetingFailed, "未查询到会议信息");
                }
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.error("MeetingViewModel getMeeting failed", throwable);
                sendMessage(MR.MeetingActivity_queryMeetingFailed, "查询会议信息失败 " + throwable.getMessage());
            }
        });
        abortables.add(queryMeetingFuture);
    }

    public void joinMeeting(IMeeting meeting) {
        logger.info("MeetingViewModel joinMeeting start");
        MeetingService meetingService = SdkImpl.getInstance().getService(MeetingService.class);
        AbortableFuture<Optional<Void>> joinMeetingFuture = meetingService.joinMeeting(meeting.getMeetingId());
        joinMeetingFuture.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                logger.info("MeetingViewModel joinMeeting success");
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.error("MeetingViewModel joinMeeting failed", throwable);
                sendMessage(MR.MeetingActivity_joinMeetingFailed, "申请入会失败 " + throwable.getMessage());
            }
        });
        abortables.add(joinMeetingFuture);
    }

    public void queryRoomInfo() {
        VideoTalkService talkService = SdkImpl.getInstance().getService(VideoTalkService.class);
        AbortableFuture<Optional<VideoChatRoom>> future = talkService.getRoom(iMeeting.getInitiator().getCodeForDomain(), SessionType.MEETING);
        future.setCallback(new RequestCallback<Optional<VideoChatRoom>>() {
            @Override
            public void onSuccess(Optional<VideoChatRoom> videoChatRoomOptional) {
                videoChatRoom = videoChatRoomOptional.get();
                if (videoChatRoomOptional.isPresent()) {
                    logger.info("MeetingViewModel queryRoomInfo success");
                    videoChatRoom = videoChatRoomOptional.get();
                    sendMessage(MR.MeetingActivity_queryRoomInfoSuccess, videoChatRoom);
                } else {
                    logger.info("MeetingViewModel getMeeting data is null");
                    sendMessage(MR.MeetingActivity_queryRoomInfoFailed, "未查询到房间信息");
                }
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.info("MeetingViewModel queryRoomInfo failed {}", throwable.getMessage());
                sendMessage(MR.MeetingActivity_queryRoomInfoFailed, "查询房间信息失败 " + throwable.getMessage());
            }
        });
        abortables.add(future);
    }

    /**
     * 绑定视频对讲组件
     */
    public void bindCaptureAndRender(boolean isShare, VideoCapture videoCapture, VideoRender videoRender) {
        VideoTalkService talkService = SdkImpl.getInstance().getService(VideoTalkService.class);
        AbortableFuture<Optional<Void>> future = talkService.bindCaptureAndRender(videoChatRoom.getRoomId(), videoCapture, videoRender);
        future.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                logger.info("MeetingViewModel bindCaptureAndRender onSuccess  room={}", videoChatRoom);
                startVideoTalk(isShare);
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.error("MeetingViewModel bindCaptureAndRender onFailed ", throwable);
                sendMessage(MR.MeetingActivity_joinRoomFailed, "查询房间信息失败 " + FileUtils.getErrMsg(throwable.getMessage()));
            }
        });
        abortables.add(future);
    }

    /**
     * 发起邀请
     */
    private void startVideoTalk(boolean isShare) {
        VideoTalkService talkService = SdkImpl.getInstance().getService(VideoTalkService.class);
        logger.info("MeetingViewModel acceptBidVideoInvite roomId : {} ,meetingId : {} ", videoChatRoom.getRoomId(), iMeeting.getMeetingId());
        AbortableFuture<Optional<Void>> future;
        if (isShare) {
            future = talkService.acceptBidVideoInvite(videoChatRoom.getRoomId(), true);
        } else {
            future = talkService.startBidVideoChat(videoChatRoom.getRoomId(), true, iMeeting.getMeetingId());
        }
        future.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                logger.info("MeetingViewModel VideoCall startBidVideoChat onSuccess ");
                sendEmptyMessage(MR.MeetingActivity_joinRoomSuccess);
                isJoinMeetingSuccess = true;
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.error("MeetingViewModel startBidVideoChat onFailed ", throwable);
                if (throwable instanceof ResponseException) {
                    ResponseException error = (ResponseException) throwable;
                    if (error.getCode() == ResultCode.UNSUPPORTED_OPERATION_EXCEPTION || error.getCode() == ResultCode.REPEAT_INVITE) {
                        sendMessage(MR.MeetingActivity_joinRoomFailed, "加入会议失败 " + FileUtils.getErrMsg(throwable.getMessage()));
                        return;
                    }
                }
                sendMessage(MR.MeetingActivity_joinRoomFailed, "加入会议失败 " + throwable.getMessage());
            }
        });
        abortables.add(future);
    }


    //切换相机
    public void switchCamera() {
        int linkCameraId = Math.abs(cameraId - 1);
        VideoTalkService videoTalkService = SdkImpl.getInstance().getService(VideoTalkService.class);
        AbortableFuture<Optional<Void>> future = videoTalkService.switchCamera(videoChatRoom.getRoomId(), linkCameraId);
        future.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                showToast("摄像头切换成功");
                cameraId = linkCameraId;
            }

            @Override
            public void onFailed(Throwable throwable) {
                showToast("摄像头切换失败");
            }
        });
        abortables.add(future);
    }

    public void callFinish() {//通话结束
        if (videoChatRoom == null) {
            sendEmptyMessage(MR.MeetingActivity_finishCall);
            return;
        }
        logger.info("MeetingActivity quitBidVideoRoom");
        VideoTalkService videoTalkService = SdkImpl.getInstance().getService(VideoTalkService.class);
        videoTalkService.quitBidVideoRoom(videoChatRoom.getRoomId()).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                logger.info("MeetingActivity quitBidVideoRoom  onSuccess ");
                sendEmptyMessage(MR.MeetingActivity_finishCall);
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.error("MeetingActivity quitBidVideoRoom onFailed ", throwable);
                sendEmptyMessage(MR.MeetingActivity_finishCall);
            }
        });
    }

    public void cancelJoinMeeting() {
        if (iMeeting == null) return;
//        if (iMeeting == null && isJoinMeetingSuccess) return;
        MeetingService meetingService = SdkImpl.getInstance().getService(MeetingService.class);
        AbortableFuture<Optional<Void>> joinMeetingFuture = meetingService.cancelJoinMeeting(iMeeting.getMeetingId());
        joinMeetingFuture.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                logger.info("MeetingActivity cancelJoinMeeting  onSuccess ");
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.error("MeetingActivity cancelJoinMeeting onFailed ", throwable);
            }
        });
        abortables.add(joinMeetingFuture);
    }

    public String getFormatTime(long startTime) {
        long diff = System.currentTimeMillis() - startTime;
        StringBuffer timeStr = new StringBuffer();
        diff = diff / 1000;
        long h = 0;
        long m = 0;
        long s = 0;
        if (diff >= 60 * 60) {
            h = diff / (60 * 60);
            m = diff % (60 * 60) / 60;
            s = diff % (60 * 60) % 60;
        } else if (diff >= 60) {
            m = diff % (60 * 60) / 60;
            s = diff % (60 * 60) % 60;
        } else {
            s = diff % (60 * 60) % 60;
        }

        DecimalFormat decimalFormat = new DecimalFormat("00");
        String format = decimalFormat.format(m);

        String format2 = decimalFormat.format(s);
        if (h > 0)
            timeStr.append(h).append(":");
        timeStr.append(format).append(":");
        timeStr.append(format2);
        return timeStr.toString();
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (abortables != null) {
            for (Abortable a : abortables) {
                a.abort();
            }
        }
    }


}
