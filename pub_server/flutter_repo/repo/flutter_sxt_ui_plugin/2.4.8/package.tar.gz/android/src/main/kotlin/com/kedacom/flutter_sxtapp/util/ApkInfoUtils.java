package com.kedacom.flutter_sxtapp.util;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import androidx.core.content.ContextCompat;

import com.kedacom.lego.fast.util.ToastUtil;
import com.kedacom.util.AppUtil;
import com.kedacom.util.LegoLog;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import static android.content.Context.ACTIVITY_SERVICE;

/**
 * author: qiuzhiyuan
 * On: 2018/11/19 10:53 星期一
 */
public class ApkInfoUtils {

    /**
     * 获取软件版本号
     *
     * @param context
     * @return
     */
    public static int getVersionCode(Context context) {
        int versionCode = 0;
        try {
            versionCode = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0).versionCode;//PackageManager.COMPONENT_ENABLED_STATE_DEFAULT
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return versionCode;
    }

    /**
     * 获取软件版本号
     *
     * @param context
     * @return
     */
    public static int getVersionCode(String pkgName, Context context) {
        int versionCode = 0;
        try {
            versionCode = context.getPackageManager().getPackageInfo(pkgName, 0).versionCode;//PackageManager.COMPONENT_ENABLED_STATE_DEFAULT
        } catch (PackageManager.NameNotFoundException e) {

        }
        return versionCode;
    }

    /**
     * 获取版本名称
     *
     * @param context
     * @return
     */
    public static String getVersionName(Context context) {
        String versionName = "";
        try {
            versionName = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return versionName;
    }

    /**
     * 获取未安装的apk的启动页名称
     *
     * @param ctx
     * @param archiveFilePath 未安装的apk文件的全路径
     * @return
     */
    public static String getUninstallAPKLauncherActivityName(Context ctx, String archiveFilePath) {
        PackageManager pm = ctx.getPackageManager();
        PackageInfo pakinfo = pm.getPackageArchiveInfo(archiveFilePath, PackageManager.GET_ACTIVITIES);

        // 设置<intent-filter>标签内需要满足的条件
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);

        String launcherActivityName = null;
        if (pakinfo != null && pakinfo.activities != null && pakinfo.activities.length > 0) {
            launcherActivityName = pakinfo.activities[0].name;//获取插件中第一个activity
        }
        return launcherActivityName;
    }

    /**
     * 停止app
     *
     * @param context
     * @param packageName
     */
    public static void killApp(Context context, String packageName) {
        ActivityManager am = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);
//        am.killBackgroundProcesses(packageName);

        List<ActivityManager.RunningAppProcessInfo> infos = am.getRunningAppProcesses();
        for (ActivityManager.RunningAppProcessInfo info : infos) {
            if (info.processName.equals(packageName)) {
                Process.killProcess(info.pid);
            }
        }

//        try {
//            Process process = Runtime.getRuntime().exec("su");
//            OutputStream out = process.getOutputStream();
//            String cmd = "am force-stop " + packageName + " \n";
//            out.write(cmd.getBytes());
//            out.flush();
//            out.close();
//
//            InputStream fis = process.getInputStream();
//            //用一个读输出流类去读
//            InputStreamReader isr = new InputStreamReader(fis);
//            //用缓冲器读行
//            BufferedReader br = new BufferedReader(isr);
//            String line = null;
//            //直到读完为止 目的就是要阻塞当前的线程到命令结束的时间
//            while ((line = br.readLine()) != null) {
//                Log.e("", line);
//            }
//            process = null;
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }

    /**
     * 方法描述：判断某一应用是否正在运行
     * Created by cafeting on 2017/2/4.
     *
     * @param context     上下文
     * @param packageName 应用的包名
     * @return true 表示正在运行，false 表示没有运行
     */
    public static boolean isAppRunning(Context context, String packageName) {
        ActivityManager am = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> list = am.getRunningTasks(100);
        if (list.size() <= 0) {
            return false;
        }
        for (ActivityManager.RunningTaskInfo info : list) {
            if (info.baseActivity.getPackageName().equals(packageName)) {
                am.moveTaskToFront(info.id, 0);
                return true;
            }
        }
        return false;
    }


    public static boolean isAppExist(Context context, String packageName) {
        if (TextUtils.isEmpty(packageName)) {
            ToastUtil.showDefaultToast("packageName do not allow empty!");
            return false;
        }
        PackageManager pm = context.getPackageManager();
        List<PackageInfo> infoList = pm.getInstalledPackages(PackageManager.GET_UNINSTALLED_PACKAGES);
        Iterator var4 = infoList.iterator();

        PackageInfo info;
        do {
            if (!var4.hasNext()) {
                return false;
            }

            info = (PackageInfo) var4.next();
        } while (!packageName.equalsIgnoreCase(info.packageName));

        return true;
    }


    public boolean hasApplication(Context context, String packageName) {
        PackageManager packageManager = context.getPackageManager();

        //获取系统中安装的应用包的信息
        List<PackageInfo> listPackageInfo = packageManager.getInstalledPackages(0);
        for (int i = 0; i < listPackageInfo.size(); i++) {
            if (listPackageInfo.get(i).packageName.equalsIgnoreCase(packageName)) {
                return true;
            }
        }
        return false;

    }

    //获取已安装应用的 uid，-1 表示未安装此应用或程序异常
    public static int getPackageUid(Context context, String packageName) {
        try {
            ApplicationInfo applicationInfo = context.getPackageManager().getApplicationInfo(packageName, 0);
            if (applicationInfo != null) {
                Log.d("", " " + applicationInfo.uid);
                return applicationInfo.uid;
            }
        } catch (Exception e) {
            return -1;
        }
        return -1;
    }

    /**
     * 判断某一 uid 的程序是否有正在运行的进程，即是否存活
     * Created by cafeting on 2017/2/4.
     *
     * @param context     上下文
     * @param packageName
     * @return true 表示正在运行，false 表示没有运行
     */
    public static boolean isProcessRunning(Context context, String packageName) {
        int uid = getPackageUid(context, packageName);
        ActivityManager am = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> runningServiceInfos = am.getRunningServices(200);
        if (runningServiceInfos.size() > 0) {
            for (ActivityManager.RunningServiceInfo appProcess : runningServiceInfos) {
                if (uid == appProcess.uid) {
                    return true;
                }
            }
        }
        return false;
    }

    public static void exitApp() {
        Process.killProcess(Process.myPid()); //获取PID
        System.exit(0);
    }


    public static void restartApp() {
        Context context = AppUtil.getApp();
        final Intent intent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(intent);
    }


    /**
     * 重启本应用
     */
    public static void restartApplication() {
        Context context = AppUtil.getApp();
        Intent intent = AppUtil.getApp().getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(intent);
        Process.killProcess(Process.myPid());
        System.exit(0);

//        Intent intent = new Intent(mContext, MainActivity.class);
//        PendingIntent restartIntent = PendingIntent.getActivity(mContext, 0, intent, Intent.FLAG_ACTIVITY_NEW_TASK);
//        AlarmManager mgr = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);
//        mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 1000, restartIntent);
//        android.os.Process.killProcess(android.os.Process.myPid());


//        //"android.permission.KILL_BACKGROUND_PROCESSES"
//        ActivityManager manager = (ActivityManager)context.getSystemService(ACTIVITY_SERVICE);
//        manager.killBackgroundProcesses(context.getPackageName());

    }

    /**
     * 获取手机IMEI
     * International Mobile Equipment Identity 国际移动设备识别码
     *
     * @param context
     * @return
     */
    public static final String getIMEI(Context context) {
        try {
            //实例化TelephonyManager对象
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            //获取IMEI号
            @SuppressLint("MissingPermission") String imei = telephonyManager.getDeviceId();
            if (imei == null) {
                imei = "";
            }
            LegoLog.d(" imei : " + imei);
            return imei;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }

    }

    /**
     * 获取手机IMSI
     * International Mobile Subscriber Identification Number  国际移动用户识别码 存储在SIM卡中
     */
    public static String getIMSI(Context context) {
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            //获取IMSI号
            @SuppressLint("MissingPermission") String imsi = telephonyManager.getSubscriberId();
            if (null == imsi) {
                imsi = "";
            }
            return imsi;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    /**
     * 获取当前进程的名字，一般就是当前app的包名
     *
     * @param context 当前上下文
     * @return 返回进程的名字
     */
    public static String getCurrentProcessName(Context context) {
        int pid = Process.myPid(); // Returns the identifier of this process
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List list = activityManager.getRunningAppProcesses();
        Iterator i = list.iterator();
        while (i.hasNext()) {
            ActivityManager.RunningAppProcessInfo info = (ActivityManager.RunningAppProcessInfo) (i.next());
            try {
                if (info.pid == pid) {
                    // 根据进程的信息获取当前进程的名字
                    return info.processName;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        // 没有匹配的项，返回为null
        return null;
    }


    /**
     * 销毁指定名称的进程
     *
     * @param processName
     * @param context
     */
    public static void killProcessByName(String processName, Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        activityManager.killBackgroundProcesses(processName);
    }

    //当前应用是否处于前台
    public static boolean isForeground(Context context) {
        if (context != null) {
            ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            List<ActivityManager.RunningAppProcessInfo> processes = activityManager.getRunningAppProcesses();
            if (processes != null) {
                for (ActivityManager.RunningAppProcessInfo processInfo : processes) {
                    if (processInfo.processName.equals(context.getPackageName())) {
                        if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    //判断activity是否在前台显示
    public static boolean isForeground(Context context, String... className) {
        if (context == null || className == null) {
            return false;
        }

        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> list = am.getRunningTasks(1);
        if (list != null && list.size() > 0) {
            ComponentName cpn = list.get(0).topActivity;
            for (int i = 0; i < className.length; i++) {
                if (className[i].equals(cpn.getClassName())) {
                    return true;
                }
            }
        }

        return false;
    }


    public static void openNoLauncherApp(Context nActivity, String packageName) {
        if (isAppRunning(nActivity, packageName)) {
            return;
        }

        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.setPackage(packageName);

        List<ResolveInfo> resolveInfos = nActivity.getPackageManager().queryIntentActivities(intent, 0);

        if (resolveInfos == null || resolveInfos.size() == 0) {
            throw new ActivityNotFoundException();
        }

        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        intent.setFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
                | Intent.FLAG_ACTIVITY_NEW_TASK);

        ComponentName cn = new ComponentName(packageName, resolveInfos.get(0).activityInfo.name);
        intent.setComponent(cn);

        nActivity.getApplicationContext().startActivity(intent);

    }

    /**
     * 启动第三方应用
     *
     * @param context
     * @param scheme
     * @param data
     */
    public static void openLauncherApp(Context context, String scheme, String data) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme));
            intent.putExtra("data", data);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            ToastUtil.showDefaultToast("暂未安装相关应用!");
        }
//        Intent intent = new Intent(Intent.ACTION_MAIN);
//        intent.setPackage(packageName);
//
//        List<ResolveInfo> resolveInfos = context.getPackageManager().queryIntentActivities(intent, 0);
//
//        if (resolveInfos == null || resolveInfos.size() == 0) {
//            throw new ActivityNotFoundException();
//        }
//        intent.addCategory(Intent.CATEGORY_LAUNCHER);
//        intent.setFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
//                | Intent.FLAG_ACTIVITY_NEW_TASK);
//        //intent.setClassName(context, targetActivity);
//        intent.putExtra("data", data);
//        ComponentName cn = new ComponentName(packageName, targetActivity);
//        intent.setComponent(cn);
//        context.getApplicationContext().startActivity(intent);
    }


    public boolean isAvilible(Context context, String packageName) {
        final PackageManager packageManager = context.getPackageManager();//获取packagemanager
        List<PackageInfo> packageInfos = packageManager.getInstalledPackages(0);//获取所有已安装程序的包信息
        List<String> pName = new ArrayList<String>();//用于存储所有已安装程序的包名
        //从pinfo中将包名字逐一取出，压入pName list中
        if (packageInfos != null) {
            for (int i = 0; i < packageInfos.size(); i++) {
                String pn = packageInfos.get(i).packageName;
                pName.add(pn);
            }
        }
        return pName.contains(packageName);//判断pName中是否有目标程序的包名，有TRUE，没有FALSE
    }

    /**
     * 根据应用唯一标识 获取应用icon
     *
     * @param applicationId
     * @return
     */
    public static Drawable getAppIcon(String applicationId) {
        PackageManager packageManager = AppUtil.getApp().getPackageManager();
        List<PackageInfo> packages = packageManager.getInstalledPackages(0);
        Drawable icon = null;
        for (int i = 0; i < packages.size(); i++) {
            PackageInfo packageInfo = packages.get(i);
//            AppInfo tmpInfo = new AppInfo();
//            tmpInfo.appName = packageInfo.applicationInfo.loadLabel(packageManager).toString();
//            tmpInfo.versionName = packageInfo.versionName;
//            tmpInfo.versionCode = packageInfo.versionCode;
            if (!TextUtils.isEmpty(packageInfo.packageName)
                    && packageInfo.packageName.equals(applicationId)) {
                icon = packageInfo.applicationInfo.loadIcon(packageManager);
            }
        }
        return icon;
    }

    public static void killAppSelf(Activity activity) {
        activity.finishAffinity();
        Process.killProcess(Process.myPid());
//        System.exit(0);
    }

    /**
     * 获取应用图标
     *
     * @param context
     * @param iconId
     * @return
     */
    public static Bitmap getAppIconBitmap(Context context, int iconId) {
        try {
            Drawable icon = ContextCompat.getDrawable(context, iconId);
            if (icon == null) {
                return null;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && icon instanceof AdaptiveIconDrawable) {
                Bitmap bitmap = Bitmap.createBitmap(icon.getIntrinsicWidth(), icon.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bitmap);
                icon.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
                icon.draw(canvas);
                return bitmap;
            } else {
                return ((BitmapDrawable) icon).getBitmap();
            }
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 获取应用图标
     *
     * @param drawable
     * @return
     */
    public static Bitmap getAppIconBitmap(Drawable drawable) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    && drawable instanceof AdaptiveIconDrawable) {
                Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(),
                        drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bitmap);
                drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
                drawable.draw(canvas);
                return bitmap;
            } else {
                return ((BitmapDrawable) drawable).getBitmap();
            }
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 获取Application 的 metadata
     *
     * @param key
     * @return
     */
    public static String getPlaceholder(String key) {
        ApplicationInfo applicationInfo = null;
        try {
            applicationInfo = AppUtil.getApp().getPackageManager()
                    .getApplicationInfo(AppUtil.getApp().getPackageName(), PackageManager.GET_META_DATA);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (applicationInfo == null) {
            return null;
        }
        String value = applicationInfo.metaData.getString(key);
        return value;
    }


    public static boolean checkAppInstalled(Context context, String pkgName) {
        if (pkgName == null || pkgName.isEmpty()) {
            return false;
        }
        PackageInfo packageInfo;
        try {
            packageInfo = context.getPackageManager().getPackageInfo(pkgName, 0);
        } catch (PackageManager.NameNotFoundException e) {
            packageInfo = null;
            e.printStackTrace();
        }
        if (packageInfo == null) {
            return false;
        } else {
            return true;//true为安装了，false为未安装
        }
    }


}
