package com.kedacom.flutter_sxtapp.receiver;

import com.kedacom.basic.common.util.StringUtil;

/**
 * 广播action
 */
public enum BroadcastAction {

    DEFAULT("DEFAULT"),
    /*************************应用内广播*************************/
    // 申请讲话
    START_SPEAK("LocalBroadcast:com.kedacom.smartciy.ptt.start_speak"),                   // 开始讲话
    SPEAK_SUCCESS("LocalBroadcast:com.kedacom.smartciy.ptt.start_speak_success"),                   // 开始讲话成功
    SPEAK_FAIL("LocalBroadcast:com.kedacom.smartciy.ptt.speak_fail"),                     // 申请讲话失败

    // 结束讲话
    END_SPEAK("LocalBroadcast:com.kedacom.smartciy.ptt.end_speak"),                       // 结束讲话
    END_SPEAK_SUCCESS("LocalBroadcast:com.kedacom.smartciy.ptt.end_speak_success"),       // 结束讲话成功
    END_SPEAK_ERR("LocalBroadcast:com.kedacom.smartciy.ptt.end_speak_err"),               // 结束讲话失败
    /**************************普通广播**************************/
    PTT_DOWN("android.intent.action.PTT.down"),
    PTT_UP("android.intent.action.PTT.up"),
    ;
    String action;

    BroadcastAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public static BroadcastAction valueOfBroadcastAction(String value) {
        for (BroadcastAction type : values()) {
            if (StringUtil.isEquals(value, type.getAction())) {
                return type;
            }
        }
        return DEFAULT;
    }
}
