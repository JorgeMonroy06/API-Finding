package com.kedacom.flutter_sxtapp.util;

import android.text.TextUtils;

import com.kedacom.flutter_sxtapp.manager.FlutterManager;
import com.kedacom.flutter_sxtapp.model.Contact;

/**
 * @author wangbaoshun
 */
public class FileUtils {

    //截取错误信息
    public static String getErrMsg(String errMsg) {
        String restultStr = "";
        if (errMsg != null && errMsg.contains("errorMsg")) {
            restultStr = errMsg.split("errorMsg = ")[1];
        }
        return restultStr;

    }

    public static String getAvatarUrl(Contact contact) {
        if (!TextUtils.isEmpty(contact.getPersonalPortrait())) {
            return FlutterManager.Companion.getInstance().getAvatarBaseUrl() + contact.getPersonalPortrait();
        } else if (!TextUtils.isEmpty(contact.getHeadPortrait())) {
            return contact.getHeadPortrait();
        }
        return "";
    }
}
