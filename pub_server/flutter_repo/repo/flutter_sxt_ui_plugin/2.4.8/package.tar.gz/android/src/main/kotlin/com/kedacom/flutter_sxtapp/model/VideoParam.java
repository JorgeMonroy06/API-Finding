package com.kedacom.flutter_sxtapp.model;

//双向音视频的 宽和高
public class VideoParam {

    //新媒体过来的宽
    private int nVideoWidht;
    //新媒体的视频高度
    private int nVideoHeight;

    public VideoParam(int nVideoWidht, int nVideoHeight) {
        this.nVideoWidht = nVideoWidht;
        this.nVideoHeight = nVideoHeight;
    }

    public int getnVideoWidht() {
        return nVideoWidht;
    }

    public int getnVideoHeight() {
        return nVideoHeight;
    }
}
