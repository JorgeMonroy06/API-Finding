package com.kedacom.flutter_sxtapp.viewmodel;

import com.kedacom.lego.fast.util.ToastUtil;
import com.kedacom.lego.fast.view.LegoFastViewModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class BaseViewModel extends LegoFastViewModel {

    protected Logger logger = LoggerFactory.getLogger(this.getClass());

    public BaseViewModel() {

    }


    @Override
    public void showToast(String message) {
        ToastUtil.showDefaultToast(message);
    }
}
