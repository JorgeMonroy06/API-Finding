package com.kedacom.flutter_sxt_ui_plugin;


import com.kedacom.flutter_sxtapp.R;

import java.util.List;

public class UIOptions {


    public static UIOptions DEFAULT = new UIOptions();

    //应用名称
    public String appName = "";
    //标题栏高度,单位dp
    public int titleHeight = 46;
    //标题栏背景图片资源
    public int titleBackgroundRes = 0;
    //标题栏文字大小，单位sp
    public float titleTextSize = 17F;
    //标题栏文字颜色
    public int titleTextColor = android.R.color.white;
    //回退按钮背景资源
    public int backBtnBackgroundRes = 0;
    //通知栏上app大图标
    public int notifyBarRes = R.mipmap.ic_ptt_notifaction_flutter;
    //通知栏上app小图标
    public int notifyIconRes = R.mipmap.ic_notification_flutter;
    //界面水印
    public boolean isShowWaterMarker = false;
    //水印文字
    public List<String> labelList;
    //水印文字大小
    public int waterMarkerTextSize = 19;
    //默认男性头像
    public int defaultManAvatarRes = R.mipmap.ic_default_avatar_man_flutter;
    //默认女性头像
    public int defaultFemaleAvatarRes = R.mipmap.ic_default_avatar_female_flutter;
    //聊天发送功能配置
    public ChatLayoutSetting chatLayoutSetting = new ChatLayoutSetting();
    //会话界面的聊天人的名词字体是否加粗
    public boolean conversNameBold = false;
    /**
     * 双向音视频是否需要自动接听
     */
    public boolean autoAccept = false;
    //会话界面标题栏是否显示
    public boolean showConversationFragmentTitle = true;
    //视频通话界面展示消息通知
    public boolean videoCallShowMsgNotify = false;
    //只接受主动入会音视频通话
    public boolean meetingFilter = false;
    //音视频通话不显示画面
    public boolean noVideoCallFrame = false;
    //只使用GPS定位
    public boolean onlyGPS = false;

    public static class ChatLayoutSetting {

        //图片
        public boolean picture = true;
        //拍摄
        public boolean photo = true;
        //文件
        public boolean file = true;
        //位置
        public boolean location = true;
        //对讲
        public boolean ptt = true;
        //音视频通话
        public boolean doubleVideo = true;
        // 群直播
        public boolean groupLive = false;
        //戳一戳
        public boolean poke = true;
        //待办
        public boolean todoTask = true;
        //群聊信息界面只展示人员
        public boolean groupOnlyChat = false;
        //多方会议
        public boolean multiMeeting = false;
        //单聊不能创建群组
        public boolean singleChatCreateGroup = true;
        //群聊不能加人
        public boolean groupChatAddUser = true;

    }
}
