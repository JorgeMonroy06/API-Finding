package com.kedacom.flutter_sxtapp.manager;

import com.kedacom.basic.app.activity.ActivityStack;
import com.kedacom.basic.common.util.Optional;
import com.kedacom.uc.common.rx.ScheduleTransformer;
import com.kedacom.uc.sdk.auth.model.IAccount;
import com.kedacom.uc.sdk.generic.constant.ConnectionState;
import com.kedacom.uc.sdk.generic.model.SessionIdentity;
import com.kedacom.uc.sdk.impl.SdkImpl;
import com.kedacom.uc.sdk.ptt.RxPttTalkService;
import com.kedacom.uc.sdk.ptt.model.AudioChatRoom;
import com.kedacom.uc.sdk.rx.ResponseFunc;
import com.kedacom.uc.sdk.rx.RxHelper;
import com.kedacom.uc.transmit.socket.SignalSocketReq;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;

public class PttTalkHelper {


    private Logger logger = LoggerFactory.getLogger(PttTalkHelper.class);
    private static PttTalkHelper instance;
    private AudioChatRoom mAudioRoom;
    private CompositeDisposable sessionCompositeDisposable;
    private RxPttTalkService pttService;
    private String loginCode = "";

    private PttTalkHelper() {
        pttService = SdkImpl.getInstance().getService(RxPttTalkService.class);
        sessionCompositeDisposable = new CompositeDisposable();
    }

    public static PttTalkHelper getInstance() {
        if (instance == null) {
            synchronized (ActivityStack.class) {
                if (instance == null) {
                    instance = new PttTalkHelper();
                }
            }
        }
        return instance;
    }

    public AudioChatRoom getAudioRoom() {
        return mAudioRoom;
    }

    public void setAudioRoom(AudioChatRoom mAudioRoom) {
        this.mAudioRoom = mAudioRoom;
    }

    public void init() {
        IAccount iAccount = SdkImpl.getInstance().getUserSession().orNull();
        if (null != iAccount) {
            if (!loginCode.equals(iAccount.getUserCode())) {
                mAudioRoom = null;
                loginCode = iAccount.getUserCode();
            }
        }
//        if (mAudioRoom == null) {
//            SdkImpl.getInstance().getService(RxGroupService.class)
//                    .rxCheckActiveGroup()
//                    .compose(ScheduleTransformer.get())
//                    .subscribe(RxHelper.NOTHING, RxHelper.DEFAULT_EXCEPTION_HANDLER);
//        }
        sessionCompositeDisposable.add(onForwardSessionSuccess());
    }

    /**
     * 监听信令连接成功
     *
     * @return
     */
    private Disposable onForwardSessionSuccess() {
        return SignalSocketReq.getInstance()
                .listenerConnectionState()
                .flatMap((Function<Optional<ConnectionState>, ObservableSource<Optional<SessionIdentity>>>) connectionStateOptional -> {
                    if (connectionStateOptional.isPresent() && connectionStateOptional.get() == ConnectionState.CONNECTED) {
                        logger.debug("get active talker.");
                        // 信令为链路连接成功信令，读取缓存的激活组信息
                        if (mAudioRoom == null) {
                            return Observable.just(Optional.absent());
                        } else {
                            return Observable.just(Optional.of(mAudioRoom.getTalker()));
                        }
                    }
                    return Observable.just(Optional.absent());
                })
                .flatMap((Function<Optional<SessionIdentity>, ObservableSource<Optional<AudioChatRoom>>>) sessionIdentityOptional -> {
                    if (sessionIdentityOptional.isPresent() && null != pttService) {
                        logger.debug("show active talker : {}", sessionIdentityOptional.get());
                        // 如果激活组和对讲服务都存在，那么就获取对讲房间
                        return pttService.rxGetRoom(sessionIdentityOptional.get().getCodeForDomain(), sessionIdentityOptional.get().getType());
                    }
                    return Observable.just(Optional.<AudioChatRoom>absent());
                })
                .flatMap((Function<Optional<AudioChatRoom>, ObservableSource<Optional<Void>>>) audioChatRoomOptional -> {
                    if (audioChatRoomOptional.isPresent()) {
                        logger.debug("history active room code : {}", audioChatRoomOptional.get().getRoomCode());
                        // 激活
                        return pttService.rxJoinAudioRoom(audioChatRoomOptional.get().getRoomCode());
                    }
                    return Observable.just(Optional.<Void>absent());
                })
                .onErrorResumeNext(new ResponseFunc<Optional<Void>>() {
                    @Override
                    public Observable<Optional<Void>> apply(Throwable throwable) throws Exception {
                        super.apply(throwable);
                        return Observable.just(Optional.<Void>absent());
                    }
                })
                .compose(ScheduleTransformer.<Optional<Void>>get())
                .subscribe(RxHelper.NOTHING, RxHelper.DEFAULT_EXCEPTION_HANDLER);
    }

    public void destroy() {
        if (sessionCompositeDisposable != null) {
            sessionCompositeDisposable.clear();
        }
    }
}
