package com.kedacom.flutter_sxtapp.viewmodel;


import android.text.TextUtils;

import androidx.lifecycle.MutableLiveData;

import com.kedacom.basic.common.util.Optional;
import com.kedacom.basic.media.bean.MediaPeriod;
import com.kedacom.flutter_sxtapp.manager.PttTalkHelper;
import com.kedacom.flutter_sxtapp.model.GroupLiveBarrageBean;
import com.kedacom.lego.MR;
import com.kedacom.uc.common.cache.ContextProvider;
import com.kedacom.uc.ptt.video.media.DefaultCameraCapture;
import com.kedacom.uc.ptt.video.media.DefaultVideoRender;
import com.kedacom.uc.sdk.Abortable;
import com.kedacom.uc.sdk.AbortableFuture;
import com.kedacom.uc.sdk.EventObserver;
import com.kedacom.uc.sdk.RequestCallback;
import com.kedacom.uc.sdk.bean.ptt.MessageInfo;
import com.kedacom.uc.sdk.event.constant.ModificationEventType;
import com.kedacom.uc.sdk.event.model.ModificationEvent;
import com.kedacom.uc.sdk.generic.attachment.TextAttachment;
import com.kedacom.uc.sdk.generic.constant.SessionType;
import com.kedacom.uc.sdk.generic.model.SessionIdentity;
import com.kedacom.uc.sdk.group.GroupService;
import com.kedacom.uc.sdk.group.model.IUserMember;
import com.kedacom.uc.sdk.impl.SdkImpl;
import com.kedacom.uc.sdk.message.MessageService;
import com.kedacom.uc.sdk.message.MessageServiceObserver;
import com.kedacom.uc.sdk.message.model.IMMessage;
import com.kedacom.uc.sdk.ptt.PttTalkService;
import com.kedacom.uc.sdk.ptt.PttTalkServiceObserver;
import com.kedacom.uc.sdk.ptt.constant.PttTalkType;
import com.kedacom.uc.sdk.ptt.model.AudioChatRoom;
import com.kedacom.uc.sdk.ptt.model.MonitorPttTalkStatusEvent;
import com.kedacom.uc.sdk.util.DomainIdUtil;
import com.kedacom.uc.sdk.vchat.VideoChatService;
import com.kedacom.uc.sdk.vchat.VideoChatServiceObserver;
import com.kedacom.uc.sdk.vchat.model.VideoChatEvent;
import com.kedacom.uc.sdk.vchat.model.VideoChatRoom;
import com.kedacom.uc.sdk.vchat.model.VideoChatRoomUser;
import com.kedacom.util.LegoLog;

import java.util.ArrayList;
import java.util.List;


public class GroupTalkViewModel extends BaseViewModel {
    // 视频对讲服务
    private VideoChatService nVideoService = null;
    private VideoChatServiceObserver nVideoObserver = null;
    private VideoChatRoom videoRoom;
    private GroupService nGroupService;
    private PttTalkService mPttService;
    private PttTalkServiceObserver mPttObserver;
    private MessageService nMsgService;
    private MessageServiceObserver nMessageServiceObserver;
    // 视频对讲组件
    private DefaultVideoRender nVideoRender;
    private DefaultCameraCapture nVideoCapture;
    private String nMasterRecorderPath = null;
    private String nMenberRecordrePath = null;
    private AudioChatRoom mAudioRoom;
    private Abortable mObortable;
    private List<Abortable> abortableList = new ArrayList<Abortable>();
    private MutableLiveData<GroupLiveBarrageBean> messageCallBackBean = new MutableLiveData<>();
    private String groupCode;

    public GroupTalkViewModel() {
        nVideoService = SdkImpl.getInstance().getService(VideoChatService.class);
        nVideoObserver = SdkImpl.getInstance().getService(VideoChatServiceObserver.class);
        nGroupService = SdkImpl.getInstance().getService(GroupService.class);
        mPttService = SdkImpl.getInstance().getService(PttTalkService.class);
        mPttObserver = SdkImpl.getInstance().getService(PttTalkServiceObserver.class);
        nMsgService = SdkImpl.getInstance().getService(MessageService.class);
        nMessageServiceObserver = SdkImpl.getInstance().getService(MessageServiceObserver.class);
    }

    private void requestMsgListen() {
        if (nMessageServiceObserver != null) {
            LegoLog.d("messageServiceObserver observerListenMsgChange");
            Abortable a = nMessageServiceObserver.observerListenMsgChange(new EventObserver<ModificationEvent<IMMessage>>() {
                @Override
                public void onEvent(ModificationEvent<IMMessage> imMessageModificationEvent) {
                    if (imMessageModificationEvent.getType() == ModificationEventType.DATA_ADD || imMessageModificationEvent.getType() == ModificationEventType.DATA_UPDATE) {
                        IMMessage imMessage = imMessageModificationEvent.getData();

                        MessageInfo info = (MessageInfo) imMessage;
                        if (info.getAttachment() instanceof TextAttachment) {
                            TextAttachment txtAttach = (TextAttachment) info.getAttachment();
                            GroupLiveBarrageBean liveBarrageBean = new GroupLiveBarrageBean();
                            liveBarrageBean.setContent(txtAttach.getText());
                            liveBarrageBean.setUserCode(info.getSender().getCode());
                            messageCallBackBean.setValue(liveBarrageBean);
                        }

                    }

                }
            }, new SessionIdentity(groupCode, SessionType.GROUP));

            abortableList.add(a);
        }
    }

    public MutableLiveData<GroupLiveBarrageBean> getMessageCallBackBean() {
        return messageCallBackBean;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
        requestMsgListen();
    }

    public void sendMsg(String msg) {
        TextAttachment textAttachment = new TextAttachment();
        textAttachment.setText(msg);
        AbortableFuture<Optional<Void>> msgAbort = nMsgService.sendMsg(groupCode, SessionType.GROUP, textAttachment);
        msgAbort.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {

            }

            @Override
            public void onFailed(Throwable throwable) {

            }
        });
        abortableList.add(msgAbort);
    }

    /**
     * 获取群组成员
     */
    public void getGroupMembers(String codeForDomain) {
        if (TextUtils.isEmpty(codeForDomain)) {
            //修复DomainIdUtil.getCode(codeForDomain)
            // crash，暂时还未复现出codeForDomain为空的情况，先过滤掉codeForDomain未null或空字符串的情况
            return;
        }

        // 群组成员
        AbortableFuture<Optional<List<IUserMember>>> memberAbo = nGroupService.getGroupMembers(DomainIdUtil.getCode(codeForDomain), Integer.MAX_VALUE);
        memberAbo.setCallback(new RequestCallback<Optional<List<IUserMember>>>() {
            @Override
            public void onSuccess(Optional<List<IUserMember>> listOptional) {
                if (listOptional.isPresent()) {
                    if (!listOptional.get().isEmpty()) {
                        sendMessage(MR.GroupLiveTalkActivity_getGroupMenberSuccess, listOptional.get());
                    }
                }
            }

            @Override
            public void onFailed(Throwable throwable) {

            }
        });
    }

    /**
     * 初始化Ptt对讲
     */
    private void initPttTalk(String groupCdeoForDomain) {
        AbortableFuture<Optional<AudioChatRoom>> future = mPttService.getRoom(groupCdeoForDomain, SessionType.GROUP);
        future.setCallback(new RequestCallback<Optional<AudioChatRoom>>() {
            @Override
            public void onSuccess(Optional<AudioChatRoom> audioChatRoomOptional) {
                if (audioChatRoomOptional.isPresent()) {
                    mAudioRoom = audioChatRoomOptional.get();
                    activityGroup();
                }
            }

            @Override
            public void onFailed(Throwable throwable) {
            }
        });

        mObortable = mPttObserver.listenPttTalk(new EventObserver<MonitorPttTalkStatusEvent>() {
            @Override
            public void onEvent(MonitorPttTalkStatusEvent monitorPttTalkStatusEvent) {
                PttTalkType pttType = monitorPttTalkStatusEvent.getType();
                if (pttType == PttTalkType.CALLEE_START_SPEAK) {
                    if (monitorPttTalkStatusEvent != null) {
                        sendMessage(MR.GroupLiveTalkActivity_onPttSpeakerApply, monitorPttTalkStatusEvent);
                    }
                } else if (pttType == PttTalkType.CALLEE_END_SPEAK) {
                    sendEmptyMessage(MR.GroupLiveTalkActivity_stopPttSpeak);
                } else if (pttType == PttTalkType.SPEAK_INTERRUPTED) {
                    showToast("讲话被打断");
                }
            }
        });
    }

    public void stopSpeak() {
        if (mAudioRoom == null)
            return;
        AbortableFuture<Optional<Void>> endFuture = mPttService.stopSpeak(mAudioRoom.getRoomCode());
        endFuture.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendEmptyMessage(MR.GroupLiveTalkActivity_stopPttSpeak);
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendEmptyMessage(MR.GroupLiveTalkActivity_stopPttSpeak);
                showToast("结束讲话失败" + throwable.getMessage());

            }
        });
    }

    public void startSpeak() {
        if (mAudioRoom == null)
            return;
        AbortableFuture<Optional<Void>> startFuture = mPttService.startSpeak(mAudioRoom.getRoomCode());
        startFuture.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendMessage(MR.GroupLiveTalkActivity_onPttSpeakerApply, null);
            }

            @Override
            public void onFailed(Throwable throwable) {
                showToast("开始讲话失败" + throwable.getMessage());
                quitRoom();
            }
        });
    }

    private void activityGroup() {
        AbortableFuture<Optional<Void>> joinFuture = mPttService.joinAudioRoom(mAudioRoom.getRoomCode());
        joinFuture.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                LegoLog.d("ptt", "onSuccess");
                PttTalkHelper.getInstance().setAudioRoom(mAudioRoom);
            }

            @Override
            public void onFailed(Throwable throwable) {

                LegoLog.d("ptt", "onFailed");
                showToast(throwable.getMessage());
                PttTalkHelper.getInstance().setAudioRoom(null);
            }
        });
    }

    public void getVideoRoom(final boolean forRefuse, String talkerCodeForDomain, SessionType talkerType) {
        AbortableFuture<Optional<VideoChatRoom>> roomAbo = nVideoService.getRoom(talkerCodeForDomain, talkerType);
        roomAbo.setCallback(new RequestCallback<Optional<VideoChatRoom>>() {
            @Override
            public void onSuccess(Optional<VideoChatRoom> videoChatRoomOptional) {
                if (videoChatRoomOptional.isPresent()) {
                    videoRoom = videoChatRoomOptional.get();
                    initPttTalk(talkerCodeForDomain);
                    sendMessage(MR.GroupLiveTalkActivity_getRoomSuccess, videoRoom);
                } else {
                    sendMessage(MR.GroupLiveTalkActivity_getRoomFailed, "获取视频直播房间为空");
                }
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_getRoomFailed, "获取视频直播房间为空");
            }
        });
    }

    //PTT对讲 退出房间
    public void quitRoom() {
        if (null != mAudioRoom) {
            AbortableFuture<Optional<Void>> quitFuture = mPttService.quitAudioRoom(mAudioRoom.getRoomCode());
            quitFuture.setCallback(new RequestCallback<Optional<Void>>() {
                @Override
                public void onSuccess(Optional<Void> voidOptional) {
                    mAudioRoom = null;
                }

                @Override
                public void onFailed(Throwable throwable) {
                    showToast(throwable.getMessage(), TOAST_INFO);
                }
            });
        }
        if (null != mObortable) {
            mObortable.abort();
        }
    }

    /**
     * 注册事件监听
     */
    public void registerObserver() {
        nVideoObserver.listenRoomUserEvent(videoRoom.getRoomId(),
                new EventObserver<ModificationEvent<List<VideoChatRoomUser>>>() {
                    @Override
                    public void onEvent(ModificationEvent<List<VideoChatRoomUser>> listModificationEvent) {

                        //sendMessage(MR);
                        if (listModificationEvent.isPresent()) {
                            sendMessage(MR.GroupLiveTalkActivity_getVideoChatRoom, listModificationEvent.getData());
                        }


                    }
                });

        nVideoObserver.listenVideoEvent(videoRoom.getRoomId(), new EventObserver<VideoChatEvent>() {
            @Override
            public void onEvent(VideoChatEvent videoChatEvent) {
                sendMessage(MR.GroupLiveTalkActivity_registerEvent, videoChatEvent);
            }
        });
    }

    /**
     * 绑定视频对讲组件
     */
    public void bindComm(DefaultCameraCapture videoCapture, DefaultVideoRender videoRender) {
        nVideoRender = videoRender;
        nVideoCapture = videoCapture;
        AbortableFuture<Optional<Void>> bindAbo = nVideoService.bindCaptureAndRender(videoRoom.getRoomId(), videoCapture, videoRender);
        bindAbo.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {

                sendEmptyMessage(MR.GroupLiveTalkActivity_bindCommSuccess);
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, throwable.getMessage());
                //finish();
            }
        });
    }

    /**
     * 接受呼叫
     */
    public void acceptCalling() {
        AbortableFuture<Optional<Void>> acceptAbo = nVideoService.acceptVideoInvite(videoRoom.getRoomId());
        acceptAbo.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                // sendEmptyMessage(MR.GroupTalk);
                sendEmptyMessage(MR.GroupLiveTalkActivity_addMenberSuccess);
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsgFinish, throwable.getMessage());
            }
        });
    }

    /**
     * 加入视频对讲房间
     */
    public void joinVideoRoom() {
        AbortableFuture<Optional<Void>> joinAbo = nVideoService.joinVideoRoom(videoRoom.getRoomId());
        joinAbo.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                // beMember();
                //formatMemberInfo();
                sendEmptyMessage(MR.GroupLiveTalkActivity_addMenberSuccess);
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "加入视频对讲失败");

            }
        });
    }

    public void refuseInvatation() {
        AbortableFuture<Optional<Void>> refuseAbo = nVideoService.refuseVideoInvite(videoRoom.getRoomId());
        refuseAbo.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsgFinish, "拒绝成功");
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsgFinish, "拒绝失败");
            }
        });
    }

    /**
     * 接受主播申请
     */
    public void acceptApply() {
        AbortableFuture<Optional<Void>> acceptAbo = nVideoService.acceptSwitchVideo(videoRoom.getRoomId());
        acceptAbo.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                // SmartCityToast.makeText(VChatActivity.this, "同意切换主播", SmartCityToast
                // .LENGTH_SHORT).show();
                //beMember();
                //stopMasterRecord();
                sendEmptyMessage(MR.GroupLiveTalkActivity_acceptHostExchage);
            }

            @Override
            public void onFailed(Throwable throwable) {
                //SmartCityToast.makeText(VChatActivity.this, "同意切换主播失败", SmartCityToast
                // .LENGTH_SHORT).show();
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, throwable.getMessage());
            }
        });
    }

    /**
     * 拒绝主播申请
     */
    public void refuseApply() {
        AbortableFuture<Optional<Void>> refuseAbo = nVideoService.refuseSwitchVideo(videoRoom.getRoomId());
        refuseAbo.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                //SmartCityToast.makeText(VChatActivity.this, "已拒绝切换主播", SmartCityToast
                // .LENGTH_SHORT).show();
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "已拒绝切换主播");
            }

            @Override
            public void onFailed(Throwable throwable) {
                // SmartCityToast.makeText(VChatActivity.this, "拒绝切换主播失败", SmartCityToast
                // .LENGTH_SHORT).show();
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "拒绝切换主播失败");
            }
        });
    }

    /**
     * 发起视频对讲
     */
    public void startVideoChat(List<String> userCodeForDomains) {
        AbortableFuture<Optional<Void>> startAbo = nVideoService.startVideoChat(videoRoom.getRoomId(), userCodeForDomains);
        startAbo.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendEmptyMessage(MR.GroupLiveTalkActivity_startVideoChat);
//                VideoCaptureDeviceInfoAndroid.getDeviceInfo();
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsgFinish, "发起讲话失败");
            }
        });
    }

    /**
     * 添加成员
     *
     * @param userCodeForDomains
     */
    public void addMember(List<String> userCodeForDomains) {
        AbortableFuture<Optional<Void>> startAbo = nVideoService.addVideoCallMember(videoRoom.getRoomId(), userCodeForDomains);
        startAbo.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendEmptyMessage(MR.GroupLiveTalkActivity_addMasterrSuccess);
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "添加成员失败");
            }
        });
    }

    /**
     * 设置静音
     *
     * @param mute
     */
    public void setMute(final boolean mute) {
        final String handleStr = mute ? "设置" : "取消";
    }

    public void setDumb(final boolean dumb) {
        final String handleStr = dumb ? "设置" : "取消";

        AbortableFuture<Optional<Void>> dumbAbo = nVideoService.setMicMute(videoRoom.getRoomId(), dumb);
        dumbAbo.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                if (dumb) {
                    sendMessage(MR.GroupLiveTalkActivity_failedMsg, "设置静音");
                } else {
                    sendMessage(MR.GroupLiveTalkActivity_failedMsg, "取消静音");
                }
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "哑音失败");
            }
        });
    }

    /**
     * 退出视频对讲
     */
    public void quitChat() {
        AbortableFuture<Optional<Void>> quitAbo = nVideoService.quitRoom(videoRoom.getRoomId());
        quitAbo.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendEmptyMessage(MR.GroupLiveTalkActivity_onSpeakerQutiChat);
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, throwable.getMessage());
            }
        });
    }

    /**
     * 停止成员的播放
     */
    public void stopMemberPlay() {
//        AbortableFuture<Optional<Void>> stopPlayAbo = nVideoRender.getPlayer().stopPlay();
//        stopPlayAbo.setCallback(new RequestCallback<Optional<Void>>() {
//            @Override
//            public void onSuccess(Optional<Void> voidOptional) {
//                sendMessage(MR.GroupTalkActivity_failedMsg, "成员停止播放");
//            }
//
//            @Override
//            public void onFailed(Throwable throwable) {
//
//                sendMessage(MR.GroupTalkActivity_failedMsg, "成员停止播放失败");
//            }
//        });
    }

    /**
     * 停止主播的采集
     */
    public void stopMasterRecord() {
//        AbortableFuture<Optional<Void>> stopRecordAbo = nVideoCapture.getRecorder()
//                .stopVideoCapture();
//        stopRecordAbo.setCallback(new RequestCallback<Optional<Void>>() {
//            @Override
//            public void onSuccess(Optional<Void> voidOptional) {
//                System.out.println("主播停止采集");
//                sendMessage(MR.GroupTalkActivity_failedMsg, "成员停止播放");
//            }
//
//            @Override
//            public void onFailed(Throwable throwable) {
//                System.out.println("主播停止采集失败");
//            }
//        });
    }

    /**
     * 申请成为主播
     */
    public void applyMaster() {
        AbortableFuture<Optional<Void>> applyAbo = nVideoService.applySwitchVideo(videoRoom.getRoomId());
        applyAbo.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "正在申请成为主播");
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "申请成为主播失败");
            }
        });
    }

    private int cameraId = 1;

    /**
     * 切换摄像头
     */
    public void switchCamera(boolean isMasterRecordering) {
        if (isMasterRecordering) {
            masterStopRecord();
        }

        final int linkCamerId = Math.abs(cameraId - 1);
        AbortableFuture<Optional<Void>> future = nVideoService.switchCamera(videoRoom.getRoomId(), linkCamerId);
        future.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                showToast("摄像头切换成功");
                cameraId = linkCamerId;
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "摄像头切换失败");
            }
        });

    }

    /**
     * 主播开始录像
     */

    public void masterStartRecord() {
        nMasterRecorderPath = "/sdcard/kedacom/sdk/ptt/master_record" + ContextProvider.getCurrentTimeMillis() + ".mp4";

        AbortableFuture<Optional<Void>> recordAbo = nVideoService.startRecord(videoRoom.getRoomId(), nMasterRecorderPath);
        recordAbo.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendMessage(MR.GroupLiveTalkActivity_setMaterRcorder, true);
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "开始录像");
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "开始录像失败");
            }
        });
    }

    /**
     * 主播结束录像
     */
    public void masterStopRecord() {
        AbortableFuture<Optional<MediaPeriod>> recordAbo = nVideoService.stopRecord(videoRoom.getRoomId());
        recordAbo.setCallback(new RequestCallback<Optional<MediaPeriod>>() {
            @Override
            public void onSuccess(Optional<MediaPeriod> mediaPeriodOptional) {
                //isMasterRecording = false;
                sendMessage(MR.GroupLiveTalkActivity_setMaterRcorder, false);
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "结束录像");
                showToast("保存在" + nMasterRecorderPath);
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "结束录像失败");
            }
        });
    }

    /**
     * 成员录像
     */
    public void memberStopRecord() {
        AbortableFuture<Optional<MediaPeriod>> stopAbo = nVideoService.stopRecord(videoRoom.getRoomId());
        stopAbo.setCallback(new RequestCallback<Optional<MediaPeriod>>() {
            @Override
            public void onSuccess(Optional<MediaPeriod> mediaPeriodOptional) {
                showToast("保存在" + nMenberRecordrePath);
                sendMessage(MR.GroupLiveTalkActivity_setMenberRecoder, false);
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "结束录像");
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "结束录像失败");

            }
        });
    }

    /**
     * 成员录像
     */
    public void memberStartRecord() {
        nMenberRecordrePath = "/sdcard/kedacom/sdk/ptt/member_record" + ContextProvider.getCurrentTimeMillis() + ".mp4";
        AbortableFuture<Optional<Void>> recordAbo = nVideoService.startRecord(videoRoom.getRoomId(), nMenberRecordrePath);
        recordAbo.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                // isMemberRecording = true;
                sendMessage(MR.GroupLiveTalkActivity_setMenberRecoder, true);
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "开始录像");
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "开始录像失败");
            }
        });
    }

    /**
     * 抓拍
     */
    public void snap(int screen_width, int screen_height) {
        final String picPathStr = "/sdcard/kedacom/sdk/ptt/snap" + ContextProvider.getCurrentTimeMillis() + ".jpg";
        AbortableFuture<Optional<Void>> mTakePic;

        mTakePic = nVideoService.startCapturePic(videoRoom.getRoomId(), picPathStr, screen_width, screen_height);
        mTakePic.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "抓拍成功:" + picPathStr);
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendMessage(MR.GroupLiveTalkActivity_failedMsg, "抓拍失败");
            }
        });
    }

    /**
     * 取消订阅
     */
    public void unRegisterAbort() {
        for (Abortable a : abortableList) {
            if (a != null) {
                a.abort();
                a = null;
            }
        }
    }
}
