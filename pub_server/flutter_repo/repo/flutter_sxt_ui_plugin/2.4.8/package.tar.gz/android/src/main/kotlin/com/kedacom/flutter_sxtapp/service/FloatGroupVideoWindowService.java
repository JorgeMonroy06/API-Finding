package com.kedacom.flutter_sxtapp.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.app.ActivityOptionsCompat;

import com.kedacom.flutter_sxtapp.R;
import com.kedacom.flutter_sxtapp.activity.GroupVideoCallActivity;
import com.kedacom.flutter_sxtapp.manager.FlutterManager;
import com.kedacom.flutter_sxtapp.util.ScreenUtils;
import com.kedacom.lego.util.Utils;
import com.kedacom.util.AppUtil;
import com.kedacom.util.LegoLog;

/**
 * Created by kd on 2020/11/6 10:39.
 */
public class FloatGroupVideoWindowService extends Service {
    private WindowManager mWindowManager;
    private WindowManager.LayoutParams wmParams;
    private LayoutInflater inflater;
    /**
     * 悬浮框布局显示
     */
    private View mFloatingLayout;
    private View layout_audio;
    private RelativeLayout selfView;
    private RelativeLayout otherView;
    private ConstraintLayout layout_root;
    /**
     * 缩小框按钮
     */
    private ImageView iv_suoxiao;
    private TextView tv_time;
    private int mTouchStartX;
    private int mTouchStartY;
    private int mTouchCurrentX;
    private int mTouchCurrentY;
    private int mStartX;
    private int mStartY;
    private int mStopX;
    private int mStopY;
    private boolean isMove;
    /**
     * 是否是视频聊天
     */
    private boolean isVideo;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        initWindow();
    }

    @Override
    public IBinder onBind(Intent intent) {
        this.isVideo = intent.getBooleanExtra("isVideo", false);
        return new FloatGroupVideoWindowService.MyBinder();
    }

    private void initFloating() {
        if (this.mFloatingLayout == null) {
            this.mFloatingLayout = this.inflater.inflate(R.layout.float_video_window_flutter, (ViewGroup) null);
        }

        this.layout_root = (ConstraintLayout) this.mFloatingLayout.findViewById(R.id.layout_root);
        this.selfView = (RelativeLayout) this.mFloatingLayout.findViewById(R.id.self_view);
        this.otherView = (RelativeLayout) this.mFloatingLayout.findViewById(R.id.other_view);
        this.iv_suoxiao = (ImageView) this.mFloatingLayout.findViewById(R.id.iv_suoxiao);
        this.layout_audio = this.mFloatingLayout.findViewById(R.id.layout_audio);
        this.tv_time = (TextView) this.mFloatingLayout.findViewById(R.id.tv_time);
        this.iv_suoxiao.setVisibility(View.GONE);
        this.mFloatingLayout.setOnTouchListener(new FloatGroupVideoWindowService.FloatingListener());
    }

    /**
     * 设置悬浮框基本参数（位置、宽高等）
     */
    private void initWindow() {
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        wmParams = getParams();//设置好悬浮窗的参数
        // 悬浮窗默认显示以左上角为起始坐标
        wmParams.gravity = Gravity.RIGHT | Gravity.TOP;
        //悬浮窗的开始位置，因为设置的是从左上角开始，所以屏幕左上角是x=0;y=0
        wmParams.x = ScreenUtils.dp2px(this, 30);
        wmParams.y = ScreenUtils.getStatusHeight(this) + ScreenUtils.dp2px(this, 50);
        //得到容器，通过这个inflater来获得悬浮窗控件
        inflater = LayoutInflater.from(this);
        // 获取浮动窗口视图所在布局

//        if(isVideo)
        mFloatingLayout = inflater.inflate(R.layout.float_video_window_flutter, null);

//        // 添加悬浮窗的视图
        mWindowManager.addView(mFloatingLayout, wmParams);

        LegoLog.d("FloatGroupVideoWindowService:addWindow");
        initFloating();//悬浮框点击事件的处理
    }

    public void setTime(String time) {
        if (this.tv_time != null) {
            this.tv_time.setText(time);
        }
    }

    public void switchToAudio() {
        this.isVideo = false;
        this.initAudioOrVideoWindow();
    }

    public void closeFloatWindow() {
        LegoLog.d("FloatGroupVideoWindowService closeFloatWindow");
        if (this.mFloatingLayout != null) {
            this.mWindowManager.removeView(this.mFloatingLayout);
            this.mFloatingLayout = null;
        }
    }

    /**
     * 等待界面缩小化
     */
    private void initAudioOrVideoWindow() {

        this.selfView.removeAllViews();
        this.otherView.removeAllViews();
        this.selfView.setVisibility(View.GONE);
        this.otherView.setVisibility(View.GONE);
        this.iv_suoxiao.setVisibility(View.GONE);
        this.layout_audio.setVisibility(View.VISIBLE);
        this.layout_audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.setEnabled(false);
                FlutterManager.Companion.getInstance().closeSelectContactPage();

                FloatGroupVideoWindowService.this.closeFloatWindow();
                stopSelf();
                Intent intent = new Intent(new Intent(Utils.getApp().getApplicationContext(), GroupVideoCallActivity.class));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                ActivityOptionsCompat options = ActivityOptionsCompat.makeCustomAnimation(AppUtil.getApp(), R.anim.fadein_flutter, R.anim.fadeout_flutter);
                ActivityCompat.startActivity(AppUtil.getApp(), intent, options.toBundle());
            }
        });
        this.layout_audio.setOnTouchListener(new FloatGroupVideoWindowService.FloatingListener());

    }

    private WindowManager.LayoutParams getParams() {
        wmParams = new WindowManager.LayoutParams();
        //设置window type 下面变量2002是在屏幕区域显示，2003则可以显示在状态栏之上
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {//8.0+
            wmParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            wmParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        }
        //设置可以显示在状态栏上

        wmParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR |
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        wmParams.format = PixelFormat.TRANSLUCENT;

        //设置悬浮窗口长宽数据
        wmParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        return wmParams;
    }

    /**
     * 双向音视频上 悬浮框上的事件处理
     */
    private class FloatingListener implements View.OnTouchListener {
        private FloatingListener() {
        }

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            int action = event.getAction();
            switch (action) {
                case MotionEvent.ACTION_DOWN:
                    isMove = false;
                    mTouchStartX = (int) event.getRawX();
                    mTouchStartY = (int) event.getRawY();
                    mStartX = (int) event.getX();
                    mStartY = (int) event.getY();
                    break;
                case MotionEvent.ACTION_UP:
                    mStopX = (int) event.getX();
                    mStopY = (int) event.getY();
                    if (Math.abs(mStartX - mStopX) >= 1 || Math.abs(mStartY - mStopY) >= 1) {
                        isMove = true;
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    mTouchCurrentX = (int) event.getRawX();
                    mTouchCurrentY = (int) event.getRawY();
                    WindowManager.LayoutParams var10000 = wmParams;
                    var10000.x += mTouchStartX - mTouchCurrentX;
                    var10000 = wmParams;
                    var10000.y += mTouchCurrentY - mTouchStartY;
                    if (mFloatingLayout != null) {
                        mWindowManager.updateViewLayout(mFloatingLayout, wmParams);
                    }
                    mTouchStartX = mTouchCurrentX;
                    mTouchStartY = mTouchCurrentY;
            }

            return isMove;
        }
    }

    @Override
    public void onDestroy() {
        LegoLog.d("FloatGroupVideoWindowService onDestoy");
        super.onDestroy();
        this.closeFloatWindow();
    }

    public class MyBinder extends Binder {
        public MyBinder() {
        }

        public FloatGroupVideoWindowService getService() {
            return FloatGroupVideoWindowService.this;
        }
    }

}
