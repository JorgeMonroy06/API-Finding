package com.kedacom.flutter_sxtapp.manager;

import android.app.Activity;
import android.app.Service;
import android.os.Vibrator;

import com.kedacom.basic.common.util.StringUtil;
import com.kedacom.flutter_sxtapp.activity.VideoCallActivity;
import com.kedacom.flutter_sxtapp.model.Contact;
import com.kedacom.flutter_sxtapp.notification.NotificationHelper;
import com.kedacom.lego.core.LegoActivityManager;
import com.kedacom.lego.fast.data.sp.SPUtil;
import com.kedacom.uc.sdk.auth.model.IAccount;
import com.kedacom.uc.sdk.conversation.model.IConversation;
import com.kedacom.uc.sdk.event.constant.ModificationEventType;
import com.kedacom.uc.sdk.event.model.ModificationEvent;
import com.kedacom.uc.sdk.generic.constant.SessionType;
import com.kedacom.uc.sdk.impl.SdkImpl;
import com.kedacom.util.AppUtil;
import com.kedacom.util.LegoLog;

import org.jetbrains.annotations.NotNull;

public class ConversstionUtils {

    private static ConversstionUtils sInstance = null;

    public static ConversstionUtils getInstance() {
        if (sInstance == null) {
            sInstance = new ConversstionUtils();

        }
        return sInstance;
    }

    /**
     * 判断是否要通知
     *
     * @param iConversation
     * @return
     */
    private boolean needNotification(IConversation iConversation) {
        //app在后台，推送
        if (SxtUIManager.getInstance().isBackground()) {
            return true;
        }

        //app在前台
        boolean state = false;
        LegoLog.d("1state---" + state);
        //**只要不是在聊天列表页，并且不在当前会话页都要推送
        //app已打开
        //当前页面是main 并且不在 ChatFragment就推送
        IAccount account = SdkImpl.getInstance().getUserSession().orNull();
        String myCode = null;
        if (account != null) {
            myCode = account.getUserCode();
        }

        Activity activity = null;
        try {
            activity = LegoActivityManager.getTopActivity();
        } catch (Exception e) {

        }
        //判断是否在主页面
        if (SPUtil.getInstance().getBoolean(iConversation.getTalker().getCode() + "code", false)) {//消息免打扰
            state = false;
            LegoLog.d("2state---" + state);
        } else if (myCode != null && iConversation.getSender() != null && iConversation.getSender().getCode().equals(myCode)) {
            state = false;
            LegoLog.d("3state---" + state);
        }
//        else if (activity instanceof InterPhoneActivity) {
//            //当前页面在ChatActivity 并且 通知的会话不是当前的会话就推送
//            ConversationInfo conInfo = (ConversationInfo) iConversation;
//
//            if (conInfo.getTalker() != null) {
//                state = !StringUtil.isEquals(conInfo.getTalker().getCode(), curActiveCode);
//            }
//            LegoLog.d("6state---" + state);
//        }
        else if (activity instanceof VideoCallActivity && !SxtUIManager.getInstance().getUiOptions().videoCallShowMsgNotify) {
            //新增
            if (myCode != null && iConversation.getSender() != null && StringUtil.isEquals(myCode, iConversation.getSender().getCode())) {
                state = false;
                LegoLog.d("state", "videoCall false");
                LegoLog.d("7state---" + state);
            }
        } else {
            state = true;
            LegoLog.d("state", "state == true");
            LegoLog.d("8state---" + state);
        }
        if (iConversation.getSender() != null) {
            if (StringUtil.isEquals(iConversation.getSender().getCode(), myCode)) {
                state = false;
                LegoLog.d("9state---" + state);
            }
        }
        LegoLog.d("9state---:" + state);
        return state;
    }

    public void monitorConvertsation(ModificationEvent<IConversation> event) {
        if (event == null) {
            return;
        }
        IConversation iConversation = event.get();
        int unreadCount = iConversation.getUnreadCount();
        if (unreadCount != 0 && iConversation.isNewUnreadIncoming() && (event.getType() == ModificationEventType.DATA_ADD || event.getType() == ModificationEventType.DATA_UPDATE)) {
            if (needNotification(iConversation)) {
                if (iConversation.getTalker().getSessionType() == SessionType.USER || iConversation.getTalker().getSessionType() == SessionType.GROUP) {
                    FlutterManager.Companion.getInstance().isNeedMsgNotification(iConversation.getTalker().getCodeForDomain(), new FlutterDataListener<Boolean>() {
                        @Override
                        public void onSuccess(Boolean data) {
                            if (data || SxtUIManager.getInstance().isBackground()) {
                                FlutterManager.Companion.getInstance().getContact(iConversation.getSender().getCode(), new FlutterDataListener<Contact>() {
                                    @Override
                                    public void onSuccess(Contact data) {
                                        NotificationHelper.getInstance().setNotificationInfo(iConversation, data.getName());
                                    }

                                    @Override
                                    public void onError(@NotNull Throwable e) {

                                    }
                                });
                            } else {
                                if (iConversation.getExtra().contains("\"promptType\":2")) {
                                    Vibrator vibrator = (Vibrator) AppUtil.getApp().getSystemService(Service.VIBRATOR_SERVICE);
                                    vibrator.vibrate(new long[]{100, 100, 100, 1000}, -1);
                                }
                            }
                        }

                        @Override
                        public void onError(@NotNull Throwable e) {

                        }
                    });
                }
            }
        }
    }

}
