package com.kedacom.flutter_sxtapp.service;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;

import com.kedacom.flutter_sxtapp.manager.DataManager;
import com.kedacom.flutter_sxtapp.model.VideoParam;
import com.kedacom.lego.message.LegoEventBus;
import com.kedacom.uc.sdk.Abortable;
import com.kedacom.webrtcsdk.callback.WebrtcCallback;
import com.kedacom.webrtcsdk.component.Constantsdef;
import com.kedacom.webrtcsdk.sdkmanager.kedamedia;
import com.kedacom.webrtcsdk.struct.SsrcReport;
import com.kedacom.webrtcsdk.struct.YUVDataInfo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;


public class PttUiService extends Service implements WebrtcCallback.CompletionCallback {

    private static Logger logger = LoggerFactory.getLogger(PttUiService.class);
    private List<Abortable> abortableList = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();
        logger.info("PttUiService onCreate");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                kedamedia.getInstance(PttUiService.this, null).setWSCallback(PttUiService.this);
            }
        }, 1500);
    }

    @Override
    public IBinder onBind(Intent intent) {
        logger.info("onBind: ");
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!DataManager.getInstance().isShiXinTongLoginSuccess()) {
            logger.info("PttUiService onCreate sxt login failed");
            return START_STICKY;
        }
        logger.info("PttUiService onCreate sxt login success");
        abort();
        return START_STICKY;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        logger.info("PttUiService onDestroy");

        abort();
    }


    private void abort() {
        if (null != abortableList) {
            for (Abortable abortable : abortableList) {
                abortable.abort();
            }
            abortableList.clear();
        }
    }


    @Override
    public void onEvent(int nCode, Bundle bundle) {
        logger.info("PttUiService kmedia onEvent: {}", nCode);
        switch (nCode) {
            case 1:
                int nLinkState = bundle.getInt(Constantsdef.BUNDLE_KEY_INT_LINK_STAT);
                logger.info("PttUiService kmedia MediiaConnectState: {}", nLinkState);
                if (nLinkState == 1) {
                    // com.kedacom.lego.fast.util.ToastUtil.showDefaultToast(getString(R.string
                    // .new_media_connect));
                } else {
                    //com.kedacom.lego.fast.util.ToastUtil.showDefaultToast(getString(R.string
                    // .new_media_disconnect));
                }
                break;
            case 2:
                YUVDataInfo info = (YUVDataInfo) bundle.getSerializable(Constantsdef.BUNDLE_KEY_SER_VIDEO_RESOLUTION);
                VideoParam videoParam = new VideoParam(info.getWidth(), info.getHeight());
                LegoEventBus.use("videoParam", VideoParam.class).postValue(videoParam);
                logger.debug("PttUiService kmedia YUVDataInfo: {},{}", info.getWidth(), info.getHeight());
                break;
            case 3:
                int icestat = bundle.getInt(Constantsdef.BUNDLE_KEY_INT_ICE_STAT);
                LegoEventBus.use("iceConnectState", Integer.class).postValue(icestat);
                logger.debug("PttUiService kmedia iceConnectState: {}", icestat);
                break;
            case 6:
                SsrcReport ssReport = (SsrcReport) bundle.getSerializable(Constantsdef.BUNDLE_KEY_SER_SSRC_REPORT);
//                LegoLog.d("SsrcReport+" + ssReport.getAudioRecvStat().toString());
                LegoEventBus.use("SsrcReport", SsrcReport.class).postValue(ssReport);
                break;
            default:
                break;
        }

    }
}
