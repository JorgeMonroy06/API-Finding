package com.kedacom.flutter_sxtapp.manager;

import android.os.Handler;
import android.os.Looper;

import com.bumptech.glide.Glide;
import com.kedacom.flutter_sxtapp.model.Contact;
import com.kedacom.sxt_flutter_plugin.util.AppUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class DataManager {

    private static DataManager sInstance = null;

    /**
     * 视信通登录状态
     */
    private boolean shiXinTongLoginSuccess = false;
    private boolean nShowOverlayPermission;
    private List<String> nSelectTalkChatCodes = new ArrayList<>();
    private Map<String, Contact> contactMapCache = new ConcurrentHashMap<>();


    private DataManager() {

    }

    public static DataManager getInstance() {
        if (sInstance == null) {
            sInstance = new DataManager();
        }
        return sInstance;
    }


    public boolean isnShowOverlayPermission() {
        return nShowOverlayPermission;
    }

    public void setShowOverlayPermission(boolean nShowOverlayPermission) {
        this.nShowOverlayPermission = nShowOverlayPermission;
    }

    public boolean isShiXinTongLoginSuccess() {
        return shiXinTongLoginSuccess;
    }

    public void setShiXinTongLoginSuccess(boolean shiXinTongLoginSuccess) {
        this.shiXinTongLoginSuccess = shiXinTongLoginSuccess;
    }

    public List<String> getSelectTalkChatCodes() {
        return nSelectTalkChatCodes;
    }


    public void setSelectTalkChatCodes(List<String> nSelectTalkChatCodes) {
        this.nSelectTalkChatCodes = nSelectTalkChatCodes;
    }

    /**
     * @param userCode 用户coade
     */
    public void addContactCache(String userCode, Contact contact) {
        if (contactMapCache != null) {
            contactMapCache.put(userCode, contact);
        }
    }

    public Contact getContact(String userCode) {
        return contactMapCache.get(userCode);
    }

    /**
     * 判断用户是否存在缓存
     */
    public boolean isCacheContact(String userCode) {
        return !contactMapCache.isEmpty() && contactMapCache.containsKey(userCode);
    }

    /**
     * 清除某一个缓存
     */
    public void removeCache(String userCode) {
        if (null != userCode && contactMapCache != null && !contactMapCache.isEmpty()) {
            contactMapCache.remove(userCode);
        }
    }

    /**
     * 清除所有缓存
     */
    public void clearContactMapData() {
        if (contactMapCache != null && !contactMapCache.isEmpty()) {
            contactMapCache.clear();
        }

        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                try {
                    Glide.get(AppUtil.getApp()).clearMemory();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Glide.get(AppUtil.getApp()).clearDiskCache();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public void clear() {
        clearContactMapData();
        nSelectTalkChatCodes.clear();
    }
}
