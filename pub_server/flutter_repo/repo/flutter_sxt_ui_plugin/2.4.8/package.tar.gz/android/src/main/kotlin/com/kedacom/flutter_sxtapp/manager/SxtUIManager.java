package com.kedacom.flutter_sxtapp.manager;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.app.ActivityOptionsCompat;

import com.google.gson.internal.LinkedTreeMap;
import com.kedacom.basic.common.resource.util.NotifyUtil;
import com.kedacom.basic.common.util.Optional;
import com.kedacom.flutter_sxt_ui_plugin.UIOptions;
import com.kedacom.flutter_sxtapp.Constants;
import com.kedacom.flutter_sxtapp.R;
import com.kedacom.flutter_sxtapp.activity.GroupVideoCallActivity;
import com.kedacom.flutter_sxtapp.activity.VideoCallActivity;
import com.kedacom.flutter_sxtapp.model.Contact;
import com.kedacom.flutter_sxtapp.model.MultiCallBean;
import com.kedacom.flutter_sxtapp.service.FloatGroupVideoWindowService;
import com.kedacom.flutter_sxtapp.service.PttUiService;
import com.kedacom.lego.fast.LegoIntent;
import com.kedacom.sxt_flutter_plugin.manager.SxtDataManager;
import com.kedacom.sxt_flutter_plugin.manager.SxtManager;
import com.kedacom.sxt_flutter_plugin.manager.SxtUICallback;
import com.kedacom.uc.sdk.RequestCallback;
import com.kedacom.uc.sdk.generic.constant.SessionType;
import com.kedacom.uc.sdk.impl.SdkImpl;
import com.kedacom.uc.sdk.util.DomainIdUtil;
import com.kedacom.uc.sdk.vchat.VideoTalkService;
import com.kedacom.uc.sdk.vchat.model.VideoChatRoom;
import com.kedacom.util.AppUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import io.flutter.plugin.common.MethodChannel;

/**
 * 主要处理页面逻辑
 */
public class SxtUIManager {
    private Logger logger = LoggerFactory.getLogger(SxtUIManager.class);

    public static SxtUIManager mInstance;
    private UIOptions uiOptions = UIOptions.DEFAULT;

    private List<Activity> activityStack = new ArrayList<>();
    private List<Activity> resumeActivityList = new ArrayList<>();
    private LinkedList<Activity> createActivityList = new LinkedList<>();
    private HashMap<String, Integer> activitiesTaskId = new HashMap<>();
    private Activity currentActivity = null;
    private Application.ActivityLifecycleCallbacks activityLifecycleCallbacks;

    public static synchronized SxtUIManager getInstance() {
        if (null == mInstance) {
            synchronized (SxtUIManager.class) {
                if (null == mInstance) {
                    mInstance = new SxtUIManager();
                }
            }
        }
        return mInstance;
    }


    public void init(Context context) {
        initGlobalActivity();
        SxtManager.Companion.getInstance().sxtUICallback(new SxtUICallback() {
            @Override
            public void onLoginSuccess() {
                FlutterManager.Companion.getInstance().requestContactBaseUrl();
                DataManager.getInstance().setShiXinTongLoginSuccess(true);
                SxtStatusManager.getInstance().loginSuccess();
                context.startService(new Intent(context, PttUiService.class));
            }

            @Override
            public void onLogout() {
                NotifyUtil.cancellAll(AppUtil.getApp());
                DataManager.getInstance().setShiXinTongLoginSuccess(false);
                SxtStatusManager.getInstance().logout();
                SxtUIManager.getInstance().logout();
                DataManager.getInstance().clear();
                context.stopService(new Intent(context, PttUiService.class));
            }
        });
    }

    public void addActivity(Activity activity) {
        activityStack.add(activity);
    }

    public void removeActivity(Activity activity) {
        activityStack.remove(activity);
    }

    public void registerUIOptions(UIOptions uiOptions) {
        if (null != uiOptions) {
            this.uiOptions = uiOptions;
        }
    }

    public UIOptions getUiOptions() {
        return uiOptions;
    }

    public void logout() {
        for (Activity activity : activityStack) {
            if (null != activity && !activity.isFinishing()) {
                activity.finish();
            }
        }
        activityStack.clear();
    }

    public void release() {
        //TODO 清除所有service
        logout();
        if (null != activityLifecycleCallbacks) {
            AppUtil.getApp().unregisterActivityLifecycleCallbacks(activityLifecycleCallbacks);
        }
        resumeActivityList.clear();
        createActivityList.clear();
        activitiesTaskId.clear();
        currentActivity = null;
        mInstance = null;
    }

    private void initGlobalActivity() {
        activityLifecycleCallbacks = new Application.ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
                createActivityList.add(activity);
                activitiesTaskId.put(activity.getClass().getCanonicalName(), activity.getTaskId());
            }

            @Override
            public void onActivityDestroyed(Activity activity) {
                createActivityList.remove(activity);
                activitiesTaskId.remove(activity.getClass().getCanonicalName());
            }

            @Override
            public void onActivityStarted(Activity activity) {
            }

            @Override
            public void onActivityResumed(Activity activity) {
                resumeActivityList.add(activity);
            }

            @Override
            public void onActivityPaused(Activity activity) {
                resumeActivityList.remove(activity);
            }

            @Override
            public void onActivityStopped(Activity activity) {
            }

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
            }
        };
        AppUtil.getApp().registerActivityLifecycleCallbacks(activityLifecycleCallbacks);
    }


    public List<Activity> getCreatedActivity() {
        return createActivityList;
    }

    public Activity getCurrentActivity() {
        if (!createActivityList.isEmpty()) {
            return createActivityList.get(createActivityList.size() - 1);
        } else {
            return null;
        }
    }

    public boolean isAppOpen() {
        return !createActivityList.isEmpty();
    }

    public HashMap<String, Integer> getActivitiesTaskId() {
        return activitiesTaskId;
    }

    public boolean isBackground() {
        return isAppOpen() && resumeActivityList.isEmpty();
    }

    public void gotoCall(String chatType, String userCodeForDomain, MethodChannel.Result result) {
        logger.info("sxt gotoCall chatType {} , userCodeForDomain {}", chatType, userCodeForDomain);
        SdkImpl.getInstance().getService(VideoTalkService.class)
                .getRoom(userCodeForDomain, SessionType.USER)
                .setCallback(new RequestCallback<Optional<VideoChatRoom>>() {
                    @Override
                    public void onSuccess(Optional<VideoChatRoom> videoChatRoomOptional) {
                        if (videoChatRoomOptional.isPresent()) {
                            LegoIntent intent = new LegoIntent(SxtUIManager.getInstance().getCurrentActivity(), VideoCallActivity.class);
                            intent.putObjectExtra("SessionType", SessionType.USER);
                            intent.putExtra("callType", chatType);
                            intent.putExtra("userCode", DomainIdUtil.getCode(userCodeForDomain));
                            intent.putExtra("userCodeForDomain", userCodeForDomain);
                            intent.putExtra("videoRoom", videoChatRoomOptional.get());
                            intent.putExtra("isStart", true);
                            SxtUIManager.getInstance().getCurrentActivity().startActivity(intent);

                            result.success(true);
                        } else {
                            result.success(false);
                        }
                    }

                    @Override
                    public void onFailed(Throwable throwable) {
                        result.success(false);
                        logger.error("sxt gotoCall onFailed", throwable);
                    }
                });
    }

    public void gotoMultiCall(String chatType, MultiCallBean multiCallBean, MethodChannel.Result result) {
        logger.info("sxt gotoMultiCall chatType {} , userCodeForDomain {}", chatType, multiCallBean.getGroup().getGroupCode());
        SdkImpl.getInstance().getService(com.kedacom.uc.sdk.vchat.MultiVideoService.class)
                .getMultiVideoRoom(multiCallBean.getGroup().getGroupCode(), SessionType.GROUP)
                .setCallback(new RequestCallback<Optional<VideoChatRoom>>() {
                    @Override
                    public void onSuccess(Optional<VideoChatRoom> videoChatRoomOptional) {
                        if (videoChatRoomOptional.isPresent()) {
                            ArrayList<String> codes = new ArrayList<>();
                            for (int i = 0; i < multiCallBean.getContactList().size(); i++) {
                                Contact contact = multiCallBean.getContactList().get(i);
                                codes.add(contact.getCode() + "@" + contact.getOriginCode());
                            }

                            // 双向音频对讲
                            LegoIntent intent = new LegoIntent(SxtUIManager.getInstance().getCurrentActivity(), GroupVideoCallActivity.class);
                            intent.putExtra("codeForDomain", multiCallBean.getGroup().getGroupCode());
                            intent.putExtra("groupCode", DomainIdUtil.getCode(multiCallBean.getGroup().getGroupCode()));
                            intent.putExtra("isSender", true);
                            intent.putStringArrayListExtra("userCodesForDomain", codes);
                            intent.putExtra("VideoChatRoom", videoChatRoomOptional.get());
                            intent.putExtra("groupName", multiCallBean.getGroup().getGroupName());
                            intent.putExtra("isVideo", Constants.VIDEOCHAT.equals(chatType));
                            SxtUIManager.getInstance().getCurrentActivity().startActivity(intent);
                        } else {
                            result.success(false);
                        }
                    }

                    @Override
                    public void onFailed(Throwable throwable) {
                        result.success(false);
                        logger.error("sxt gotoMultiCall onFailed", throwable);
                    }
                });
    }

    public void returnMultiCall(MultiCallBean param, MethodChannel.Result result) {
        if (!SxtDataManager.Companion.getInstance().isCalling())
            return;

        AppUtil.getApp().stopService(new Intent(AppUtil.getApp(), FloatGroupVideoWindowService.class));
        Intent intent = new Intent(new Intent(AppUtil.getApp(), GroupVideoCallActivity.class));
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (param != null && param.getContactList() != null && !param.getContactList().isEmpty()) {
            ArrayList<String> codes = new ArrayList<>();
            for (int i = 0; i < param.getContactList().size(); i++) {
                Contact contact = param.getContactList().get(i);
                codes.add(contact.getCode() + "@" + contact.getOriginCode());
            }
            intent.putExtra("userCodesForDomain", codes);
        }
        ActivityOptionsCompat options = ActivityOptionsCompat.makeCustomAnimation(AppUtil.getApp(), R.anim.fadein_flutter, R.anim.fadeout_flutter);
        ActivityCompat.startActivity(AppUtil.getApp(), intent, options.toBundle());
        result.success(null);
    }

    public void backtoMultiCall(LinkedTreeMap<String, Object> data) {
        String groupCode = (String) data.get("groupCode");
        if (SxtDataManager.Companion.getInstance().isCalling()) {
            AppUtil.getApp().stopService(new Intent(AppUtil.getApp(), FloatGroupVideoWindowService.class));
            Intent intent = new Intent(new Intent(AppUtil.getApp(), GroupVideoCallActivity.class));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            ActivityOptionsCompat options = ActivityOptionsCompat.makeCustomAnimation(AppUtil.getApp(), R.anim.fadein_flutter, R.anim.fadeout_flutter);
            ActivityCompat.startActivity(AppUtil.getApp(), intent, options.toBundle());
        } else {
            SdkImpl.getInstance().getService(com.kedacom.uc.sdk.vchat.MultiVideoService.class)
                    .getMultiVideoRoom(groupCode, SessionType.GROUP)
                    .setCallback(new RequestCallback<Optional<VideoChatRoom>>() {
                        @Override
                        public void onSuccess(Optional<VideoChatRoom> videoChatRoomOptional) {
                            if (videoChatRoomOptional.isPresent()) {
                                ArrayList<String> codes = new ArrayList<>();

                                // 双向音频对讲
                                LegoIntent intent = new LegoIntent(SxtUIManager.getInstance().getCurrentActivity(), GroupVideoCallActivity.class);
                                intent.putExtra("codeForDomain", groupCode);
                                intent.putExtra("groupCode", DomainIdUtil.getCode(groupCode));
                                intent.putExtra("isSender", true);
                                intent.putStringArrayListExtra("userCodesForDomain", codes);
                                intent.putExtra("VideoChatRoom", videoChatRoomOptional.get());
//                                intent.putExtra("groupName", multiCallBean.getGroup().getGroupName());
                                intent.putExtra("isVideo", videoChatRoomOptional.get().isVideoChat());
                                SxtUIManager.getInstance().getCurrentActivity().startActivity(intent);
                            }
                        }

                        @Override
                        public void onFailed(Throwable throwable) {
                            logger.error("sxt gotoMultiCall onFailed", throwable);
                        }
                    });
        }

    }

    public void startMultiMeeting() {
        FlutterManager.Companion.getInstance().startMultiMeeting();
    }

    public void stopMultiMeeting() {
        FlutterManager.Companion.getInstance().stopMultiMeeting();
    }

}
