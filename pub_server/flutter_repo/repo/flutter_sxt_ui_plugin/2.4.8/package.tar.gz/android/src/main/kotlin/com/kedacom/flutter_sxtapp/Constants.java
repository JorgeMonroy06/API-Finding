package com.kedacom.flutter_sxtapp;

public class Constants {
    //语音聊天
    public static final String LANGUAGE = "language";

    //视频聊天
    public static final String VIDEOCHAT = "videochat";


    public static final String THIRD_PLATFORM = "thrid_form";

    public final static int PUSH_SOURCE_MEETING_INVITING = 102;
    public final static int PUSH_VIDEO_CALL_INVITING = 103;
    public final static int PUSH_GROUP_VIDEO_CALL_INVITING = 104;
    public final static int PUSH_MESSAGE_CLICK = 105;

    /**
     * log tag constant
     */
    public static final String LOGGERTAG_ANDROID_SXT = "androidSxt";
}
