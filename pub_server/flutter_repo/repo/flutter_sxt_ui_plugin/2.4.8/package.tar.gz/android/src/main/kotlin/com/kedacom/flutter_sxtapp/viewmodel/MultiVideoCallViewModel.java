package com.kedacom.flutter_sxtapp.viewmodel;


import android.widget.ImageView;
import android.widget.TextView;

import com.kedacom.basic.common.util.Optional;
import com.kedacom.flutter_sxtapp.manager.SxtDataLoader;
import com.kedacom.lego.MR;
import com.kedacom.uc.sdk.Abortable;
import com.kedacom.uc.sdk.AbortableFuture;
import com.kedacom.uc.sdk.RequestCallback;
import com.kedacom.uc.sdk.generic.constant.SessionType;
import com.kedacom.uc.sdk.impl.SdkImpl;
import com.kedacom.uc.sdk.vchat.MultiVideoService;
import com.kedacom.uc.sdk.vchat.MultiVideoServiceObservable;
import com.kedacom.uc.sdk.vchat.model.VideoCapture;
import com.kedacom.uc.sdk.vchat.model.VideoChatRoom;
import com.kedacom.uc.sdk.vchat.model.VideoRender;

import java.util.ArrayList;
import java.util.List;

public class MultiVideoCallViewModel extends BaseViewModel {

    private MultiVideoService multiVideoService;
    private MultiVideoServiceObservable videoObserver;
    private List<Abortable> abortables = new ArrayList<>();
    private int cameraId = 1;


    public MultiVideoCallViewModel() {
        multiVideoService = SdkImpl.getInstance().getService(MultiVideoService.class);
        this.videoObserver = SdkImpl.getInstance().getService(MultiVideoServiceObservable.class);
    }

    /**
     * 切换相机
     *
     * @param roomId
     */
    public void switchCamera(String roomId, int cameraId) {
        AbortableFuture<Optional<Void>> future = multiVideoService.switchMultiVideoCamera(roomId, cameraId);
        future.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                showToast("摄像头切换成功");

            }

            @Override
            public void onFailed(Throwable throwable) {
                showToast("摄像头切换失败");

            }
        });
        abortables.add(future);
    }

    /**
     * 退出房间
     *
     * @param roomId
     */
    public void quitChatRoomTrigger(String roomId) {
        logger.info("MultiVideoCallViewModel quitChatRoomTrigger roomId : {}", roomId);
        multiVideoService.quitMultiVideoRoom(roomId).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendEmptyMessage(MR.GroupVideoCallActivity_quitMultiRoomSuccess);
            }

            @Override
            public void onFailed(Throwable e) {
                sendMessage(MR.GroupVideoCallActivity_quitMultiRoomFailed, e.getMessage());
            }
        });
    }

    /**
     * 获取聊天房间
     *
     * @param talkerCodeForDomain
     * @param sessionType
     */
    public void getMultiVideRoom(String talkerCodeForDomain, SessionType sessionType) {

        multiVideoService.getMultiVideoRoom(talkerCodeForDomain, sessionType).setCallback(new RequestCallback<Optional<VideoChatRoom>>() {
            @Override
            public void onSuccess(Optional<VideoChatRoom> value) {
                if (value != null && value.isPresent()) {
                    sendMessage(MR.GroupVideoCallActivity_getMulitVideoRoomResult, value.get());
                }
            }

            @Override
            public void onFailed(Throwable e) {
                sendMessage(MR.GroupVideoCallActivity_getMultiRoomFailed, e.getMessage());
            }
        });

    }

    public void bindCaptureAndRender(String roomId, VideoCapture capture, VideoRender render) {

        multiVideoService.bindMultiCaptureAndRender(roomId, capture, render).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendEmptyMessage(MR.GroupVideoCallActivity_bindCaptureAndRenderResult);
            }

            @Override
            public void onFailed(Throwable e) {

            }
        });
    }

    public void addMultiVideoMember(String roomId, List<String> roomUserCodesForDomain) {
        multiVideoService.addMultiVideoCallMember(roomId, roomUserCodesForDomain).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendEmptyMessage(MR.GroupVideoCallActivity_addMenberResultSuccess);
                logger.debug("addMultiVideoMember  onNext :");
            }

            @Override
            public void onFailed(Throwable e) {

            }
        });
    }

    public void joinBidChatRoomTrigger(String roomId, boolean isEnableVideo) {
        multiVideoService.joinMultiVideoRoom(roomId, isEnableVideo).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendEmptyMessage(MR.GroupVideoCallActivity_joinChatRoomResult);
            }

            @Override
            public void onFailed(Throwable e) {

            }
        });
    }

    public void startVideoChatTrigger(List<String> roomUserCodes, String roomId, boolean isEnableVideo) {
        multiVideoService.startMultiVideoChat(roomId, roomUserCodes, isEnableVideo).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                logger.debug("GropVideoCallStartVideoSuccess startVideoChatResult suceess ");
                sendEmptyMessage(MR.GroupVideoCallActivity_startVideoChatResult);
            }

            @Override
            public void onFailed(Throwable e) {
                logger.debug("GropVideoCallStartVideoSuccess startVideoChatResult failed {} ", e.getMessage());
            }
        });

    }

    public void rxSetVideoCameraStatus(String roomId, final boolean isCloseCamera) {

        multiVideoService.setMultiVideoCameraStatus(roomId, isCloseCamera).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {

            }

            @Override
            public void onFailed(Throwable e) {

            }
        });

    }

    public void onQuiet(String roomId, final boolean bMute) {

        multiVideoService.muteMultiVideoMic(roomId, bMute).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                logger.debug("setMicMute onNext:");
                sendMessage(MR.GroupVideoCallActivity_setQuitResult, bMute);

            }

            @Override
            public void onFailed(Throwable e) {
                logger.error("setMicMute onError:");

            }
        });

    }

    public void acceptInviteTrigger(String roomId, boolean isEnableVideo) {
        multiVideoService.acceptMultiVideoInvite(roomId, isEnableVideo).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                logger.debug("acceptInviteTrigger  onNext :");
                sendEmptyMessage(MR.GroupVideoCallActivity_acceptInviteResult);
            }

            @Override
            public void onFailed(Throwable e) {
                logger.error("acceptInviteTrigger onError:", e);

            }
        });
    }

    public void refuseBidVideoInviteTrigger(String roomId) {

        multiVideoService.refuseMultiVideoInvite(roomId).setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendEmptyMessage(MR.GroupVideoCallActivity_refuseInviteResult);
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.error("onError:", throwable);

            }
        });
    }

    /**
     * 根据用户code 获取用户头像和姓名
     *
     * @param userCode
     * @param headImage
     * @param nameTxt
     */
    public void getUserHeadImagePath(String userCode, ImageView headImage, TextView nameTxt) {
        SxtDataLoader.loadUserInfo(userCode, nameTxt, headImage);
    }

    public void unregister() {
        if (abortables != null) {
            for (Abortable a : abortables) {
                a.abort();
                a = null;
            }
        }
    }
}
