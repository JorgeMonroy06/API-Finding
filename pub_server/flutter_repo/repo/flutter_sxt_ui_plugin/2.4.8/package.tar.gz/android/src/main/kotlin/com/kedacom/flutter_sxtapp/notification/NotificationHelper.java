package com.kedacom.flutter_sxtapp.notification;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.kedacom.flutter_sxtapp.Constants;
import com.kedacom.flutter_sxtapp.manager.SxtUIManager;
import com.kedacom.sxt_flutter_plugin.util.AppUtil;
import com.kedacom.uc.sdk.conversation.model.IConversation;
import com.kedacom.uc.sdk.generic.constant.SessionType;

public class NotificationHelper {

    public static final String VIDEO_CALL_NOTIFICATION_ID = "10001";
    public static final String MESSAGE_NOTIFICATION_ID = "10002";

    private NotificationHelper() {
    }

    private static NotificationHelper instance;

    public static NotificationHelper getInstance() {
        if (null == instance) {
            instance = new NotificationHelper();
        }
        return instance;
    }

    public void sendGroupVideoCallNotification(Context context, boolean isVideo, Intent intent) {
        //先添加后显示
        Bitmap btm = BitmapFactory.decodeResource(context.getResources(), SxtUIManager.getInstance().getUiOptions().notifyBarRes);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(context, VIDEO_CALL_NOTIFICATION_ID)
                .setSmallIcon(SxtUIManager.getInstance().getUiOptions().notifyIconRes)
                .setContentTitle(context.getApplicationInfo().nonLocalizedLabel)
                .setDefaults(Notification.DEFAULT_ALL)
                .setOngoing(true)
                .setGroup("VIDEO_CALL")
                .setGroupSummary(false)
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_MAX);

        String content = (isVideo ? "视频" : "语音") + "通话中，点击返回";
        mBuilder.setContentText(content);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(VIDEO_CALL_NOTIFICATION_ID, "通话提醒", NotificationManager.IMPORTANCE_HIGH);
            //获取通知管理器对象
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            channel.enableVibration(true);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
        mBuilder.setLargeIcon(btm);
        mBuilder.setAutoCancel(false);//自己维护通知的消失

        //封装一个Intent
        Intent resultIntent = new Intent();
        resultIntent.setAction(NotificationDict.NOTICE_CLICK);
        resultIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        resultIntent.putExtra(NotificationDict.PACKAGE_NAME, context.getPackageName());
        resultIntent.putExtra("event", intent.getSerializableExtra("event"));
        resultIntent.putExtra("isSender", intent.getBooleanExtra("isSender", false));
        resultIntent.putExtra("isVideo", intent.getBooleanExtra("isVideo", false));
        resultIntent.putExtra("codeForDomain", intent.getStringExtra("codeForDomain"));
        resultIntent.putExtra("groupCode", intent.getStringExtra("groupCode"));
        resultIntent.putExtra("VideoChatRoom", intent.getSerializableExtra("VideoChatRoom"));
        resultIntent.putExtra("turnFlag", Constants.PUSH_GROUP_VIDEO_CALL_INVITING);
        PendingIntent resultPendingIntent = PendingIntent.getBroadcast(context, VIDEO_CALL_NOTIFICATION_ID.hashCode(), resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);   //封装一个Intent
        // 设置通知主题的意图
        mBuilder.setContentIntent(resultPendingIntent);
        //获取通知管理器对象
        NotificationManager mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (null != mNotificationManager) {
            mNotificationManager.notify(VIDEO_CALL_NOTIFICATION_ID.hashCode(), mBuilder.build());
        }
    }

    public void sendVideoCallNotification(Context context, boolean isVideo, Intent intent) {
        //先添加后显示
        Bitmap btm = BitmapFactory.decodeResource(context.getResources(), SxtUIManager.getInstance().getUiOptions().notifyBarRes);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(context, VIDEO_CALL_NOTIFICATION_ID)
                .setSmallIcon(SxtUIManager.getInstance().getUiOptions().notifyIconRes)
                .setContentTitle(context.getApplicationInfo().nonLocalizedLabel)
                .setDefaults(Notification.DEFAULT_ALL)
                .setOngoing(true)
                .setGroup("VIDEO_CALL")
                .setGroupSummary(false)
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_MAX);

        String content = (isVideo ? "视频" : "语音") + "通话中，点击返回";
        mBuilder.setContentText(content);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(VIDEO_CALL_NOTIFICATION_ID, "通话提醒", NotificationManager.IMPORTANCE_HIGH);
            //获取通知管理器对象
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            channel.enableVibration(true);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
        mBuilder.setLargeIcon(btm);
        mBuilder.setAutoCancel(false);//自己维护通知的消失

        //封装一个Intent
        Intent resultIntent = new Intent();
        resultIntent.setAction(NotificationDict.NOTICE_CLICK);
        resultIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        resultIntent.putExtra(NotificationDict.PACKAGE_NAME, context.getPackageName());
        resultIntent.putExtra("callType", intent.getStringExtra("callType"));
        resultIntent.putExtra("userCodeForDomain", intent.getStringExtra("userCodeForDomain"));
        resultIntent.putExtra("userCode", intent.getStringExtra("userCode"));
        resultIntent.putExtra("isSender", intent.getBooleanExtra("isSender", false));
        resultIntent.putExtra("videoRoom", intent.getSerializableExtra("videoRoom"));
        resultIntent.putExtra("meetingId", intent.getStringExtra("meetingId"));
        resultIntent.putExtra("turnFlag", Constants.PUSH_VIDEO_CALL_INVITING);
        PendingIntent resultPendingIntent = PendingIntent.getBroadcast(context, VIDEO_CALL_NOTIFICATION_ID.hashCode(), resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);   //封装一个Intent
        // 设置通知主题的意图
        mBuilder.setContentIntent(resultPendingIntent);
        //获取通知管理器对象
        NotificationManager mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (null != mNotificationManager) {
            mNotificationManager.notify(VIDEO_CALL_NOTIFICATION_ID.hashCode(), mBuilder.build());
        }
    }

    public void sendMeetingNotification(Context context, String id, boolean isLinkId) {
        //先添加后显示
        Bitmap btm = BitmapFactory.decodeResource(context.getResources(), SxtUIManager.getInstance().getUiOptions().notifyBarRes);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(context, id)
                .setSmallIcon(SxtUIManager.getInstance().getUiOptions().notifyIconRes)
                .setContentTitle(context.getApplicationInfo().nonLocalizedLabel)
                .setOngoing(true)
                .setGroup("MEETING")
                .setGroupSummary(false)
                .setPriority(Notification.PRIORITY_MAX);

        String content = "您收到了一条会议邀请，点击进入！";
        mBuilder.setContentText(content);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(id, "会议通知", NotificationManager.IMPORTANCE_HIGH);
            //获取通知管理器对象
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            channel.enableVibration(true);
//            if (!SXTSettingsConfig.getMessageSoundNotify()) {
//                channel.setSound(null, null);
//            }
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        } else {
//            if (!SXTSettingsConfig.getMessageSoundNotify() && !SXTSettingsConfig.getMessageVibrateNotify()) {
//                mBuilder.setSound(null);
//                mBuilder.setVibrate(null);
//            } else if (!SXTSettingsConfig.getMessageSoundNotify() && SXTSettingsConfig.getMessageVibrateNotify()) {
//                mBuilder.setSound(null);
//                mBuilder.setDefaults(Notification.DEFAULT_VIBRATE);
//            } else if (SXTSettingsConfig.getMessageSoundNotify() && !SXTSettingsConfig.getMessageVibrateNotify()) {
//                mBuilder.setVibrate(null);
//                mBuilder.setDefaults(Notification.DEFAULT_SOUND);
//            } else {
            mBuilder.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE);
//            }
        }
        mBuilder.setLargeIcon(btm);
        mBuilder.setAutoCancel(false);//自己维护通知的消失

        //构建一个Intent
        Intent resultIntent = new Intent();
        resultIntent.setAction(NotificationDict.NOTICE_CLICK);
        resultIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        resultIntent.putExtra(NotificationDict.PACKAGE_NAME, context.getPackageName());
        resultIntent.putExtra(NotificationDict.NOTICE_CONTENT, id);
        resultIntent.putExtra(NotificationDict.NOTICE_ISLINKID, isLinkId);
        resultIntent.putExtra("turnFlag", Constants.PUSH_SOURCE_MEETING_INVITING);
        //封装一个Intent
        PendingIntent resultPendingIntent = PendingIntent.getBroadcast(context, id.hashCode(), resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);   //封装一个Intent
        // 设置通知主题的意图
        mBuilder.setContentIntent(resultPendingIntent);
        //获取通知管理器对象
        NotificationManager mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (null != mNotificationManager) {
            mNotificationManager.notify(id.hashCode(), mBuilder.build());
        }
    }

    public void setNotificationInfo(IConversation iConversation, String senderName) {
        String content = (iConversation.getTalker().getSessionType() == SessionType.GROUP) ? iConversation.getTalker().getName() : senderName;

        //先添加后显示
        Bitmap btm = BitmapFactory.decodeResource(AppUtil.getApp().getResources(), SxtUIManager.getInstance().getUiOptions().notifyBarRes);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(AppUtil.getApp(), MESSAGE_NOTIFICATION_ID)
                .setSmallIcon(SxtUIManager.getInstance().getUiOptions().notifyIconRes)
                .setContentTitle(content + " [" + iConversation.getUnreadCount() + "条]")
                .setOngoing(false)
                .setGroup("MESSAGE")
                .setGroupSummary(true)
                .setPriority(Notification.PRIORITY_HIGH);
        String notificationContent = ((iConversation.getTalker().getSessionType() == SessionType.GROUP) ? (senderName + " : ") : "")
                + iConversation.getContent();
        mBuilder.setContentText(notificationContent);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(MESSAGE_NOTIFICATION_ID, notificationContent, NotificationManager.IMPORTANCE_LOW);
            //获取通知管理器对象
            NotificationManager notificationManager = (NotificationManager) AppUtil.getApp().getSystemService(Context.NOTIFICATION_SERVICE);
            channel.enableVibration(true);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        } else {
            mBuilder.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE);
        }

        mBuilder.setLargeIcon(btm);
        mBuilder.setAutoCancel(true);//自己维护通知的消失

        //构建一个Intent
        Intent resultIntent = new Intent();
        resultIntent.setAction(NotificationDict.NOTICE_CLICK);
        resultIntent.putExtra(NotificationDict.PACKAGE_NAME, AppUtil.getApp().getPackageName());
        resultIntent.putExtra("sessionEntity", iConversation.getTalker());
        resultIntent.putExtra("turnFlag", Constants.PUSH_MESSAGE_CLICK);
        //封装一个Intent
        PendingIntent resultPendingIntent = PendingIntent.getBroadcast(AppUtil.getApp(), MESSAGE_NOTIFICATION_ID.hashCode(), resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);   //封装一个Intent
        // 设置通知主题的意图
        mBuilder.setContentIntent(resultPendingIntent);
        //获取通知管理器对象
        NotificationManager mNotificationManager = (NotificationManager) AppUtil.getApp().getSystemService(Context.NOTIFICATION_SERVICE);
        if (null != mNotificationManager) {
            mNotificationManager.notify(MESSAGE_NOTIFICATION_ID.hashCode(), mBuilder.build());
        }
    }
}
