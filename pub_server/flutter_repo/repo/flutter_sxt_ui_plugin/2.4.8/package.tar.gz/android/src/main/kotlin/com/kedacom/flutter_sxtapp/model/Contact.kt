package com.kedacom.flutter_sxtapp.model

class Contact {

    var id: String? = null
    var code: String? = null
    var pcode: String? = null
    var showInAddressBook: String? = null
    var originCode: String? = null
    var createdTime: Long? = null
    var updatedTime: Long? = null
    var updatedBy: String? = null
    var dataFromCode: String? = null
    var isAudit: String? = null
    var policeNo: String? = null
    var sex: String? = null
    var deptId: String? = null
    var deptId_name: String? = null
    var headPortrait: String? = null
    var personalPortrait: String? = null
    var sequence: String? = null
    var pttNo: String? = null
    var createdBy: String? = null
    var name: String? = null
    var showInAddressBookName: String? = null
    var status: String? = null
    var email: String? = null
    var birthday: String? = null
    var officeAddress: String? = null
    var gbId: String? = null
    var shortNo: String? = null
    var telNo: String? = null
    var fixedNo: String? = null
    var identity: String? = null
    var nameSpell: String? = null
    var sortIndex: Long? = null
}