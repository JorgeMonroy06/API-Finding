package com.kedacom.flutter_sxtapp.adapter;


import com.kedacom.flutter_sxtapp.databinding.ItemGroupTalkMenberFlutterBinding;
import com.kedacom.flutter_sxtapp.manager.SxtDataLoader;
import com.kedacom.lego.adapter.recyclerview.LegoBaseRecyclerViewAdapter;
import com.kedacom.lego.adapter.recyclerview.LegoBaseRecyclerViewBindingHolder;

import java.util.List;

public class GroupUserMenberAdapter extends LegoBaseRecyclerViewAdapter<String> {
    public GroupUserMenberAdapter(int layoutId, List<String> data) {
        super(layoutId, data);
    }

    @Override
    public void onBindViewHolder(LegoBaseRecyclerViewBindingHolder holder, int position) {
        super.onBindViewHolder(holder, position);
        ItemGroupTalkMenberFlutterBinding itemMenber = (ItemGroupTalkMenberFlutterBinding) holder.getBinding();

        String userCode = nData.get(position);
        itemMenber.txtCode.setText(userCode);
        itemMenber.txtCode.setText(userCode);
        SxtDataLoader.loadUserInfo(userCode, itemMenber.txtDiscussGroupName, itemMenber.imgDiscussion);
    }
}
