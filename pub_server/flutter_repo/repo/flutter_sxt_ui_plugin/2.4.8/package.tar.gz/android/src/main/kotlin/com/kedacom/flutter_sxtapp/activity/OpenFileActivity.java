package com.kedacom.flutter_sxtapp.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.kedacom.flutter_sxtapp.manager.FlutterManager;
import com.kedacom.sxt_flutter_plugin.model.Job;
import com.kedacom.widget.filepicker.FilePickerActivity;
import com.kedacom.widget.filepicker.bean.FilePickerItem;
import com.kedacom.widget.filepicker.bean.FilePickerOptions;

import java.util.ArrayList;
import java.util.HashMap;

public class OpenFileActivity extends AppCompatActivity {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FilePickerOptions filePickerOptions = new FilePickerOptions()
                // 设置最多选择的文件个数
                .setMaxPickerCount(3)
//                .setTitleBarBgResId(R.drawable.bg_gradient_actionbar_flutter)
                .setColorAccent(Color.parseColor("#0972EE"))
                .setFinishPickButtonText("发送");

        Intent intent = new Intent(this, FilePickerActivity.class);
        intent.putExtra(FilePickerActivity.EXTRA_NAME_FILEPICKER, filePickerOptions);
        startActivityForResult(intent, 200);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 200 && resultCode == Activity.RESULT_OK) {
            ArrayList<FilePickerItem> filePickerResult = data.getParcelableArrayListExtra(FilePickerActivity.EXTRA_NAME_FILEPICKER_RESULT);
            if (null != filePickerResult && !filePickerResult.isEmpty()) {
                HashMap<String, Object> map = new Gson().fromJson(new Gson().toJson(Job.Companion.createJob(0, filePickerResult)), HashMap.class);
                FlutterManager.Companion.getInstance().onOpenFileResult(map);
                finish();
            } else {
                finish();
            }
        } else {
            finish();
        }
    }
}
