package com.kedacom.flutter_sxtapp.model;

/**
 * @author wangbaoshun
 *  群直播弹幕对应的消息bean
 */
public class GroupLiveBarrageBean {

    private int barrageType;
    private String userCode;
    private String content;

    public int getBarrageType() {
        return barrageType;
    }

    public void setBarrageType(int barrageType) {
        this.barrageType = barrageType;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
