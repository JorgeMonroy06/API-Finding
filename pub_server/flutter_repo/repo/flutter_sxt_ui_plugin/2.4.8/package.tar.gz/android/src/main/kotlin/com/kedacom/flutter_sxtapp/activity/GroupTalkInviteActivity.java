package com.kedacom.flutter_sxtapp.activity;

import android.app.Activity;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;

import com.kedacom.basic.common.util.StringUtil;
import com.kedacom.flutter_sxtapp.R;
import com.kedacom.flutter_sxtapp.databinding.ActivityGroupTalkInviteFlutterBinding;
import com.kedacom.flutter_sxtapp.manager.SxtDataLoader;
import com.kedacom.flutter_sxtapp.model.Contact;
import com.kedacom.flutter_sxtapp.util.VibratorUtil;
import com.kedacom.flutter_sxtapp.viewmodel.GroupTalkInviteViewModel;
import com.kedacom.lego.annotation.Extra;
import com.kedacom.lego.annotation.OnMessage;
import com.kedacom.lego.annotation.ViewModel;
import com.kedacom.lego.fast.LegoIntent;
import com.kedacom.lego.message.LegoEventBus;
import com.kedacom.uc.sdk.generic.constant.SessionType;

import java.lang.reflect.Field;
import java.util.Timer;
import java.util.TimerTask;


@ViewModel(GroupTalkInviteViewModel.class)
public class GroupTalkInviteActivity extends BaseActivity<ActivityGroupTalkInviteFlutterBinding, GroupTalkInviteViewModel> {

    @Extra("codeForDomain")
    private String nCodeForDomain;
    @Extra("groupCode")
    private String nGroupCode;
    @Extra("isIncoming")
    private boolean isIncomming = false;
    @Extra("invatationMsg")
    private String invatationMsg;
    @Extra("sessionType")
    private SessionType nSessionType = SessionType.GROUP;

    @Extra("userCode")
    private String userCode;

    private Ringtone nRingTone;
    private Timer ntimer = new Timer();
    private Observer<String> closeVideoCallObserver;

    @Override
    public int getContentViewId() {
        return R.layout.activity_group_talk_invite_flutter;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (userCode.contains("@")) {
            String userCode1 = userCode.split("@")[0];
            mViewModel.getUserName(userCode1);
        }
        keyBoardScreen();
        mViewModel.getUserName(userCode);

        nRingTone = initRingtone(GroupTalkInviteActivity.this);
        startTip();
        mViewModel.getVideoRoom(userCode);

        closeVideoCallObserver = new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                logger.debug("closeGroupVideoCallEvent current nCodeForDomain:{},s:{}", nCodeForDomain, s);
                if (StringUtil.isEquals(s, "phoneInterruption")) {
                    logger.info(getString(R.string.call_interrupt_re_dial));
                }
                if (nCodeForDomain == null || (StringUtil.isEquals(s, nCodeForDomain)) || StringUtil.isEquals("disconnect", s)) {
                    if (!isFinishing()) {
                        logger.debug("callFinish closeVideoCallEventBus {}", s);
                        mViewModel.refuseInvatation(userCode);
                    }
                }
            }
        };
        LegoEventBus.use("closeGroupVideoCall", String.class).observeForever(closeVideoCallObserver);
    }

    /*

     * 锁屏显示 设置窗体的样式
     */
    private void keyBoardScreen() {
        final Window win = getWindow();
        win.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON);

    }

    private void startTip() {
        nRingTone.play();
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                VibratorUtil.Vibrate(GroupTalkInviteActivity.this, 1500L);
            }
        };
        ntimer.schedule(timerTask, 0L, 2000L);

    }

    @OnMessage
    public void getUserInfoSuccess(Contact contact) {
        if (!StringUtil.isEmpty(contact.getName())) {
            mBinding.tvName.setText(contact.getName());
        } else {
            getUsrNameImg(contact.getCode(), mBinding.tvName, mBinding.ivIcon);
        }
    }

    @OnMessage
    public void refusesSuccess() {
        finish();
    }

    private void getUsrNameImg(String userCode, TextView namTv, ImageView userImg) {
        SxtDataLoader.loadUserInfo(userCode, namTv, userImg);
    }

    //拒绝
    public void refuseVideo(View view) {
        mViewModel.refuseInvatation(userCode);
    }


    //接受通话
    public void acceptVideo(View view) {
        LegoIntent intent = new LegoIntent(GroupTalkInviteActivity.this, GroupLiveTalkActivity.class);
        intent.putExtra("codeForDomain", nCodeForDomain);
        intent.putObjectExtra("talkerType", SessionType.GROUP);
        intent.putExtra("isIncoming", true);
        intent.putExtra("groupCode", nGroupCode);
        intent.putExtra("msg", invatationMsg);
        startActivity(intent);
        finish();
    }

    private Ringtone initRingtone(Activity context) {
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALL);
        Ringtone tone = RingtoneManager.getRingtone(context, notification);
        setRingtoneRepeat(tone);
        return tone;
    }

    private void setRingtoneRepeat(Ringtone ringtone) {
        Class<Ringtone> clazz = Ringtone.class;
        try {
            Field audio = clazz.getDeclaredField("mAudio");
            audio.setAccessible(true);
            MediaPlayer target = (MediaPlayer) audio.get(ringtone);
            target.setLooping(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void stopMedia() {
        if (nRingTone != null) {
            nRingTone.stop();
            ntimer.cancel();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopMedia();
        if (null != closeVideoCallObserver) {
            LegoEventBus.use("closeGroupVideoCall", String.class).removeObserver(closeVideoCallObserver);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        stopMedia();
    }
}
