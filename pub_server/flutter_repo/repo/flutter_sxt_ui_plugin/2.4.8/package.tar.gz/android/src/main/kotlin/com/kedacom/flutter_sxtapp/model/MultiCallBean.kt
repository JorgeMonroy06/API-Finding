package com.kedacom.flutter_sxtapp.model

import com.kedacom.sxt_flutter_plugin.model.group.Group


class MultiCallBean {

    var group: Group? = null
    var contactList: List<Contact>? = null

}