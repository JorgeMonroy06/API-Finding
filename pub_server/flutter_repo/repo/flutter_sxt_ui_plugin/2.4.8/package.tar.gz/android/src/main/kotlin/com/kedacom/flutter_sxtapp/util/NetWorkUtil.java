package com.kedacom.flutter_sxtapp.util;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;

import com.kedacom.uc.common.bean.SystemStatus;
import com.kedacom.uc.common.cache.BusinessServerStatus;

public class NetWorkUtil {


    /**
     * 获取当前的网络状态 ：没有网络0：WIFI网络1：2G网络2：3G网络3,4G网络4
     *
     * @param context
     * @return
     */
    public static int getAPNType(Context context) {
        int netType = 0;
        ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo == null) {
            return netType;
        }
        int nType = networkInfo.getType();
        if (nType == ConnectivityManager.TYPE_WIFI) {
            netType = 1;// wifi
        } else if (nType == ConnectivityManager.TYPE_MOBILE) {
            int nSubType = networkInfo.getSubtype();
            TelephonyManager mTelephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            switch (nSubType) {
                case TelephonyManager.NETWORK_TYPE_GPRS:
                case TelephonyManager.NETWORK_TYPE_EDGE:
                case TelephonyManager.NETWORK_TYPE_CDMA:
                case TelephonyManager.NETWORK_TYPE_1xRTT:
                case TelephonyManager.NETWORK_TYPE_IDEN:
                    netType = 2;
                    break;
                case TelephonyManager.NETWORK_TYPE_UMTS:
                case TelephonyManager.NETWORK_TYPE_EVDO_0:
                case TelephonyManager.NETWORK_TYPE_EVDO_A:
                case TelephonyManager.NETWORK_TYPE_HSDPA:
                case TelephonyManager.NETWORK_TYPE_HSUPA:
                case TelephonyManager.NETWORK_TYPE_HSPA:
                case TelephonyManager.NETWORK_TYPE_EVDO_B:
                case TelephonyManager.NETWORK_TYPE_EHRPD:
                case TelephonyManager.NETWORK_TYPE_HSPAP:
                    netType = 3;
                    break;
                case TelephonyManager.NETWORK_TYPE_LTE:
                    netType = 4;
                    break;
                default:
                    netType = 5;
            }
        }
        return netType;
    }

    /**
     * 判断信令服务器状态
     *
     * @return
     */
    public static boolean judgeSignNet() {
        SystemStatus signServerStatus = BusinessServerStatus.getInstance().getSignServerStatus();
        if (signServerStatus == SystemStatus.SIGN_SERVER_DISCONNECTED || signServerStatus == SystemStatus.SIGN_SERVER_CONNECTING) { //信令服务器未连接
            return true;
        }
        return false;
    }

    /**
     * 判断数据服务器状态
     *
     * @return
     */
    public static boolean judgeDataNet() {
        SystemStatus dataServerStatus = BusinessServerStatus.getInstance().getDataServerStatus();
        if (dataServerStatus == SystemStatus.DATA_SERVER_DISCONNECTED || dataServerStatus == SystemStatus.DATA_SERVER_CONNECTING) {//数据服务器未连接
            return true;
        }
        return false;

    }
}
