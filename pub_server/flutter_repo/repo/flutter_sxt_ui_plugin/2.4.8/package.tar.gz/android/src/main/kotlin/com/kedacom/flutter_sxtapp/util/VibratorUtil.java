package com.kedacom.flutter_sxtapp.util;

import android.app.Activity;
import android.content.Context;
import android.os.Vibrator;

public class VibratorUtil {
    public static final long VIBRATE_DURATION_SHORT = 200;

    public static void Vibrate(Context activity, long milliseconds) {
        ((Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE)).vibrate(milliseconds);
    }

    public static void Vibrate(Activity activity, long[] pattern, boolean isRepeat) {
        ((Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE)).vibrate(pattern, isRepeat ? 1 : -1);
    }

    public static void VibrateCancel(Activity activity) {
        ((Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE)).cancel();
    }

    public static void VibrateSingle(Activity activity) {
        ((Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE)).vibrate(100);
    }
}
