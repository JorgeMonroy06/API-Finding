package com.kedacom.flutter_sxtapp.widget;

import com.kedacom.uc.sdk.bean.ptt.UserGroupInfo;

/**
 * Created by wangbaoshun on 2019/1/23.
 */

public interface OnGroupTalkSelectInterface {
    void onSelectGroupTalk(boolean isSelected, UserGroupInfo userGroupInfo);
}
