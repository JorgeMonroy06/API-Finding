package com.kedacom.flutter_sxtapp.util;

public class ClickEventUtils {
    private static long lastClickTime;
    private static boolean flag = true;

    private static boolean isFastDoubleClick(int space) {
        long time = System.currentTimeMillis();
        boolean isFastClick = false;
        if (time - lastClickTime < space) {
            isFastClick = true;
        }
        if (!isFastClick) {
            lastClickTime = time;
        }
        return isFastClick;
    }

    public static boolean needRaiseClickEvent(int space) {
        return isFastDoubleClick(space);
    }

    public static boolean needRaiseClickEvent() {
        return isFastDoubleClick(1500);
    }
}
