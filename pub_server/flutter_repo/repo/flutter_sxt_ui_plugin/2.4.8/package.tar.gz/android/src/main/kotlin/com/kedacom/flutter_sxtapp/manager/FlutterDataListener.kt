package com.kedacom.flutter_sxtapp.manager

interface FlutterDataListener<T> {

    fun onSuccess(data: T)
    fun onError(e: Throwable)
}