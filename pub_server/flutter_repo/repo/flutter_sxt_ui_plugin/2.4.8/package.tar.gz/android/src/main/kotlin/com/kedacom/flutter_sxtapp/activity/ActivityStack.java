package com.kedacom.flutter_sxtapp.activity;

import android.app.Activity;

import java.util.Iterator;
import java.util.Stack;

public final class ActivityStack {
    private static Stack<Activity> activityStack;
    private static Stack<Activity> videoActityStack;
    private static ActivityStack instance;


    private ActivityStack() {
    }

    public static ActivityStack getInstance() {
        if (instance == null) {
            synchronized (ActivityStack.class) {
                if (instance == null) {
                    instance = new ActivityStack();
                    activityStack = new Stack();
                    videoActityStack = new Stack<>();
                }
            }
        }
        return instance;
    }

    public int getCount() {
        return activityStack.size();
    }

    public int getVideoStatckCount() {
        return videoActityStack.size();
    }

    public <T extends Activity> void addActivity(T t) {
        activityStack.add(t);
    }

    public <T extends Activity> void addVideoCallActivity(T t) {
        videoActityStack.add(t);
    }

    public Activity topActivity() {
        if (activityStack == null) {
            throw new NullPointerException("Activity stack is Null,your Activity must extend BaseActivity");
        } else if (activityStack.isEmpty()) {
            return null;
        } else {
            return (Activity) activityStack.lastElement();
        }
    }

    public <T extends Activity> Activity findActivity(Class<T> cls) {
        Iterator it = activityStack.iterator();
        while (it.hasNext()) {
            Activity activity = (Activity) it.next();
            if (activity.getClass().equals(cls)) {
                return activity;
            }
        }
        return null;
    }

    public void finishActivity() {
        Activity activity = (Activity) activityStack.lastElement();
        if (activity != null) {
        }
        finishActivity(activity);
    }

    public <T extends Activity> void finishActivity(T t) {
        if (t != null) {
            activityStack.remove(t);
        }
    }

    public <T extends Activity> void findishVideoActivity(T t) {
        if (t != null) {
            videoActityStack.remove(t);
        }
    }

    public <T extends Activity> void finishActivity(Class<T> cls) {
        Iterator it = activityStack.iterator();
        while (it.hasNext()) {
            Activity activity = (Activity) it.next();
            if (cls.equals(activity.getClass())) {
                activity.finish();
                it.remove();
            }
        }
    }

    public void finishOthersActivity(Class<?> cls) {
        Iterator it = activityStack.iterator();
        while (it.hasNext()) {
            Activity activity = (Activity) it.next();
            if (!activity.getClass().equals(cls)) {
                finishActivity(activity);
            }
        }
    }

    public void finishAllActivity() {
        int size = activityStack.size();
        for (int i = 0; i < size; i++) {
            if (activityStack.get(i) != null) {
                ((Activity) activityStack.get(i)).finish();
            }
        }
        activityStack.clear();
    }

    public <T extends Activity> boolean existsActivity(Class<T> cls) {
        for (int i = 0; i < activityStack.size(); i++) {
            if (((Activity) activityStack.get(i)).getClass() == cls) {
                return true;
            }
        }
        return false;
    }

    public <T extends Activity> boolean finishActivityWhileTop(Class<T> cls) {
        for (int i = 0; i < activityStack.size(); i++) {
            if (((Activity) activityStack.get(i)).getClass() == cls) {
                while (activityStack.size() != i) {
                    ((Activity) activityStack.get(i)).finish();
                    activityStack.remove(i);
                }
                return true;
            }
        }
        return false;
    }

    public <T extends Activity> int indexOfActivity(Class<T> cls) {
        for (int i = 0; i < activityStack.size(); i++) {
            if (((Activity) activityStack.get(i)).getClass() == cls) {
                return i;
            }
        }
        return -1;
    }

    public <T extends Activity> int lastIndexOfActivity(Class<T> cls) {
        for (int size = activityStack.size() - 1; size >= 0; size++) {
            if (((Activity) activityStack.get(size)).getClass() == cls) {
                return size;
            }
        }
        return -1;
    }

    public Stack<Activity> getStackActivities() {
        return activityStack;
    }

    public Stack<Activity> getVideoActityStackes() {
        return videoActityStack;
    }
}
