package com.kedacom.flutter_sxtapp.viewmodel;


public class PermissionGuideViewModel extends BaseViewModel {

}
