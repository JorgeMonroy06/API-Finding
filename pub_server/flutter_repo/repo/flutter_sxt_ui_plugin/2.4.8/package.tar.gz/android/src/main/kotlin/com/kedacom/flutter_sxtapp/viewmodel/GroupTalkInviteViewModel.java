package com.kedacom.flutter_sxtapp.viewmodel;


import com.kedacom.basic.common.util.Optional;
import com.kedacom.flutter_sxtapp.manager.FlutterDataListener;
import com.kedacom.flutter_sxtapp.manager.FlutterManager;
import com.kedacom.flutter_sxtapp.model.Contact;
import com.kedacom.lego.MR;
import com.kedacom.uc.sdk.AbortableFuture;
import com.kedacom.uc.sdk.RequestCallback;
import com.kedacom.uc.sdk.generic.constant.SessionType;
import com.kedacom.uc.sdk.impl.SdkImpl;
import com.kedacom.uc.sdk.vchat.VideoChatService;
import com.kedacom.uc.sdk.vchat.model.VideoChatRoom;

import org.jetbrains.annotations.NotNull;

public class GroupTalkInviteViewModel extends BaseViewModel {

    private VideoChatService nVideoChatService;
    private VideoChatRoom nVideoChatRoom;

    public GroupTalkInviteViewModel() {
        nVideoChatService = SdkImpl.getInstance().getService(VideoChatService.class);
    }

    public void getVideoRoom(String talkerCodeForDomain) {
        AbortableFuture<Optional<VideoChatRoom>> roomAbo = nVideoChatService.getRoom(talkerCodeForDomain, SessionType.GROUP);
        roomAbo.setCallback(new RequestCallback<Optional<VideoChatRoom>>() {
            @Override
            public void onSuccess(Optional<VideoChatRoom> videoChatRoomOptional) {
                if (videoChatRoomOptional.isPresent()) {
                    nVideoChatRoom = videoChatRoomOptional.get();
                }
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendEmptyMessage(MR.GroupTalkInviteActivity_refusesSuccess);
            }
        });
    }

    public void getUserName(String userCode) {
        FlutterManager.Companion.getInstance().getContact(userCode, new FlutterDataListener<Contact>() {
            @Override
            public void onSuccess(Contact contact) {
                sendMessage(MR.GroupTalkInviteActivity_getUserInfoSuccess, contact);
            }

            @Override
            public void onError(@NotNull Throwable e) {
                logger.error("getUser failed  ", e);
            }
        });
    }

    public void refuseInvatation(String talkerCodeForDomain) {
        if (nVideoChatRoom == null) {
            AbortableFuture<Optional<VideoChatRoom>> roomAbo = nVideoChatService.getRoom(talkerCodeForDomain, SessionType.GROUP);
            roomAbo.setCallback(new RequestCallback<Optional<VideoChatRoom>>() {
                @Override
                public void onSuccess(Optional<VideoChatRoom> videoChatRoomOptional) {
                    if (videoChatRoomOptional.isPresent()) {
                        nVideoChatRoom = videoChatRoomOptional.get();
                        refuseInvatation();
                    }

                }

                @Override
                public void onFailed(Throwable throwable) {
                    sendEmptyMessage(MR.GroupTalkInviteActivity_refusesSuccess);
                }
            });
        } else {
            refuseInvatation();
        }
    }

    private void refuseInvatation() {
        AbortableFuture<Optional<Void>> refuseAbo = nVideoChatService.refuseVideoInvite(nVideoChatRoom.getRoomId());
        refuseAbo.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                sendEmptyMessage(MR.GroupTalkInviteActivity_refusesSuccess);
            }

            @Override
            public void onFailed(Throwable throwable) {
                sendEmptyMessage(MR.GroupTalkInviteActivity_refusesSuccess);
            }
        });
    }
}
