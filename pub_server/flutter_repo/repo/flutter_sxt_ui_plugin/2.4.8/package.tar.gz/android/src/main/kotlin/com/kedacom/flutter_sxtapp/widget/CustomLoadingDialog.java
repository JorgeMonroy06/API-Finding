package com.kedacom.flutter_sxtapp.widget;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import com.kedacom.flutter_sxtapp.R;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class CustomLoadingDialog extends BaseDialogFragment {


    @Override
    public @NotNull
    Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_custom_loading_flutter, null);
        Dialog dialog = new Dialog(getActivity());
        dialog.setContentView(view);
        return dialog;
    }
}
