package com.kedacom.flutter_sxtapp.manager

import android.content.Context
import android.content.Context.POWER_SERVICE
import android.content.Intent
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Html
import android.text.TextUtils
import androidx.appcompat.app.AlertDialog
import com.google.gson.Gson
import com.google.gson.internal.LinkedTreeMap
import com.google.gson.reflect.TypeToken
import com.kedacom.basic.common.util.Optional
import com.kedacom.flutter_sxtapp.Constants
import com.kedacom.flutter_sxtapp.activity.OpenFileActivity
import com.kedacom.flutter_sxtapp.activity.PermissionGuideActivity
import com.kedacom.flutter_sxtapp.model.Contact
import com.kedacom.flutter_sxtapp.model.MultiCallBean
import com.kedacom.sxt_flutter_plugin.manager.SxtDataManager
import com.kedacom.sxt_flutter_plugin.model.message.SessionEntity
import com.kedacom.sxt_flutter_plugin.util.AppUtil
import com.kedacom.uc.sdk.RequestCallback
import com.kedacom.uc.sdk.generic.constant.SessionType
import com.kedacom.uc.sdk.impl.SdkImpl
import com.kedacom.uc.sdk.vchat.MultiVideoService
import com.kedacom.uc.sdk.vchat.model.VideoCallType
import com.kedacom.uc.sdk.vchat.model.VideoChatRoom
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.android.FlutterActivityLaunchConfigs
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.JSONMethodCodec
import io.flutter.plugin.common.MethodChannel
import org.json.JSONObject
import java.util.*


class FlutterManager private constructor() {

    private val NATIVE_TO_FLUTTER_CHANNEL = "com.kedacom.flutter_sxtapp.activity/NATIVE_TO_FLUTTER_CHANNEL"
    private val FLUTTER_TO_NATIVE_CHANNEL = "com.kedacom.flutter_sxtapp.activity/FLUTTER_TO_NATIVE_CHANNEL"
    private lateinit var native_to_flutter_method_channel: MethodChannel
    private lateinit var flutter_to_native_method_channel: MethodChannel
    var avatarBaseUrl = ""

    companion object {
        val instance: FlutterManager by lazy(mode = LazyThreadSafetyMode.SYNCHRONIZED) {
            FlutterManager()
        }
    }

    fun dispose() {
        native_to_flutter_method_channel.setMethodCallHandler(null)
        flutter_to_native_method_channel.setMethodCallHandler(null)

    }

    fun bindMethodChannel(flutterPluginBinding: FlutterPlugin.FlutterPluginBinding) {
        native_to_flutter_method_channel = MethodChannel(
            flutterPluginBinding.binaryMessenger,
            NATIVE_TO_FLUTTER_CHANNEL,
            JSONMethodCodec.INSTANCE
        )
        flutter_to_native_method_channel = MethodChannel(
            flutterPluginBinding.binaryMessenger,
            FLUTTER_TO_NATIVE_CHANNEL,
            JSONMethodCodec.INSTANCE
        )
        flutter_to_native_method_channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "GET_BASE_URL" -> {
                    result.success("")
                }
                "START_VOICE_CALL" -> {
                    val param = Gson().fromJson(
                        (call.arguments as JSONObject).toString(),
                        Contact::class.java
                    )
                    SxtUIManager.getInstance()
                        .gotoCall(Constants.LANGUAGE, param.code + "@" + param.originCode, result)
                }
                "START_VIDEO_CALL" -> {
                    val param = Gson().fromJson(
                        (call.arguments as JSONObject).toString(),
                        Contact::class.java
                    )
                    SxtUIManager.getInstance()
                        .gotoCall(Constants.VIDEOCHAT, param.code + "@" + param.originCode, result)
                }
                "START_MULTI_VOICE_CALL" -> {
                    val param = Gson().fromJson(
                        (call.arguments as JSONObject).toString(),
                        MultiCallBean::class.java
                    )
                    SxtUIManager.getInstance().gotoMultiCall(Constants.LANGUAGE, param, result)
                }
                "START_MULTI_VIDEO_CALL" -> {
                    val param = Gson().fromJson(
                        (call.arguments as JSONObject).toString(),
                        MultiCallBean::class.java
                    )
                    SxtUIManager.getInstance().gotoMultiCall(Constants.VIDEOCHAT, param, result)
                }
                "RETURN_MULTI_CALL" -> {
                    val param = Gson().fromJson(
                        (call.arguments as JSONObject).toString(),
                        MultiCallBean::class.java
                    )
                    SxtUIManager.getInstance().returnMultiCall(param, result)
                }
                "BACK_TO_MULTI_CALL" -> {
                    val param =
                        Gson().fromJson((call.arguments as JSONObject).toString(), Map::class.java)
                    SxtUIManager.getInstance().backtoMultiCall(param as LinkedTreeMap<String, Any>?)
                }
                "REQUEST_FLOAT_WINDOW_PERMISSION" -> {
                    showDialogToApplyPermission()
                    result.success(true)
                }
                "HAS_FLOAT_WINDOW_PERMISSION" -> {
                    //检查悬浮窗权限
                    if (Build.VERSION.SDK_INT >= 23) {
                        result.success(Settings.canDrawOverlays(AppUtil.getApp()))
                    } else {
                        result.success(true)
                    }
                }
                "GO_TO_DESKTOP" -> {
                    SxtUIManager.getInstance().currentActivity?.moveTaskToBack(false)
                }
                "SET_SPEAKER_PHONE_ON" -> {
                    val audioManager = AppUtil.getApp()!!.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val isOpen = call.arguments as Boolean
                    Handler(Looper.getMainLooper()).postDelayed({
                        if (isOpen) {
                            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
                            audioManager.isSpeakerphoneOn = true
                        } else {
                            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
                            audioManager.isSpeakerphoneOn = false
                        }
                        result.success(null)
                    }, 300)
                }
                "GET_MULTI_MEETING_INFO" -> {
                    val multiVideoService = SdkImpl.getInstance().getService(MultiVideoService::class.java)
                    multiVideoService.getMultiVideoRoom(call.arguments as String, SessionType.GROUP)
                        .setCallback(object : RequestCallback<Optional<VideoChatRoom>>() {

                            override fun onFailed(e: Throwable) {

                            }

                            override fun onSuccess(value: Optional<VideoChatRoom>?) {
                                if (value != null && value.isPresent) {
                                    val videoChatRoom = value.get();
                                    if (videoChatRoom.hasMembers() && videoChatRoom.roomType == VideoCallType.MULTI_VIDEO) {
                                        val map = HashMap<String, Any?>()
                                        val user = SdkImpl.getInstance().userSession.orNull()
                                        map["code"] = if (videoChatRoom.anchorUserCodeForDomain == user.user.userCodeForDomain) null else videoChatRoom.anchorUserCodeForDomain
                                        map["isVideo"] = videoChatRoom.isVideoChat
                                        map["groupCode"] = videoChatRoom.contactCodeForDomain
                                        map["isCalling"] = SxtDataManager.instance.isCalling
                                        result.success(map)
                                    } else {
                                        result.success(null)
                                    }
                                } else {
                                    result.success(null)
                                }
                            }
                        })
                }
                "REQUEST_BLESS_PERMISSION" -> {
                    val powerManager =
                        AppUtil.getApp()!!.getSystemService(POWER_SERVICE) as PowerManager
                    val hasIgnored: Boolean =
                        powerManager.isIgnoringBatteryOptimizations(AppUtil.getApp()!!.packageName)
                    //  判断当前APP是否有加入电池优化的白名单，如果没有，弹出加入电池优化的白名单的设置对话框。
                    if (!hasIgnored) {
                        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        intent.data = Uri.parse("package:" + AppUtil.getApp()!!.packageName)
                        SxtUIManager.getInstance().currentActivity.startActivity(intent)
                    }
                }
                "GO_TO_PERMISSION_GUIDE_PAGE" -> {
                    val permissionIntent = Intent(
                        SxtUIManager.getInstance().currentActivity,
                        PermissionGuideActivity::class.java
                    )
                    SxtUIManager.getInstance().currentActivity.startActivity(permissionIntent)
                }
                "GO_TO_FILE_PICK_PAGE" -> {
                    val permissionIntent = Intent(
                        SxtUIManager.getInstance().currentActivity,
                        OpenFileActivity::class.java
                    )
                    SxtUIManager.getInstance().currentActivity.startActivity(permissionIntent)
                }
                "GET_VIDEO_DURATION" -> {
                    var dur = 1L
                    val retriever = MediaMetadataRetriever()
                    retriever.setDataSource(call.arguments as String) //在获取前，设置文件路径（应该只能是本地路径）
                    val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    retriever.release() //释放
                    if (!TextUtils.isEmpty(duration)) {
                        dur = duration.toLong()
                    }
                    result.success(dur)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }

    fun isNeedMsgNotification(code: String, listener: FlutterDataListener<Boolean>) {
        native_to_flutter_method_channel.invokeMethod(
            "IS_SHOW_MSG_NOTIFICATION",
            code,
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                    listener.onSuccess((result ?: true) as Boolean)
                }

                override fun error(errorCode: String?, errorMessage: String?, errorDetails: Any?) {
                    listener.onError(IllegalAccessError(errorMessage))
                }

                override fun notImplemented() {
                    listener.onError(IllegalAccessError("flutter method notImplemented"))
                }
            }
        )
    }

    fun getContact(code: String, listener: FlutterDataListener<Contact>) {
        native_to_flutter_method_channel.invokeMethod(
            "GET_CONTACTS",
            arrayListOf(code),
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                    val listType = object : TypeToken<ArrayList<Contact>>() {}.type
                    val contact: List<Contact> = Gson().fromJson(result.toString(), listType)
                    listener.onSuccess(contact[0])
                }

                override fun error(errorCode: String?, errorMessage: String?, errorDetails: Any?) {
                    listener.onError(IllegalAccessError(errorMessage))
                }

                override fun notImplemented() {
                    listener.onError(IllegalAccessError("flutter method notImplemented"))
                }
            }
        )
    }

    fun getContact(codes: List<String>, listener: FlutterDataListener<List<Contact>>) {
        native_to_flutter_method_channel.invokeMethod(
            "GET_CONTACTS",
            codes,
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                    val contact = Gson().fromJson<List<Contact>>(
                        Gson().toJson(result),
                        object : TypeToken<List<Contact>>() {}.type
                    )
                    listener.onSuccess(contact)
                }

                override fun error(errorCode: String?, errorMessage: String?, errorDetails: Any?) {
                    listener.onError(IllegalAccessError(errorMessage))
                }

                override fun notImplemented() {
                    listener.onError(IllegalAccessError("flutter method notImplemented"))
                }
            }
        )
    }

    fun closeSelectContactPage() {
        native_to_flutter_method_channel.invokeMethod(
            "CLOSE_SELECT_CONTACT_PAGE",
            null,
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                }

                override fun error(errorCode: String?, errorMessage: String?, errorDetails: Any?) {
                }

                override fun notImplemented() {
                }
            }
        )
    }

    fun multiMeetingSelectContactPage(groupCode: String, codes: List<String>) {
        val map: MutableMap<String, Any> = mutableMapOf()
        map["groupCode"] = groupCode
        map["selectCode"] = codes
        native_to_flutter_method_channel.invokeMethod(
            "MULTI_MEETING_SELECT_CONTACT_PAGE",
            map,
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                }

                override fun error(errorCode: String?, errorMessage: String?, errorDetails: Any?) {
                }

                override fun notImplemented() {
                }
            }
        )
    }

    fun startMultiMeeting() {
        val map = mutableMapOf<String, Any?>()
        native_to_flutter_method_channel.invokeMethod(
            "START_MULTI_MEETING",
            map,
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                }

                override fun error(errorCode: String?, errorMessage: String?, errorDetails: Any?) {
                }

                override fun notImplemented() {
                }
            }
        )
    }

    fun stopMultiMeeting() {
        native_to_flutter_method_channel.invokeMethod(
            "STOP_MULTI_MEETING",
            null,
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                }

                override fun error(errorCode: String?, errorMessage: String?, errorDetails: Any?) {
                }

                override fun notImplemented() {
                }
            }
        )
    }

    fun updateMultiMeeting() {
        val map = mutableMapOf<String, Any?>()
        native_to_flutter_method_channel.invokeMethod(
            "UPDATE_MULTI_MEETING",
            map,
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                }

                override fun error(errorCode: String?, errorMessage: String?, errorDetails: Any?) {
                }

                override fun notImplemented() {
                }
            }
        )
    }


    fun startVideoCalling() {
        native_to_flutter_method_channel.invokeMethod(
            "START_VIDEO_CALLING",
            null,
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                }

                override fun error(errorCode: String?, errorMessage: String?, errorDetails: Any?) {
                }

                override fun notImplemented() {
                }
            }
        )
    }

    fun endVideoCalling() {
        native_to_flutter_method_channel.invokeMethod(
            "END_VIDEO_CALLING",
            null,
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                }

                override fun error(errorCode: String?, errorMessage: String?, errorDetails: Any?) {
                }

                override fun notImplemented() {
                }
            }
        )
    }


    private fun showDialogToApplyPermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (!Settings.canDrawOverlays(SxtUIManager.getInstance().currentActivity)) {
                //申请权限
                val alertDialog = AlertDialog.Builder(SxtUIManager.getInstance().currentActivity)
                alertDialog.setTitle("提示")
                alertDialog.setMessage(Html.fromHtml("<font color='#333333'>请授予应用悬浮框权限</font>"))
                alertDialog.setPositiveButton("确定") { _, _ -> applyFloatWindowPermission() }
                alertDialog.setNegativeButton("取消") { dialog, _ -> dialog?.dismiss() }
                alertDialog.show()
            }
        }
    }

    private fun applyFloatWindowPermission() {
        val permissionIntent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        permissionIntent.data = Uri.parse("package:" + AppUtil.getApp()?.packageName)
        SxtUIManager.getInstance().currentActivity.startActivityForResult(permissionIntent, 10002)
    }

    fun requestContactBaseUrl() {
        native_to_flutter_method_channel.invokeMethod(
            "GET_CONTACT_AVATAR_BASE_URL",
            null,
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                    try {
                        avatarBaseUrl = result as String
                        print("avatarBaseUrl:$avatarBaseUrl")
                    } catch (e: Exception) {
                        print(e)
                    }
                }

                override fun error(errorCode: String?, errorMessage: String?, errorDetails: Any?) {
                    print(errorDetails)
                }

                override fun notImplemented() {
                    print("GET_CONTACT_AVATAR_BASE_URL notImplemented")
                }
            })
    }

    fun startFlutterPage() {
        var hasFlutterActivity = false
        SxtUIManager.getInstance().createdActivity?.forEach {
            if (it is FlutterActivity) {
                hasFlutterActivity = true
                val intent = Intent(com.kedacom.util.AppUtil.getApp(), it.javaClass)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                com.kedacom.util.AppUtil.getApp()?.startActivity(intent)
            }
        }
        if (!hasFlutterActivity) {
            val intent = FlutterActivity
                .withNewEngine()
//                    .withCachedEngine("my_engine_id")
                .backgroundMode(FlutterActivityLaunchConfigs.BackgroundMode.transparent)
                .build(com.kedacom.util.AppUtil.getApp()!!.applicationContext)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            com.kedacom.util.AppUtil.getApp()?.startActivity(intent)
        }
    }

    fun goToChatPage(sessionEntity: SessionEntity) {
        //app在后台，推送
        if (SxtUIManager.getInstance().isBackground) {
            startFlutterPage()
        }
        var method = ""
        var args: Any? = null
        when (sessionEntity.sessionType) {
            com.kedacom.sxt_flutter_plugin.model.SessionType.USER,
            com.kedacom.sxt_flutter_plugin.model.SessionType.GROUP -> {
                method = "GO_TO_CHAT_PAGE"
                args = sessionEntity
            }
            com.kedacom.sxt_flutter_plugin.model.SessionType.CONTROL_ALARM,
            com.kedacom.sxt_flutter_plugin.model.SessionType.PERSON_ALARM -> {
                method = "GO_TO_ALARM_PAGE"
                args = sessionEntity
            }
        }
        val map = Gson().fromJson(Gson().toJson(args), Map::class.java)
        native_to_flutter_method_channel.invokeMethod(method, map, object : MethodChannel.Result {
            override fun success(result: Any?) {
            }

            override fun error(errorCode: String?, errorMessage: String?, errorDetails: Any?) {
            }

            override fun notImplemented() {
            }
        })
    }

    fun onOpenFileResult(map: HashMap<String, Any>) {
        native_to_flutter_method_channel.invokeMethod(
            "ON_OPEN_FILE_RESULT",
            map,
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                }

                override fun error(errorCode: String?, errorMessage: String?, errorDetails: Any?) {
                }

                override fun notImplemented() {
                }
            })
    }

}