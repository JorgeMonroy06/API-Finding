package com.kedacom.flutter_sxtapp.activity;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;

import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;

import com.kedacom.basic.common.util.Optional;
import com.kedacom.basic.common.util.StringUtil;
import com.kedacom.flutter_sxtapp.R;
import com.kedacom.flutter_sxtapp.databinding.ActivityMeetingFlutterBinding;
import com.kedacom.flutter_sxtapp.manager.FlutterManager;
import com.kedacom.flutter_sxtapp.model.VideoParam;
import com.kedacom.flutter_sxtapp.util.ClickEventUtils;
import com.kedacom.flutter_sxtapp.viewmodel.MeetingViewModel;
import com.kedacom.flutter_sxtapp.widget.CustomLoadingDialog;
import com.kedacom.lego.annotation.Extra;
import com.kedacom.lego.annotation.OnMessage;
import com.kedacom.lego.fast.widget.dialog.AlertDialog;
import com.kedacom.lego.fast.widget.dialog.ConfirmDialog;
import com.kedacom.lego.message.LegoEventBus;
import com.kedacom.sxt_flutter_plugin.manager.SxtDataManager;
import com.kedacom.uc.ptt.video.media.DefaultCameraCapture;
import com.kedacom.uc.ptt.video.media.DefaultVideoRender;
import com.kedacom.uc.sdk.AbortableFuture;
import com.kedacom.uc.sdk.RequestCallback;
import com.kedacom.uc.sdk.auth.model.IAccount;
import com.kedacom.uc.sdk.generic.model.SessionIdentity;
import com.kedacom.uc.sdk.impl.SdkImpl;
import com.kedacom.uc.sdk.meeting.constant.ApplyJoinResultType;
import com.kedacom.uc.sdk.meeting.constant.MeetingOperateType;
import com.kedacom.uc.sdk.meeting.constant.MeetingOptions;
import com.kedacom.uc.sdk.meeting.constant.MeetingState;
import com.kedacom.uc.sdk.meeting.model.ApplyJoinResultEvent;
import com.kedacom.uc.sdk.meeting.model.IMeeting;
import com.kedacom.uc.sdk.meeting.model.MMemberOperateEvent;
import com.kedacom.uc.sdk.meeting.model.MeetingOperateEvent;
import com.kedacom.uc.sdk.vchat.VideoTalkService;
import com.kedacom.uc.sdk.vchat.model.VideoChatRoom;
import com.kedacom.webrtc.RendererCommon;
import com.kedacom.webrtc.SurfaceViewRenderer;
import com.kedacom.webrtcsdk.component.Constantsdef;
import com.kedacom.webrtcsdk.sdkmanager.kedamedia;

public class MeetingActivity extends BaseActivity<ActivityMeetingFlutterBinding, MeetingViewModel> {

    @Extra
    private String linkId;
    @Extra
    private boolean isLinkId;
    private Handler timerHandler = new Handler();
    private long startTime = 0;//通话时长
    private boolean isMute = false;
    private boolean isHeadset = false;
    private boolean isSpeakOn = true;

    private CustomLoadingDialog customLoadingDialog;
    private DefaultVideoRender videoRender;
    private DefaultCameraCapture videoCapture;
    private AudioManager nAudioManager;
    /**
     * ICE连接状态的
     */
    private Observer<Integer> iceConnectStateObserver;
    private Observer<String> closeVideoCallObserver;
    private Observer<String> acceptCallObserver;
    private Observer<String> videoSelfAcceptObserver;
    private Observer<String> inviteMeetingCallObserver;
    private Observer<MMemberOperateEvent> memberOperateObserver;
    private Observer<MeetingOperateEvent> meetingOperateObserver;
    private Observer<ApplyJoinResultEvent> applyJoinResultEventObserver;
    /**
     * 第一帧数据的调整
     */
    private Observer<VideoParam> adjustVideoParamObserver;

    @Override
    public int getContentViewId() {
        return R.layout.activity_meeting_flutter;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FlutterManager.Companion.getInstance().startVideoCalling();
        MeetingOptions.DEFAULT.joinWaitTime = 1000 * 60 * 2;

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        initData();
        setListener();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        logger.info("VideoCallActivity onConfigurationChanged");
        if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            getViewDataBinding().llLand.setVisibility(View.GONE);
            getViewDataBinding().tvTimeLand.setVisibility(View.GONE);

            getViewDataBinding().llInfo.setVisibility(View.VISIBLE);
        } else if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            getViewDataBinding().llLand.setVisibility(View.VISIBLE);
            getViewDataBinding().tvTimeLand.setVisibility(View.VISIBLE);

            getViewDataBinding().llInfo.setVisibility(View.GONE);
        }
    }

    private void setListener() {
        getViewDataBinding().ivSwitchCam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ClickEventUtils.needRaiseClickEvent())
                    return;
                getViewModel().switchCamera();
            }
        });
        getViewDataBinding().ivSwitchCamLand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ClickEventUtils.needRaiseClickEvent())
                    return;
                getViewModel().switchCamera();
            }
        });
        getViewDataBinding().ivHandup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ClickEventUtils.needRaiseClickEvent())
                    return;
                getViewModel().callFinish();
            }
        });
        getViewDataBinding().tvTimeLand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ClickEventUtils.needRaiseClickEvent())
                    return;
                getViewModel().callFinish();
            }
        });
        getViewDataBinding().ivMute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isMute = !isMute;
                setMute(isMute);
            }
        });
        getViewDataBinding().ivMuteLand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isMute = !isMute;
                setMute(isMute);
            }
        });
        getViewDataBinding().ivHandFree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isSpeakOn = !isSpeakOn;
                setSpeaker(isSpeakOn);
            }
        });
        getViewDataBinding().ivHandFreeLand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isSpeakOn = !isSpeakOn;
                setSpeaker(isSpeakOn);
            }
        });
    }

    /**
     * 设置开关静音
     */
    private void setMute(boolean isMute, boolean showToast) {
        getViewDataBinding().ivMute.setImageResource(isMute ? R.mipmap.bid_video_mute_open_flutter : R.mipmap.bid_video_mute_close_flutter);
        getViewDataBinding().ivMuteLand.setImageResource(isMute ? R.mipmap.bid_video_mute_open_flutter : R.mipmap.bid_video_mute_close_flutter);
        logger.info("MeetingActivity setMute isMute : {} ", isMute);
        VideoTalkService videoTalkService = SdkImpl.getInstance().getService(VideoTalkService.class);
        AbortableFuture<Optional<Void>> future = videoTalkService.setMicMute(getViewModel().videoChatRoom.getRoomId(), isMute);
        future.setCallback(new RequestCallback<Optional<Void>>() {
            @Override
            public void onSuccess(Optional<Void> voidOptional) {
                MeetingActivity.this.isMute = isMute;
                logger.info("MeetingActivity videoCall onSetMicMute onSuccess isMute:" + isMute);
            }

            @Override
            public void onFailed(Throwable throwable) {
                logger.info("MeetingActivity videoCall onSetMicMute {} ,isMute: {}", throwable.getMessage(), isMute);
                if (isMute) {
                    if (showToast) {
                        showToast("设置静音失败");
                    }
                } else {
                    if (showToast) {
                        showToast("取消静音失败");
                    }
                }
            }
        });
    }

    /**
     * 设置开关静音
     */
    private void setMute(boolean isMute) {
        setMute(isMute, true);
    }

    //点击扬声器切换视图发生视图变化
    private void setSpeaker(boolean isSpeakOn) {
        if (isHeadset) {
            logger.info("MeetingActivity onSpeakerClicked isHeadset: " + isHeadset);
            return;
        }
        getViewDataBinding().ivHandFree.setImageResource(isSpeakOn ? R.mipmap.bid_video_speakout_flutter : R.mipmap.bid_video_speaking_flutter);
        getViewDataBinding().ivHandFreeLand.setImageResource(isSpeakOn ? R.mipmap.bid_video_speakout_flutter : R.mipmap.bid_video_speaking_flutter);
        logger.info("MeetingActivity onSpeakerClicked {}", isSpeakOn);
        kedamedia.getInstance(this, null).setHandsFree(isSpeakOn);
    }

    private void initData() {
        customLoadingDialog = new CustomLoadingDialog();
        customLoadingDialog.show(this);

        nAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        iceConnectState();
        closeMeetingCallEventBus();
        acceptVideoParamEventBus();
        addMeetingOperateEventBus();
        acceptCallEventBus();
        addVideoSelfAcceptObserver();
        addMemberOperateEventBus();
        inviteMeetingCallEventBus();
        applyJoinResultEventObserverEventBus();

        IAccount iAccount = SdkImpl.getInstance().getUserSession().orNull();
        if (null == iAccount || (iAccount != null && !iAccount.isOnline())) {
            AlertDialog alertDialog = new AlertDialog.Builder()
                    .message(getString(R.string.login_sxt_first))
                    .okButtonText("我知道了")
                    .build();
            alertDialog.setOkBtnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
            alertDialog.show(this);
        } else if (SxtDataManager.Companion.getInstance().isCalling()) {
            showAlert("正在进行音视频通话中!");
        } else {
            // 获取唤醒参数
            Intent intent = getIntent();
            String action = intent.getAction();
            if (Intent.ACTION_VIEW.equals(action)) {
                try {
                    String sharelinkId = getIntent().getData().getQueryParameter("sharelinkId");
                    logger.info("MeetingActivity get sharelinkId {}", sharelinkId);
                    getViewModel().getMeetingByLinkId(sharelinkId);
                } catch (Exception e) {
                    logger.error("MeetingActivity get sharelinkId error", e);
                    showAlert("会议链接无效");
                }
            } else {
                if (isLinkId) {
                    getViewModel().getMeetingByLinkId(linkId);
                } else {
                    getViewModel().getMeeting(linkId);
                }
            }
        }
        SxtDataManager.Companion.getInstance().setCalling(true);//是否进行双向视频。用来判断不可进行ptt对讲
    }

    private void inviteMeetingCallEventBus() {
        inviteMeetingCallObserver = new Observer<String>() {
            @Override
            public void onChanged(String data) {
                logger.debug("inviteMeetingCallEventBus ");
                initVideoData();
            }
        };
        LegoEventBus.use("MEETING_AUTO_ACCEPT", String.class).observeForever(inviteMeetingCallObserver);
    }

    private void applyJoinResultEventObserverEventBus() {
        applyJoinResultEventObserver = new Observer<ApplyJoinResultEvent>() {
            @Override
            public void onChanged(ApplyJoinResultEvent applyJoinResultEvent) {
                if (applyJoinResultEvent.getType() == ApplyJoinResultType.AGREE) {
//            initVideoData();
                    //等待音视频邀请信令
                } else if (applyJoinResultEvent.getType() == ApplyJoinResultType.REFUSE) {
                    showAlert("申请入会被拒绝");
                } else if (applyJoinResultEvent.getType() == ApplyJoinResultType.CANCEL) {
                    showAlert("会议已取消");
                } else if (applyJoinResultEvent.getType() == ApplyJoinResultType.TIME_OUT) {
                    showAlert("申请入会超时");
                } else if (applyJoinResultEvent.getType() == ApplyJoinResultType.UNDEFINE) {
                    showAlert("申请入会失败 " + applyJoinResultEvent.getReason());
                }
            }
        };
        LegoEventBus.use("ApplyJoinResultEvent", ApplyJoinResultEvent.class).observeForever(applyJoinResultEventObserver);
    }

    //第一帧码流回调分辨率 主要是针对 手机和web 执法记录仪 入会调度
    private void acceptVideoParamEventBus() {
        adjustVideoParamObserver = new Observer<VideoParam>() {
            @Override
            public void onChanged(@Nullable VideoParam videoParam) {
                logger.debug("acceptVideoParamEventBus {},{}", videoParam.getnVideoHeight(), videoParam.getnVideoWidht());
                listenResolutionChangeResult(videoParam);
            }
        };
        LegoEventBus.use("videoParam", VideoParam.class).observeForever(adjustVideoParamObserver);
    }

    private void acceptCallEventBus() {
        acceptCallObserver = new Observer<String>() {
            @Override
            public void onChanged(@Nullable String roomId) {
                if (null != getViewModel().videoChatRoom && getViewModel().videoChatRoom.getRoomId().equals(roomId)) {
                    if (null != customLoadingDialog) {
                        customLoadingDialog.dismiss();
                    }
                    //加入成功后清除该会议通知栏通知
                    startTimer();
                    clearNotify();
                }
            }
        };
        LegoEventBus.use("CALLEE_ACK_AGREE", String.class).observeForever(acceptCallObserver);
    }

    private void addVideoSelfAcceptObserver() {
        videoSelfAcceptObserver = new Observer<String>() {
            @Override
            public void onChanged(@Nullable String roomId) {
                if (null != getViewModel().videoChatRoom && getViewModel().videoChatRoom.getRoomId().equals(roomId)) {
                    if (null != customLoadingDialog) {
                        customLoadingDialog.dismiss();
                    }
                    //加入成功后清除该会议通知栏通知
                    startTimer();
                    clearNotify();
                }
            }
        };
        LegoEventBus.use("VIDEO_SELF_ACCEPT", String.class).observeForever(videoSelfAcceptObserver);
    }

    /**
     * ICE状态监听
     */
    private void iceConnectState() {
        iceConnectStateObserver = new Observer<Integer>() {
            @Override
            public void onChanged(@Nullable Integer iceConnectState) {
                switch (iceConnectState) {
                    case Constantsdef.ICE_STATUS.ICE_CONNECT_SUCCESS:
                        logger.info(getString(R.string.ice_connect_successful));
                        break;
                    case Constantsdef.ICE_STATUS.ICE_CONNECT_DISCONNECT:
                        logger.info(getString(R.string.ice_disconnect));
                        break;
                    case Constantsdef.ICE_STATUS.ICE_CONNECT_FAILED:
                        logger.info(getString(R.string.ice_connection_fail));
                        logger.debug("callFinish ice连接失败");
                        getViewModel().callFinish();
                        break;
                }
            }
        };
        LegoEventBus.use("iceConnectState", Integer.class).observeForever(iceConnectStateObserver);
    }

    //外部事件收到通知 关闭界面
    private void closeMeetingCallEventBus() {
        closeVideoCallObserver = new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                logger.debug("closeVideoCallEventBus current videoRoom:{},s:{}", getViewModel().videoChatRoom, s);
                if (StringUtil.isEquals(s, "phoneInterruption")) {
                    logger.info(getString(R.string.call_interrupt_re_dial));
                }
                if (getViewModel().videoChatRoom == null || (getViewModel().videoChatRoom != null && StringUtil.isEquals(s, getViewModel().videoChatRoom.getRoomId())) || StringUtil.isEquals("disconnect", s)) {
                    if (!isFinishing()) {
                        logger.debug("callFinish closeVideoCallEventBus {}", s);
                        getViewModel().callFinish();
                    }
                }
            }
        };
        LegoEventBus.use("closeVideoCall", String.class).observeForever(closeVideoCallObserver);
    }

    private void addMeetingOperateEventBus() {
        meetingOperateObserver = new Observer<MeetingOperateEvent>() {

            @Override
            public void onChanged(@Nullable MeetingOperateEvent meetingOperateEvent) {
                if (meetingOperateEvent.isPresent() && meetingOperateEvent.get().getLinkId().equals(linkId)) {
                    IMeeting meeting = meetingOperateEvent.get();
                    if (meeting.getMeetingState() == MeetingState.END) {
                        showAlert("会议已结束");
                        clearNotify();
                    } else if (meeting.getMeetingState() == MeetingState.ABNORMAL) {
                        showAlert("会议状态异常");
                    } else if (meeting.getMeetingState() == MeetingState.UNDEFINED) {
                        showAlert("会议状态异常");
                    }
                }
            }
        };
        LegoEventBus.use("MeetingOperateEvent", MeetingOperateEvent.class).observeForever(meetingOperateObserver);
    }

    private void addMemberOperateEventBus() {
        memberOperateObserver = new Observer<MMemberOperateEvent>() {

            @Override
            public void onChanged(@Nullable MMemberOperateEvent mMemberOperateEvent) {
                if (mMemberOperateEvent.isPresent() && mMemberOperateEvent.get().getMeeting().getLinkId().equals(linkId)) {
                    IMeeting meeting = mMemberOperateEvent.get().getMeeting();
                    if (meeting.getMeetingOperateType() == MeetingOperateType.KICKOUT) {
                        showAlert("您已被移出会议");
                        clearNotify();
                    } else if (meeting.getMeetingOperateType() == MeetingOperateType.FINISH) {
                        showAlert("会议已结束");
                        clearNotify();
                    }
                }
            }
        };
        LegoEventBus.use("MMemberOperateEvent", MMemberOperateEvent.class).observeForever(memberOperateObserver);
    }

    private void initVideoData() {
        initMeetingView();
        mViewModel.queryRoomInfo();
    }

    private void initMeetingView() {
        videoRender = new DefaultVideoRender(this);
        videoCapture = new DefaultCameraCapture();
        SurfaceViewRenderer surfaceView = videoRender.getView();
        getViewDataBinding().flViedoView.addView(surfaceView);
        SurfaceViewRenderer selfViewRenderer = videoRender.getView2();

        surfaceView.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
        surfaceView.setEnableHardwareScaler(false);

        selfViewRenderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
        selfViewRenderer.setZOrderMediaOverlay(true);
        selfViewRenderer.setEnableHardwareScaler(true);
    }

    @OnMessage
    public void queryMeetingSuccess(IMeeting meeting) {
        if (linkId == null) {
            //通过linkId入会
            if (meeting.getMeetingMembers() != null && !meeting.getMeetingMembers().isEmpty()) {
                boolean isContains = false;
                IAccount iAccount = SdkImpl.getInstance().getUserSession().orNull();
                for (SessionIdentity sessionIdentity : meeting.getMeetingMembers()) {
                    if (sessionIdentity.getCodeForDomain().equals(iAccount.getUser().getUserCodeForDomain())) {
                        isContains = true;
                        break;
                    }
                }
                if (isContains) {
                    getViewModel().joinMeeting(meeting);
                } else {
                    showAlert("当前登录人与会议被邀请人账号不一致！");
                }
            } else {
                showAlert("当前登录人与会议被邀请人账号不一致！");
            }
        } else {
            if (meeting.getMeetingState() == MeetingState.END) {
                showAlert("会议已结束");
                clearNotify();
            } else if (meeting.getMeetingState() == MeetingState.ABNORMAL) {
                showAlert("会议状态异常");
            } else if (meeting.getMeetingState() == MeetingState.MEETING) {
                if (isLinkId) {
                    getViewModel().joinMeeting(meeting);
                } else {
                    initVideoData();
                }
            } else if (meeting.getMeetingState() == MeetingState.UNDEFINED) {
                if (isLinkId) {
                    getViewModel().joinMeeting(meeting);
                } else {
                    initVideoData();
                }
            }
        }
    }


    private void showAlert(String message) {
        if (TextUtils.isEmpty(message)) return;

        AlertDialog alertDialog = new AlertDialog.Builder()
                .message(message)
                .okButtonText("我知道了")
                .build();
        alertDialog.setOkBtnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getViewModel().callFinish();
                finish();
            }
        });
        alertDialog.show(this);
    }

    private void showExitMeetingAlert() {
        ConfirmDialog alertDialog = new ConfirmDialog.Builder()
                .msg("返回将退出会议，请确认是否返回？")
                .positiveBtnText("确认")
                .negativeBtnText("取消")
                .positiveClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        getViewModel().callFinish();
                        finish();
                    }
                })
                .build();
        alertDialog.show(this);
    }

    @OnMessage
    public void queryMeetingFailed(String message) {
        showAlert(message);
    }

    @OnMessage
    public void queryRoomInfoSuccess(VideoChatRoom videoChatRoom) {
        getViewModel().bindCaptureAndRender(linkId == null || isLinkId, videoCapture, videoRender);
    }

    @OnMessage
    public void queryRoomInfoFailed(String message) {
        showAlert(message);
    }

    @OnMessage
    public void joinRoomSuccess() {
        setSpeaker(isSpeakOn);
        setMute(isMute, false);
    }

    @OnMessage
    public void joinMeetingFailed(String message) {
        showAlert(message);
    }


    private void clearNotify() {
        if (null != linkId) {
            NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            mNotificationManager.cancel(linkId.hashCode());
        }
    }

    private void startTimer() {
        if (startTime == 0) {
            startTime = System.currentTimeMillis();
        }
        timerHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                String time = getViewModel().getFormatTime(startTime);
                getViewDataBinding().tvTime.setText(time);
                getViewDataBinding().tvTimeLand.setText(time);

                startTimer();
            }
        }, 1000);
    }

    @OnMessage
    public void joinRoomFailed(String message) {
        showAlert(message);
    }

    @OnMessage
    public void finishCall() {
        if (!isFinishing())
            finish();
    }

    /**
     * 切换到听筒
     */
    public void changeToReceiver() {
        nAudioManager.setSpeakerphoneOn(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            nAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
        } else {
            nAudioManager.setMode(AudioManager.MODE_IN_CALL);
        }
    }

    /**
     * 切换到扬声器
     */
    public void changeToSpeaker() {
        nAudioManager.setMode(AudioManager.MODE_NORMAL);
        nAudioManager.setSpeakerphoneOn(true);
    }

    public void listenResolutionChangeResult(VideoParam videoParam) {
        if (videoParam == null) {
            return;
        }
        if (videoParam.getnVideoHeight() < videoParam.getnVideoWidht()) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            logger.trace("listenResolutionChangeResult  resolution.height ={}  resolution.width = {} ", videoParam.getnVideoHeight(), videoParam.getnVideoWidht());
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }

    @Override
    public void onBackPressed() {
        showExitMeetingAlert();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        FlutterManager.Companion.getInstance().endVideoCalling();
        getViewModel().cancelJoinMeeting();
        SxtDataManager.Companion.getInstance().setCalling(false);
        timerHandler.removeCallbacksAndMessages(null);
        if (null != closeVideoCallObserver) {
            LegoEventBus.use("closeVideoCall", String.class).removeObserver(closeVideoCallObserver);
        }
        if (null != adjustVideoParamObserver) {
            LegoEventBus.use("videoParam", VideoParam.class).removeObserver(adjustVideoParamObserver);
        }
        if (null != iceConnectStateObserver) {
            LegoEventBus.use("iceConnectState", Integer.class).removeObserver(iceConnectStateObserver);
        }
        if (null != meetingOperateObserver) {
            LegoEventBus.use("MeetingOperateEvent", MeetingOperateEvent.class).removeObserver(meetingOperateObserver);
        }
        if (null != memberOperateObserver) {
            LegoEventBus.use("MMemberOperateEvent", MMemberOperateEvent.class).removeObserver(memberOperateObserver);
        }
        if (null != acceptCallObserver) {
            LegoEventBus.use("CALLEE_ACK_AGREE", String.class).removeObserver(acceptCallObserver);
        }
        if (null != videoSelfAcceptObserver) {
            LegoEventBus.use("VIDEO_SELF_ACCEPT", String.class).removeObserver(videoSelfAcceptObserver);
        }
        if (null != inviteMeetingCallObserver) {
            LegoEventBus.use("MEETING_AUTO_ACCEPT", String.class).removeObserver(inviteMeetingCallObserver);
        }
        if (null != applyJoinResultEventObserver) {
            LegoEventBus.use("ApplyJoinResultEvent", ApplyJoinResultEvent.class).removeObserver(applyJoinResultEventObserver);
        }
        if (null != videoRender) {
            videoRender.recycle();
        }
    }
}
