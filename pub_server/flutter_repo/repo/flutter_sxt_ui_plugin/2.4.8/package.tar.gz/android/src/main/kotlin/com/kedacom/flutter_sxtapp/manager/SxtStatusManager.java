package com.kedacom.flutter_sxtapp.manager;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;

import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;

import com.kedacom.basic.common.util.Optional;
import com.kedacom.basic.common.util.StringUtil;
import com.kedacom.flutter_sxtapp.Constants;
import com.kedacom.flutter_sxtapp.R;
import com.kedacom.flutter_sxtapp.activity.GroupTalkInviteActivity;
import com.kedacom.flutter_sxtapp.activity.GroupVideoCallActivity;
import com.kedacom.flutter_sxtapp.activity.VideoCallActivity;
import com.kedacom.flutter_sxtapp.notification.NotificationClickReceiver;
import com.kedacom.flutter_sxtapp.notification.NotificationDict;
import com.kedacom.flutter_sxtapp.notification.NotificationHelper;
import com.kedacom.flutter_sxtapp.receiver.PttAudioReceiver;
import com.kedacom.lego.fast.LegoIntent;
import com.kedacom.lego.fast.util.ToastUtil;
import com.kedacom.lego.message.LegoEventBus;
import com.kedacom.lego.message.LegoMessageManager;
import com.kedacom.sxt_flutter_plugin.manager.SxtDataManager;
import com.kedacom.uc.sdk.Abortable;
import com.kedacom.uc.sdk.AbortableFuture;
import com.kedacom.uc.sdk.EventObserver;
import com.kedacom.uc.sdk.conversation.ConversationObserver;
import com.kedacom.uc.sdk.conversation.model.IConversation;
import com.kedacom.uc.sdk.event.model.ModificationEvent;
import com.kedacom.uc.sdk.impl.SdkImpl;
import com.kedacom.uc.sdk.meeting.MeetingServiceObserver;
import com.kedacom.uc.sdk.meeting.constant.MeetingMemberEventType;
import com.kedacom.uc.sdk.meeting.model.ApplyJoinResultEvent;
import com.kedacom.uc.sdk.meeting.model.IMeeting;
import com.kedacom.uc.sdk.meeting.model.MMemberOperateEvent;
import com.kedacom.uc.sdk.meeting.model.MeetingOperateEvent;
import com.kedacom.uc.sdk.util.DomainIdUtil;
import com.kedacom.uc.sdk.vchat.MultiVideoServiceObservable;
import com.kedacom.uc.sdk.vchat.VideoChatServiceObserver;
import com.kedacom.uc.sdk.vchat.VideoTalkServiceObserver;
import com.kedacom.uc.sdk.vchat.constant.VideoChatEventType;
import com.kedacom.uc.sdk.vchat.model.VideoChatEvent;
import com.kedacom.util.AppUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class SxtStatusManager {

    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private static SxtStatusManager mInstance;

    private static final String STATE_UPDATE_MEETING = "update_meeting_state";
    private static final String STATE_UPDATE_POINT_CALL = "update_point_call_state";
    private static final String AUDIO_OR_VIDEO_COMING = "AUDIO_OR_VIDEO_COMING";
    private static final String CALL_INCOMING = "CALL_INCOMING";

    private NotificationClickReceiver notificationClickReceiver;
    private PttAudioReceiver pttAudioReceiver;
    private List<Abortable> abortables = new ArrayList<>();
    private Abortable groupTalkAbortable;
    private Abortable videoServiceAbortable;
    private MeetingServiceObserver meetingServiceObserver;
    private Abortable meetingAbortable;
    private AbortableFuture<Optional<IMeeting>> meetingFuture;
    private boolean isMeeting; //是否在会议
    private boolean isPoint;  //是否在点调
    private Handler statusHandler;

    private Observer<Boolean> isMeetingObserver = new Observer<Boolean>() {
        @Override
        public void onChanged(@Nullable Boolean result) {
            logger.info("SxtStatusManager STATE_UPDATE_MEETING isMeeting : {}", result);
            isMeeting = result;
        }
    };
    private Observer<Boolean> isPointObserver = new Observer<Boolean>() {
        @Override
        public void onChanged(@Nullable Boolean result) {
            logger.info("SxtStatusManager STATE_UPDATE_POINT_CALL isPoint : {}", result);
            isPoint = result;
        }
    };


    public static synchronized SxtStatusManager getInstance() {
        if (null == mInstance) {
            synchronized (SxtStatusManager.class) {
                if (null == mInstance) {
                    mInstance = new SxtStatusManager();
                }
            }
        }
        return mInstance;
    }

    public void loginSuccess() {
        statusHandler = new Handler();
        addVideoLanguageChatOber();
        addVideoGroupTalkListener();
        addMultiGroupVideoCallObser();
        addListeners();
        addMeetingOperationEventListener();
        LegoEventBus.use(STATE_UPDATE_MEETING, Boolean.class).observeForever(isMeetingObserver);
        LegoEventBus.use(STATE_UPDATE_POINT_CALL, Boolean.class).observeForever(isPointObserver);

        pttAudioReceiver = new PttAudioReceiver(AppUtil.getApp());
        pttAudioReceiver.registerPttAudioReceiver();

        if (null == notificationClickReceiver) {
            notificationClickReceiver = new NotificationClickReceiver();
        }
        try {
            IntentFilter intentFilter = new IntentFilter(NotificationDict.NOTICE_CLICK);
            intentFilter.setPriority(1000);
            AppUtil.getApp().registerReceiver(notificationClickReceiver, intentFilter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addListeners() {
        MeetingServiceObserver meetingServiceObserver = SdkImpl.getInstance().getService(MeetingServiceObserver.class);
        abortables.add(meetingServiceObserver.observerListenApplyJoinResult(new EventObserver<ApplyJoinResultEvent>() {
            @Override
            public void onEvent(ApplyJoinResultEvent applyJoinResultEvent) {
                logger.info("SxtStatusManager ApplyJoinResultEvent : {}", applyJoinResultEvent.toString());
                LegoEventBus.use("ApplyJoinResultEvent", ApplyJoinResultEvent.class).postValue(applyJoinResultEvent);
            }
        }));
        ConversationObserver mConversationObserver = SdkImpl.getInstance().getService(ConversationObserver.class);
        //消息监听
        abortables.add(mConversationObserver.listenConvChange(new EventObserver<ModificationEvent<IConversation>>() {
            @Override
            public void onEvent(ModificationEvent<IConversation> iConversationModificationEvent) {
                if (iConversationModificationEvent.get().getSender() != null) {
                    String sendCode = iConversationModificationEvent.get().getSender().getCode();
                    if (!StringUtil.isEquals(sendCode, "server_poly") && !StringUtil.isEquals(sendCode, "server_single")) {
                        try {
                            ConversstionUtils.getInstance().monitorConvertsation(iConversationModificationEvent);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }));
    }

    public void logout() {
        statusHandler.removeCallbacksAndMessages(null);
        statusHandler = null;
        LegoEventBus.use(STATE_UPDATE_MEETING, Boolean.class).removeObserver(isMeetingObserver);
        LegoEventBus.use(STATE_UPDATE_POINT_CALL, Boolean.class).removeObserver(isPointObserver);
        if (null != groupTalkAbortable) {
            groupTalkAbortable.abort();
        }
        groupTalkAbortable = null;
        if (null != videoServiceAbortable) {
            videoServiceAbortable.abort();
        }
        videoServiceAbortable = null;
        if (null != meetingFuture) {
            meetingFuture.abort();
        }
        meetingFuture = null;
        if (null != meetingAbortable) {
            meetingAbortable.abort();
        }
        meetingAbortable = null;
        if (null != pttAudioReceiver) {
            pttAudioReceiver.unregisterPttAudioReceiver();
        }
        if (null != notificationClickReceiver) {
            try {
                AppUtil.getApp().unregisterReceiver(notificationClickReceiver);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (abortables != null) {
            for (Abortable a : abortables) {
                a.abort();
            }
            abortables.clear();
        }
        videoServiceAbortable = null;
        isMeeting = false;
        isPoint = false;
        mInstance = null;
    }


    private void addMultiGroupVideoCallObser() {
        Abortable abort = SdkImpl.getInstance().getService(MultiVideoServiceObservable.class).listenMultiVideoEvents(new EventObserver<VideoChatEvent>() {
            @Override
            public void onEvent(VideoChatEvent event) {
                Activity activity = SxtUIManager.getInstance().getCurrentActivity();
                logger.info("SxtStatusManager videoService MutilVideolistenBidVideoEvents {}", event);
                if (event == null || event.get() == null) {
                    return;
                }
                LegoEventBus.use("groupMutivideoRoomStateCall", VideoChatEvent.class).postValue(event);
                NotificationManager mNotificationManager = (NotificationManager) AppUtil.getApp().getSystemService(Context.NOTIFICATION_SERVICE);
                switch (event.getType()) {
                    case VIDEO_SHARE_INVITE_CALL:
                        SxtUIManager.getInstance().startMultiMeeting();
                        break;
                    case INCOMING:
                        SxtUIManager.getInstance().startMultiMeeting();

                        Intent intent = new Intent(activity, GroupVideoCallActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        intent.putExtra("event", event);
                        intent.putExtra("isSender", false);
                        intent.putExtra("isVideo", true);
                        event.get().getContactCodeForDomain();
                        intent.putExtra("codeForDomain", event.get().getContactCodeForDomain());
                        intent.putExtra("groupCode", event.get().getContactCodeForDomain().split("@")[0]);
                        intent.putExtra("VideoChatRoom", event.get());
                        activity.startActivity(intent);

                        //用于判断国产手机没有开启后台弹出界面权限时，没有打开通话界面的问题
                        statusHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                List<Activity> activityList = SxtUIManager.getInstance().getCreatedActivity();
                                boolean isContainsCalActivity = false;
                                for (int i = 0; i < activityList.size(); i++) {
                                    Activity calActivity = activityList.get(i);
                                    if (calActivity instanceof GroupVideoCallActivity) {
                                        isContainsCalActivity = true;
                                        break;
                                    }
                                }
                                if (!isContainsCalActivity) {
                                    NotificationHelper.getInstance().sendGroupVideoCallNotification(activity, false, intent);
                                }
                            }
                        }, 800);
                        break;
                    case VOICE_INCOMING:
                        SxtUIManager.getInstance().startMultiMeeting();

                        Intent voiceIntent = new Intent(activity, GroupVideoCallActivity.class);
                        voiceIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        voiceIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        voiceIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        voiceIntent.putExtra("event", event);
                        voiceIntent.putExtra("isSender", false);
                        voiceIntent.putExtra("isVideo", false);
                        voiceIntent.putExtra("codeForDomain", event.get().getContactCodeForDomain());
                        voiceIntent.putExtra("groupCode", event.get().getContactCodeForDomain().split("@")[0]);
                        voiceIntent.putExtra("VideoChatRoom", event.get());
                        activity.startActivity(voiceIntent);

                        //用于判断国产手机没有开启后台弹出界面权限时，没有打开通话界面的问题
                        statusHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                List<Activity> activityList = SxtUIManager.getInstance().getCreatedActivity();
                                boolean isContainsCalActivity = false;
                                for (int i = 0; i < activityList.size(); i++) {
                                    Activity calActivity = activityList.get(i);
                                    if (calActivity instanceof GroupVideoCallActivity) {
                                        isContainsCalActivity = true;
                                        break;
                                    }
                                }
                                if (!isContainsCalActivity) {
                                    NotificationHelper.getInstance().sendGroupVideoCallNotification(activity, false, voiceIntent);
                                }
                            }
                        }, 800);
                        break;
                    case CALLEE_ACK_CANCEL:
//                        if (ActivityStack.getInstance().existsActivity(VideoMultiGroupInviteActivity.class)) {
//                            System.out.println("rxListenBidVideoEvents  finish VideoMultiGroupInviteActivity");
//                            ActivityStack.getInstance().finishActivity(VideoMultiGroupInviteActivity.class);
//                        }
                        mNotificationManager.cancel(NotificationHelper.VIDEO_CALL_NOTIFICATION_ID.hashCode());
                        break;
                    case VIDEO_SELF_CANCEL:
                        LegoEventBus.use("closeGroupMutiVideoCall", String.class).postValue(event.get().getRoomId());
                        break;
                    case INCOMING_TIMEOUT:
                        if (event.getCodesForDomain() != null && !event.getCodesForDomain().isEmpty()) {
                            if (event.getCodesForDomain().get(0).equals(event.getData().getUserCodeForDomain())) {
                                LegoEventBus.use("closeGroupMutiVideoCall", String.class).postValue(event.get().getRoomId());
                                //如果域名相同表示自己超时了
                                return;
                            }
                        }
                        mNotificationManager.cancel(NotificationHelper.VIDEO_CALL_NOTIFICATION_ID.hashCode());
                        break;
                    case VIDEO_ALONE_TERMINATE:
                        LegoEventBus.use("closeGroupMutiVideoCall", String.class).postValue(event.get().getRoomId());
                        SxtUIManager.getInstance().stopMultiMeeting();
                        mNotificationManager.cancel(NotificationHelper.VIDEO_CALL_NOTIFICATION_ID.hashCode());
                        break;
                }
            }
        });
        abortables.add(abort);
    }

    /**
     * 个人语音视频聊天的
     */
    protected void addVideoLanguageChatOber() {
        logger.info("SxtStatusManager addVideoLanguageChatOber");
        VideoTalkServiceObserver videoServiceObserver = SdkImpl.getInstance().getService(VideoTalkServiceObserver.class);
        if (null != videoServiceAbortable) {
            videoServiceAbortable.abort();
        }
        videoServiceAbortable = videoServiceObserver.listenBidVideoEvents(new EventObserver<VideoChatEvent>() {
            @Override
            public void onEvent(VideoChatEvent videoChatEvent) {
                logger.info(this.getClass().getSimpleName() + " videoService listenBidVideoEvents {}", videoChatEvent);
                logger.info(this.getClass().getSimpleName() + " videoService listenBidVideoEvents videoChatEvent.type {}", videoChatEvent.getType());
                if (videoChatEvent == null || videoChatEvent.get() == null) {
                    return;
                }
                if (videoChatEvent.isMeeting() && videoChatEvent.isIfAutoAccept() && videoChatEvent.getType() == VideoChatEventType.INCOMING) {
                    LegoEventBus.use("MEETING_AUTO_ACCEPT", String.class).postValue("");
                    return;
                }

//                if (videoChatEvent.isMeeting()) {
//                    //如果是会议单独执行逻辑
//                    MeetingService meetingService = SdkImpl.getInstance().getService(MeetingService.class);
//                    meetingFuture = meetingService.queryMeetingFromServer(videoChatEvent.getMeetingId());
//                    meetingFuture.setCallback(new RequestCallback<Optional<IMeeting>>() {
//                        @Override
//                        public void onSuccess(Optional<IMeeting> iMeetingOptional) {
//                            logger.info("SxtStatusManager queryMeeting onSuccess");
//                            if (iMeetingOptional.isPresent() && iMeetingOptional.get().getMeetingState() == MeetingState.MEETING) {
//                                logger.info("SxtStatusManager sendMeetingNotification");
//                                NotificationHelper.getInstance().sendMeetingNotification(AppUtil.getApp(), videoChatEvent.getMeetingId());
//                            }
//                        }
//
//                        @Override
//                        public void onFailed(Throwable throwable) {
//                            logger.error("SxtStatusManager queryMeeting onFailed", throwable);
//                        }
//                    });
//                }
                LegoEventBus.use("videoRoomStateCall", VideoChatEventType.class).postValue(videoChatEvent.getEvent());
                LegoEventBus.use("closeCamera", String.class).postValue("closeCamera");
                String callType;
                Activity activity = SxtUIManager.getInstance().getCurrentActivity();
                logger.info("SxtStatusManager videoChatEvent.getType():" + videoChatEvent.getType());
                switch (videoChatEvent.getType()) {
                    case INCOMING:
                        if (isMeeting) {
                            logger.info("SxtStatusManager INCOMING isMeeting");
                            LegoMessageManager.getInstance().sendMessage(CALL_INCOMING, videoChatEvent);
                        } else if (isPoint) {
                            logger.info("SxtStatusManager INCOMING isPoint");
                            LegoMessageManager.getInstance().sendMessage(AUDIO_OR_VIDEO_COMING, videoChatEvent);
                        } else {
                            callType = Constants.VIDEOCHAT;
                            if (videoChatEvent.get().isCalling()) {
                                Activity currentActivity = SxtUIManager.getInstance().getCurrentActivity();
                                if (currentActivity instanceof VideoCallActivity) {
                                    if (((VideoCallActivity) currentActivity).isMeStart() && ((VideoCallActivity) currentActivity).getTalkerCode().equals(videoChatEvent.getSrcUserCode())) {
                                        currentActivity.finish();
                                    } else {
                                        break;
                                    }
                                }
                                LegoIntent intent = new LegoIntent(activity, VideoCallActivity.class);
                                intent.putObjectExtra("SessionType", videoChatEvent.get().getSessionType());
                                intent.putExtra("callType", callType);
                                intent.putExtra("userCodeForDomain", videoChatEvent.getSrcUserCode());
                                intent.putExtra("userCode", videoChatEvent.getSrcUserCode().split("@")[0]);
                                intent.putExtra("isSender", false);
                                intent.putExtra("videoRoom", videoChatEvent.get());
                                intent.putExtra("meetingId", videoChatEvent.getMeetingId());
                                activity.startActivity(intent);

                                //用于判断国产手机没有开启后台弹出界面权限时，没有打开通话界面的问题
                                statusHandler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        List<Activity> activityList = SxtUIManager.getInstance().getCreatedActivity();
                                        boolean isContainsCalActivity = false;
                                        for (int i = 0; i < activityList.size(); i++) {
                                            Activity calActivity = activityList.get(i);
                                            if (calActivity instanceof VideoCallActivity) {
                                                isContainsCalActivity = true;
                                                break;
                                            }
                                        }
                                        if (!isContainsCalActivity) {
                                            NotificationHelper.getInstance().sendVideoCallNotification(activity, true, intent);
                                        }
                                    }
                                }, 800);
                            }
                            logger.info("SxtStatusManager INCOMING 视频聊天");
                        }
                        break;
                    case VOICE_INCOMING:
                        if (isMeeting) {
                            logger.info("SxtStatusManager VOICE_INCOMING isMeeting ");
                            LegoMessageManager.getInstance().sendMessage(CALL_INCOMING, videoChatEvent);
                        } else if (isPoint) {
                            logger.info("SxtStatusManager INCOMING isPoint");
                            LegoMessageManager.getInstance().sendMessage(AUDIO_OR_VIDEO_COMING, videoChatEvent);
                        } else {
                            callType = Constants.LANGUAGE;
                            if (videoChatEvent.get().isCalling()) {
                                Activity currentActivity = SxtUIManager.getInstance().getCurrentActivity();
                                if (currentActivity instanceof VideoCallActivity) {
                                    if (((VideoCallActivity) currentActivity).isMeStart() && DomainIdUtil.getCode(((VideoCallActivity) currentActivity).getTalkerCode()).equals(videoChatEvent.getSrcUserCode())) {
                                        currentActivity.finish();
                                    } else {
                                        break;
                                    }
                                }
                                LegoIntent intent = new LegoIntent(activity, VideoCallActivity.class);
                                intent.putObjectExtra("SessionType", videoChatEvent.get().getSessionType());
                                intent.putExtra("callType", callType);
                                intent.putExtra("userCodeForDomain", videoChatEvent.getSrcUserCode());
                                intent.putExtra("userCode", videoChatEvent.getSrcUserCode().split("@")[0]);
                                intent.putExtra("isSender", false);
                                intent.putExtra("videoRoom", videoChatEvent.get());
                                intent.putExtra("meetingId", videoChatEvent.getMeetingId());
                                activity.startActivity(intent);

                                //用于判断国产手机没有开启后台弹出界面权限时，没有打开通话界面的问题
                                statusHandler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        List<Activity> activityList = SxtUIManager.getInstance().getCreatedActivity();
                                        boolean isContainsCalActivity = false;
                                        for (int i = 0; i < activityList.size(); i++) {
                                            Activity calActivity = activityList.get(i);
                                            if (calActivity instanceof VideoCallActivity) {
                                                isContainsCalActivity = true;
                                                break;
                                            }
                                        }
                                        if (!isContainsCalActivity) {
                                            NotificationHelper.getInstance().sendVideoCallNotification(activity, false, intent);
                                        }
                                    }
                                }, 800);
                            }
                            logger.info("SxtStatusManager VOICE_INCOMING 音频聊天");
                        }
                        break;
                    case VIDEO_NOTIFY_SELF_OTHER_ISBUSY:
                        ToastUtil.showDefaultToast(AppUtil.getApp().getString(R.string.other_side_busy));
                        break;
                    case OTHER_DEVICE_ACK_AGREE:
                        ToastUtil.showDefaultToast(AppUtil.getApp().getString(R.string.videotalk_other_device_agree));
                        LegoEventBus.use("closeVideoCall", String.class).postValue(videoChatEvent.get().getRoomId());
                        break;
                    case OTHER_DEVICE_ACK_REFUSE:
                        ToastUtil.showDefaultToast(AppUtil.getApp().getString(R.string.videotalk_other_device_refuse));
                        LegoEventBus.use("closeVideoCall", String.class).postValue(videoChatEvent.get().getRoomId());
                        break;
                    case VIDEO_ALONE_ERROR:
                    case INCOMING_TIMEOUT:
                    case CALLEE_ACK_REJECT:
                    case VIDEO_ALONE_TERMINATE:
                    case CALLEE_ACK_CANCEL:
                    case CALLEE_ACK_FAILURE:
                    case VIDEO_SELF_QUIT:
                    case CALLEE_ACK_QUIT://双向视频或语音 退出操作
                        logger.info("SxtStatusManager CALLEE_ACK_REJECT");
                        LegoEventBus.use("closeVideoCall", String.class).postValue(videoChatEvent.get().getRoomId());
                        SxtDataManager.Companion.getInstance().setCalling(false);
                        FlutterManager.Companion.getInstance().updateMultiMeeting();

                        NotificationManager mNotificationManager = (NotificationManager) AppUtil.getApp().getSystemService(Context.NOTIFICATION_SERVICE);
                        mNotificationManager.cancel(NotificationHelper.VIDEO_CALL_NOTIFICATION_ID.hashCode());
                        break;
                    case CALLEE_ACK_AGREE:
                        LegoEventBus.use("CALLEE_ACK_AGREE", String.class).postValue(videoChatEvent.get().getRoomId());
                        break;
                    case VIDEO_SELF_ACCEPT:
                        LegoEventBus.use("VIDEO_SELF_ACCEPT", String.class).postValue(videoChatEvent.get().getRoomId());
                        break;
                    case VIDEO_TALK_JOIN_SUCCESS:
                        LegoEventBus.use("VIDEO_TALK_JOIN_SUCCESS", String.class).postValue(videoChatEvent.get().getRoomId());
                        break;
                    default:
                        break;
                }
            }
        });
    }

    /**
     * 群视频聊天的监听
     */
    protected void addVideoGroupTalkListener() {
        VideoChatServiceObserver videoChatObserver = SdkImpl.getInstance().getService(VideoChatServiceObserver.class);
        if (null != groupTalkAbortable) {
            groupTalkAbortable.abort();
        }
        groupTalkAbortable = videoChatObserver.listenVideoEvents(new EventObserver<VideoChatEvent>() {
            @Override
            public void onEvent(VideoChatEvent videoChatEvent) {
                logger.debug(this.getClass().getSimpleName() + " VideoGroupTalk videoChatEvent {}", videoChatEvent);
//                if (isMeeting) {
//                    logger.info("SxtStatusManager group INCOMING isMeeting ");
//                    LegoMessageManager.getInstance().sendMessage(CALL_INCOMING, videoChatEvent);
//                } else {
                Activity activity = SxtUIManager.getInstance().getCurrentActivity();
                if (videoChatEvent.getType() == VideoChatEventType.INCOMING) {
                    LegoIntent intent = new LegoIntent(activity, GroupTalkInviteActivity.class);
                    intent.putExtra("codeForDomain", videoChatEvent.get().getContactCodeForDomain());
                    intent.putObjectExtra("talkerType", videoChatEvent.get().getSessionType().getValue());
                    intent.putExtra("isIncoming", true);
                    intent.putExtra("groupCode", videoChatEvent.get().getContactCodeForDomain().split("@")[0]);
                    intent.putExtra("msg", videoChatEvent.getSrcUserCode() + "邀请您加入直播");
                    intent.putExtra("userCode", videoChatEvent.getSrcUserCode());
                    intent.putExtra("videoRoom", videoChatEvent.getData());
                    intent.setAction(Intent.ACTION_MAIN);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.addCategory(Intent.CATEGORY_HOME);
                    activity.startActivity(intent);
                } else if (videoChatEvent.getType() == VideoChatEventType.VIDEO_ALONE_TERMINATE || videoChatEvent.getType() == VideoChatEventType.VIDEO_ANCHOR_QUIT) {
                    LegoEventBus.use("closeGroupVideoCall", String.class).postValue(videoChatEvent.get().getContactCodeForDomain());
                }
//                }
            }
        });
    }

    private void addMeetingOperationEventListener() {
        meetingServiceObserver = SdkImpl.getInstance().getService(MeetingServiceObserver.class);
        meetingServiceObserver.observerListenMMemberOperationEvent(new EventObserver<MMemberOperateEvent>() {
            @Override
            public void onEvent(MMemberOperateEvent mMemberOperateEvent) {
                logger.info("SxtStatusManager MMemberOperateEvent：" + mMemberOperateEvent.toString());
                LegoEventBus.use("MMemberOperateEvent", MMemberOperateEvent.class).postValue(mMemberOperateEvent);
                if (mMemberOperateEvent.getType() == MeetingMemberEventType.REINVITE) {
                    logger.info("SxtStatusManager sendMeetingNotification");
                    NotificationHelper.getInstance().sendMeetingNotification(AppUtil.getApp(), mMemberOperateEvent.get().getMeeting().getMeetingId(), false);
                } else if (mMemberOperateEvent.getType() == MeetingMemberEventType.REINVITE2) {
                    logger.info("SxtStatusManager sendMeetingNotification");
                    NotificationHelper.getInstance().sendMeetingNotification(AppUtil.getApp(), mMemberOperateEvent.get().getMeeting().getLinkId(), true);
                } else if (mMemberOperateEvent.getType() == MeetingMemberEventType.KICKOUT) {
                    NotificationManager mNotificationManager = (NotificationManager) AppUtil.getApp().getSystemService(Context.NOTIFICATION_SERVICE);
                    mNotificationManager.cancel(mMemberOperateEvent.get().getMeeting().getMeetingId().hashCode());
                }
            }
        });
        if (null != meetingAbortable) {
            meetingAbortable.abort();
        }
        meetingAbortable = meetingServiceObserver.observerListenMeetingOperationEvent(new EventObserver<MeetingOperateEvent>() {
            @Override
            public void onEvent(MeetingOperateEvent meetingOperateEvent) {
                logger.info("SxtStatusManager MeetingOperateEvent：" + meetingOperateEvent.toString());
                LegoEventBus.use("MeetingOperateEvent", MeetingOperateEvent.class).postValue(meetingOperateEvent);
//                if (meetingOperateEvent.isPresent() && meetingOperateEvent.get().getMeetingState() == MeetingState.MEETING) {
//                    NotificationHelper.getInstance().sendMeetingNotification(AppUtil.getApp(), meetingOperateEvent.get().getMeetingId());
//                }
            }
        });
    }


}
