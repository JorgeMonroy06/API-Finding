package com.kedacom.flutter_sxtapp.notification;

/**
 * Author：chumengwei on 2019/1/25 16:04
 * <p>
 * We can do anything we want to do if we stick to it long enough.
 */
public class NotificationDict {

    public static final String NOTICE_CLICK = "szga.jwpt.xc.notice.click";

    public static final String PACKAGE_NAME = "packageName";

    public static final String NOTICE_CONTENT = "noticeContent";

    public static final String NOTICE_ISLINKID = "NOTICE_ISLINKID";


    /**
     * 推送者的code；
     */
    public static final String NOTIFICATION_USERCODE = "notification_user_code";

}
