#import "AppDelegate.h"
#import "GeneratedPluginRegistrant.h"
//#import "FlutterSxtUiPlugin.h"
//#import "SxtAppDelegate.h"
@implementation AppDelegate

- (BOOL)application:(UIApplication *)application
    didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
  [GeneratedPluginRegistrant registerWithRegistry:self];
  // Override point for customization after application launch.
//    [[SxtAppDelegate shareInstance]registerSxtAppDelegate:application appDelegate:self];
  return [super application:application didFinishLaunchingWithOptions:launchOptions];
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    
//    NSLog(@"\n ===> 程序进入前台 !");
//    if ([KDConfigManager sharedInstance].isLogin) {
//        return;
//    }
//    [self.channel registerChannelEventWithController];
}

//- (void)applicationWillResignActive:(UIApplication *)application {
//    NSLog(@"\n ===> 程序暂行 !");
//    [[SxtAppDelegate shareInstance]applicationWillResignActive:application];
//}
//
//- (void)applicationDidEnterBackground:(UIApplication *)application
//{
//    [[SxtAppDelegate shareInstance]applicationDidEnterBackground:application];
//     NSLog(@"\n ===> 程序进入后台 !");
//}
//
//- (void)applicationDidBecomeActive:(UIApplication *)application
//{
//    [[SxtAppDelegate shareInstance]applicationDidBecomeActive:application];
//    NSLog(@"\n ===> 程序重新激活 !");
//
//}
@end
