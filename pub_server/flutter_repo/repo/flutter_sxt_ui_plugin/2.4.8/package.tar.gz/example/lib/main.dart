import 'package:apm_kit/apm_kit.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_sxt_ui_plugin/bean/map_config.dart';
import 'package:flutter_sxt_ui_plugin/bean/server_config.dart';
import 'package:flutter_sxt_ui_plugin/bean/ui_options.dart';
import 'package:flutter_sxt_ui_plugin/flutter_sxt_ui_plugin.dart';
import 'package:flutter_sxt_ui_plugin/manager/app_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/my_navigator.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/message_free/message_free_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/strong_reminder/strong_reminder_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/ontop/ontop_conversation_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/login_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/scroll_physics_config.dart';
import 'package:kd_flutter_map/kd_flutter_map.dart';

void main() {
  APM.runApp(
    apmDisabled: false,
    prepare: () {
      WidgetsFlutterBinding.ensureInitialized();
      GestureBinding.instance?.resamplingEnabled = true;
      //初始化视信通插件
      FlutterSxtUIPlugin.init();
      ServerConfig serverConfig = ServerConfig();

//昆仑环境
      serverConfig.sxtIp = "47.100.250.39";
      serverConfig.sxtPort = "39900";
      serverConfig.sxtClientId = "";
      serverConfig.sxtClientSecret = "";
      serverConfig.sxtUseSsl = false;
      serverConfig.contactClientId = "xingchen";
      serverConfig.contactClientSecret = "J85905";
      serverConfig.contactBaseUrl = "http://bestkunlun.com";

      //172.16.249.177环境
      // serverConfig.sxtIp = "172.16.249.177";
      // serverConfig.sxtPort = "9900";
      // serverConfig.sxtClientId = "";
      // serverConfig.sxtClientSecret = "";
      // serverConfig.sxtUseSsl = false;
      // serverConfig.contactClientId = "xingchen";
      // serverConfig.contactClientSecret = "5eSLvh";
      // serverConfig.contactBaseUrl = "http://dolphin-dev.kedacom.com";

//test环境
//   serverConfig.sxtIp = "10.65.5.214";
//   // serverConfig.sxtIp = "dispatch.testdolphin.com";
//   serverConfig.sxtPort = "59443";
//   serverConfig.sxtClientId = "";
//   serverConfig.sxtClientSecret = "";
//   serverConfig.sxtUseSsl = true;
//   serverConfig.contactClientId = "xingchen";
//   serverConfig.contactClientSecret = "y479XI";
//   serverConfig.contactBaseUrl = "http://dispatch.testdolphin.com";

      //乌鲁木齐现场
      // serverConfig.sxtIp = "220.171.134.49";
      // serverConfig.sxtPort = "39900";
      // serverConfig.sxtClientId = "ptt";
      // serverConfig.sxtClientSecret = "6iEu5KMblpyS";
      // serverConfig.sxtUseSsl = false;
      // serverConfig.contactClientId = "ptt";
      // serverConfig.contactClientSecret = "498c87";
      // serverConfig.contactBaseUrl = "http://220.171.134.49:30081";

      //配置服务器
      FlutterSxtUIPlugin.setServerConfig(serverConfig);

      //配置UI样式
      UIOptions uiOptions = UIOptions();
      uiOptions.androidNotifyBarRes = "@mipmap/ic_notification";
      uiOptions.enableUpdateGroupMember = true; //是否支持添加或删除群成员
      uiOptions.enableDeleteGroup = true; //是否支持删除群组
      uiOptions.enableUpdateGroupName = true; //是否支持修改群名称
      uiOptions.enableChatPageClickMember = true; //是否支持聊天界面点击群成员头像
      uiOptions.enableTransVoiceToText = true;
      uiOptions.transVoiceToTextAppKey = "EDBjFkdbjwCm403STKHZyl1N";
      uiOptions.transVoiceToTextAppSecret = "NlxnidSB3nSHIsGrZK0UPDwzcmhLOdD0";
      FlutterSxtUIPlugin.setUIConfig(uiOptions);

      MapConfig mapConfig = MapConfig();
      mapConfig.latLng = LatLng(la: 31.3, lo: 120.6);
      mapConfig.isOffline = false;
      mapConfig.fromMobile = true;
      mapConfig.showDownloadMapButton = false;
      mapConfig.androidKey = "be6e87d80bb6d18e4b2dce5b6e0da0c5";
      mapConfig.iosKey = "9d6e12b91d2c16a9cf05cfa8e3cf01c4";

      FlutterSxtUIPlugin.setMapConfig(mapConfig);
    },
    app: MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => MessageFreeBloc(),
        ),
        BlocProvider(
          create: (context) => OnTopConversationBloc(),
        ),
        BlocProvider(
          create: (context) => StrongReminderBloc(),
        ),
      ],
      child: App(),
    ),
    config: APMConfig(
      fpsConfig: FpsConfig(
        60,
        500,
      ),
    ),
  );
}

class App extends StatelessWidget {
  // This widget is the root of your application.
  final MyNavigator ins = MyNavigator.getInstance();
  final GlobalKey<NavigatorState>? globalKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    AppManager.instance.globalKey = globalKey;
    return MaterialApp(
      navigatorKey: globalKey,
      locale: APM.locale(context),
      // Add the locale here
      localizationsDelegates: [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: [
        const Locale('zh', 'CN'),
        const Locale('en', 'US'),
      ],
      navigatorObservers: [
        MyNavigator.getInstance(),
        APM.initNavigatorObserver(),
      ],
      title: '视信通',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      builder: (context, child) {
        return APM.appBuilder(
            context,
            FlutterEasyLoading(
              child: ScrollConfiguration(
                behavior: const ScrollPhysicsConfig(),
                child: child!,
              ),
            ));
      },
      home: LoginPage(
        needAutoLogin: true,
      ),
    );
  }
}
