package com.kedacom.flutter_sxt_plugin_example

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.kedacom.flutter_sxt_ui_plugin.UIOptions
import com.kedacom.flutter_sxtapp.manager.SxtUIManager


class SplashActivity : Activity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SxtUIManager.getInstance().init(this)
        startActivity(Intent(this, MainActivity::class.java))
        val uiOptions = UIOptions()
        uiOptions.notifyBarRes = R.mipmap.ic_ptt_notifaction_flutter
        uiOptions.notifyIconRes = R.mipmap.ic_notification_flutter
        SxtUIManager.getInstance().registerUIOptions(uiOptions)
    }
}