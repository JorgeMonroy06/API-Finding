package com.kedacom.flutter_sxt_plugin_example;

import android.os.Bundle;

import androidx.annotation.Nullable;

import com.kedacom.widget.common.StatusBarUtil;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StatusBarUtil.statusBarImmersion(this);
    }
}
