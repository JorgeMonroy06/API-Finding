//
//  KDAudioCallView.m
//  KDVLine_Example
//
//  Created by samuel on 2021/3/31.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import "KDAudioCallView.h"
#import <KDWebRTC/KDWebRTC.h>
#import <Masonry/Masonry.h>
#import <SDWebImage/SDWebImage.h>
#import "SxtConfigConstant.h"
#import <SVProgressHUD/SVProgressHUD.h>
@interface KDAudioCallView()<FunctionDelegate>

@property (nonatomic, strong) KDRTCSDKApi* kdsdkapi;

@property(nonatomic, assign) AVAudioSessionPortOverride portOverride;
@property (nonatomic,copy) void(^dismissBlock)(void);
@end

@implementation KDAudioCallView

- (instancetype)initWidthDismissBlock:(void (^)(void))dismissBlock
{
    self = [super init];
    if (self) {
        self.dismissBlock = dismissBlock;
        self.portOverride = AVAudioSessionPortOverrideNone; //听筒模式
    }
    return self;
}


- (void)startAudio
{
//    [SVProgressHUD show];
    KDNETConfig* config = [KDNETConfig new];
    config.wsIp = self.contactModel.RTCIp;
    config.wsPort = [self.contactModel.RTCPort intValue];
    if (self.contactModel.stunIp.length > 0) {
        config.stunIp = self.contactModel.stunIp;
        config.stunPort = [self.contactModel.stunPort intValue];
    }
    self.kdsdkapi = [KDRTCSDKApi getInstance];
    [self.kdsdkapi configure:config];
    
    
    KDAudioReqParams* params = [[KDAudioReqParams alloc] init];
    params.callerId = self.contactModel.caller;
    params.calleeId = self.contactModel.callee;
    params.resourceId = self.contactModel.deviceid;
    params.audioType = 117;
    params.shouldGetStats = false;
    if (self.contactModel.stunPort.length > 0) {
        params.stunUrl = [[NSString alloc] initWithFormat:@"%@:%@", self.contactModel.stunIp, self.contactModel.stunPort];
    }
    
    self.kdsdkapi = [KDRTCSDKApi getInstance];
    
    [self.kdsdkapi startAudioCall:params callback:self];
    
}

-(void)enableAudioMic:(BOOL)enable {
    [self.kdsdkapi enableAudioMic:enable];
}

- (void)completionHandler:(int)error obj:(NSObject*)obj {
    //重置听筒/扬声器模式
    [self.kdsdkapi setAudioSession:self.portOverride shouldChangeRouteWithCompletion:^{
    }];
    NSLog(@"startVideoCall err:%d", error);
//    [SVProgressHUD dismiss];
    if (error == KDSTATUS_ICE_CONNECTED) {
        Log(@"successful");
    } else{
//        [SVProgressHUD showErrorWithStatus:@"视频连接失败，请重新尝试"];
//        if (self.dismissBlock) {
//            self.dismissBlock();
//        }
    }
}

- (void)changeSpeakerWithSelected:(BOOL )selected
{
    if (selected) {
        self.portOverride = AVAudioSessionPortOverrideSpeaker;
    }else{
        self.portOverride = AVAudioSessionPortOverrideNone;
    }
    [self.kdsdkapi setAudioSession:self.portOverride shouldChangeRouteWithCompletion:^{
    }];
}

- (void)stop{
    [self.kdsdkapi stopAudioCall];
    [KDRTCSDKApi destroy];
}

@end
