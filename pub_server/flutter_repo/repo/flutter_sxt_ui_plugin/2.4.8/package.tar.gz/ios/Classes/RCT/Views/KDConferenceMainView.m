//
//  KDConferenceMainView.m
//  Runner
//
//  Created by xzc on 2021/5/21.
//

#import "KDConferenceMainView.h"
#import "KDConferenceView.h"
#import "KDConferenceMemberCollectionView.h"
#import <AVFoundation/AVFoundation.h>
#import "KDWechatUtil.h"
#import "UIView+Draggable.h"
#import "SxtAppDelegate.h"
#import "SxtUserModel.h"
#import "SxtGroupHandle.h"
#import "SxtConstant.h"
#import <SVProgressHUD/SVProgressHUD.h>
#import "SxtToast.h"
#import "KDSoundAndShakeManager.h"
#import <Masonry/Masonry.h>
#import <SDWebImage/SDWebImage.h>
#import "SxtConfigConstant.h"
#import "KDUtil.h"
#import <Reachability/Reachability.h>
@interface KDConferenceMainView ()<KDVideoHandleDelegate,FlutterStreamHandler>

//@property (nonatomic, strong) KDAccountModel *account;

@property (nonatomic, strong) KDVideoHandle *videoHandle;

@property (nonatomic, strong) UIImageView *accountImage;

@property (nonatomic, weak) UIView *senderView;

@property (nonatomic, strong) UIView *userView;

@property (nonatomic, strong) UIView *inviteView;

@property (nonatomic, strong) UILabel *infoLab;

@property (nonatomic, strong) KDConferenceView *conferenceView;

@property (nonatomic, strong) NSTimer *timer;

@property (nonatomic, assign) NSInteger timeCount;

@property (nonatomic, strong) KDMessageModel *message;

@property (nonatomic, assign) KDVLineRTCShowType showType;

@property (nonatomic, strong) UIButton *narrowBtn;

@property (nonatomic, strong) UIView *containView;
@property (nonatomic, strong) UILabel *openCameraLab;

@property (nonatomic, copy) NSString *groupCode;

@property CGPoint movePoint;
@property BOOL isVoice;
@property (nonatomic, strong) NSMutableArray<SxtUserModel *> *userList;

@property (nonatomic, strong) KDConferenceMemberCollectionView *memberCollectView;

@end
@implementation KDConferenceMainView
- (instancetype )initConferenceMainViewWithMessage:(KDMessageModel *)message showType:(KDVLineRTCShowType)showType groupCode:(NSString *)groupCode {
    return [self initConferenceMainViewWithMessage:message showType:showType isJoin:NO groupCode:groupCode];
}

- (instancetype )initConferenceMainViewWithMessage:(KDMessageModel *)message showType:(KDVLineRTCShowType)showType isJoin:(BOOL)isJoin groupCode:(NSString *)groupCode {
    self = [super init];
    if (self) {
        [[UIApplication sharedApplication]setStatusBarHidden:YES];
        self.backgroundColor = [UIColor colorWithHexString:@"#27242A"];
        float width = [UIScreen mainScreen].bounds.size.width;
        float height = [UIScreen mainScreen].bounds.size.height;
        self.movePoint = CGPointMake(width - 60, height - 120);
        self.draggingType = DraggingTypeDisabled;
        __weak typeof(self)weakSelf = self;
        self.delegate = weakSelf;
        self.frame = [UIScreen mainScreen].bounds;
        [UIApplication sharedApplication].idleTimerDisabled = true;
        [KDConfigManager sharedInstance].isVideoOnline = YES;
        
        self.videoHandle = [[KDVideoHandle alloc] init];
        self.videoHandle.delegate = self;
        self.showType = showType;
        self.message = message;
        self.groupCode = groupCode;
        self.isVoice = (self.showType == KDVLineRTCShowType_Voice_Active || self.showType == KDVLineRTCShowType_Voice_Passive) ? YES : NO;
        [SVProgressHUD show];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(networkStateChange) name:kReachabilityChangedNotification object:nil];
        Reachability *connect = [Reachability reachabilityForInternetConnection];
        [connect startNotifier];
        
        if (self.showType == KDVLineRTCShowType_Video_Active || self.showType == KDVLineRTCShowType_Voice_Active) {//主动邀请
            [self startVideoNativeToFlutter];
            [self updateVideoNativeToFlutter];
            [self loadUserInfo:YES userBlock:^(NSString *baseUrl, NSMutableArray *userList) {
                [SVProgressHUD dismiss];
                [weakSelf renderChatView];
                [weakSelf.conferenceView startConference: weakSelf.showType == KDVLineRTCShowType_Video_Active ? NO: YES sender:weakSelf.message.sender];
            }];
            
        } else {
            [self disposeTimer];
            self.timer = [NSTimer scheduledTimerWithTimeInterval:1 block:^(NSTimer * _Nonnull timer) {
                weakSelf.timeCount ++;
                if (weakSelf.timeCount > 10) {
                    [weakSelf disposeTimer];
                    [SxtToast showInfo:@"会议邀请未接听"];
                    [KDSoundAndShakeManager stopVideoChatSoundAndShake];
                    KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)weakSelf.message.contentAttachment;
                    [weakSelf.videoHandle setCurrentStatusWithRoom:mediaAttachment.room status:KDRoomStatus_Away];
                    [weakSelf.videoHandle refuseWithMessageModel:weakSelf.message];
                    [weakSelf dismiss];
                }
            } repeats:YES];

            if (!isJoin || ![KDSoundAndShakeManager shareInstance].isPlaying) {
                [KDSoundAndShakeManager startVideoChatSoundAndShake];
            }
            UIImageView *accountbgImage = [[UIImageView alloc] initWithFrame:self.bounds];
            accountbgImage.contentMode= UIViewContentModeScaleAspectFit;
            accountbgImage.image = [KDUtil getImage:@"KD_account_default"];
            [self.containView addSubview:accountbgImage];
            self.accountImage = accountbgImage;
            
            UIBlurEffect * blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
            UIVisualEffectView * visualView = [[UIVisualEffectView alloc] initWithEffect:blur];
            visualView.frame = accountbgImage.bounds;
            [accountbgImage addSubview:visualView];
            
            UIView *inviteView = [[UIView alloc] init];
            [self.containView addSubview:inviteView];
            self.inviteView = inviteView;
            [inviteView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.edges.equalTo(self.containView);
            }];
            
            [self loadUserInfo:false userBlock:^(NSString *baseUrl,NSMutableArray *userList) {
                [SVProgressHUD dismiss];
                NSMutableArray *userArray = [NSMutableArray arrayWithArray:userList];
                [userList enumerateObjectsUsingBlock:^(SxtUserModel *userModel, NSUInteger idx, BOOL * _Nonnull stop) {
                    if ([weakSelf.message.sender isEqualToString:userModel.userCodeDomain]) {
                        [weakSelf renderSenderView:userModel baseUrl:baseUrl];
                        [userArray removeObject:userModel];
                    } else if ([[KDConfigManager sharedInstance].userCodeDomain isEqualToString:userModel.userCodeDomain]) {
                        [userArray removeObject:userModel];
                    }
                }];
//                weakSelf.invitingUserList = userArray;
                if (userArray.count) {
                    [weakSelf renderUserView:userArray];
                }
                [weakSelf renderFunctionView];
            }];
            
        }
        

        UIButton *foldBtn = [[UIButton alloc] init];
        [foldBtn setImage:[KDUtil getImage:@"KD_fold"] forState:UIControlStateNormal];
        [foldBtn addTarget:self action:@selector(zoomInvitViewEvent) forControlEvents:UIControlEventTouchUpInside];
        [self.containView addSubview:foldBtn];
        [foldBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.containView).offset(10);
            make.top.equalTo(self.containView).offset(33);
            make.size.mas_equalTo(CGSizeMake(26, 26));
        }];
    }
    return self;
}

- (void)networkStateChange
{
    
    Reachability *reachability = [Reachability reachabilityWithHostName:@"www.baidu.com"];
    switch ([reachability currentReachabilityStatus]) {
        case 0://没有网
            [SxtToast showInfo:@"网络已断开"];
            [self handupChat:nil];
        case 1:
            NSLog(@"WIFI网络");
            break;
        case 2:
            NSLog(@"手机自带网络");
            break;
        default:
            break;
    }
}

-(void)disposeTimer {
    if (self.timer) {
        [self.timer invalidate];
        self.timer = nil;
        self.timeCount = 0;
    }
}

-(void)createTimer {
    [self disposeTimer];
    __weak typeof(self)weakSelf = self;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1 block:^(NSTimer * _Nonnull timer) {
        weakSelf.timeCount ++;
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:weakSelf.timeCount];
        NSDateFormatter *formate = [[NSDateFormatter alloc] init];
        formate.timeZone = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        formate.dateFormat = @"mm:ss";
        weakSelf.infoLab.text = [formate stringFromDate:date];
    } repeats:YES];
}

-(void)addNewMemberList {
    [SVProgressHUD show];
    KDMutiMediaAttachment *attachment = (KDMutiMediaAttachment *)self.message.contentAttachment;
    __weak typeof(self)weakSelf = self;
    [SVProgressHUD show];
    [self.videoHandle queryRoomDetailWithRoom:attachment.room Completion:^(int result, NSArray<KDVideoRoomInfoModel *> * _Nonnull roomInfoArray) {
        [SVProgressHUD dismiss];
        NSMutableArray *userCodeArray = [NSMutableArray array];
        for (KDVideoRoomInfoModel *roomInfoModel in roomInfoArray) {
            [roomInfoModel.members enumerateObjectsUsingBlock:^(KDVideoMemberInfoModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (obj.state == KDVideoState_Accept || obj.state == KDVideoState_Inviting) {
                    [userCodeArray addObject:obj.code];
                }
            }];
        }
        [weakSelf zoomInvitViewEvent];
        [[SxtAppDelegate shareInstance] nativeToFlutterWithMethodName:MULTI_MEETING_SELECT_CONTACT_PAGE arguments:@{@"groupCode":weakSelf.groupCode,@"selectCode":userCodeArray} result:^(id  _Nullable result) {
            [SVProgressHUD dismiss];
        }];
    }];
}


-(void)loadUserInfo:(BOOL)isActive userBlock:(void (^)(NSString *,NSMutableArray *))userBlock{
    KDMutiMediaAttachment *attachment = (KDMutiMediaAttachment *)self.message.contentAttachment;
    if (!isActive) {
        __weak typeof(self)weakSelf = self;
        [self.videoHandle queryRoomDetailWithRoom:attachment.room Completion:^(int result, NSArray<KDVideoRoomInfoModel *> * _Nonnull roomInfoArray) {
            KDVideoRoomInfoModel *model = roomInfoArray.firstObject;
            [weakSelf getUserDetail:model.members isActive:isActive userBlock:userBlock];
        }];
    } else {
        NSMutableArray *roomInfoArray = [NSMutableArray array];
        for (NSString *codeStr in attachment.users) {
            KDVideoMemberInfoModel *model = [[KDVideoMemberInfoModel alloc]init];
            model.code = codeStr;
            if ([model.code isEqualToString:[KDConfigManager sharedInstance].userCodeDomain]) {
                model.state = KDVideoState_Accept;
            } else {
                model.state = KDVideoState_Inviting;
            }
            [roomInfoArray addObject:model];
        }
        [self getUserDetail:roomInfoArray isActive:isActive userBlock:userBlock];
    }
}

-(void)getUserDetail:(NSArray<KDVideoMemberInfoModel *> *)members
            isActive:(BOOL)isActive
           userBlock:(void (^)(NSString *,NSMutableArray *))userBlock {
    NSMutableArray *codeList = [NSMutableArray array];
    [members enumerateObjectsUsingBlock:^(KDVideoMemberInfoModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [codeList addObject:obj.code];
    }];
    [[SxtAppDelegate shareInstance] nativeToFlutterWithMethodName:GET_CONTACT_AVATAR_BASE_URL arguments:nil result:^(id  _Nullable baseUrl) {
        [[SxtAppDelegate shareInstance] nativeToFlutterWithMethodName:GET_CONTACTS arguments:codeList result:^(id  _Nullable result) {
            if (![result isKindOfClass:[NSArray class]]) {
                return;
            }
            NSArray *userList = (NSArray *)result;
            NSMutableArray *userArray = [NSMutableArray array];
            for (KDVideoMemberInfoModel *model in members) {
                for (NSDictionary *dic in userList) {
                    SxtUserModel *userModel = [SxtUserModel modelWithDictionary:dic];
                    if ([userModel.userCodeDomain isEqualToString:model.code]) {
                        userModel.headUrl = [NSString stringWithFormat:@"%@%@",baseUrl,userModel.personalPortrait];
                        switch (model.state) {
                            case KDVideoState_Inviting:
                                userModel.multiState = MultiState_Invited;
                                break;
                            case KDVideoState_Accept:
                                userModel.multiState = MultiState_Accept;
                                break;
                            default:
                                userModel.multiState = MultiState_Refuse;
                                break;
                        }
                        [userArray addObject:userModel];
                        break;
                    }
                }
            }
            
            self.userList = userArray;
            if (userBlock) {
                if (!isActive) {
                    userBlock(baseUrl,userArray);
                } else {
                    userBlock(baseUrl,[NSMutableArray array]);
                }
            }
        }];
    }];
}

- (void)dismiss
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.dismissBlock) {
            self.dismissBlock();
        }
        [[UIApplication sharedApplication]setStatusBarHidden:NO];
        [self disposeTimer];
        [[SxtAppDelegate shareInstance]nativeToFlutterWithMethodName:END_VIDEO_CALLING arguments:nil result:nil];
        self.delegate = nil;
        self.videoHandle.delegate = nil;
        [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionTransitionCrossDissolve animations:^{
            self.alpha = 0;
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
        }];
        
    });
}

-(void)zoomInvitViewEvent {
    self.backgroundColor = [UIColor whiteColor];
    self.layer.cornerRadius = 26;
    self.clipsToBounds = true;
    [UIView animateWithDuration:0.5 animations:^{
        self.containView.alpha = 0;
        self.narrowBtn.alpha = 1;
        self.frame = CGRectMake(self.movePoint.x, self.movePoint.y, 52, 52);
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
        self.draggingType = DraggingTypeNormal;
    }];
}

-(void)expandInvitViewEvent {
    [self expandInvitViewEvent:NO];
}

-(void)expandInvitViewEvent:(BOOL)isAutoCloseContactPage {
    if (!isAutoCloseContactPage) {
        [[SxtAppDelegate shareInstance] nativeToFlutterWithMethodName:CLOSE_SELECT_CONTACT_PAGE arguments:nil result:^(id  _Nullable result) {}];
    }
    self.backgroundColor = [UIColor colorWithHexString:@"#27242A"];
    self.layer.cornerRadius = 0;
    self.clipsToBounds = false;
    [UIView animateWithDuration:0.5 animations:^{
        self.narrowBtn.alpha = 0;
        self.containView.alpha = 1;
        self.frame = [UIScreen mainScreen].bounds;
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
        self.draggingType = DraggingTypeDisabled;
    }];
}

-(void)startVideoNativeToFlutter {
    [[SxtAppDelegate shareInstance] nativeToFlutterWithMethodName:START_MULTI_MEETING arguments:nil result:^(id  _Nullable result) {}];
}

-(void)stopVideoNativeToFlutter {
    [[SxtAppDelegate shareInstance] nativeToFlutterWithMethodName:STOP_MULTI_MEETING arguments:nil result:^(id  _Nullable result) {}];
}
-(void)updateVideoNativeToFlutter {
    [[SxtAppDelegate shareInstance] nativeToFlutterWithMethodName:UPDATE_MULTI_MEETING arguments:nil result:^(id  _Nullable result) {}];
}

//接受会议
- (void)acceptChat:(UIButton *)sender
{
    for (SxtUserModel *userModel in self.userList) {
        if ([userModel.userCodeDomain isEqualToString:[KDConfigManager sharedInstance].userCodeDomain]) {
            userModel.multiState = MultiState_Accept;
        }
    }
    [KDSoundAndShakeManager stopVideoChatSoundAndShake];
    [self startVideoNativeToFlutter];
    [self updateVideoNativeToFlutter];
    [self.videoHandle acceptWithMessageModel:self.message];
    
    [self.inviteView removeFromSuperview];
    [self renderChatView];
    [self.conferenceView startConference:self.isVoice sender:self.message.sender];

    //更新计时器
    [self disposeTimer];
    [self createTimer];
    
}


//拒绝会议
- (void)refuseChat:(UIButton *)sender
{
    [KDSoundAndShakeManager stopVideoChatSoundAndShake];
    [self.videoHandle refuseWithMessageModel:self.message];
    [self dismiss];
}

//挂断音视频
- (void)handupChat:(UIButton *)sender
{
    [self disposeTimer];
    [self.conferenceView stopConference:self.isVoice];
    [KDSoundAndShakeManager stopVideoChatSoundAndShake];
    KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)self.message.contentAttachment;
    [self.videoHandle stopWithRoom:mediaAttachment.room Completion:^(BOOL success) {
        
        Log(@"结束视频");
    }];
    [self dismiss];
}

//免提
- (void)selectMicrophone:(UIButton *)sender
{
    KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)self.message.contentAttachment;
    sender.selected = !sender.selected;
    [self.conferenceView changeSpeakerWithSelected:sender.selected];
    [self.videoHandle operateMicWithRoom:mediaAttachment.room isOpen:!sender.selected];
}

////前摄与后摄切换
//- (void)changeCamera:(UIButton *)sender
//{
//    [self.conferenceView changeCamera];
//}

//静音(是否录制声音)
- (void)setMute:(UIButton *)sender
{
    sender.selected = !sender.selected;
    [self.conferenceView setMute:sender.selected];
}

- (void)openCamera:(UIButton *)sender
{
    sender.selected = !sender.selected;
    KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)self.message.contentAttachment;
    [self.videoHandle operateCameraWithRoom:mediaAttachment.room isOpen:!sender.selected];
    [self.conferenceView openOrCloseCamera:sender.selected];
    if (sender.isSelected) {
        self.openCameraLab.text = @"打开摄像头";
    } else {
        self.openCameraLab.text = @"关闭摄像头";
    }
}


-(void)refreshConferenceView:(NSArray *)userList {
    [self expandInvitViewEvent:YES];
    if (self.containView && userList.count) {
        NSMutableArray *array = [NSMutableArray array];
        for (NSDictionary *dic in userList) {
            SxtUserModel *model = [SxtUserModel modelWithDictionary:dic];
            model.multiState = MultiState_Invited;
            [array addObject:model];
        }
        [self.userList addObjectsFromArray:array];
        [self.conferenceView refreshUI:array isVoice:self.isVoice isExtraAdd:YES];
    }
}


- (void)videoHandle:(KDVideoHandle *)videoHandle ConferenceDidFInishWithMessageModel:(KDMessageModel *)messageModel {

    [self stopVideoNativeToFlutter];
    [self.conferenceView stopConference:self.isVoice];
    [self disposeTimer];
    KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)messageModel.contentAttachment;
    NSArray *roomArray = [NSArray arrayWithObject:mediaAttachment.room];
    __weak typeof(self)weakSelf = self;
    [self.videoHandle stopWithRoom:mediaAttachment.room Completion:^(BOOL success) {
        [weakSelf.videoHandle destroyRoomWithRooms:roomArray];
    }];
    [SxtToast showInfo:@"会议结束"];
    [self dismiss];
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        
//    });
    
//        [self.timer invalidate];
//        self.timer = nil;
//        [self.videoCallView stop];
//        [self.audioCallView stop];
//        [KDSoundAndShakeManager stopVideoChatSoundAndShake];
//    [KDWechatUtil showToastWithText:[NSString stringWithFormat:@"%@已拒绝",messageModel.sender]];
//    NSLog(@"——————————————————————会议结束");
//    [KDWechatUtil showToastWithText:[NSString stringWithFormat:@"会议结束"]];
}

- (void)videoHandle:(KDVideoHandle *)videoHandle listenVideoEventWithMessageModel:(KDMessageModel *)messageModel
{
    KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)messageModel.contentAttachment;
    NSLog(@"——————————————————————消息发送者：%@，%ld",messageModel.sender,mediaAttachment.singleType);
   if(mediaAttachment.singleType == KDSingleType_Accept){
        if(self.showType == KDVLineRTCShowType_Video_Active || self.showType == KDVLineRTCShowType_Voice_Active){
            //更新计时器
            [KDSoundAndShakeManager stopVideoChatSoundAndShake];
            [self disposeTimer];
            [self createTimer];
        } 
       [self.conferenceView refreshConferenceUserView:@[messageModel.sender] state:MultiState_Accept isClose:self.isVoice];
   } else if (mediaAttachment.singleType == KDSingleType_Quit) {
       BOOL isContainUser = NO;
       for (SxtUserModel *model in self.userList) {
           if ([model.userCodeDomain isEqualToString:messageModel.sender]) {
               isContainUser = YES;
           }
       }
       if (!isContainUser) {
           return;;
       }
       [KDSoundAndShakeManager stopVideoChatSoundAndShake];
       [self.conferenceView refreshConferenceUserView:@[messageModel.sender] state:MultiState_Refuse isClose:self.isVoice];
       [[SxtAppDelegate shareInstance] nativeToFlutterWithMethodName:GET_CONTACTS arguments:@[messageModel.sender] result:^(id  _Nullable result) {
           if (![result isKindOfClass:[NSArray class]]) {
               return;
           }
           NSArray *userList = (NSArray *)result;
           SxtUserModel *userModel = [SxtUserModel modelWithDictionary:userList.firstObject];
           [SxtToast showInfo:[NSString stringWithFormat:@"%@退出会议",userModel.name]];
       }];
   } else if (mediaAttachment.singleType == KDSingleType_Invite) {
       NSLog(@"——————————————————————邀请：%@",messageModel.sender);
       __weak typeof(self)weakSelf = self;
       if (self.conferenceView) {
           //自己已经接受邀请后的ui
           [self.conferenceView refreshConferenceUserView:mediaAttachment.users state:MultiState_Invited isClose:self.isVoice];
           [self loadUserInfo:NO userBlock:^(NSString *baseUrl, NSMutableArray *userList) {
//               [SVProgressHUD dismiss];
               [weakSelf.conferenceView refreshUI:userList isVoice:weakSelf.isVoice isExtraAdd:NO];
           }];
       } else {
           //自己还没接受邀请后的ui
           [self loadUserInfo:NO userBlock:^(NSString *baseUrl, NSMutableArray *userList) {
               NSMutableArray *userArray = [NSMutableArray arrayWithArray:weakSelf.userList];
               for (SxtUserModel *model in weakSelf.userList) {
                   if ([model.userCodeDomain isEqualToString:[KDConfigManager sharedInstance].userCodeDomain] ||
                       [model.userCodeDomain isEqualToString:weakSelf.message.sender]) {
                       [userArray removeObject:model];
                   }
               }
               [weakSelf.memberCollectView addInviteMemberData:userArray];
           }];
       }
   } else if (mediaAttachment.singleType == KDSingleType_OpenCamera) {
       self.isVoice = NO;
       [self.conferenceView refreshConferenceUserView:@[messageModel.sender] state:MultiState_Other isClose:self.isVoice];
   } else if (mediaAttachment.singleType == KDSingleType_CloseCamera) {
       self.isVoice = YES;
       [self.conferenceView refreshConferenceUserView:@[messageModel.sender] state:MultiState_Other isClose:self.isVoice];
   } else if (mediaAttachment.singleType == KDSingleType_Refuse) {
       if ([messageModel.sender isEqualToString:[KDConfigManager sharedInstance].userCodeDomain]) {
           return;
       }
//       if ([messageModel.receiver isEqualToString:self.groupCode]) {
//           return;
//       }
       [KDSoundAndShakeManager stopVideoChatSoundAndShake];
       [self.conferenceView refreshConferenceUserView:@[messageModel.sender] state:MultiState_Refuse isClose:self.isVoice];
       [[SxtAppDelegate shareInstance] nativeToFlutterWithMethodName:GET_CONTACTS arguments:@[messageModel.sender] result:^(id  _Nullable result) {
           NSArray *userList = (NSArray *)result;
           NSMutableString *str = [NSMutableString string];
           for (NSDictionary *dic in userList) {
               SxtUserModel *userModel = [SxtUserModel modelWithDictionary:dic];
               [str appendString:userModel.name];
               if ([userList indexOfObject:dic] < userList.count - 1) {
                   [str appendString:@","];
               }
           }
           if (mediaAttachment.status == KDRoomStatus_Dnd) {
               [SxtToast showInfo:[NSString stringWithFormat:@"%@正忙",str]];
           } else if (mediaAttachment.status == KDRoomStatus_Away) {
               [SxtToast showInfo:[NSString stringWithFormat:@"%@未接听",str]];
           } else if (mediaAttachment.status == KDRoomStatus_OnLine) {
               [SxtToast showInfo:[NSString stringWithFormat:@"%@不在线",str]];
           } else {
               [SxtToast showInfo:[NSString stringWithFormat:@"%@已拒绝",str]];
           }
       }];
   }
}

- (void)renderSenderView:(SxtUserModel *)userModel baseUrl:(NSString *)baseUrl
{
    NSString *imageUrl = [NSString stringWithFormat:@"%@%@",baseUrl,userModel.personalPortrait];
    [self.accountImage sd_setImageWithURL:[NSURL URLWithString:imageUrl] placeholderImage:[KDUtil getImage:@"KD_account_default"]];
    
    UIView *senderView = [[UIView alloc] init];
    [self.inviteView addSubview:senderView];
    self.senderView = senderView;
    [senderView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.inviteView);
        make.bottom.equalTo(self.inviteView.mas_centerY);
    }];
    
    UILabel *lab = [[UILabel alloc] init];
    lab.font = [UIFont systemFontOfSize:14];
    lab.text = [NSString stringWithFormat:@"邀请你加入%@聊天",self.isVoice?@"语音":@"视频"];
    lab.textColor = [UIColor whiteColor];
    lab.textAlignment = NSTextAlignmentCenter;
    [senderView addSubview:lab];
    [lab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(senderView);
        make.height.mas_equalTo(16);
        make.bottom.equalTo(senderView);
    }];
    
    UILabel *accountName = [[UILabel alloc] init];
    accountName.font = [UIFont systemFontOfSize:22 weight:UIFontWeightMedium];
    accountName.text = userModel.name;
    accountName.textColor = [UIColor whiteColor];
    accountName.textAlignment = NSTextAlignmentCenter;
    [senderView addSubview:accountName];
    [accountName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(lab.mas_top).offset(-13);
        make.height.mas_equalTo(24);
        make.left.right.equalTo(senderView);
    }];
    
    UIImageView *accountImage = [[UIImageView alloc] init];
    accountImage.layer.cornerRadius = 5;
    accountImage.clipsToBounds = YES;
    [senderView addSubview:accountImage];

    [accountImage sd_setImageWithURL:[NSURL URLWithString:imageUrl] placeholderImage:[KDUtil getImage:@"KD_account_default"]];
    [accountImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(senderView);
        make.bottom.equalTo(accountName.mas_top).offset(-13);
        make.size.mas_equalTo(CGSizeMake(132, 132));
        make.top.equalTo(senderView);
    }];
    
}


- (void)renderUserView:(NSMutableArray *)userlist
{
    UIView *userView = [[UIView alloc] init];
    [self.inviteView addSubview:userView];
    [userView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.inviteView);
        make.top.equalTo(self.inviteView.mas_centerY);
    }];
    
    UILabel *countLab = [[UILabel alloc] init];
    countLab.textAlignment = NSTextAlignmentCenter;
    countLab.textColor = [UIColor whiteColor];
    countLab.text = [NSString stringWithFormat:@"还有%ld人参与聊天",userlist.count] ;
    countLab.font = [UIFont systemFontOfSize:12];
    [userView addSubview:countLab];
    [countLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(userView);
        make.height.mas_equalTo(14);
        make.top.equalTo(userView).offset(35);
    }];
    
    
    KDConferenceMemberCollectionView *memberCollectView = [[KDConferenceMemberCollectionView alloc] initWithUserModel:userlist];
    self.memberCollectView = memberCollectView;
//    memberCollectView.message = self.message;
    [userView addSubview:memberCollectView];
    [memberCollectView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(userView);
        make.top.equalTo(countLab.mas_bottom).offset(20);
        make.bottom.equalTo(userView);
        make.height.mas_equalTo(50);
    }];
    
    
}


- (void)renderFunctionView
{
    UILabel *refuseLab = [[UILabel alloc] init];
    refuseLab.text = @"拒绝";
    refuseLab.textAlignment = NSTextAlignmentCenter;
    refuseLab.font = [UIFont systemFontOfSize:12];
    refuseLab.textColor = [UIColor whiteColor];
    [self.inviteView addSubview:refuseLab];
    [refuseLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.inviteView).multipliedBy(0.5);
        make.size.mas_equalTo(CGSizeMake(100, 40));
        make.bottom.equalTo(self.inviteView).offset(-46);
    }];
    
    UIButton *refuseBtn = [[UIButton alloc] init];
    [refuseBtn setImage:[KDUtil getImage:@"KD_cancel"] forState:UIControlStateNormal];
    [refuseBtn addTarget:self action:@selector(refuseChat:) forControlEvents:UIControlEventTouchUpInside];
    [self.inviteView addSubview:refuseBtn];
    [refuseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.inviteView).multipliedBy(0.5);
        make.bottom.equalTo(refuseLab.mas_top).offset(-10);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
    
    UILabel *acceptLab = [[UILabel alloc] init];
    acceptLab.text = @"接听";
    acceptLab.textAlignment = NSTextAlignmentCenter;
    acceptLab.font = [UIFont systemFontOfSize:12];
    acceptLab.textColor = [UIColor whiteColor];
    [self.inviteView addSubview:acceptLab];
    [acceptLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.inviteView).multipliedBy(1.5);
        make.size.mas_equalTo(CGSizeMake(100, 40));
        make.bottom.equalTo(self.inviteView).offset(-46);
    }];
    
    UIButton *acceptBtn = [[UIButton alloc] init];
    [acceptBtn setImage:[KDUtil getImage:@"KD_accept"] forState:UIControlStateNormal];
    [acceptBtn addTarget:self action:@selector(acceptChat:) forControlEvents:UIControlEventTouchUpInside];
    [self.inviteView addSubview:acceptBtn];
    [acceptBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.inviteView).multipliedBy(1.5);
        make.bottom.equalTo(acceptLab.mas_top).offset(-10);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
}

- (void)renderChatView
{
    UIButton *addBtn = [[UIButton alloc] init];
    [addBtn addTarget:self action:@selector(addNewMemberList) forControlEvents:UIControlEventTouchUpInside];
    [addBtn setImage:[KDUtil getImage:@"KD_add_plus"] forState:UIControlStateNormal];
    [self.containView addSubview:addBtn];
    [addBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.containView).offset(-10);
        make.top.equalTo(self.containView).offset(33);
        make.size.mas_equalTo(CGSizeMake(26, 26));
    }];

    KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)self.message.contentAttachment;
    KDRTCContactModel *contactModel = [[KDRTCContactModel alloc] init];
//    contactModel.caller = [KDConfigManager sharedInstance].userCodeDomain;
    contactModel.callee = self.message.sender;
    contactModel.deviceid = mediaAttachment.resourceId;
    contactModel.RTCIp = [KDConfigManager sharedInstance].webRTCIp;
    contactModel.RTCPort = [KDConfigManager sharedInstance].webRTCPort;
    contactModel.stunIp = [KDConfigManager sharedInstance].stunIp;
    contactModel.stunPort = [KDConfigManager sharedInstance].stunPort;
    contactModel.userList = self.userList;
    __weak typeof(self)weakSelf = self;
    KDConferenceView *conferenceView = [[KDConferenceView alloc] initWithContactModel:contactModel isVoice:self.isVoice newUserBlock:^(NSMutableArray<SxtUserModel *> * _Nonnull userList) {
        NSMutableArray *codeList = [NSMutableArray array];
        [userList enumerateObjectsUsingBlock:^(SxtUserModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            [codeList addObject:obj.userCodeDomain];
        }];
        [weakSelf.videoHandle addMembersWithRoom:mediaAttachment.room users:codeList];
    } dismissBlock:nil];
    [self.containView addSubview:conferenceView];
    self.conferenceView = conferenceView;
    [conferenceView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.containView);
        make.top.equalTo(self.containView).offset(bAllNavTotalHeight);
        make.size.mas_equalTo(CGSizeMake(SxtScreenWidth, SxtScreenWidth));
    }];
    
    UILabel *infoLab = [[UILabel alloc] init];
    infoLab.text = @"正在呼叫";
    infoLab.textAlignment = NSTextAlignmentCenter;
    infoLab.textColor = [UIColor whiteColor];
    infoLab.font = [UIFont systemFontOfSize:14];
    [self.containView addSubview:infoLab];
    self.infoLab = infoLab;
    [infoLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.containView);
        make.height.mas_equalTo(20);
        make.top.equalTo(conferenceView.mas_bottom).offset(15);
    }];
    
    UILabel *openCameraLab = [[UILabel alloc] init];
    openCameraLab.text = @"关闭摄像头";
    openCameraLab.textAlignment = NSTextAlignmentCenter;
    openCameraLab.font = [UIFont systemFontOfSize:14];
    openCameraLab.textColor = [UIColor whiteColor];
    self.openCameraLab = openCameraLab;
    [self.containView addSubview:openCameraLab];
    [openCameraLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.containView.mas_right).offset(-SxtScreenWidth/6);
        make.size.mas_equalTo(CGSizeMake(100, 12));
        make.top.equalTo(infoLab.mas_bottom).offset(self.height*(40.0/667.0));
    }];
    
    UIButton *openCameraBtn = [[UIButton alloc] init];
    [openCameraBtn setImage:[KDUtil getImage:@"KD_conference_video"] forState:UIControlStateNormal];
    [openCameraBtn setImage:[KDUtil getImage:@"KD_conference_video_selected"] forState:UIControlStateSelected];
    [openCameraBtn addTarget:self action:@selector(openCamera:) forControlEvents:UIControlEventTouchUpInside];
    [self.containView addSubview:openCameraBtn];
    [openCameraBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.containView.mas_right).offset(-SxtScreenWidth/6);
        make.top.equalTo(openCameraLab.mas_bottom).offset(10);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
    
    
    UILabel *handFreeLab = [[UILabel alloc] init];
    handFreeLab.text = @"免提";
    handFreeLab.textAlignment = NSTextAlignmentCenter;
    handFreeLab.font = [UIFont systemFontOfSize:12];
    handFreeLab.textColor = [UIColor whiteColor];
    [self.containView addSubview:handFreeLab];
    [handFreeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.containView);
        make.size.mas_equalTo(CGSizeMake(40, 14));
        make.centerY.equalTo(openCameraLab);
    }];
    
    UIButton *handFreeBtn = [[UIButton alloc] init];
    [handFreeBtn setImage:[KDUtil getImage:@"KD_conference_speaker"] forState:UIControlStateNormal];
    [handFreeBtn setImage:[KDUtil getImage:@"KD_conference_speaker_selected"] forState:UIControlStateSelected];
    [handFreeBtn addTarget:self action:@selector(selectMicrophone:) forControlEvents:UIControlEventTouchUpInside];
    [self.containView addSubview:handFreeBtn];
    [handFreeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.containView);
        make.top.equalTo(handFreeLab.mas_bottom).offset(10);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
    
    UILabel *noSoundLab = [[UILabel alloc] init];
    noSoundLab.text = @"静音";
    noSoundLab.textAlignment = NSTextAlignmentCenter;
    noSoundLab.font = [UIFont systemFontOfSize:12];
    noSoundLab.textColor = [UIColor whiteColor];
    [self.containView addSubview:noSoundLab];
    [noSoundLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.containView.mas_left).offset(SxtScreenWidth/6);
        make.size.mas_equalTo(CGSizeMake(40, 12));
        make.centerY.equalTo(openCameraLab);
    }];
    
    UIButton *noSoundBtn = [[UIButton alloc] init];
    [noSoundBtn setImage:[KDUtil getImage:@"KD_conference_silent"] forState:UIControlStateNormal];
    [noSoundBtn setImage:[KDUtil getImage:@"KD_conference_silent_selected"] forState:UIControlStateSelected];
    [noSoundBtn addTarget:self action:@selector(setMute:) forControlEvents:UIControlEventTouchUpInside];
    [self.containView addSubview:noSoundBtn];
    [noSoundBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.containView.mas_left).offset(SxtScreenWidth/6);
        make.top.equalTo(noSoundLab.mas_bottom).offset(10);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
    
    
    
    UIButton *cancelBtn = [[UIButton alloc] init];
    [cancelBtn setImage:[KDUtil getImage:@"KD_cancel"] forState:UIControlStateNormal];
    [cancelBtn addTarget:self action:@selector(handupChat:) forControlEvents:UIControlEventTouchUpInside];
    [self.containView addSubview:cancelBtn];
    [cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.containView);
        make.top.equalTo(handFreeBtn.mas_bottom).offset(20);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
    

}

-(void)draggingDidEnded:(UIView *)view {
    CGPoint point = view.frame.origin;
    float screenWidth = [UIScreen mainScreen].bounds.size.width;
    float screenHeight = [UIScreen mainScreen].bounds.size.height;
    float selfSize = 52;
    if (point.x+self.width > screenWidth) {
        self.movePoint = CGPointMake(screenWidth - self.width, point.y);
        self.frame = CGRectMake(self.movePoint.x, self.movePoint.y, selfSize, selfSize);
    } else if (point.y+self.height > screenHeight) {
        self.movePoint = CGPointMake(point.x, screenHeight - self.height);
        self.frame = CGRectMake(self.movePoint.x, self.movePoint.y, selfSize, selfSize);
    }else if (point.x < 0) {
        self.movePoint = CGPointMake(0, point.y);
        self.frame = CGRectMake(self.movePoint.x, self.movePoint.y, selfSize, selfSize);
    } else if (point.y < 0) {
        self.movePoint = CGPointMake(point.x, 0);
        self.frame = CGRectMake(self.movePoint.x, self.movePoint.y, selfSize, selfSize);
    } else {
        self.movePoint = CGPointMake(point.x, point.y);
        self.frame = CGRectMake(self.movePoint.x, self.movePoint.y, selfSize, selfSize);
    }
}


- (void)dealloc
{
    NSLog(@"****************释放KDConferenceMainView*************");
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    [SVProgressHUD dismiss];
    [self updateVideoNativeToFlutter];
    [KDConfigManager sharedInstance].isVideoOnline = NO;
    [UIApplication sharedApplication].idleTimerDisabled = false;
}

- (void)show
{
    UIWindow *rootWindow = [UIApplication sharedApplication].keyWindow;
    [rootWindow endEditing:YES];
    [rootWindow addSubview:self];
}

-(UIButton *)narrowBtn {
    if (!_narrowBtn) {
        _narrowBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_narrowBtn setImage:[KDUtil getImage:@"KD_guaduan"] forState:UIControlStateNormal];
        [_narrowBtn addTarget:self action:@selector(expandInvitViewEvent) forControlEvents:UIControlEventTouchUpInside];
        _narrowBtn.alpha = 0;
        [self addSubview:_narrowBtn];
        [_narrowBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(self);
            make.size.mas_equalTo(CGSizeMake(52, 52));
        }];
    }
    return _narrowBtn;
}

-(UIView *)containView {
    if (!_containView) {
        _containView = [[UIView alloc]initWithFrame:self.bounds];
        [self addSubview:_containView];
    }
    return _containView;
}

@end
