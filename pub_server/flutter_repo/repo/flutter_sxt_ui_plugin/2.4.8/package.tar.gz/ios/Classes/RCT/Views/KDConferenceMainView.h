//
//  KDConferenceMainView.h
//  Runner
//
//  Created by xzc on 2021/5/21.
//

#import <UIKit/UIKit.h>
#import "KDVLineEnums.h"
#import <KDVLine/KDVLine.h>
@interface KDConferenceMainView : UIView
@property (nonatomic,copy) void(^dismissBlock)(void);
- (instancetype )initConferenceMainViewWithMessage:(KDMessageModel *)message showType:(KDVLineRTCShowType)showType isJoin:(BOOL)isJoin groupCode:(NSString *)groupCode;
- (instancetype )initConferenceMainViewWithMessage:(KDMessageModel *)message showType:(KDVLineRTCShowType)showType groupCode:(NSString *)groupCode;
- (void)show;
-(void)refreshConferenceView:(NSArray *)userList;
-(void)expandInvitViewEvent;
-(void)zoomInvitViewEvent;
@end
