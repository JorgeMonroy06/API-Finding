//
//  KDUserLoadingView.h
//  Runner
//
//  Created by xzc on 2021/6/15.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KDUserLoadingView : UIView
-(void)startLoad;
-(void)stopLoad;
@end

NS_ASSUME_NONNULL_END
