//
//  SxtConfigConstant.h
//  Runner
//
//  Created by xzc on 2021/4/29.
//

#ifndef SxtConfigConstant_h
#define SxtConfigConstant_h

#define TopStatuHeight    (kIsBangsScreen?44:20)
//系统底部TabBar高度
#define bTabBarHeight          (kIsBangsScreen?83:49)
//系统导航栏总高度
#define bAllNavTotalHeight     (kIsBangsScreen?88:64)
// 底部安全区域远离高度
#define kBottomSafeHeight      (kIsBangsScreen?34:0)

#define SxtScreenWidth           [UIScreen mainScreen].bounds.size.width

#define SxtScreenHeight           [UIScreen mainScreen].bounds.size.height

#define kIsBangsScreen ({\
    BOOL isBangsScreen = NO; \
    if (@available(iOS 11.0, *)) { \
    UIWindow *window = [[UIApplication sharedApplication].windows firstObject]; \
    isBangsScreen = window.safeAreaInsets.bottom > 0; \
    } \
    isBangsScreen; \
})

#ifdef DEBUG
#define Log(FORMAT, ...) fprintf(stderr, "[%s:%d行] %s\n", [[[NSString stringWithUTF8String:__FILE__] lastPathComponent] UTF8String], __LINE__, [[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] UTF8String]);
#else
#define Log(...)
#endif

#endif /* SxtConfigConstant_h */

