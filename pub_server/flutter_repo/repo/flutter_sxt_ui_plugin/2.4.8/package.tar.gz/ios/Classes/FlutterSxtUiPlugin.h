#import <Flutter/Flutter.h>

@interface FlutterSxtUiPlugin : NSObject<FlutterPlugin>
@end
