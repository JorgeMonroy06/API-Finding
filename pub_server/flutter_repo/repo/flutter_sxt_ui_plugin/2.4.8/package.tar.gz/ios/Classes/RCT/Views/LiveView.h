//
//  VideoCallView.h
//  kdrtcapidemo
//
//  Created by mac on 2021/1/5.
//
#import <UIKit/UIKit.h>

#import <WebRTC/RTCVideoRenderer.h>
#import <WebRTC/RTCCameraPreviewView.h>

@protocol LiveDelegate <NSObject>

- (void)onMessage:(NSString*)msg;
- (void)onFinished;

@end


// Video call view that shows local and remote video, provides a label to
// display status, and also a hangup button.
@interface LiveView : UIView

@property(nonatomic, readonly) UILabel *statusLabel;
@property(nonatomic, readonly) RTC_OBJC_TYPE(RTCCameraPreviewView) * localVideoView;
@property(nonatomic, readonly) __kindof UIView<RTC_OBJC_TYPE(RTCVideoRenderer)> *remoteVideoView;
@property(nonatomic, weak) id<LiveDelegate> callDelegate;


- (void)start:(NSString *)caller callee:(NSString *)callee deviceid:(NSString *)deviceid
         nmIp:(NSString*)nmIp nmPort:(NSString*)nmPort
         stunIp:(NSString*)stunIp stunPort:(NSString*)stunPort;

- (void)stop;

@end
