//
//  KDConferenceMemberCollectionView.m
//  KDVLine_Example
//
//  Created by samuel on 2021/5/19.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import "KDConferenceMemberCollectionView.h"
#import "KDConferenceMemberCollectionViewCell.h"
#import "SxtUserModel.h"
#import <Masonry/Masonry.h>
@interface KDConferenceMemberCollectionView()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic, strong) NSMutableArray<SxtUserModel *> *userArray;

@property (nonatomic, weak) UICollectionView *collectView;

@end

@implementation KDConferenceMemberCollectionView

- (instancetype)initWithUserModel:(NSMutableArray *)userArray
{
    self = [super init];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.userArray = userArray;
        [self renderView];
    }
    return self;
}

- (void)renderView
{
    UICollectionViewFlowLayout *flowLayout1 =[[UICollectionViewFlowLayout alloc]init];
    flowLayout1.itemSize = CGSizeMake(48,48);
    flowLayout1.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);
    flowLayout1.minimumLineSpacing = 10;
    flowLayout1.minimumInteritemSpacing = 10;
    flowLayout1.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    UICollectionView *collectView = [[UICollectionView alloc] initWithFrame:self.bounds collectionViewLayout:flowLayout1];
    collectView.showsVerticalScrollIndicator = NO;
    collectView.showsHorizontalScrollIndicator = NO;
    collectView.scrollEnabled = YES;
    [collectView registerClass:[KDConferenceMemberCollectionViewCell class] forCellWithReuseIdentifier:@"KDConferenceMemberCollectionViewCellID"];
    collectView.backgroundColor = [UIColor clearColor];
    collectView.delegate = self;
    collectView.dataSource = self;
    [self addSubview:collectView];
    self.collectView = collectView;
    [collectView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
    
}

-(void)addInviteMemberData:(NSMutableArray<SxtUserModel *> *) userArray {
    for (SxtUserModel *newUser in userArray) {
        BOOL isHas = NO;
        for (SxtUserModel *oldUser in self.userArray) {
            if ([newUser.userCodeDomain isEqualToString:oldUser.userCodeDomain]) {
                isHas = true;
            }
        }
        if (!isHas) {
            [self.userArray addObject:newUser];
        }
    }
    [self.collectView reloadData];
}


//- (void)setMessage:(KDMessageModel *)message
//{
//    _message = message;
//    KDMutiMediaAttachment *attachment = (KDMutiMediaAttachment *)message.contentAttachment;
//    self.userShowArray = [NSMutableArray array];
//    [attachment.users enumerateObjectsUsingBlock:^(NSString *userCode, NSUInteger idx, BOOL * _Nonnull stop) {
//        if (![userCode isEqualToString:message.sender] && ![userCode isEqualToString:[KDConfigManager sharedInstance].userCodeDomain]) {
//            [self.userShowArray addObject:userCode];
//        }
//    }];
//    [self.collectView reloadData];
//
//}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    NSInteger numberOfItems = [collectionView numberOfItemsInSection:0];
    UICollectionViewFlowLayout *flowLayout = (UICollectionViewFlowLayout *)collectionViewLayout;
    CGFloat combinedItemWidth = (numberOfItems * flowLayout.itemSize.width) + ((numberOfItems - 1)*flowLayout.minimumInteritemSpacing);
    CGFloat padding = (collectionView.frame.size.width - combinedItemWidth)/2;
    padding = padding>0 ? padding :0 ;

    return UIEdgeInsetsMake(0, padding,0, padding);
}

- (NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return  1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView
     numberOfItemsInSection:(NSInteger)section {
    return self.userArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView
                  cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"KDConferenceMemberCollectionViewCellID";
    KDConferenceMemberCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    cell.imageUrl = self.userArray[indexPath.row].headUrl;
    return cell;
}

@end
