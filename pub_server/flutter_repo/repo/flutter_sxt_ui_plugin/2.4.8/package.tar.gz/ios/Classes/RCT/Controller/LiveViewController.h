//
//  LiveViewController.h
//  RTCSDK
//
//  Created by mac on 2021/1/21.
//  Copyright © 2021 BlueAirLJ. All rights reserved.
//

#ifndef LiveViewController_h
#define LiveViewController_h

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface LiveViewController : UIViewController

- (instancetype)initWithConfig:(NSString *)callee
                        deviceid:(NSString *)deviceid
                        nmIp:(NSString*)nmIp nmPort:(NSString*)nmPort
                        stunIp:(NSString*)stunIp stunPort:(NSString*)stunPort;

@end

#endif /* LiveViewController_h */
