//
//  KDSoundAndShakeManager.m
//  KDVLine_Example
//
//  Created by samuel on 2021/4/1.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import "KDSoundAndShakeManager.h"
#import <AVFoundation/AVFoundation.h>


static SystemSoundID soundID;
@implementation KDSoundAndShakeManager

//单利方法
+ (instancetype)shareInstance {
   //注意下面这行代码直接写在这里就可以，不用担心多次调用出问题；1.static id instance = nil;只是编一阶段的初始值，真正赋值后就是一个唯一的值 2. onceToken地址没有被释放就不会再次进入dispatch_once函数
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[super allocWithZone:NULL] init];
    });
    return instance;
}

//alloc new 方式创建实例最终都会执行这个方法
+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    return [[self class] shareInstance];
}
//copy mutableCopy 方式创建实例最终都会执行这个方法
- (instancetype)copyWithZone:(struct _NSZone *)zone{
    return [[self class] shareInstance];
}

+ (void)startVideoChatSoundAndShake
{
    if ([KDSoundAndShakeManager shareInstance].isPlaying) {
        return;
    }
    [KDSoundAndShakeManager shareInstance].isPlaying = YES;
    NSBundle *bundle = [NSBundle bundleForClass:[self class]];
    NSString *path = [bundle pathForResource:@"voip_call" ofType:@"caf" inDirectory:@"flutter_sxt_ui_bundle.bundle"];
    AudioServicesCreateSystemSoundID((__bridge CFURLRef)[NSURL fileURLWithPath:path], &soundID );
    AudioServicesAddSystemSoundCompletion(soundID, NULL, NULL, systemAudioCallback, NULL);
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    AudioServicesPlayAlertSound(soundID);
}

+ (void)startCommonMessageAndShake
{
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    AudioServicesPlaySystemSound(1002);
}

void systemAudioCallback (SystemSoundID soundID, void* clientData) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.7 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [KDSoundAndShakeManager shareInstance].isPlaying = NO;
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    });
}

+ (void)stopVideoChatSoundAndShake
{
    [KDSoundAndShakeManager shareInstance].isPlaying = NO;
    AudioServicesDisposeSystemSoundID(kSystemSoundID_Vibrate);
    AudioServicesDisposeSystemSoundID(soundID);
    AudioServicesRemoveSystemSoundCompletion(soundID);
}



@end
