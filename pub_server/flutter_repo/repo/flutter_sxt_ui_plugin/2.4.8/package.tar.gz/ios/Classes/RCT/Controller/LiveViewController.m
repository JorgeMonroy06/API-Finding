//
//  LiveViewController.m
//  RTCSDK
//
//  Created by mac on 2021/1/21.
//  Copyright © 2021 BlueAirLJ. All rights reserved.
//


#import "LiveViewController.h"
#import "LiveView.h"
#import "RTCSDK/KDRTCSDKApi.h"

@interface LiveViewController ()<LiveDelegate>

@end


@implementation LiveViewController{
    LiveView *_liveView;
    NSString* _callee;
    NSString* _deviceid;
    
    NSString* _nmIp;
    NSString* _nmPort;
    NSString* _stunIp;
    NSString* _stunPort;
    
    KDRTCSDKApi* kdsdkapi;
}


- (instancetype)initWithConfig:(NSString *)callee
                      deviceid:(NSString *)deviceid
                      nmIp:(NSString*)nmIp nmPort:(NSString*)nmPort
                      stunIp:(NSString*)stunIp stunPort:(NSString*)stunPort{
    if (self = [super init]) {
        _callee = callee;
        _deviceid = deviceid;
        _nmIp = nmIp;
        _nmPort = nmPort;
        _stunIp = stunIp;
        _stunPort = stunPort;
    }
    
    KDNETConfig* config = [KDNETConfig new];
    config.wsIp = _nmIp;
    config.wsPort = [_nmPort intValue];
    if (_stunIp.length > 0 && _stunIp.length > 0) {
        config.stunIp = _stunIp;
        config.stunPort = [_stunPort intValue];
    }
    
    kdsdkapi = [KDRTCSDKApi getInstance];
    [kdsdkapi configure:config];
    return self;
}

- (void)viewDidLoad {
  [super viewDidLoad];
    [_liveView start:nil callee:_callee deviceid:_deviceid nmIp:_nmIp nmPort:_nmPort stunIp:_stunIp stunPort:_stunPort];
  _liveView.callDelegate = self;
}

- (void)loadView {
  self.title = @"Live";
  _liveView = [[LiveView alloc] initWithFrame:CGRectZero];
  self.view = _liveView;
  
}

- (void)viewDidDisappear:(BOOL)animated {
    if (self.isBeingDismissed || self.isMovingFromParentViewController
        || (self.navigationController && self.navigationController.isBeingDismissed)) {
        //TODO: release important resource
        [_liveView stop];
    }
    [super viewDidDisappear:animated];
}


- (void)showAlertWithMessage:(NSString*)message {
  UIAlertController *alert =
      [UIAlertController alertControllerWithTitle:nil
                                          message:message
                                   preferredStyle:UIAlertControllerStyleAlert];

  UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"OK"
                                                          style:UIAlertActionStyleDefault
                                                        handler:^(UIAlertAction *action){
                                                        }];

  [alert addAction:defaultAction];
  [self presentViewController:alert animated:YES completion:nil];
}
- (void)onMessage:(NSString *)msg {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self showAlertWithMessage:msg];
    });
    
}

- (void)onFinished{
    if (![self isBeingDismissed]) {
      NSLog(@"Dismissing VC");
      [self dismissViewControllerAnimated:YES completion:^{
        
      }];
    }
    
}

@end

