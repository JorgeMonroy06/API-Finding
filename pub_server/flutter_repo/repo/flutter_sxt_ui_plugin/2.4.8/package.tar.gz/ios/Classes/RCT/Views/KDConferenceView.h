//
//  KDConferenceView.h
//  KDVLine_Example
//
//  Created by samuel on 2021/5/19.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KDRTCContactModel.h"
#import <sxt_flutter_plugin/SxtUserModel.h>
#import "KDConferenceSingleUserView.h"
NS_ASSUME_NONNULL_BEGIN

@interface KDConferenceView : UIView

@property (nonatomic, strong) KDRTCContactModel *contactModel;

- (instancetype)initWithContactModel:(KDRTCContactModel *)contactModel
                             isVoice:(BOOL)isVoice
                        newUserBlock:(void (^)(NSMutableArray<SxtUserModel *> *))newUserBlock
                        dismissBlock:(void (^)(void))dismissBlock;

- (void)refreshConferenceUserView:(NSArray *)userCodeList state:(MultiState)state isClose:(BOOL)isClose;

- (void)startConference:(BOOL)isVoice sender:(NSString *)sender;

- (void)stopConference:(BOOL)isVoice;

- (void)changeCamera;

- (void)changeSpeakerWithSelected:(BOOL )selected;

- (void)openOrCloseCamera:(BOOL)isClose;

- (void)setMute:(BOOL)enable;

-(void)refreshUI:(NSArray *)userList
         isVoice:(BOOL)isVoice
      isExtraAdd:(BOOL)isExtraAdd;


@end

NS_ASSUME_NONNULL_END
