//
//  KDVLineEnums.h
//  KDVLine_Example
//
//  Created by samuel on 2021/3/3.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#ifndef KDVLineEnums_h
#define KDVLineEnums_h

typedef NS_ENUM (NSInteger,KDVLineRTCShowType){
    KDVLineRTCShowType_Voice_Active = 0,//语音主动邀请
    KDVLineRTCShowType_Voice_Passive,//语音被动邀请
    KDVLineRTCShowType_Video_Active,//视频主动邀请
    KDVLineRTCShowType_Video_Passive,//视频被动邀请

};




#endif /* KDVLineEnums_h */
