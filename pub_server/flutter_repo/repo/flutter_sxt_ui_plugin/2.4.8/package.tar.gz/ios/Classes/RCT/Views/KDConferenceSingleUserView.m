//
//  KDConferenceSingleUserView.m
//  KDVLine_Example
//
//  Created by samuel on 2021/5/19.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//
#import "SxtGroupHandle.h"
#import "KDConferenceSingleUserView.h"
#import <KDWebRTC/KDWebRTC.h>
#import "KDUserLoadingView.h"
#import <Masonry/Masonry.h>
#import "SxtConfigConstant.h"
#import <SDWebImage/SDWebImage.h>
#import "KDUtil.h"
//#import "WebRTC/RTCDispatcher.h"
//#import "WebRTC/RTCAudioSession.h"
//#import "WebRTC/RTCVideoRenderer.h"
//#import "WebRTC/RTCCameraPreviewView.h"
//#import "WebRTC/RTCVideoRenderer.h"
//#import "WebRTC/RTCCameraPreviewView.h"

@interface KDConferenceSingleUserView()<RTC_OBJC_TYPE (RTCVideoViewDelegate)>

@property (nonatomic, strong) UIImageView *iconImageView;

@property (nonatomic, strong) UIButton *callBtn;

@property (nonatomic, strong) UILabel *nameLab;

@property (nonatomic, strong) KDUserLoadingView *loadingView;

@end

@implementation KDConferenceSingleUserView

@synthesize count = _count;
@synthesize userModel = _userModel;
//@synthesize isUsed = _isUsed;
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.contentMode = UIViewContentModeScaleAspectFill;
        self.clipsToBounds = YES;
        RTC_OBJC_TYPE(RTCEAGLVideoView) *remoteViewTmp = [[RTC_OBJC_TYPE(RTCEAGLVideoView) alloc] init];
        remoteViewTmp.delegate = self;

        [self addSubview:remoteViewTmp];
        
        self.remoteVideoView = remoteViewTmp;
        
        UIImageView *iconImageView = [[UIImageView alloc] init];
        [self addSubview:iconImageView];
        self.iconImageView = iconImageView;
        [iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self);
        }];
        
        UIButton *callBtn = [[UIButton alloc] init];
        callBtn.backgroundColor = [UIColor blackColor];
        callBtn.alpha = 0.5;
        callBtn.hidden = YES;
        [callBtn setImage:[KDUtil getImage:@"KD_video_call"] forState:UIControlStateNormal];
        [callBtn addTarget:self action:@selector(reAddMember) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:callBtn];
        self.callBtn = callBtn;
        [callBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self);
        }];
        
        UILabel *nameLab = [[UILabel alloc]init];
        nameLab.textColor = [UIColor whiteColor];
        nameLab.font = [UIFont systemFontOfSize:13];
        [self addSubview:nameLab];
        [nameLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(10);
            make.bottom.equalTo(self).offset(-5);
        }];
        self.nameLab = nameLab;
    }
    return self;
}

-(void)reAddMember {
    if (self.newUserBlock) {
        self.newUserBlock(@[self.userModel]);
        self.state = MultiState_Invited;
    }
}

-(void)setCount:(NSInteger)count {
    _count = count;
    CGFloat width;
    if (count > 4) {
        width = SxtScreenWidth/3;
    }else{
        width = SxtScreenWidth/2;
    }
    CGFloat height = width/(3.0/4.0);
    [self.remoteVideoView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(width, height));
        make.center.equalTo(self);
    }];
}

- (void)setUserModel:(SxtUserModel *)userModel
{
    _userModel = userModel;
    if ([userModel.userCodeDomain isEqualToString:[KDConfigManager sharedInstance].userCodeDomain]) {
        CGFloat width;
        if (self.count > 4) {
            width = SxtScreenWidth/3;
        }else{
            width = SxtScreenWidth/2;
        }
        self.localVideoView = [[RTC_OBJC_TYPE(RTCCameraPreviewView) alloc] init];
        [self addSubview:self.localVideoView];
        CGFloat height = width/(3.0/4.0);
        [self.localVideoView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(width, height));
            make.center.equalTo(self);
        }];
        [self bringSubviewToFront:self.iconImageView];
        [self bringSubviewToFront:self.nameLab];
        [self layoutIfNeeded];
        [self.remoteVideoView removeFromSuperview];
//        self.iconImageView.hidden = NO;
//        [self.iconImageView removeFromSuperview];
    } else {
    }
    [self.iconImageView sd_setImageWithURL:[NSURL URLWithString:userModel.headUrl] placeholderImage:[KDUtil getImage:@"KD_user_multi_default"]];
    self.nameLab.text = userModel.name;
    
}

-(void)setState:(MultiState)state {
    _state = state;
    switch (state) {
        case MultiState_Refuse:{
            self.callBtn.hidden = NO;
            self.iconImageView.hidden = NO;
            [self stopLoad];
            break;}
        case MultiState_Invited:
            self.callBtn.hidden = YES;
            self.iconImageView.hidden = NO;
            [self startLoad];
            break;
        case MultiState_Accept:
            self.callBtn.hidden = YES;
            self.iconImageView.hidden = self.isVoice ? NO : YES;
            [self stopLoad];
            break;
        default:
            self.iconImageView.hidden = self.isVoice ? NO : YES;
            break;
    }
}

-(void)showCallBtn:(BOOL)isShow {
    self.callBtn.hidden = !isShow;
}


- (void)setIsVoice:(BOOL)isVoice {
    _isVoice = isVoice;
//    self.iconImageView.hidden = !isVoice;
}

-(void)startLoad {
    [self.loadingView startLoad];
}

-(void)stopLoad {
    [self.loadingView stopLoad];
}


- (void)videoView:(id<RTCVideoRenderer>)videoView didChangeVideoSize:(CGSize)size
{

}

-(KDUserLoadingView *)loadingView {
    if (!_loadingView) {
        _loadingView = [[KDUserLoadingView alloc]init];
        _loadingView.backgroundColor = [UIColor clearColor];
        [self addSubview:_loadingView];
        [_loadingView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self);
        }];
    }
    return _loadingView;
}

- (void)dealloc
{
    [_loadingView stopLoad];
    NSLog(@"dealloc");
}

@end
