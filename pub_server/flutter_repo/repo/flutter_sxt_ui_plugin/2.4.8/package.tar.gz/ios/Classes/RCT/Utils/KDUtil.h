//
//  KDUtil.h
//  KDVLine_Example
//
//  Created by samuel on 2021/5/10.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KDUtil : NSObject

+ (UIViewController *)getCurrentViewController;

+ (NSString *)getParamByName:(NSString *)name URLString:(NSString *)url;

+(UIImage *)getImage:(NSString *)imageName;
@end

NS_ASSUME_NONNULL_END
