//
//  KDSoundAndShakeManager.h
//  KDVLine_Example
//
//  Created by samuel on 2021/4/1.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KDSoundAndShakeManager : NSObject
@property (nonatomic, assign) BOOL isPlaying;
+ (instancetype)shareInstance;
/// 播放音视频声音与震动
+ (void)startVideoChatSoundAndShake;

/// 播放普通消息声音与震动
+ (void)startCommonMessageAndShake;

/// 结束音视频声音与震动
+ (void)stopVideoChatSoundAndShake;


@end

NS_ASSUME_NONNULL_END
