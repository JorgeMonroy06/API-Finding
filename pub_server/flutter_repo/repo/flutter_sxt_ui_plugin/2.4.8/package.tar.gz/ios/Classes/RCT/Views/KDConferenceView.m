//
//  KDConferenceView.m
//  KDVLine_Example
//
//  Created by samuel on 2021/5/19.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import "KDConferenceView.h"
#import <KDWebRTC/KDWebRTC.h>
#import <SVProgressHUD/SVProgressHUD.h>
#import "SxtGroupHandle.h"
#import <Masonry/Masonry.h>
#import "SxtConfigConstant.h"
@interface KDConferenceView()<RTC_OBJC_TYPE (RTCVideoViewDelegate), FunctionDelegate>

@property (nonatomic, strong) KDRTCSDKApi* kdsdkapi;

@property (nonatomic, strong) NSMutableArray *userViewArray;

@property (nonatomic,copy) void(^newUserBlock)(NSMutableArray<SxtUserModel *> *);
@property (nonatomic,copy) void(^dismissBlock)(void);
@property (nonatomic,copy) KDConferenceStartReq *conferenceStartReq;
@end

@implementation KDConferenceView

- (instancetype)initWithContactModel:(KDRTCContactModel *)contactModel
                             isVoice:(BOOL)isVoice
                        newUserBlock:(void (^)(NSMutableArray<SxtUserModel *> *))newUserBlock
                        dismissBlock:(void (^)(void))dismissBlock
{
    self = [super init];
    if (self) {
        self.userViewArray = [NSMutableArray array];
        self.contactModel = contactModel;
        self.newUserBlock = newUserBlock;
        self.dismissBlock = dismissBlock;
        [self refreshUI:nil isVoice:isVoice isExtraAdd:NO];
    }
    
    return self;
}


/// 刷新界面
/// @param userList 需要显示在界面的人数
/// @param isVoice 是否是语音会议
/// @param isExtraAdd 是否是额外加人
-(void)refreshUI:(NSArray *)userList
         isVoice:(BOOL)isVoice
      isExtraAdd:(BOOL)isExtraAdd {
    
    NSMutableArray *calleeArray = [NSMutableArray arrayWithArray:self.contactModel.userList];
    NSMutableArray *newUserViewArray = [NSMutableArray array];
    for (SxtUserModel *newUserModel in userList) {
        __block BOOL isHas = false;
        [calleeArray enumerateObjectsUsingBlock:^(SxtUserModel *userModel, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([newUserModel.userCodeDomain isEqualToString:userModel.userCodeDomain]) {
                isHas = true;
                [calleeArray replaceObjectAtIndex:idx withObject:newUserModel];
                *stop = YES;
            }
        }];
        if (!isHas) {
            [calleeArray addObject:newUserModel];
        }
    }
    
    CGFloat width;
    if (calleeArray.count > 4) {
        width = SxtScreenWidth/3;
    }else{
        width = SxtScreenWidth/2;
    }
    
    [calleeArray enumerateObjectsUsingBlock:^(SxtUserModel *userModel, NSUInteger idx, BOOL * _Nonnull stop) {
        BOOL isHas = false;
        KDConferenceSingleUserView *userView;
        for (KDConferenceSingleUserView *userOldView in self.userViewArray) {
            if ([userOldView.userModel.userCodeDomain isEqualToString:userModel.userCodeDomain]) {
                isHas = true;
                userView = userOldView;
                break;
            }
        }
        if (!isHas) {
            userView = [[KDConferenceSingleUserView alloc] init];
            ((KDConferenceSingleUserView *)userView).newUserBlock = self.newUserBlock;
            ((KDConferenceSingleUserView *)userView).count = calleeArray.count;
            ((KDConferenceSingleUserView *)userView).userModel = userModel;
            [self addSubview:userView];
            [newUserViewArray addObject:userView];
        }
        userView.isVoice = isVoice;
        userView.state = userModel.multiState;
        CGFloat leftOffset;
        CGFloat topOffset;
        if (calleeArray.count > 4) {
            topOffset = idx /3 *width;
            NSInteger multiple = calleeArray.count / 3;
            if (calleeArray.count % 3 > 0 && multiple * 3 < (idx + 1)) {
                leftOffset = (idx - multiple * 3) * width;
            } else {
                leftOffset = (2- (idx + 1) % 3) *width;
            }
        }else{
            topOffset = idx /2 *width;
            if (calleeArray.count % 2 > 0 && idx == calleeArray.count - 1 ) {
                leftOffset = (SxtScreenWidth - width)/2;
            } else {
                leftOffset = (1- (idx + 1) % 2) *width;
            }
        }
        [userView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(width, width));
            make.left.equalTo(self).offset(leftOffset);
            make.top.equalTo(self).offset(topOffset);
        }];
        
    }];
    self.contactModel.userList = calleeArray;
    [self.userViewArray addObjectsFromArray:newUserViewArray];
    if (userList && userList.count) {
        if (newUserViewArray.count) {
            KDConferenceAddReq *params = [[KDConferenceAddReq alloc]init];
            params.calleeViewDic = [NSMutableDictionary dictionary];
            params.mediaType = isVoice ? 1 : 0;
            [newUserViewArray enumerateObjectsUsingBlock:^(UIView *view, NSUInteger idx, BOOL * _Nonnull stop) {
                KDConferenceSingleUserView *obj = (KDConferenceSingleUserView *)view;
                obj.state = MultiState_Invited;
                [params.calleeViewDic setObject:obj.remoteVideoView forKey:obj.userModel.userCodeDomain];
            }];
            [self.kdsdkapi addCallees:params];
        }
        if (isExtraAdd && self.newUserBlock) {
            self.newUserBlock([NSMutableArray arrayWithArray:userList]);
        }
    }
}
     

- (void)startConference:(BOOL)isVoice sender:(NSString *)sender
{
    KDNETConfig* config = [KDNETConfig new];
    config.wsIp = self.contactModel.RTCIp;
    config.wsPort = [self.contactModel.RTCPort intValue];
    if (self.contactModel.stunIp.length > 0) {
        config.stunIp = self.contactModel.stunIp;
        config.stunPort = [self.contactModel.stunPort intValue];
    }
    self.kdsdkapi = [KDRTCSDKApi getInstance];
    [self.kdsdkapi configure:config];
    
    //0视频，1音频
    self.conferenceStartReq.mediaType = isVoice ? 1 : 0;
    self.conferenceStartReq.callerId = self.contactModel.caller;
    self.conferenceStartReq.resourceId = self.contactModel.deviceid;
    self.conferenceStartReq.videoType = 106;
    self.conferenceStartReq.audioType = 117;
    self.conferenceStartReq.shouldGetStats = YES;
    if (self.contactModel.stunIp.length > 0) {
        self.conferenceStartReq.stunUrl = [NSString stringWithFormat:@"%@:%@",self.contactModel.stunIp,self.contactModel.stunPort];
    }
    self.conferenceStartReq.calleeViewDic = [NSMutableDictionary dictionary];
    [self.userViewArray enumerateObjectsUsingBlock:^(KDConferenceSingleUserView *view, NSUInteger idx, BOOL * _Nonnull stop) {
        KDConferenceSingleUserView *obj = (KDConferenceSingleUserView *)view;
        obj.isVoice = isVoice;
        if ([view.userModel.userCodeDomain isEqualToString:[KDConfigManager sharedInstance].userCodeDomain]) {
            self.conferenceStartReq.localVideoView = obj.localVideoView;
        }else{
            [self.conferenceStartReq.calleeViewDic setObject:obj.remoteVideoView forKey:obj.userModel.userCodeDomain];
        }
    }];
    [self.kdsdkapi startConference:self.conferenceStartReq callback:self];
}


/// 刷新页面上的已有人数
/// @param userCodeList 用于判断界面上是否已有相关的view
- (void)refreshConferenceUserView:(NSArray *)userCodeList state:(MultiState)state isClose:(BOOL)isClose
{
    for (NSString *code in userCodeList) {
        for (KDConferenceSingleUserView *userView in self.userViewArray) {
            if ([userView.userModel.userCodeDomain isEqualToString:code]) {
                userView.isVoice = isClose;
                userView.state = state;
                break;
            }
        }
        for (SxtUserModel *userModel in self.contactModel.userList) {
            if ([userModel.userCodeDomain isEqualToString:code]) {
                userModel.multiState = state;
                break;
            }
        }
    }
}

- (void)removeUsersConferenceView
{
    CGFloat width;
    if (self.userViewArray.count > 4) {
        width = SxtScreenWidth/3;
    }else{
        width = SxtScreenWidth/2;
    }
    
    [self.userViewArray enumerateObjectsUsingBlock:^(KDConferenceSingleUserView *obj, NSUInteger idx, BOOL * _Nonnull stop) {
        CGFloat leftOffset;
        CGFloat topOffset;
        if (self.userViewArray.count > 4) {
            topOffset = (idx + 1) /3 *width;
            leftOffset = (2- (idx + 1) % 3) *width;
        }else{
            topOffset = idx /2 *width;
            leftOffset = (1- (idx + 1) % 2) *width;
        }
        
        
        [obj mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(width, width));
            make.left.equalTo(self).offset(leftOffset);
            make.top.equalTo(self).offset(topOffset);
        }];
    }];
}

- (void)completionHandler:(int)error obj:(NSObject*)obj {
//    if (!obj &&
//        (error == KDSTATUS_ICE_DISCONNECTED ||
//                 error == KDSTATUS_ICE_FAILED ||
//                 error == KDSTATUS_NM_LINK_FAILED)) {
//        dispatch_async(dispatch_get_main_queue(), ^{
//            [SVProgressHUD showErrorWithStatus:@"网络连接失败，请重新连接"];
//        });
//
//    }
    switch (error) {
        case KDSTATUS_ICE_CONNECTED:
            NSLog(@"——————————————————————ICE连接成功");
            if (error == KDSTATUS_VIDEO_RECV_SUCCESS || error == KDSTATUS_AUDIO_RECV_SUCCESS) {
                    NSLog(@"——————————————————————码流接受成功%@",obj);
                for (KDConferenceSingleUserView *userView in self.userViewArray) {
                    if ([userView.userModel.userCodeDomain isEqualToString:(NSString *)obj] && userView.state != MultiState_Accept) {
                        userView.state = MultiState_Accept;
                        break;
                    }
                }
            } else if (error == KDSTATUS_VIDEO_RECV_FAILED || error == KDSTATUS_AUDIO_RECV_FAILED){
                    NSLog(@"——————————————————————码流接受失败%@",obj);
            }
            break;
        case KDSTATUS_ICE_DISCONNECTED:
            NSLog(@"——————————————————————ICE断开连接");
            break;
        default:
            NSLog(@"——————————————————————ICE连接失败");
            break;
    }
}

- (void)addUser:(NSString *)userCode
{
    
}

- (void)stopConference:(BOOL)isVoice
{
    KDConferenceStopReq *stopReq = [[KDConferenceStopReq alloc]init];
    stopReq.mediaType = isVoice ? 1 : 0;
    [self.kdsdkapi stopConference:stopReq];
    [KDRTCSDKApi destroy];
}

- (void)changeCamera
{
    [self.kdsdkapi switchCamera:^(NSError *err) {
        NSLog(@"switchCamera %@", err);
//        dispatch_async(dispatch_get_main_queue(), ^(void) {
//          sender.enabled = true;
//        });
    }];
}

- (void)changeSpeakerWithSelected:(BOOL )selected
{
    if (selected) {
        [self.kdsdkapi setAudioSession:AVAudioSessionPortOverrideSpeaker shouldChangeRouteWithCompletion:^{
        }];
    }else{
        [self.kdsdkapi setAudioSession:AVAudioSessionPortOverrideNone shouldChangeRouteWithCompletion:^{
        }];
    }
    
}


- (void)openOrCloseCamera:(BOOL)isClose
{
    if (!isClose) {
        [self.kdsdkapi startCamera:^(NSError *error) {
            NSLog(@"%@",error);
        }];
    } else {
        [self.kdsdkapi stopCamera];
    }
    [self refreshConferenceUserView:@[[KDConfigManager sharedInstance].userCodeDomain] state:MultiState_Other isClose:isClose];
}

- (void)setMute:(BOOL)enable {
    [self.kdsdkapi enableAudioMic:enable];
}

-(KDConferenceStartReq *)conferenceStartReq {
    if (!_conferenceStartReq) {
        _conferenceStartReq = [[KDConferenceStartReq alloc]init];
    }
    return _conferenceStartReq;
}

@end
