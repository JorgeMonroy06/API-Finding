//
//  KDConferenceMemberCollectionView.h
//  KDVLine_Example
//
//  Created by samuel on 2021/5/19.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KDConferenceMemberCollectionView : UIView
//
//@property (nonatomic, strong) KDMessageModel *message;
- (instancetype)initWithUserModel:(NSMutableArray *)userArray;
-(void)addInviteMemberData:(NSMutableArray *) userArray;
@end

NS_ASSUME_NONNULL_END
