//
//  SxtToast.h
//  flutter_sxt_ui_plugin
//
//  Created by xzc on 2021/8/13.
//

#import <Foundation/Foundation.h>
@interface SxtToast : NSObject
+(void)showInfo:(NSString *)info;
@end
