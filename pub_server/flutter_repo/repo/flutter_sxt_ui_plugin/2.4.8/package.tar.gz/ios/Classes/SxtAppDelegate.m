//
//  SxtAppDelegate.m
//  Runner
//
//  Created by xzc on 2021/6/18.
//

#import "SxtAppDelegate.h"
#import "KDInvitView.h"
#import "KDSXTChannelMethod.h"
#import "SxtConfigConstant.h"
#import "SxtConversationModel.h"
#import "SxtGroupHandle.h"
#import "KDConferenceMainView.h"
#import "SxtConstant.h"
#import "SxtFlutterToNativeNotification.h"
#import "SxtConversationHandle.h"
@interface SxtAppDelegate ()<KDVideoHandleDelegate,FlutterStreamHandler>
@property (nonatomic, strong) KDSXTChannelMethod *channel;
@property (nonatomic, strong) KDVideoHandle *videoHandle;
@property (nonatomic, copy) FlutterEventSink events; //推送点击通知，可以用此block回调
@end
@implementation SxtAppDelegate

//单利方法
+ (instancetype)shareInstance {
   //注意下面这行代码直接写在这里就可以，不用担心多次调用出问题；1.static id instance = nil;只是编一阶段的初始值，真正赋值后就是一个唯一的值 2. onceToken地址没有被释放就不会再次进入dispatch_once函数
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[super allocWithZone:NULL] init];
    });
    return instance;
}

//alloc new 方式创建实例最终都会执行这个方法
+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    return [[self class] shareInstance];
}
//copy mutableCopy 方式创建实例最终都会执行这个方法
- (instancetype)copyWithZone:(struct _NSZone *)zone{
    return [[self class] shareInstance];
}

-(void)registerSxtAppDelegate:(UIApplication *)application appDelegate:(FlutterAppDelegate *)appDelegate {
    self.videoHandle = [[KDVideoHandle alloc] init];
    self.videoHandle.delegate = self;
    [self.channel registerChannelMethodWithController];
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    NSLog(@"\n ===> 程序进入前台 !");
}

- (void)applicationWillResignActive:(UIApplication *)application {
    [[NSNotificationCenter defaultCenter]postNotificationName:FlutterToNative_Notification_AllUnreadCount object:nil];
    KDAccountHandle *channel = [[KDAccountHandle alloc] init];
    [channel updateAppStatus:KDAppRunStatus_Background];
    NSLog(@"\n ===> 程序暂行 !");
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
     NSLog(@"\n ===> 程序进入后台 !");
    [UIApplication sharedApplication].applicationIconBadgeNumber = [KDConversationHandle getAllConversationUnreadCount];
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    if (![KDConfigManager sharedInstance].isLogin) {
        return;
    }
    KDAccountHandle *channel = [[KDAccountHandle alloc] init];
    [channel updateAppStatus:KDAppRunStatus_Foreground];
    NSLog(@"\n ===> 程序重新激活 !");
      
}

- (void)videoHandle:(KDVideoHandle *)videoHandle listenVideoEventWithMessageModel:(KDMessageModel *)messageModel
{
    [self jumpControllerWithMessage:messageModel];
}

//在聊天页面，多方会议结束
- (void)videoHandle:(KDVideoHandle *)videoHandle ConferenceDidFInishWithMessageModel:(KDMessageModel *)messageModel {
    NSLog(@"ConferenceDidFInishWithMessageModel");
    if (messageModel.videoChatStatus == KDVideoChatStatus_Fininsh &&
        messageModel.messageType == KDMessageType_Muti_Media) {
        [self nativeToFlutterWithMethodName:STOP_MULTI_MEETING arguments:nil result:^(id  _Nullable result) {}];
    }
}

-(void)jumpControllerWithMessage:(KDMessageModel *)messageModel {
    if (![KDConfigManager sharedInstance].isLogin) {
        self.pushMsg = messageModel;
        return;
    }
    if (messageModel.messageType == KDMessageType_Muti_Media) {
        KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)messageModel.contentAttachment;
        if (mediaAttachment.singleType == KDSingleType_Invite) {
            if (messageModel.chatType == KDChatType_Group) {
                [[SxtAppDelegate shareInstance]nativeToFlutterWithMethodName:START_VIDEO_CALLING arguments:nil result:nil];
                __block BOOL isExistSelf = NO;
                [mediaAttachment.users enumerateObjectsUsingBlock:^(NSString *obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    if ([obj isEqualToString:[KDConfigManager sharedInstance].userCodeDomain]) {
                        isExistSelf = YES;
                        *stop = YES;
                    }
                }];
                if (isExistSelf && !self.conferenceMainView) {
                    KDConferenceMainView *conferenceMainView = [[KDConferenceMainView alloc]initConferenceMainViewWithMessage:messageModel showType:(mediaAttachment.isOpenCamera ? KDVLineRTCShowType_Video_Passive : KDVLineRTCShowType_Voice_Passive) groupCode:messageModel.chatType == KDChatType_Group ? messageModel.receiver : nil];
                    __weak typeof(self)weakSelf = self;
                    conferenceMainView.dismissBlock = ^{
                        weakSelf.conferenceMainView = nil;
                    };
                    [conferenceMainView show];
                    self.conferenceMainView = conferenceMainView;
                }

            } else {
                if ([messageModel.receiver isEqualToString:[KDConfigManager sharedInstance].userCodeDomain] && !self.invitView) {
                    __weak typeof(self)weakSelf = self;
                    [[SxtAppDelegate shareInstance]nativeToFlutterWithMethodName:START_VIDEO_CALLING arguments:nil result:nil];
                    KDInvitView *invitView = [[KDInvitView alloc] initInitViewWithMessage:messageModel showType:(mediaAttachment.isOpenCamera ? KDVLineRTCShowType_Video_Passive : KDVLineRTCShowType_Voice_Passive)];
                    [invitView show];
                    invitView.dismissBlock = ^{
                        weakSelf.invitView = nil;
                    };
                    self.invitView = invitView;
                }
            }
        }
    } else {
        SxtSessionEntity *sender = [[SxtSessionEntity alloc]init];
        sender.code = messageModel.sender;
        sender.sessionType = [SxtEnumType getNewSessionType:messageModel.chatType];
        [self nativeToFlutterWithMethodName:GO_TO_CHAT_PAGE arguments:[sender modelToJSONObject] result:nil];
    }
}

-(void)nativeToFlutterWithMethodName:(NSString *)methodName arguments:(id)arguments result:(FlutterResult _Nullable)callback {
    UIViewController *controller = self.rootViewController;
    FlutterJSONMethodCodec *flutterToNativeCodec = [[FlutterJSONMethodCodec alloc] init];
    FlutterMethodChannel* flutterToNativeChannel = [FlutterMethodChannel methodChannelWithName:NATIVE_TO_FLUTTER_CHANNEL binaryMessenger:controller codec:flutterToNativeCodec];
    [flutterToNativeChannel invokeMethod:methodName arguments:arguments result:callback];
}

-(UIViewController *)rootViewController {
    UIViewController *rootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
    if (rootVC == nil) {
        NSArray *windows = [UIApplication sharedApplication].windows;
        if (windows.count) {
            UIWindow *window = windows.firstObject;
            return window.rootViewController;
        }
    }
    return rootVC;
}

-(KDSXTChannelMethod *)channel {
    if (!_channel) {
        _channel = [[KDSXTChannelMethod alloc] init];
    }
    return _channel;
}

@end
