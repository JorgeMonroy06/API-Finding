//
//  KDAudioCallView.h
//  KDVLine_Example
//
//  Created by samuel on 2021/3/31.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KDRTCContactModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface KDAudioCallView : UIView

@property (nonatomic, strong) KDRTCContactModel *contactModel;
- (instancetype)initWidthDismissBlock:(void (^)(void))dismissBlock;
/// 开始音频通话
- (void)startAudio;

/// 结束音频通话
- (void)stop;

/// 扬声器切换
/// @param selected 是否选中
- (void)changeSpeakerWithSelected:(BOOL )selected;

-(void)enableAudioMic:(BOOL)enable;
@end

NS_ASSUME_NONNULL_END
