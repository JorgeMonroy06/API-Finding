//
//  LiveView.m
//  kdrtcapidemo
//
//  Created by mac on 2021/1/5.
//

#import <Foundation/Foundation.h>
#import "LiveView.h"
#import "RTCSDK/KDRTCSDKApi.h"
#import "RTCSDK/KDVideoAudioReqParams.h"
#import "RTCSDK/KDStatusEvent.h"
#import "RTCSDK/ErrorCode.h"
#import "UIImage+ARDUtilities.h"

#import "WebRTC/RTCDispatcher.h"
#import "WebRTC/RTCAudioSession.h"

#import "WebRTC/RTCEAGLVideoView.h"
#if defined(RTC_SUPPORTS_METAL)
#import "WebRTC/RTCMTLVideoView.h"  // nogncheck
#endif

static CGFloat const kButtonPadding = 16;
static CGFloat const kButtonSize = 48;
static CGFloat const kLocalVideoViewSize = 120;
static CGFloat const kLocalVideoViewPadding = 8;

@interface LiveView () <RTC_OBJC_TYPE (RTCVideoViewDelegate), FunctionDelegate>

@property(nonatomic, assign) AVAudioSessionPortOverride portOverride;
@end

@implementation LiveView{
    CGSize _remoteVideoSize;
    NSString* _caller;
    NSString* _callee;
    NSString* _deviceid;
    NSString* _nmIp;
    NSString* _nmPort;
    NSString* _stunIp;
    NSString* _stunPort;
    
    KDRTCSDKApi* _kdsdkapi;
    NSString* _liveRequestId;
    
    UIButton *_routeChangeButton;
    UIButton *_cameraSwitchButton;
    UIButton *_hangupButton;
}

@synthesize statusLabel = _statusLabel;
@synthesize localVideoView = _localVideoView;
@synthesize remoteVideoView = _remoteVideoView;
@synthesize callDelegate = _callDelegate;
@synthesize portOverride = _portOverride;

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {

  #if defined(RTC_SUPPORTS_METAL)
      _remoteVideoView = [[RTC_OBJC_TYPE(RTCMTLVideoView) alloc] initWithFrame:CGRectZero];
  #else
      RTC_OBJC_TYPE(RTCEAGLVideoView) *remoteView =
          [[RTC_OBJC_TYPE(RTCEAGLVideoView) alloc] initWithFrame:CGRectZero];
      remoteView.delegate = self;
      _remoteVideoView = remoteView;
  #endif

      [self addSubview:_remoteVideoView];

      _localVideoView = [[RTC_OBJC_TYPE(RTCCameraPreviewView) alloc] initWithFrame:CGRectZero];
      [self addSubview:_localVideoView];
        
    _routeChangeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _routeChangeButton.backgroundColor = [UIColor grayColor];
    _routeChangeButton.layer.cornerRadius = kButtonSize / 2;
    _routeChangeButton.layer.masksToBounds = YES;
    UIImage *image = [UIImage imageForName:@"ic_surround_sound_black_24dp.png"
                                     color:[UIColor whiteColor]];
    [_routeChangeButton setImage:image forState:UIControlStateNormal];
    [_routeChangeButton addTarget:self
                           action:@selector(onRouteChange:)
                 forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_routeChangeButton];

    // TODO(tkchin): don't display this if we can't actually do camera switch.
    _cameraSwitchButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _cameraSwitchButton.backgroundColor = [UIColor grayColor];
    _cameraSwitchButton.layer.cornerRadius = kButtonSize / 2;
    _cameraSwitchButton.layer.masksToBounds = YES;
    image = [UIImage imageForName:@"ic_switch_video_black_24dp.png" color:[UIColor whiteColor]];
    [_cameraSwitchButton setImage:image forState:UIControlStateNormal];
    [_cameraSwitchButton addTarget:self
                      action:@selector(onCameraSwitch:)
            forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_cameraSwitchButton];

    _hangupButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _hangupButton.backgroundColor = [UIColor redColor];
    _hangupButton.layer.cornerRadius = kButtonSize / 2;
    _hangupButton.layer.masksToBounds = YES;
    image = [UIImage imageForName:@"ic_call_end_black_24dp.png"
                            color:[UIColor whiteColor]];
    [_hangupButton setImage:image forState:UIControlStateNormal];
    [_hangupButton addTarget:self
                      action:@selector(onHangup:)
            forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_hangupButton];
        
  }
  return self;
}


- (void)start:(NSString *)caller callee:(NSString *)callee deviceid:(NSString *)deviceid
         nmIp:(NSString*)nmIp nmPort:(NSString*)nmPort
         stunIp:(NSString*)stunIp stunPort:(NSString*)stunPort{
    _caller = caller;
    _callee = callee;
    _deviceid = deviceid;
    
    _nmIp = nmIp;
    _nmPort = nmPort;
    _stunIp = stunIp;
    _stunPort = stunPort;
    
    KDLiveReqParams* params = [[KDLiveReqParams alloc] init];
    params.calleeId = _callee;
    params.resourceId = _deviceid;
    params.remoteVideoView = _remoteVideoView;
    params.fakeRender = [FakeVideoRender new];
    params.shouldGetStats = YES;
//    params.resolutionType = Resolusion720P;
    if (_stunPort.length > 0) {
        params.stunUrl = [[NSString alloc] initWithFormat:@"%@:%@", _stunIp, _stunPort];
    }
    
    _kdsdkapi = [KDRTCSDKApi getInstance];
    _liveRequestId = [_kdsdkapi startLive:params callback:self];
}

- (void)onStopVideoCall:(id)sender {
    [_kdsdkapi stopLive:_liveRequestId];
    [KDRTCSDKApi destroy];
}

- (void)stop{
    [_kdsdkapi stopLive:_liveRequestId];
    [KDRTCSDKApi destroy];
}



- (void)layoutSubviews {
  CGRect bounds = self.bounds;
    
  if (_remoteVideoSize.width > 0 && _remoteVideoSize.height > 0) {
    // Aspect fill remote video into bounds.
    CGRect remoteVideoFrame =
        AVMakeRectWithAspectRatioInsideRect(_remoteVideoSize, bounds);
    CGFloat scale = 1;
    if (remoteVideoFrame.size.width > remoteVideoFrame.size.height) {
      // Scale by height.
      scale = bounds.size.height / remoteVideoFrame.size.height;
    } else {
      // Scale by width.
      scale = bounds.size.width / remoteVideoFrame.size.width;
    }
    remoteVideoFrame.size.height *= scale;
    remoteVideoFrame.size.width *= scale;
    _remoteVideoView.frame = remoteVideoFrame;
    _remoteVideoView.center =
        CGPointMake(CGRectGetMidX(bounds), CGRectGetMidY(bounds));
  } else {
    _remoteVideoView.frame = bounds;
  }

  // Aspect fit local video view into a square box.
  CGRect localVideoFrame =
      CGRectMake(0, 0, kLocalVideoViewSize, kLocalVideoViewSize);
  // Place the view in the bottom right.
  localVideoFrame.origin.x = CGRectGetMaxX(bounds)
      - localVideoFrame.size.width - kLocalVideoViewPadding;
  localVideoFrame.origin.y = CGRectGetMaxY(bounds)
      - localVideoFrame.size.height - kLocalVideoViewPadding;
  _localVideoView.frame = localVideoFrame;
  self.backgroundColor = [UIColor blackColor];
    
    // Place hangup button in the bottom left.
    _hangupButton.frame =
        CGRectMake(CGRectGetMinX(bounds) + kButtonPadding,
                   CGRectGetMaxY(bounds) - kButtonPadding -
                       kButtonSize,
                   kButtonSize,
                   kButtonSize);

    // Place button to the right of hangup button.
    CGRect cameraSwitchFrame = _hangupButton.frame;
    cameraSwitchFrame.origin.x =
        CGRectGetMaxX(cameraSwitchFrame) + kButtonPadding;
    _cameraSwitchButton.frame = cameraSwitchFrame;

    // Place route button to the right of camera button.
    CGRect routeChangeFrame = _cameraSwitchButton.frame;
    routeChangeFrame.origin.x =
        CGRectGetMaxX(routeChangeFrame) + kButtonPadding;
    _routeChangeButton.frame = routeChangeFrame;
    
}






#pragma mark - RTC_OBJC_TYPE(RTCVideoViewDelegate)

- (void)videoView:(id<RTC_OBJC_TYPE(RTCVideoRenderer)>)videoView didChangeVideoSize:(CGSize)size {
  if (videoView == _remoteVideoView) {
    _remoteVideoSize = size;
  }
  [self setNeedsLayout];
}

- (void)completionHandler:(int)error obj:(NSObject*)obj {
    NSLog(@"startVideoCall err:%d", error);
    if (error == KDSTATUS_ICE_CONNECTED) {
        [_callDelegate onMessage:@"successful"];
    } else{
        [_callDelegate onMessage:@"failed"];
    }
    
}

#pragma mark - Private

- (void)onCameraSwitch:(UIButton *)sender {
    sender.enabled = false;
    [_kdsdkapi switchCamera:^(NSError *err) {
        NSLog(@"switchCamera %@", err);
        dispatch_async(dispatch_get_main_queue(), ^(void) {
          sender.enabled = true;
        });
    }];
 
}

- (void)onRouteChange:(UIButton *)sender {
    sender.enabled = false;
    if (_portOverride == AVAudioSessionPortOverrideNone) {
        _portOverride = AVAudioSessionPortOverrideSpeaker;
    }else{
        _portOverride = AVAudioSessionPortOverrideNone;
    }
    [_kdsdkapi setAudioSession:_portOverride shouldChangeRouteWithCompletion:^{
        dispatch_async(dispatch_get_main_queue(), ^(void) {
          sender.enabled = true;
        });
    }];
}

- (void)onHangup:(id)sender {
    [self stop];
    [_callDelegate onFinished];
}


#pragma mark alert





@end
