//
//  KDSXTChannelMethod.m
//  Runner
//
//  Created by samuel on 2021/4/28.
//

#import "KDSXTChannelMethod.h"
#import "KDInvitView.h"
#import "SxtConfigConstant.h"
#import <sxt_flutter_plugin/SxtGroupHandle.h>
#import "KDConferenceMainView.h"
#import "SxtConstant.h"
#import "SxtUserModel.h"
#import "SxtAppDelegate.h"
#import "SxtConversationModel.h"
#import <KDWebRTC/KDWebRTC.h>
#import "SxtPttChatManager.h"
@interface KDSXTChannelMethod()<FlutterStreamHandler>
@property (nonatomic, strong) KDVideoHandle *videoHandle;
@end


@implementation KDSXTChannelMethod

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.videoHandle = [[KDVideoHandle alloc] init];
    }
    return self;
}

-(void)dealloc{
    NSLog(@"dealloc");
}

- (void)registerChannelEventWithController {
    UIViewController *controller = (FlutterViewController*)[SxtAppDelegate shareInstance].rootViewController;
    FlutterJSONMethodCodec *flutterToNativeCodec = [[FlutterJSONMethodCodec alloc] init];
    FlutterMethodChannel* flutterToNativeChannel = [FlutterMethodChannel methodChannelWithName:NATIVE_TO_FLUTTER_CHANNEL binaryMessenger:controller codec:flutterToNativeCodec];
    [flutterToNativeChannel invokeMethod:LOGIN arguments:nil];
}

- (void)registerChannelMethodWithController
{
    UIViewController *controller = (FlutterViewController*)[SxtAppDelegate shareInstance].rootViewController;
    FlutterJSONMethodCodec *flutterToNativeCodec = [[FlutterJSONMethodCodec alloc] init];
    FlutterMethodChannel* flutterToNativeChannel = [FlutterMethodChannel methodChannelWithName:FLUTTER_TO_NATIVE_CHANNEL binaryMessenger:controller codec:flutterToNativeCodec];
    [flutterToNativeChannel setMethodCallHandler:^(FlutterMethodCall* call, FlutterResult result) {
      NSLog(@"非桥接层参数：%@",call.arguments);
      if ([START_VOICE_CALL isEqualToString:call.method]) {//发起音频
          SxtUserModel *userModel = [SxtUserModel modelWithDictionary:call.arguments];
          KDVideoModel *videoModel = [[KDVideoModel alloc] init];
          NSString *code = userModel.code;
          if (![code containsString:@"@"]) {
              code = [NSString stringWithFormat:@"%@@%@",userModel.code,userModel.originCode];
          }
          videoModel.code = code;
          videoModel.chatType = KDChatType_User;
          videoModel.roomType = KDRoomType_MutiVideo;
          videoModel.cameraOpen = NO;//视频聊天
          videoModel.userArray = [NSArray arrayWithObject:code];
          [self.videoHandle startVideoWithVideoModel:videoModel Completion:^(BOOL success, KDMessageModel * _Nonnull message) {
              if (success) {
                  KDInvitView *invitView = [[KDInvitView alloc] initInitViewWithMessage:message showType:KDVLineRTCShowType_Voice_Active];
                  [invitView show];
              }
              result(@(success));
          }];
      }else if([START_VIDEO_CALL isEqualToString:call.method]){//发起视频
          SxtUserModel *userModel = [SxtUserModel modelWithDictionary:call.arguments];
          KDVideoModel *videoModel = [[KDVideoModel alloc] init];
          NSString *code = userModel.code;
          if (![code containsString:@"@"]) {
              code = [NSString stringWithFormat:@"%@@%@",userModel.code,userModel.originCode];
          }
          videoModel.code = code;
          videoModel.userArray = [NSArray arrayWithObject:code];
          videoModel.chatType = KDChatType_User;
          videoModel.roomType = KDRoomType_MutiVideo;
          videoModel.cameraOpen = YES;//视频聊天
          [self.videoHandle startVideoWithVideoModel:videoModel Completion:^(BOOL success, KDMessageModel * _Nonnull message) {
              if (success) {
                  KDInvitView *invitView = [[KDInvitView alloc] initInitViewWithMessage:message showType:KDVLineRTCShowType_Video_Active];
                  [invitView show];
              }
              result(@(success));
          }];
      }else if([START_MULTI_VIDEO_CALL isEqualToString:call.method]){//发起多方视频会议
          NSDictionary *groupDic = (NSDictionary *)call.arguments;
          SxtGroupModel *group = [SxtGroupModel modelWithDictionary:groupDic[@"group"]];
          NSMutableArray *userArray = [NSMutableArray array];
          for (NSDictionary *dic in groupDic[@"contactList"]) {
              SxtUserModel *userModel = [SxtUserModel modelWithDictionary:dic];
              if (userModel.code.length > 0) {
                  [userArray addObject:[NSString stringWithFormat:@"%@@%@",userModel.code,userModel.originCode]];
              } else {
                  NSLog(@"参加音视频会议的用户code为空");
              }
          }
          [userArray addObject:[KDConfigManager sharedInstance].userCodeDomain];
          [self addKDConferenceMainView:group.groupCode userCodeList:userArray isCameraOpen:YES isJoin:NO callHandler:result];
      }else if([START_MULTI_VOICE_CALL isEqualToString:call.method]){//发起多方音频会议
          NSDictionary *groupDic = (NSDictionary *)call.arguments;
          SxtGroupModel *group = [SxtGroupModel modelWithDictionary:groupDic[@"group"]];
          NSMutableArray *userArray = [NSMutableArray array];
          for (NSDictionary *dic in groupDic[@"contactList"]) {
              SxtUserModel *userModel = [SxtUserModel modelWithDictionary:dic];
              if (userModel.code.length > 0) {
                  [userArray addObject:[NSString stringWithFormat:@"%@@%@",userModel.code,userModel.originCode]];
              } else {
                  NSLog(@"参加音视频会议的用户code为空");
              }
          }
          [userArray addObject:[KDConfigManager sharedInstance].userCodeDomain];
          [self addKDConferenceMainView:group.groupCode userCodeList:userArray isCameraOpen:NO isJoin:NO callHandler:result];
      }else if([REQUEST_FLOAT_WINDOW_PERMISSION isEqualToString:call.method]){//请求悬浮桌面权限
          
      }else if([GO_TO_DESKTOP isEqualToString:call.method]){//去桌面

      }else if ([SET_SPEAKER_PHONE_ON isEqualToString:call.method]) {
          //ppt设置扬声器
          BOOL isOnSpeaker = [call.arguments boolValue];
          [[SxtPttChatManager sharedInstance]setAudioSpeaker:isOnSpeaker?AVAudioSessionPortOverrideSpeaker:AVAudioSessionPortOverrideNone];
      }else if([SDK_METHOD_AllOW_GO_TO_CHAT_PAGE isEqualToString:call.method] && [SxtAppDelegate shareInstance].pushMsg){//跳转到具体的消息页面
          [[SxtAppDelegate shareInstance]jumpControllerWithMessage:[SxtAppDelegate shareInstance].pushMsg];
          [SxtAppDelegate shareInstance].pushMsg = nil;
      }else if([GET_CONTACT_AVATAR_BASE_URL isEqualToString:call.method]){
          
      }else if([GET_CONTACTS isEqualToString:call.method]){
          NSLog(@"******GET_CONTACTS");
      }else if([GET_MULTI_MEETING_INFO isEqualToString:call.method]){
          __weak typeof(self)weakSelf = self;
          [self.videoHandle queryGroupResumeGroup:call.arguments Completion:^(int resultInfo, NSArray<KDVideoRoomInfoModel *> * _Nonnull roomInfoArray) {
              KDVideoRoomInfoModel *videoRoomInfoModel = roomInfoArray.firstObject;
              if (!videoRoomInfoModel || videoRoomInfoModel.roomType != KDRoomType_MutiVideo) {
                  result(nil);
                  return;
              }
              if (videoRoomInfoModel.room.length > 0) {
                  [weakSelf.videoHandle queryRoomDetailWithRoom:videoRoomInfoModel.room Completion:^(int resultValue, NSArray<KDVideoRoomInfoModel *> * _Nonnull roomInfoArray) {
                      KDVideoRoomInfoModel *videoRoomInfoModel = roomInfoArray.firstObject;
                      result([weakSelf videoRoomInfo:videoRoomInfoModel groupCode:call.arguments]);
                  }];
              } else {
                  result([weakSelf videoRoomInfo:videoRoomInfoModel groupCode:call.arguments]);
              }
          }];

          
      }else if([RETURN_MULTI_CALL isEqualToString:call.method] && [SxtAppDelegate shareInstance].conferenceMainView){
          NSLog(@"******RETURN_MULTI_CALL");
          if ([call.arguments isKindOfClass:[NSDictionary class]]) {
              NSDictionary *dic = (NSDictionary *)call.arguments;
              [[SxtAppDelegate shareInstance].conferenceMainView refreshConferenceView:[dic objectForKey:@"contactList"]];
          }
      }else if([BACK_TO_MULTI_CALL isEqualToString:call.method]){
          //点击多方会议上面的一条
          NSLog(@"******BACK_TO_MULTI_CALL");
          if ([SxtAppDelegate shareInstance].conferenceMainView) {
              [[SxtAppDelegate shareInstance].conferenceMainView expandInvitViewEvent];
          } else {
              __weak typeof(self)weakSelf = self;
              if ([call.arguments isKindOfClass:[NSDictionary class]]) {
                  NSDictionary *dic = (NSDictionary *)call.arguments;
                  NSString *room = dic[@"room"];
                  NSString *groupCode = dic[@"groupCode"];
                  if (room.length) {
                      [self.videoHandle queryRoomDetailWithRoom:room Completion:^(int resultValue, NSArray<KDVideoRoomInfoModel *> * _Nonnull roomInfoArray) {
                          KDVideoRoomInfoModel *videoRoomInfoModel = roomInfoArray.firstObject;
                          NSMutableArray *userCodeList = [NSMutableArray array];
                          for (KDVideoMemberInfoModel *memberInfoModel in videoRoomInfoModel.members) {
                              [userCodeList addObject:memberInfoModel.code];
                          }
                          [weakSelf addKDConferenceDetailMainView:groupCode userCodeList:userCodeList isCameraOpen:videoRoomInfoModel.isOpenCamera isJoin:YES resourceId:videoRoomInfoModel.resourceId room:videoRoomInfoModel.room callHandler:result];
                      }];
                  } else {
                      [self.videoHandle queryGroupResumeGroup:call.arguments Completion:^(int resultInfo, NSArray<KDVideoRoomInfoModel *> * _Nonnull roomInfoArray) {
                          NSLog(@"%@",roomInfoArray);
                          __block KDVideoRoomInfoModel *videoRoomInfoModel = roomInfoArray.firstObject;
                          [weakSelf.videoHandle queryRoomDetailWithRoom:videoRoomInfoModel.room Completion:^(int resultValue, NSArray<KDVideoRoomInfoModel *> * _Nonnull roomInfoArray) {
                              videoRoomInfoModel = roomInfoArray.firstObject;
                              NSMutableArray *userCodeList = [NSMutableArray array];
                              for (KDVideoMemberInfoModel *memberInfoModel in videoRoomInfoModel.members) {
                                  [userCodeList addObject:memberInfoModel.code];
                              }
                              [weakSelf addKDConferenceDetailMainView:groupCode userCodeList:userCodeList isCameraOpen:videoRoomInfoModel.isOpenCamera isJoin:YES  resourceId:videoRoomInfoModel.resourceId room:videoRoomInfoModel.room callHandler:result];
                          }];
                      }];
                  }
              }
          }
      }
      else {
        result(FlutterMethodNotImplemented);
      }
    }];
}

-(NSMutableDictionary *)videoRoomInfo:(KDVideoRoomInfoModel *)videoRoomInfoModel groupCode:(NSString *)groupCode {
    BOOL isHasOwn = false;
    for (KDVideoMemberInfoModel *model in videoRoomInfoModel.members) {
        if ([[KDConfigManager sharedInstance].userCodeDomain containsString:model.code]) {
            isHasOwn = YES;
        }
    }
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    if (isHasOwn) {
        if (![videoRoomInfoModel.anchor isEqualToString:[KDConfigManager sharedInstance].userCodeDomain]) {
            [dic setValue:videoRoomInfoModel.anchor forKey:@"code"];
        }
        [dic setValue:groupCode forKey:@"groupCode"];
        [dic setValue:videoRoomInfoModel.room.length > 0 ? videoRoomInfoModel.room : @"" forKey:@"room"];
        [dic setValue:@(videoRoomInfoModel.isOpenCamera) forKey:@"isVideo"];
        [dic setValue:@([KDConfigManager sharedInstance].isVideoOnline) forKey:@"isCalling"];
    }
    return dic;
}

-(void)addKDConferenceMainView:(NSString *)groupCode
                  userCodeList:(NSArray *)userCodeList
                    isCameraOpen:(BOOL)isCameraOpen
                    isJoin:(BOOL)isJoin
                   callHandler:(FlutterResult) result {
    [self addKDConferenceDetailMainView:groupCode userCodeList:userCodeList isCameraOpen:isCameraOpen isJoin:isJoin resourceId:nil room:nil callHandler:result];
}

-(void)addKDConferenceDetailMainView:(NSString *)groupCode
                  userCodeList:(NSArray *)userCodeList
                    isCameraOpen:(BOOL)isCameraOpen
                    isJoin:(BOOL)isJoin
                    resourceId:(NSString *)resourceId
                    room:(NSString *)room
                   callHandler:(FlutterResult) result {
    
    KDVideoModel *videoModel = [[KDVideoModel alloc] init];
    videoModel.code = groupCode;
    videoModel.chatType = KDChatType_Group;
    videoModel.roomType = KDRoomType_MutiVideo;
    videoModel.cameraOpen = isCameraOpen;
    videoModel.userArray = userCodeList;
    if (isJoin) {
        KDMessageModel *message = [[KDMessageModel alloc]init];
        message.chatType = KDChatType_Group;
        message.messageType = KDMessageType_Muti_Media;
        KDMutiMediaAttachment *attachment = [[KDMutiMediaAttachment alloc]init];
        attachment.users = userCodeList;
        attachment.isOpenCamera = isCameraOpen;
        attachment.resourceId = resourceId;
        attachment.room = room;
        message.contentAttachment = attachment;
        [self.videoHandle joinMeetingWithRoom:room];
        KDConferenceMainView *conferenceMainView = [[KDConferenceMainView alloc] initConferenceMainViewWithMessage:message showType:isCameraOpen ? KDVLineRTCShowType_Video_Active:KDVLineRTCShowType_Voice_Active isJoin:isJoin groupCode:groupCode];
        [conferenceMainView show];
        conferenceMainView.dismissBlock = ^{
            [SxtAppDelegate shareInstance].conferenceMainView = nil;
        };
        [SxtAppDelegate shareInstance].conferenceMainView = conferenceMainView;
    } else {
        [self.videoHandle startVideoWithVideoModel:videoModel Completion:^(BOOL success, KDMessageModel * _Nonnull message) {
            if (success) {
                KDConferenceMainView *conferenceMainView = [[KDConferenceMainView alloc] initConferenceMainViewWithMessage:message showType:isCameraOpen ? KDVLineRTCShowType_Video_Active:KDVLineRTCShowType_Voice_Active  groupCode:groupCode];
                [conferenceMainView show];
                conferenceMainView.dismissBlock = ^{
                    [SxtAppDelegate shareInstance].conferenceMainView = nil;
                };
                [SxtAppDelegate shareInstance].conferenceMainView = conferenceMainView;
            }
            result(@(success));
        }];
    }
    
}

@end
