//
//  KDSXTChannelMethod.h
//  Runner
//
//  Created by samuel on 2021/4/28.
//

#import <Foundation/Foundation.h>
#import <Flutter/Flutter.h>

@interface KDSXTChannelMethod : NSObject

@property (nonatomic, copy) FlutterEventSink events;

- (void)registerChannelEventWithController;

- (void)registerChannelMethodWithController;

@end

