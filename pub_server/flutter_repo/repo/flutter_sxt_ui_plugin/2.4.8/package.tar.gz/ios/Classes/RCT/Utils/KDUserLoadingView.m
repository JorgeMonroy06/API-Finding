//
//  KDUserLoadingView.m
//  Runner
//
//  Created by xzc on 2021/6/15.
//

#import "KDUserLoadingView.h"
#import <Masonry/Masonry.h>
#import <SDWebImage/SDWebImage.h>
@interface KDUserLoadingView()
@property (nonatomic, strong)UIView *middleView;
@property (nonatomic, strong)UIView *leftView;
@property (nonatomic, strong)UIView *rightView;
@property (nonatomic, assign) BOOL isStop;
@end
@implementation KDUserLoadingView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        UIView *middleView = [[UIView alloc]init];
        middleView.backgroundColor = [UIColor whiteColor];
        middleView.alpha = 0.5;
        middleView.layer.cornerRadius = 3;
        middleView.clipsToBounds = YES;
        [self addSubview:middleView];
        [middleView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(self);
            make.size.mas_equalTo(CGSizeMake(6, 6));
        }];
        self.middleView = middleView;
        
        UIView *leftView = [[UIView alloc]init];
        leftView.backgroundColor = [UIColor whiteColor];
        leftView.layer.cornerRadius = 3;
        leftView.clipsToBounds = YES;
        leftView.alpha = 0.5;
        [self addSubview:leftView];
        [leftView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(middleView.mas_left).offset(-6);
            make.centerY.equalTo(middleView);
            make.size.mas_equalTo(CGSizeMake(6, 6));
        }];
        self.leftView = leftView;
        
        UIView *rightView = [[UIView alloc]init];
        rightView.backgroundColor = [UIColor whiteColor];
        rightView.layer.cornerRadius = 3;
        rightView.clipsToBounds = YES;
        rightView.alpha = 0.5;
        [self addSubview:rightView];
        [rightView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(middleView.mas_right).offset(6);
            make.centerY.equalTo(middleView);
            make.size.mas_equalTo(CGSizeMake(6, 6));
        }];
        self.rightView = rightView;
    }
    return self;
}

-(void)startLoad {
    self.hidden = NO;
    self.isStop = NO;
    [self startAnimiation];
}

-(void)startAnimiation {
    self.leftView.alpha = 1;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 0.5 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        self.leftView.alpha = 0.5;
        self.middleView.alpha = 1;
        if (self.isStop) return;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 0.5 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            self.middleView.alpha = 0.5;
            self.rightView.alpha = 1;
            if (self.isStop) return;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 0.5 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                self.rightView.alpha = 0.5;
                if (self.isStop) return;
                [self startLoad];
            });
        });
    });
}

-(void)stopLoad {
    self.isStop = YES;
    self.hidden = YES;
}

@end
