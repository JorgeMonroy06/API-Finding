//
//  KDVideoCallView.m
//  KDVLine_Example
//
//  Created by samuel on 2021/3/23.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import "KDVideoCallView.h"
#import <KDWebRTC/KDWebRTC.h>
#import "UIImage+ARDUtilities.h"
#import "SxtConfigConstant.h"
#import <Masonry/Masonry.h>
#import <SVProgressHUD/SVProgressHUD.h>

@interface KDVideoCallView()<RTC_OBJC_TYPE (RTCVideoViewDelegate),FunctionDelegate>

@property(nonatomic, strong) RTC_OBJC_TYPE(RTCCameraPreviewView) * localVideoView;
@property(nonatomic, strong) __kindof UIView<RTC_OBJC_TYPE(RTCVideoRenderer)> *remoteVideoView;

@property (nonatomic, strong) KDRTCSDKApi* kdsdkapi;

@property(nonatomic, assign) AVAudioSessionPortOverride portOverride;
@property (nonatomic,copy) void(^dismissBlock)(void);
@property (nonatomic,copy) void(^changeDirectionBlock)(SxtDeviceDirection);
@end

@implementation KDVideoCallView

//@synthesize localVideoView = _localVideoView;
//@synthesize remoteVideoView = _remoteVideoView;

- (instancetype)initWidthDismissBlock:(void (^)(void))dismissBlock changeDirectionBlock:(void (^)(SxtDeviceDirection))changeDirectionBlock
{
    self = [super init];
    if (self) {
        self.backgroundColor = [UIColor blackColor];
        [self renderView];
        self.dismissBlock = dismissBlock;
        self.changeDirectionBlock = changeDirectionBlock;
        self.portOverride = AVAudioSessionPortOverrideNone;//听筒模式
    }
    return self;
}

- (void)renderView
{
#if defined(RTC_SUPPORTS_METAL)
     self.remoteVideoView = [[RTC_OBJC_TYPE(RTCMTLVideoView) alloc] init];
#else
    RTC_OBJC_TYPE(RTCEAGLVideoView) *remoteView =
        [[RTC_OBJC_TYPE(RTCEAGLVideoView) alloc] init];
    remoteView.delegate = self;
    remoteView.clipsToBounds = YES;
    self.remoteVideoView = remoteView;
#endif
    
    [self addSubview:self.remoteVideoView];
    [self.remoteVideoView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
    
    self.localVideoView = [[RTC_OBJC_TYPE(RTCCameraPreviewView) alloc] init];
    [self addSubview:self.localVideoView];
    [self.localVideoView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self).offset(-20);
        make.top.equalTo(self).offset(TopStatuHeight+13);
        make.size.mas_equalTo(CGSizeMake(66, 123));
    }];
}

- (void)startVideo
{
//    [SVProgressHUD show];
    KDNETConfig* config = [KDNETConfig new];
    config.wsIp = self.contactModel.RTCIp;
    config.wsPort = [self.contactModel.RTCPort intValue];
    if (self.contactModel.stunIp.length > 0) {
        config.stunIp = self.contactModel.stunIp;
        config.stunPort = [self.contactModel.stunPort intValue];
    }
    [self.kdsdkapi configure:config];
    
    
    KDVideoAudioReqParams* params = [[KDVideoAudioReqParams alloc] init];
    params.callerId = self.contactModel.caller;
    params.calleeId = self.contactModel.callee;
    params.resourceId = self.contactModel.deviceid;
    params.videoType = 106;
    params.audioType = 117;
    params.shouldGetStats = false;
    params.localVideoView = self.localVideoView;
    params.remoteVideoView = self.remoteVideoView;
    params.orientation = UIDeviceOrientationPortrait;
    if (self.contactModel.stunPort.length > 0) {
        params.stunUrl = [[NSString alloc] initWithFormat:@"%@:%@", self.contactModel.stunIp, self.contactModel.stunPort];
    }
    [self.kdsdkapi startVideoCall:params callback:self];
    
}

-(void)enableAudioMic:(BOOL)enable {
    [self.kdsdkapi enableAudioMic:enable];
}

- (void)videoView:(id<RTC_OBJC_TYPE(RTCVideoRenderer)>)videoView didChangeVideoSize:(CGSize)size {
  if (videoView == self.remoteVideoView) {
      if (size.width > 0 && size.height > 0) {

        // Aspect fill remote video into bounds.
        CGRect remoteVideoFrame =
            AVMakeRectWithAspectRatioInsideRect(size, self.bounds);
//        CGFloat width = self.bounds.size.height*(remoteVideoFrame.size.width/remoteVideoFrame.size.height);
//        CGSize newSize = CGSizeMake(width, self.bounds.size.height);

        CGFloat scale = 1;
        if (remoteVideoFrame.size.width > remoteVideoFrame.size.height) {
          // Scale by height.
          scale = self.bounds.size.width / remoteVideoFrame.size.height;
        } else {
          // Scale by width.
          scale = self.bounds.size.width / remoteVideoFrame.size.width;
        }
        remoteVideoFrame.size.height *= scale;
        remoteVideoFrame.size.width *= scale;
        [self.remoteVideoView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.centerY.equalTo(self);
            make.size.mas_equalTo(remoteVideoFrame.size);
        }];

        if (size.width > size.height) {
            NSLog(@"Horizontal:%d",TopStatuHeight);
            [self.localVideoView mas_remakeConstraints:^(MASConstraintMaker *make) {
              make.right.equalTo(self).offset(-20);
              make.bottom.equalTo(self).offset(-(kBottomSafeHeight+13));
              make.size.mas_equalTo(CGSizeMake(140*1.1,79*1.1));
            }];
        }else {
            NSLog(@"Vertical:%d", TopStatuHeight);
            [self.localVideoView mas_remakeConstraints:^(MASConstraintMaker *make) {
              make.right.equalTo(self).offset(-20);
              make.top.equalTo(self).offset(TopStatuHeight+13);
              make.size.mas_equalTo(CGSizeMake(66, 123));
            }];
        }
        if (self.changeDirectionBlock) {
            self.changeDirectionBlock(size.width > size.height ? SxtDeviceDirection_Horizontal : SxtDeviceDirection_Vertical);
        }
          
//          dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
//              if (self.changeDirectionBlock) {
//                  [self.localVideoView mas_remakeConstraints:^(MASConstraintMaker *make) {
//                    make.right.equalTo(self).offset(-20);
//                    make.bottom.equalTo(self).offset(-(kBottomSafeHeight+13));
//                    make.size.mas_equalTo(CGSizeMake(79, 140));
//                  }];
//                  self.changeDirectionBlock(SxtDeviceDirection_Horizontal);
//              }
//          });
          
      } else {
          [self.remoteVideoView mas_remakeConstraints:^(MASConstraintMaker *make) {
              make.edges.equalTo(self);
          }];
      }
  }
}

- (void)onStopVideoCall:(id)sender {
    [self.kdsdkapi stopVideoCall];
    [KDRTCSDKApi destroy];
}

- (void)completionHandler:(int)error obj:(NSObject*)obj {
    //重置听筒/扬声器模式
    [self.kdsdkapi setAudioSession:self.portOverride shouldChangeRouteWithCompletion:^{
    }];
    NSLog(@"startVideoCall err:%d", error);
//    [SVProgressHUD dismiss];
    if (error == KDSTATUS_ICE_CONNECTED) {
        Log(@"successful");
    } else{
//        [SVProgressHUD showErrorWithStatus:@"视频连接失败，请重新尝试"];
//        if (self.dismissBlock) {
//            self.dismissBlock();
//        }
    }
}

- (void)changeSpeakerWithSelected:(BOOL )selected
{
    if (selected) {
        self.portOverride = AVAudioSessionPortOverrideNone;
    }else{
        self.portOverride = AVAudioSessionPortOverrideSpeaker;
    }
    [self.kdsdkapi setAudioSession:self.portOverride shouldChangeRouteWithCompletion:^{
    }];
}

- (void)stop{
    [self.kdsdkapi stopVideoCall];
    [KDRTCSDKApi destroy];
}

- (void)changeCamera
{
    [self.kdsdkapi switchCamera:^(NSError *err) {
        NSLog(@"switchCamera %@", err);
//        dispatch_async(dispatch_get_main_queue(), ^(void) {
//          sender.enabled = true;
//        });
    }];
}

- (void)changeToVoice
{
    [self.kdsdkapi stopCamera];
    self.remoteVideoView.hidden = YES;
    self.localVideoView.hidden = YES;
//    [self.remoteVideoView removeFromSuperview];
//    [self.localVideoView removeFromSuperview];
}

-(KDRTCSDKApi *)kdsdkapi {
    if (!_kdsdkapi) {
        _kdsdkapi = [KDRTCSDKApi getInstance];
    }
    return _kdsdkapi;
}

@end
