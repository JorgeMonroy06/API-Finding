//
//  KDVideoCallView.h
//  KDVLine_Example
//
//  Created by samuel on 2021/3/23.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KDRTCContactModel.h"

NS_ASSUME_NONNULL_BEGIN
typedef NS_ENUM(NSUInteger, SxtDeviceDirection) {
    SxtDeviceDirection_Vertical  = 0,
    SxtDeviceDirection_Horizontal,
};
@interface KDVideoCallView : UIView

@property (nonatomic, strong) KDRTCContactModel *contactModel;

- (instancetype)initWidthDismissBlock:(void (^)(void))dismissBlock changeDirectionBlock:(void (^)(SxtDeviceDirection))changeDirectionBlock;
- (void)startVideo;

- (void)stop;

- (void)changeCamera;

- (void)changeToVoice;

- (void)changeSpeakerWithSelected:(BOOL )selected;

-(void)enableAudioMic:(BOOL)enable;
@end

NS_ASSUME_NONNULL_END
