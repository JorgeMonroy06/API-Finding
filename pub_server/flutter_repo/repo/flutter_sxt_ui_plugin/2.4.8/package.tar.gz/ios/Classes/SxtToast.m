//
//  SxtToast.m
//  flutter_sxt_ui_plugin
//
//  Created by xzc on 2021/8/13.
//

#import "SxtToast.h"
#import <SVProgressHUD/SVProgressHUD.h>
#import "SxtConfigConstant.h"
@implementation SxtToast
+(void)showInfo:(NSString *)info {
    [SVProgressHUD setDefaultStyle:SVProgressHUDStyleDark];
    [SVProgressHUD setInfoImage:nil];
    [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 250/667*SxtScreenHeight)];
    [SVProgressHUD showInfoWithStatus:info];
}
@end
