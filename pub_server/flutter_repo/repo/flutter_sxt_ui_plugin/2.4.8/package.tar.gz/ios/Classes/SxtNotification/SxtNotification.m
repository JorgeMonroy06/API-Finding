//
//  SxtNotification.m
//  Runner
//
//  Created by xzc on 2021/6/18.
//

#import "SxtNotification.h"
#import "KDSoundAndShakeManager.h"
#import "KDUtil.h"
#import "SxtAppDelegate.h"
#import "SxtConfigConstant.h"
#import "KDConfigManager.h"
#import "KDAccountHandle.h"
#import "KDNotificationHelper.h"
#import "SxtConversationHandle.h"
@implementation SxtNotification
+ (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    if (![deviceToken isKindOfClass:[NSData class]]) return;
    const unsigned *tokenBytes = [deviceToken bytes];
    NSString *hexToken = [NSString stringWithFormat:@"%08x%08x%08x%08x%08x%08x%08x%08x",
    ntohl(tokenBytes[0]), ntohl(tokenBytes[1]), ntohl(tokenBytes[2]),
    ntohl(tokenBytes[3]), ntohl(tokenBytes[4]), ntohl(tokenBytes[5]),
    ntohl(tokenBytes[6]), ntohl(tokenBytes[7])];
    Log(@"deviceToken===========%@",hexToken);
    [KDConfigManager sharedInstance].deviceToken = hexToken;
    KDAccountHandle *channel = [[KDAccountHandle alloc] init];
    [channel updatePushToken:hexToken];
}

+(BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options
{
    if (![[KDConfigManager sharedInstance]isLogin]) {
        return NO;
    }
    NSString *urlStr = url.absoluteString;
    NSString *linkId = [KDUtil getParamByName:@"sharelinkId" URLString:urlStr];
    //TODO:linkId主动入会
    KDVideoHandle *videoHandle = [[KDVideoHandle alloc] init];
    [videoHandle startJoinActiveMeetingWithLinkId:linkId];
    return YES;
}

+ (void)replyPushNotificationAuthorization:(UIApplication *)application delegate:(id)delegate {
    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    //必须写代理，不然无法监听通知的接收与点击事件
    center.delegate = delegate;
    [center requestAuthorizationWithOptions:(UNAuthorizationOptionBadge | UNAuthorizationOptionSound | UNAuthorizationOptionAlert) completionHandler:^(BOOL granted, NSError * _Nullable error) {
        if (!error && granted) {
            //用户点击允许
            Log(@"注册成功");
        }else{
            //用户点击不允许
            Log(@"注册失败");
        }
    }];

    // 可以通过 getNotificationSettingsWithCompletionHandler 获取权限设置
    //之前注册推送服务，用户点击了同意还是不同意，以及用户之后又做了怎样的更改我们都无从得知，现在 apple 开放了这个 API，我们可以直接获取到用户的设定信息了。注意UNNotificationSettings是只读对象哦，不能直接修改！
    [center getNotificationSettingsWithCompletionHandler:^(UNNotificationSettings * _Nonnull settings) {
        Log(@"========%@",settings);
//打印结果 ========<UNNotificationSettings: 0x1740887f0; authorizationStatus: Authorized, notificationCenterSetting: Enabled, soundSetting: Enabled, badgeSetting: Enabled, lockScreenSetting: Enabled, alertSetting: NotSupported, carPlaySetting: Enabled, alertStyle: Banner>
    }];
    //注册远端消息通知获取device token
    [application registerForRemoteNotifications];

}

//iOS10 以后
// App处于前台接收到通知
+ (void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler {
    if ([UIApplication sharedApplication].applicationState == UIApplicationStateActive) {
        completionHandler(UNNotificationPresentationOptionNone);
        return;
    }
    
    if([notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        Log(@"iOS10 收到远程通知");
        if ([UIApplication sharedApplication].applicationState == UIApplicationStateActive) {
            completionHandler(UNNotificationPresentationOptionNone);
            return;
        }
    }else {
        // 判断为本地通知
        Log(@"iOS10 收到本地通知");
    }
    
    // 在前台默认不显示推送，如果要显示，就要设置以下内容
    // 微信设置里-新消息通知-微信打开时-声音or振动  就是该原理
    // 需要执行这个方法，选择是否提醒用户，有Badge、Sound、Alert三种类型可以设置
    completionHandler(UNNotificationPresentationOptionBadge|
                      UNNotificationPresentationOptionSound|
                      UNNotificationPresentationOptionAlert);

}

// 点击通知后会调用
+ (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler
{
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    KDNotificationHelper *noticHelper = [[KDNotificationHelper alloc] init];
    [noticHelper handleNotificationWithResponse:response Completion:^(KDMessageModel * _Nonnull message) {
        [[SxtAppDelegate shareInstance] jumpControllerWithMessage:message];
    }];
    // 此处必须要执行下行代码，不然会报错
    completionHandler();
}

+ (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification {
    
}
@end
