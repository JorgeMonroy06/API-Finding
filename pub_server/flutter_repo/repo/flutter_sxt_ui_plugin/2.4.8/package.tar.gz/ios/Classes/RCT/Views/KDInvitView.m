//
//  KDInvitView.m
//  Runner
//
//  Created by samuel on 2021/4/28.
//

#import "KDInvitView.h"
#import "KDVideoCallView.h"
#import "KDRTCContactModel.h"
#import <AVFoundation/AVFoundation.h>
#import "KDLocalVideoView.h"
#import "KDAudioCallView.h"
#import "KDWechatUtil.h"
#import "KDSoundAndShakeManager.h"
#import "SxtConfigConstant.h"
#import "SxtAppDelegate.h"
#import "SxtConstant.h"
#import "SxtGroupHandle.h"
#import "SxtUserModel.h"
#import "UIView+Draggable.h"
#import <Masonry/Masonry.h>
#import <SDWebImage/SDWebImage.h>
#import "KDUtil.h"
#import "SxtToast.h"
#import <Reachability/Reachability.h>
@interface KDInvitView()<KDVideoHandleDelegate,DraggingDelegate>

//@property (nonatomic, strong) KDAccountModel *account;

@property (nonatomic, weak) UIImageView *centerIconImage;

@property (nonatomic, weak) UIImageView *videoIconImage;

@property (nonatomic, weak) UILabel *centerNameLab;

@property (nonatomic, weak) UILabel *videoNameLab;

@property (nonatomic, weak) UIImageView *accountImage;

@property (nonatomic, weak) KDVideoCallView *videoCallView;

@property (nonatomic, weak) KDAudioCallView *audioCallView;

@property (nonatomic, weak) UIView *functionView;

@property (nonatomic, weak) UIView *contactFunctionView;

@property (nonatomic, strong) KDVideoHandle *videoHandle;

@property (nonatomic, weak) KDLocalVideoView *cameraPreviewView;

@property (nonatomic, assign) NSInteger timeCount;

@property (nonatomic, strong) NSTimer *timer;

@property (nonatomic, strong) KDMessageModel *message;

@property (nonatomic, assign) KDVLineRTCShowType showType;

@property (nonatomic, strong) UIView *containView;

@property (nonatomic, strong) UIButton *narrowBtn;

@property (nonatomic, strong) UIPanGestureRecognizer *panGestureRecognizer;

@property (nonatomic, strong) UILabel *changeLab;

@property (nonatomic, strong) UILabel *timeLab;

@property (nonatomic, strong) UIButton *changeBtn;

@property (nonatomic, strong) UIButton *foldBtn;

@property (nonatomic, assign) SxtDeviceDirection direction;

@property CGPoint movePoint;
@end

@implementation KDInvitView

-(UIView *)containView {
    if (!_containView) {
        _containView = [[UIView alloc]initWithFrame:self.bounds];
        _containView.tag = 100;
        [self addSubview:_containView];
    }
    return _containView;
}

-(UIButton *)narrowBtn {
    if (!_narrowBtn) {
        _narrowBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_narrowBtn setImage:[KDUtil getImage:@"KD_guaduan"] forState:UIControlStateNormal];
        [_narrowBtn addTarget:self action:@selector(expandInvitViewEvent) forControlEvents:UIControlEventTouchUpInside];
        _narrowBtn.alpha = 0;
        [self addSubview:_narrowBtn];
        [_narrowBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(self);
            make.size.mas_equalTo(CGSizeMake(52, 52));
        }];
    }
    return _narrowBtn;
}

- (instancetype )initInitViewWithMessage:(KDMessageModel *)message showType:(KDVLineRTCShowType)showType
{
    self = [super init];
    if (self) {
        [[UIApplication sharedApplication]setStatusBarHidden:YES];
        self.clipsToBounds = true;
        self.direction = SxtDeviceDirection_Vertical;
        float width = [UIScreen mainScreen].bounds.size.width;
        float height = [UIScreen mainScreen].bounds.size.height;
        self.movePoint = CGPointMake(width - 60, height - 120);
        self.draggingType = DraggingTypeDisabled;
        __weak typeof(self)weakSelf = self;
        self.delegate = weakSelf;
        self.frame = [UIScreen mainScreen].bounds;
        [UIApplication sharedApplication].idleTimerDisabled = true;
        
        [KDConfigManager sharedInstance].isVideoOnline = YES;
        self.message = message;
        self.showType = showType;
        self.videoHandle = [[KDVideoHandle alloc] init];
        self.videoHandle.delegate = self;
        [self setBaseUI:NO];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(networkStateChange) name:kReachabilityChangedNotification object:nil];
        Reachability *connect = [Reachability reachabilityForInternetConnection];
        [connect startNotifier];
    }
    return self;
}

- (void)networkStateChange
{
    
    Reachability *reachability = [Reachability reachabilityWithHostName:@"www.baidu.com"];
    switch ([reachability currentReachabilityStatus]) {
        case 0:{//没有网
            [SxtToast showInfo:@"网络已断开"];
            [self handupChat:nil];
        }
            break;
        case 1:
            NSLog(@"WIFI网络");
            break;
        case 2:
            NSLog(@"手机自带网络");
            break;
        default:
            break;
    }
}


-(void)setBaseUI:(BOOL)isVideoToVoice {
    __weak typeof(self)weakSelf = self;
    if (self.showType == KDVLineRTCShowType_Video_Passive || self.showType == KDVLineRTCShowType_Video_Active) {
        KDVideoCallView *videoCallView = [[KDVideoCallView alloc] initWidthDismissBlock:^{
            [weakSelf handupChat:nil];
        } changeDirectionBlock:^(SxtDeviceDirection direction) {
            [weakSelf setVideoContectState:direction];
        }];

        [self.containView addSubview:videoCallView];
        self.videoCallView = videoCallView;
        [videoCallView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self.containView);
        }];
        if (self.showType == KDVLineRTCShowType_Video_Passive && ![KDSoundAndShakeManager shareInstance].isPlaying) {
            [KDSoundAndShakeManager startVideoChatSoundAndShake];
        }
    }else{
        KDAudioCallView *audioCallView = [[KDAudioCallView alloc] initWidthDismissBlock:^{
            [weakSelf handupChat:nil];
        }];
        [self.containView addSubview:audioCallView];
        self.audioCallView = audioCallView;
        [audioCallView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self.containView);
        }];
        if (self.showType == KDVLineRTCShowType_Voice_Passive && ![KDSoundAndShakeManager shareInstance].isPlaying) {
            [KDSoundAndShakeManager startVideoChatSoundAndShake];
        }
    }
    
    if (!isVideoToVoice && (self.showType == KDVLineRTCShowType_Video_Passive || self.showType == KDVLineRTCShowType_Voice_Passive)) {
        [self disposeTimer:YES];
        self.timer = [NSTimer scheduledTimerWithTimeInterval:1 block:^(NSTimer * _Nonnull timer) {
            weakSelf.timeCount ++;
            if (weakSelf.timeCount > 30) {
                [SxtToast showInfo:@"对方已挂断"];
                [KDSoundAndShakeManager stopVideoChatSoundAndShake];
                KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)weakSelf.message.contentAttachment;
                [weakSelf.videoHandle setCurrentStatusWithRoom:mediaAttachment.room status:KDRoomStatus_Away];
                [weakSelf.videoHandle refuseWithMessageModel:weakSelf.message];
                [weakSelf dismiss];
            }
        } repeats:YES];
    }


    UIImageView *accountImage = [[UIImageView alloc] initWithFrame:self.containView.bounds];
    accountImage.contentMode= UIViewContentModeScaleAspectFit;
//        KDFileHandle *fileHandle = [[KDFileHandle alloc] init];
//        NSString *imageUrl = [fileHandle getWholeurlWithUrl:self.account.headImage];
//        [accountImage sd_setImageWithURL:[NSURL URLWithString:imageUrl] placeholderImage:[UIImage imageNamed:@"KD_account_default"]];

    [self.containView addSubview:accountImage];
    self.accountImage = accountImage;

    UIBlurEffect * blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    UIVisualEffectView * visualView = [[UIVisualEffectView alloc] initWithEffect:blur];
    visualView.frame = accountImage.bounds;
    [accountImage addSubview:visualView];

    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.layer.cornerRadius = 5;
    imageView.clipsToBounds = YES;
    [self.containView addSubview:imageView];
    self.centerIconImage = imageView;
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.containView);
        make.bottom.equalTo(self.containView.mas_centerY);
        make.size.mas_equalTo(CGSizeMake(132, 132));
    }];

    UILabel *nameLab = [[UILabel alloc] init];
    nameLab.textAlignment = NSTextAlignmentCenter;
    nameLab.font = [UIFont systemFontOfSize:22 weight:UIFontWeightMedium];
    nameLab.textColor = [UIColor whiteColor];
    [self.containView addSubview:nameLab];
    self.centerNameLab = nameLab;
    [nameLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(imageView.mas_bottom).offset(20);
        make.left.right.equalTo(self.containView);
        make.height.mas_equalTo(24);
    }];

    UIView *functionView = [[UIView alloc] init];
    [self.containView addSubview:functionView];
    self.functionView = functionView;
    [functionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.containView);
        make.top.equalTo(self.containView).offset(TopStatuHeight);
        make.bottom.equalTo(self.containView);
    }];
    
    UIButton *foldBtn = [[UIButton alloc] init];
    [foldBtn setImage:[KDUtil getImage:@"KD_fold"] forState:UIControlStateNormal];
    [foldBtn addTarget:self action:@selector(zoomInvitViewEvent) forControlEvents:UIControlEventTouchUpInside];
    [self.containView addSubview:foldBtn];
    self.foldBtn = foldBtn;
    [foldBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.containView).offset(10);
        make.top.equalTo(self.containView).offset(TopStatuHeight + 25);
        make.size.mas_equalTo(CGSizeMake(26, 26));
    }];

    if (self.showType == KDVLineRTCShowType_Voice_Active) {
        [self setVoiceActiveInviteState];
        [self setVoiceInviteUserState];
        [self loadUserInfo:@[self.message.receiver] voice:YES];
    } else if (self.showType == KDVLineRTCShowType_Voice_Passive) {
        [self setVoicePassiveInviteState];
        [self setVoiceInviteUserState];
        [self loadUserInfo:@[self.message.sender] voice:YES];
    } else if (self.showType == KDVLineRTCShowType_Video_Active) {
        self.centerNameLab.hidden = YES;
        self.centerIconImage.hidden = YES;
        [self setVideoActiveInviteState];
        [self setVideoInviteUserState];
        [self loadUserInfo:@[self.message.receiver] voice:NO];
    } else if (self.showType == KDVLineRTCShowType_Video_Passive) {
        self.centerNameLab.hidden = YES;
        self.centerIconImage.hidden = YES;
        [self setVideoPassiveInviteState];
        [self setVideoInviteUserState];
        [self loadUserInfo:@[self.message.sender] voice:NO];
    }
}

-(void)loadUserInfo:(NSArray *)userArray voice:(BOOL)isVoice{
    [[SxtAppDelegate shareInstance] nativeToFlutterWithMethodName:GET_CONTACTS arguments:userArray result:^(id  _Nullable result) {
        if (![result isKindOfClass:[NSArray class]]) {
            return;
        }
        NSArray *userList = (NSArray *)result;
        SxtUserModel *userModel = [SxtUserModel modelWithDictionary:userList.firstObject];
        [[SxtAppDelegate shareInstance] nativeToFlutterWithMethodName:GET_CONTACT_AVATAR_BASE_URL arguments:nil result:^(id  _Nullable result) {
            UIImage *defaultImage = [KDUtil getImage:@"KD_account_default"];
            if (userModel.personalPortrait.length > 0) {
                NSString *imageUrl = [NSString stringWithFormat:@"%@%@",result,userModel.personalPortrait];
                if (!isVoice) {
                    self.videoNameLab.text = userModel.name;
                    [self.videoIconImage sd_setImageWithURL:[NSURL URLWithString:imageUrl] placeholderImage:defaultImage];
                }
                self.centerNameLab.text = userModel.name;
                [self.centerIconImage sd_setImageWithURL:[NSURL URLWithString:imageUrl] placeholderImage:defaultImage];
                [self.accountImage sd_setImageWithURL:[NSURL URLWithString:imageUrl] placeholderImage:defaultImage];
            } else if (userModel.headPortrait.length > 0) {
                NSString *imageUrl = [NSString stringWithFormat:@"%@%@",result,userModel.headPortrait];
                if (!isVoice) {
                    self.videoNameLab.text = userModel.name;
                    [self.videoIconImage sd_setImageWithURL:[NSURL URLWithString:imageUrl] placeholderImage:defaultImage];
                }
                self.centerNameLab.text = userModel.name;
                [self.centerIconImage sd_setImageWithURL:[NSURL URLWithString:imageUrl] placeholderImage:defaultImage];
                [self.accountImage sd_setImageWithURL:[NSURL URLWithString:imageUrl] placeholderImage:defaultImage];
            } else {
                [self.centerIconImage setImage:defaultImage];
                [self.videoIconImage setImage:defaultImage];
                [self.accountImage setImage:defaultImage];
                self.centerNameLab.text = userModel.name;
                if (!isVoice) {
                    self.videoNameLab.text = userModel.name;
                }
            }
            return;
        }];
    }];
    
}

-(void)zoomInvitViewEvent {

    [UIView animateWithDuration:0.5 animations:^{
        self.containView.alpha = 0;
        self.narrowBtn.alpha = 1;
        self.frame = CGRectMake(self.movePoint.x, self.movePoint.y, 52, 52);
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
//        [self setDragGestures:YES];
        self.draggingType = DraggingTypeNormal;
    }];
}

-(void)expandInvitViewEvent {
    [UIView animateWithDuration:0.5 animations:^{
        self.narrowBtn.alpha = 0;
        self.containView.alpha = 1;
        self.frame = [UIScreen mainScreen].bounds;
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
//        [self setDragGestures:NO];
        self.draggingType = DraggingTypeDisabled;
    }];
}


-(void)draggingDidEnded:(UIView *)view {
    CGPoint point = view.frame.origin;
    float screenWidth = [UIScreen mainScreen].bounds.size.width;
    float screenHeight = [UIScreen mainScreen].bounds.size.height;
    float selfSize = 52;
    if (point.x+self.width > screenWidth) {
        self.movePoint = CGPointMake(screenWidth - self.width, point.y);
        self.frame = CGRectMake(self.movePoint.x, self.movePoint.y, selfSize, selfSize);
    } else if (point.y+self.height > screenHeight) {
        self.movePoint = CGPointMake(point.x, screenHeight - self.height);
        self.frame = CGRectMake(self.movePoint.x, self.movePoint.y, selfSize, selfSize);
    }else if (point.x < 0) {
        self.movePoint = CGPointMake(0, point.y);
        self.frame = CGRectMake(self.movePoint.x, self.movePoint.y, selfSize, selfSize);
    } else if (point.y < 0) {
        self.movePoint = CGPointMake(point.x, 0);
        self.frame = CGRectMake(self.movePoint.x, self.movePoint.y, selfSize, selfSize);
    } else {
        self.movePoint = CGPointMake(point.x, point.y);
        self.frame = CGRectMake(self.movePoint.x, self.movePoint.y, selfSize, selfSize);
    }
}

-(void)disposeTimer:(BOOL)isResetCount {
    if (self.timer) {
        [self.timer invalidate];
        self.timer = nil;
        if (isResetCount) {
            self.timeCount = 0;
        }
    }
}

-(void)createTimer{
    __weak typeof(self)weakSelf = self;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1 block:^(NSTimer * _Nonnull timer) {
        weakSelf.timeCount ++;
        weakSelf.timeLab.text = [weakSelf timeCountToTimeStr:weakSelf.timeCount];
    } repeats:YES];
}

-(NSString *)timeCountToTimeStr:(NSInteger)timeCount {
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:timeCount];
    NSDateFormatter *formate = [[NSDateFormatter alloc] init];
    formate.timeZone = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    formate.dateFormat = @"mm:ss";
    return [formate stringFromDate:date];
}


- (void)videoHandle:(KDVideoHandle *)videoHandle listenVideoEventWithMessageModel:(KDMessageModel *)messageModel
{
    KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)messageModel.contentAttachment;
    __weak typeof(self)weakSelf = self;
    if (mediaAttachment.singleType == KDSingleType_Refuse &&
        (self.showType == KDVLineRTCShowType_Video_Active ||
         self.showType == KDVLineRTCShowType_Voice_Active)) {//拒绝
        [self disposeTimer:YES];
        [self.videoCallView stop];
        [self.audioCallView stop];
        [KDSoundAndShakeManager stopVideoChatSoundAndShake];
        NSArray *roomArray = [NSArray arrayWithObject:mediaAttachment.room];
        [self.videoHandle stopWithRoom:mediaAttachment.room Completion:^(BOOL success) {
            [weakSelf.videoHandle destroyRoomWithRooms:roomArray];
        }];
        
        [SxtToast showInfo:[SxtEnumType mediaTypeToPromptString:messageModel]];
        [self dismiss];
    }else if(mediaAttachment.singleType == KDSingleType_End &&
             ([messageModel.sender isEqualToString:self.message.sender] ||
              [messageModel.sender isEqualToString:self.message.receiver])){                   //挂断TODO(未接通的时候不需要stop音视频)
        [self disposeTimer:YES];
        [self.videoCallView stop];
        [self.audioCallView stop];
        [KDSoundAndShakeManager stopVideoChatSoundAndShake];
        NSArray *roomArray = [NSArray arrayWithObject:mediaAttachment.room];
        [self.videoHandle stopWithRoom:mediaAttachment.room Completion:^(BOOL success) {
            [weakSelf.videoHandle destroyRoomWithRooms:roomArray];
        }];
        [self dismiss];
        [SxtToast showInfo:[SxtEnumType mediaTypeToPromptString:messageModel]];
        
    }else if(mediaAttachment.singleType == KDSingleType_Accept){
        [KDSoundAndShakeManager stopVideoChatSoundAndShake];
        KDMutiMediaAttachment *oldAttachment = (KDMutiMediaAttachment *)self.message.contentAttachment;
        KDRTCContactModel *contactModel = [[KDRTCContactModel alloc] init];
        contactModel.caller = [KDConfigManager sharedInstance].userCodeDomain;
        contactModel.callee = messageModel.sender;
        contactModel.deviceid = oldAttachment.resourceId;
        contactModel.RTCIp = [KDConfigManager sharedInstance].webRTCIp;
        contactModel.RTCPort = [KDConfigManager sharedInstance].webRTCPort;
        contactModel.stunIp = [KDConfigManager sharedInstance].stunIp;
        contactModel.stunPort = [KDConfigManager sharedInstance].stunPort;
        Log(@"callBack-----%@---------%@",contactModel.caller,contactModel.callee);
        [self refreshAcceptView:contactModel];
    } else if (mediaAttachment.singleType == KDSingleType_CloseCamera) {
        if (self.functionView != nil) {
            [self activeChangeToVoice:nil];
        } else {
            [self acceptChangeToVoice];
        }
        
    }
}

-(void)refreshAcceptView:(KDRTCContactModel *)contactModel {
    if (self.showType == KDVLineRTCShowType_Video_Active || self.showType == KDVLineRTCShowType_Video_Passive) {
        self.videoCallView.contactModel = contactModel;
        [self.cameraPreviewView removeFromSuperview];
        self.accountImage.hidden = YES;
        [self.functionView removeFromSuperview];
        self.functionView = nil;
//        [self setVideoContectState];
        [self.videoCallView startVideo];
    }else if(self.showType == KDVLineRTCShowType_Voice_Active || self.showType == KDVLineRTCShowType_Voice_Passive){
        [self resetCenterNameLabUI:NO];
        self.audioCallView.contactModel = contactModel;
        [self.functionView removeFromSuperview];
        self.functionView = nil;
        [self setVoiceConnectState];
        [self.audioCallView startAudio];
    }
}

//拒绝音视频
- (void)refuseChat:(UIButton *)sender
{
    [KDSoundAndShakeManager stopVideoChatSoundAndShake];
    [self.videoHandle refuseWithMessageModel:self.message];
    [self dismiss];
}

//挂断音视频
- (void)handupChat:(UIButton *)sender
{
    [KDSoundAndShakeManager stopVideoChatSoundAndShake];
    [self disposeTimer:YES];
    [self.videoCallView stop];
    [self.audioCallView stop];
    KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)self.message.contentAttachment;
    [self.videoHandle stopWithRoom:mediaAttachment.room Completion:^(BOOL success) {

        Log(@"结束视频");
    }];
    [self dismiss];
}

//接受视频邀请
- (void)acceptChat:(UIButton *)sender
{
    [KDSoundAndShakeManager stopVideoChatSoundAndShake];
    [self.videoHandle acceptWithMessageModel:self.message];
    KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)self.message.contentAttachment;
    KDRTCContactModel *contactModel = [[KDRTCContactModel alloc] init];
    contactModel.caller = [KDConfigManager sharedInstance].userCodeDomain;
    contactModel.callee = self.message.sender;
    contactModel.deviceid = mediaAttachment.resourceId;
    contactModel.RTCIp = [KDConfigManager sharedInstance].webRTCIp;
    contactModel.RTCPort = [KDConfigManager sharedInstance].webRTCPort;
    contactModel.stunIp = [KDConfigManager sharedInstance].stunIp;
    contactModel.stunPort = [KDConfigManager sharedInstance].stunPort;
    
    Log(@"accept-----%@---------%@",contactModel.caller,contactModel.callee);
    [self refreshAcceptView:contactModel];
}

-(void)resetCenterNameLabUI:(BOOL)isInvited {
    if (isInvited) {
        [self.centerNameLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(_centerIconImage.mas_bottom).offset(50);
            make.left.right.equalTo(self.containView);
            make.height.mas_equalTo(24);
        }];
    } else {
        [self.centerNameLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(_centerIconImage.mas_bottom).offset(20);
            make.left.right.equalTo(self.containView);
            make.height.mas_equalTo(24);
        }];
    }
}

//麦克风静音切换
- (void)setMute:(UIButton *)sender
{
    sender.selected = !sender.selected;
    [self.videoCallView enableAudioMic:sender.selected];
    [self.audioCallView enableAudioMic:sender.selected];
}

//前摄与后摄切换
- (void)changeCamera:(UIButton *)sender
{
    [self.videoCallView changeCamera];
}

//免提
- (void)changeVoice:(UIButton *)sender
{
    KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)self.message.contentAttachment;
    sender.selected = !sender.selected;
    [self.videoCallView changeSpeakerWithSelected:sender.selected];
    [self.audioCallView changeSpeakerWithSelected:sender.selected];
    [self.videoHandle operateVoiceWithRoom:mediaAttachment.room isOpen:sender.selected];
}

//正式开始视频通话的界面，切换语音
- (void)changeToVoice:(UIButton *)sender
{
    [self acceptChangeToVoice];
    KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)self.message.contentAttachment;
    [self.videoHandle operateCameraWithRoom:mediaAttachment.room isOpen:NO];
}

- (void)acceptChangeToVoice {
    [self.videoCallView changeToVoice];
    [self.contactFunctionView removeFromSuperview];
    [self setVoiceConnectState];
    self.accountImage.hidden = NO;
    self.centerNameLab.hidden = NO;
    self.centerIconImage.hidden = NO;
    self.videoCallView.hidden = YES;
}

//主动邀请的界面，切换语音
- (void)activeChangeToVoice:(UIButton *)sender {
    UIView *contentView = [self viewWithTag:100];
    [contentView removeAllSubviews];;
    self.showType = self.showType == KDVLineRTCShowType_Video_Passive ? KDVLineRTCShowType_Voice_Passive : KDVLineRTCShowType_Voice_Active;
    self.videoCallView = nil;
    [self setBaseUI:YES];
    KDMutiMediaAttachment *mediaAttachment = (KDMutiMediaAttachment *)self.message.contentAttachment;
    [self.videoHandle operateCameraWithRoom:mediaAttachment.room isOpen:NO];
}

//接收邀请的界面，切换语音
- (void)invitedChangeToVoice:(UIButton *)sender
{
    [self acceptChat:nil];
    [self changeToVoice:nil];
}


- (void)setVoiceActiveInviteState
{
    UILabel *cancelLab = [[UILabel alloc] init];
    cancelLab.text = @"取消";
    cancelLab.textAlignment = NSTextAlignmentCenter;
    cancelLab.font = [UIFont systemFontOfSize:12];
    cancelLab.textColor = [UIColor whiteColor];
    [self.functionView addSubview:cancelLab];
    [cancelLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView);
        make.size.mas_equalTo(CGSizeMake(100, 12));
        make.bottom.equalTo(self.functionView).offset(-46);
    }];
    
    UIButton *cancelBtn = [[UIButton alloc] init];
    [cancelBtn setImage:[KDUtil getImage:@"KD_cancel"] forState:UIControlStateNormal];
    [cancelBtn addTarget:self action:@selector(handupChat:) forControlEvents:UIControlEventTouchUpInside];
    [self.functionView addSubview:cancelBtn];
    [cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView);
        make.bottom.equalTo(cancelLab.mas_top).offset(-10);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
}

- (void)setVoicePassiveInviteState
{
    UILabel *refuseLab = [[UILabel alloc] init];
    refuseLab.text = @"拒绝";
    refuseLab.textAlignment = NSTextAlignmentCenter;
    refuseLab.font = [UIFont systemFontOfSize:12];
    refuseLab.textColor = [UIColor whiteColor];
    [self.functionView addSubview:refuseLab];
    [refuseLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView).multipliedBy(0.5);
        make.size.mas_equalTo(CGSizeMake(100, 40));
        make.bottom.equalTo(self.functionView).offset(-46);
    }];
    
    UIButton *refuseBtn = [[UIButton alloc] init];
    [refuseBtn setImage:[KDUtil getImage:@"KD_cancel"] forState:UIControlStateNormal];
    [refuseBtn addTarget:self action:@selector(refuseChat:) forControlEvents:UIControlEventTouchUpInside];
    [self.functionView addSubview:refuseBtn];
    [refuseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView).multipliedBy(0.5);
        make.bottom.equalTo(refuseLab.mas_top).offset(-10);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
    
    UILabel *acceptLab = [[UILabel alloc] init];
    acceptLab.text = @"接听";
    acceptLab.textAlignment = NSTextAlignmentCenter;
    acceptLab.font = [UIFont systemFontOfSize:12];
    acceptLab.textColor = [UIColor whiteColor];
    [self.functionView addSubview:acceptLab];
    [acceptLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView).multipliedBy(1.5);
        make.size.mas_equalTo(CGSizeMake(100, 40));
        make.bottom.equalTo(self.functionView).offset(-46);
    }];
    
    UIButton *acceptBtn = [[UIButton alloc] init];
    [acceptBtn setImage:[KDUtil getImage:@"KD_accept"] forState:UIControlStateNormal];
    [acceptBtn addTarget:self action:@selector(acceptChat:) forControlEvents:UIControlEventTouchUpInside];
    [self.functionView addSubview:acceptBtn];
    [acceptBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView).multipliedBy(1.5);
        make.bottom.equalTo(acceptLab.mas_top).offset(-10);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
}

- (void)setVoiceInviteUserState
{
    [self resetCenterNameLabUI:YES];
    
    UILabel *infoLab = [[UILabel alloc] init];
    if (self.showType == KDVLineRTCShowType_Voice_Active) {
        infoLab.text = @"正在等待对方接受邀请…";
    }else{
        infoLab.text = @"邀请你语音通话";
    }
    infoLab.textAlignment = NSTextAlignmentCenter;
    infoLab.font = [UIFont systemFontOfSize:14];
    infoLab.textColor = [UIColor whiteColor];
    [self.functionView addSubview:infoLab];
    [infoLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.centerIconImage.mas_bottom).offset(12);
        make.left.right.equalTo(self.functionView);
        make.height.mas_equalTo(14);
    }];
}

- (void)setVideoActiveInviteState
{
    KDLocalVideoView *localView = [[KDLocalVideoView alloc] init];
    [self.functionView addSubview:localView];
    self.cameraPreviewView = localView;
    [localView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.functionView);
    }];
    
    UILabel *cancelLab = [[UILabel alloc] init];
    cancelLab.text = @"取消";
    cancelLab.textAlignment = NSTextAlignmentCenter;
    cancelLab.font = [UIFont systemFontOfSize:12];
    cancelLab.textColor = [UIColor whiteColor];
    [self.functionView addSubview:cancelLab];
    [cancelLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView);
        make.size.mas_equalTo(CGSizeMake(100, 12));
        make.bottom.equalTo(self.functionView).offset(-46);
    }];
    
    UIButton *cancelBtn = [[UIButton alloc] init];
    [cancelBtn setImage:[KDUtil getImage:@"KD_cancel"] forState:UIControlStateNormal];
    [cancelBtn addTarget:self action:@selector(handupChat:) forControlEvents:UIControlEventTouchUpInside];
    [self.functionView addSubview:cancelBtn];
    [cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView);
        make.bottom.equalTo(cancelLab.mas_top).offset(-10);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
    
    UILabel *changeLab = [[UILabel alloc] init];
    changeLab.text = @"切到语音通话";
    changeLab.textAlignment = NSTextAlignmentCenter;
    changeLab.font = [UIFont systemFontOfSize:12];
    changeLab.textColor = [UIColor whiteColor];
    self.changeLab = changeLab;
    [self.functionView addSubview:changeLab];
    [changeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView);
        make.size.mas_equalTo(CGSizeMake(120, 12));
        make.bottom.equalTo(cancelBtn.mas_top).offset(-22);
    }];
    
    UIButton *changeBtn = [[UIButton alloc] init];
    [changeBtn setImage:[KDUtil getImage:@"kd_change_voice"] forState:UIControlStateNormal];
    [changeBtn addTarget:self action:@selector(activeChangeToVoice:) forControlEvents:UIControlEventTouchUpInside];
    self.changeBtn = changeBtn;
    [self.functionView addSubview:changeBtn];
    [changeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView);
        make.bottom.equalTo(changeLab.mas_top);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
}

- (void)setVideoPassiveInviteState
{
    UILabel *refuseLab = [[UILabel alloc] init];
    refuseLab.text = @"拒绝";
    refuseLab.textAlignment = NSTextAlignmentCenter;
    refuseLab.font = [UIFont systemFontOfSize:12];
    refuseLab.textColor = [UIColor whiteColor];
    [self.functionView addSubview:refuseLab];
    [refuseLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView).multipliedBy(0.5);
        make.size.mas_equalTo(CGSizeMake(100, 12));
        make.bottom.equalTo(self.functionView).offset(-46);
    }];
    
    UIButton *refuseBtn = [[UIButton alloc] init];
    [refuseBtn setImage:[KDUtil getImage:@"KD_cancel"] forState:UIControlStateNormal];
    [refuseBtn addTarget:self action:@selector(refuseChat:) forControlEvents:UIControlEventTouchUpInside];
    [self.functionView addSubview:refuseBtn];
    [refuseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView).multipliedBy(0.5);
        make.bottom.equalTo(refuseLab.mas_top).offset(-10);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
    
    UILabel *acceptLab = [[UILabel alloc] init];
    acceptLab.text = @"接听";
    acceptLab.textAlignment = NSTextAlignmentCenter;
    acceptLab.font = [UIFont systemFontOfSize:12];
    acceptLab.textColor = [UIColor whiteColor];
    [self.functionView addSubview:acceptLab];
    [acceptLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView).multipliedBy(1.5);
        make.size.mas_equalTo(CGSizeMake(100, 12));
        make.bottom.equalTo(self.functionView).offset(-46);
    }];
    
    UIButton *acceptBtn = [[UIButton alloc] init];
    [acceptBtn setImage:[KDUtil getImage:@"KD_video_accept"] forState:UIControlStateNormal];
    [acceptBtn addTarget:self action:@selector(acceptChat:) forControlEvents:UIControlEventTouchUpInside];
    [self.functionView addSubview:acceptBtn];
    [acceptBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView).multipliedBy(1.5);
        make.bottom.equalTo(acceptLab.mas_top).offset(-10);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
    
    UILabel *changeLab = [[UILabel alloc] init];
    changeLab.text = @"切到语音通话";
    changeLab.textAlignment = NSTextAlignmentCenter;
    changeLab.font = [UIFont systemFontOfSize:12];
    changeLab.textColor = [UIColor whiteColor];
    self.changeLab = changeLab;
    [self.functionView addSubview:changeLab];
    [changeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView).multipliedBy(1.5);
        make.size.mas_equalTo(CGSizeMake(120, 12));
        make.bottom.equalTo(acceptBtn.mas_top).offset(-22);
    }];
    
    UIButton *changeBtn = [[UIButton alloc] init];
    [changeBtn setImage:[KDUtil getImage:@"kd_change_voice"] forState:UIControlStateNormal];
    [changeBtn addTarget:self action:@selector(invitedChangeToVoice:) forControlEvents:UIControlEventTouchUpInside];
    self.changeBtn = changeBtn;
    [self.functionView addSubview:changeBtn];
    [changeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.functionView).multipliedBy(1.5);
        make.bottom.equalTo(changeLab.mas_top).offset(-5);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
}

- (void)setVideoInviteUserState
{
    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.layer.cornerRadius = 5;
    imageView.clipsToBounds = YES;
    [self.functionView addSubview:imageView];
    self.videoIconImage = imageView;
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.functionView).offset(33);
        make.right.equalTo(self.functionView).offset(-20);
        make.size.mas_equalTo(CGSizeMake(66, 66));
    }];
    
    UILabel *nameLab = [[UILabel alloc] init];
    nameLab.textAlignment = NSTextAlignmentRight;
    nameLab.font = [UIFont systemFontOfSize:22 weight:UIFontWeightMedium];
    nameLab.textColor = [UIColor whiteColor];
    [self.functionView addSubview:nameLab];
    self.videoNameLab = nameLab;
    [nameLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(imageView);
        make.right.equalTo(imageView.mas_left).offset(-12);
        make.height.mas_equalTo(24);
    }];
    
    UILabel *infoLab = [[UILabel alloc] init];
    if (self.showType == KDVLineRTCShowType_Video_Active) {
        infoLab.text = @"正在等待对方接受邀请…";
    }else{
        infoLab.text = @"邀请你视频会议";
    }
    infoLab.textAlignment = NSTextAlignmentRight;
    infoLab.font = [UIFont systemFontOfSize:14];
    infoLab.textColor = [UIColor whiteColor];
    [self.functionView addSubview:infoLab];
    [infoLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(nameLab.mas_bottom).offset(8);
        make.right.equalTo(imageView.mas_left).offset(-12);
        make.height.mas_equalTo(14);
    }];
}

- (void)setVoiceConnectState
{
    
    //语音挂断
    UILabel *cancelLab = [[UILabel alloc] init];
    cancelLab.text = @"挂断";
    cancelLab.textAlignment = NSTextAlignmentCenter;
    cancelLab.font = [UIFont systemFontOfSize:12];
    cancelLab.textColor = [UIColor whiteColor];
    [self.containView addSubview:cancelLab];
    [cancelLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.containView);
        make.size.mas_equalTo(CGSizeMake(100, 12));
        make.bottom.equalTo(self.containView).offset(-46);
    }];
    
    UIButton *cancelBtn = [[UIButton alloc] init];
    [cancelBtn setImage:[KDUtil getImage:@"KD_cancel"] forState:UIControlStateNormal];
    [cancelBtn addTarget:self action:@selector(handupChat:) forControlEvents:UIControlEventTouchUpInside];
    [self.containView addSubview:cancelBtn];
    [cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.containView);
        make.bottom.equalTo(cancelLab.mas_top).offset(-10);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
    
    UILabel *timeLab = [[UILabel alloc] init];
    timeLab.textColor = [UIColor whiteColor];
    timeLab.font = [UIFont systemFontOfSize:14];
    timeLab.textAlignment = NSTextAlignmentCenter;
    [self.containView addSubview:timeLab];
    [timeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(cancelBtn.mas_top).offset(-10);
        make.height.mas_equalTo(20);
        make.centerX.equalTo(cancelBtn);
        make.width.mas_equalTo(120);
    }];
    self.timeLab = timeLab;
    self.timeLab.text = [self timeCountToTimeStr:self.timeCount];
    [self disposeTimer:NO];
    [self createTimer];
    
    UILabel *noSoundLab = [[UILabel alloc] init];
    noSoundLab.text = @"静音";
    noSoundLab.textAlignment = NSTextAlignmentCenter;
    noSoundLab.font = [UIFont systemFontOfSize:12];
    noSoundLab.textColor = [UIColor whiteColor];
    [self.containView addSubview:noSoundLab];
    [noSoundLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.containView.mas_left).offset(SxtScreenWidth/6);
        make.size.mas_equalTo(CGSizeMake(40, 12));
        make.bottom.equalTo(self.containView).offset(-46);
    }];
    
    UIButton *noSoundBtn = [[UIButton alloc] init];
    [noSoundBtn setImage:[KDUtil getImage:@"KD_silent"] forState:UIControlStateNormal];
    [noSoundBtn setImage:[KDUtil getImage:@"KD_silent_selected"] forState:UIControlStateSelected];
    [noSoundBtn addTarget:self action:@selector(setMute:) forControlEvents:UIControlEventTouchUpInside];
    [self.containView addSubview:noSoundBtn];
    [noSoundBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.containView.mas_left).offset(SxtScreenWidth/6);
        make.bottom.equalTo(noSoundLab.mas_top).offset(-10);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
    
    UILabel *handFreeLab = [[UILabel alloc] init];
    handFreeLab.text = @"免提";
    handFreeLab.textAlignment = NSTextAlignmentCenter;
    handFreeLab.font = [UIFont systemFontOfSize:12];
    handFreeLab.textColor = [UIColor whiteColor];
    [self.containView addSubview:handFreeLab];
    [handFreeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.containView.mas_right).offset(-SxtScreenWidth/6);
        make.size.mas_equalTo(CGSizeMake(40, 12));
        make.bottom.equalTo(self.containView).offset(-46);
    }];
    
    UIButton *handFreeBtn = [[UIButton alloc] init];
    [handFreeBtn setImage:[KDUtil getImage:@"KD_hand_free"] forState:UIControlStateNormal];
    [handFreeBtn setImage:[KDUtil getImage:@"KD_hand_free_selected"] forState:UIControlStateSelected];
    [handFreeBtn addTarget:self action:@selector(changeVoice:) forControlEvents:UIControlEventTouchUpInside];
    [self.containView addSubview:handFreeBtn];
    [handFreeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.containView.mas_right).offset(-SxtScreenWidth/6);
        make.bottom.equalTo(handFreeLab.mas_top).offset(-10);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
    
}

- (void)setVideoContectState:(SxtDeviceDirection)direction
{
    [self.contactFunctionView removeFromSuperview];
    self.contactFunctionView = nil;
    UIView *contactFunctionView = [[UIView alloc] init];
//    contactFunctionView.backgroundColor = [UIColor clearColor];
    [self.containView addSubview:contactFunctionView];
    self.contactFunctionView = contactFunctionView;

    UILabel *cancelLab = [[UILabel alloc] init];
    cancelLab.textAlignment = NSTextAlignmentCenter;
    cancelLab.font = [UIFont systemFontOfSize:12];
    cancelLab.textColor = [UIColor whiteColor];
    [contactFunctionView addSubview:cancelLab];
    
    
    UIButton *cancelBtn = [[UIButton alloc] init];
    [cancelBtn addTarget:self action:@selector(handupChat:) forControlEvents:UIControlEventTouchUpInside];
    [contactFunctionView addSubview:cancelBtn];
    
    
    UILabel *noSoundLab = [[UILabel alloc] init];
    noSoundLab.text = @"静音";
    noSoundLab.textAlignment = NSTextAlignmentCenter;
    noSoundLab.font = [UIFont systemFontOfSize:12];
    noSoundLab.textColor = [UIColor whiteColor];
    [contactFunctionView addSubview:noSoundLab];
    
    
    UIButton *noSoundBtn = [[UIButton alloc] init];
    [noSoundBtn setImage:[KDUtil getImage:@"KD_silent"] forState:UIControlStateNormal];
    [noSoundBtn setImage:[KDUtil getImage:@"KD_silent_selected"] forState:UIControlStateSelected];
    [noSoundBtn addTarget:self action:@selector(setMute:) forControlEvents:UIControlEventTouchUpInside];
    [contactFunctionView addSubview:noSoundBtn];
    
    
    UILabel *handFreeLab = [[UILabel alloc] init];
    handFreeLab.text = @"免提";
    handFreeLab.textAlignment = NSTextAlignmentCenter;
    handFreeLab.font = [UIFont systemFontOfSize:12];
    handFreeLab.textColor = [UIColor whiteColor];
    [contactFunctionView addSubview:handFreeLab];
    
    
    UIButton *handFreeBtn = [[UIButton alloc] init];
    [handFreeBtn setImage:[KDUtil getImage:@"KD_hand_free"] forState:UIControlStateNormal];
    [handFreeBtn setImage:[KDUtil getImage:@"KD_hand_free_selected"] forState:UIControlStateSelected];
    [handFreeBtn addTarget:self action:@selector(changeVoice:) forControlEvents:UIControlEventTouchUpInside];
    [contactFunctionView addSubview:handFreeBtn];
    
    
    UILabel *changeLab = [[UILabel alloc] init];
    changeLab.text = @"切到语音通话";
    changeLab.textAlignment = NSTextAlignmentCenter;
    changeLab.font = [UIFont systemFontOfSize:12];
    changeLab.textColor = [UIColor whiteColor];
    self.changeLab = changeLab;
    [contactFunctionView addSubview:changeLab];
    
    
    UIButton *changeBtn = [[UIButton alloc] init];
    [changeBtn setImage:[KDUtil getImage:@"KD_change_voice_gray"] forState:UIControlStateNormal];
    [changeBtn addTarget:self action:@selector(changeToVoice:) forControlEvents:UIControlEventTouchUpInside];
    self.changeBtn = changeBtn;
    [contactFunctionView addSubview:changeBtn];
    
    
    
    UILabel *changeCameraLab = [[UILabel alloc] init];
    changeCameraLab.text = @"切换摄像头";
    changeCameraLab.textAlignment = NSTextAlignmentCenter;
    changeCameraLab.font = [UIFont systemFontOfSize:12];
    changeCameraLab.textColor = [UIColor whiteColor];
    [contactFunctionView addSubview:changeCameraLab];
    
    
    UIButton *changeCameraBtn = [[UIButton alloc] init];
    [changeCameraBtn setImage:[KDUtil getImage:@"KD_change_camera_gray"] forState:UIControlStateNormal];
    [changeCameraBtn addTarget:self action:@selector(changeCamera:) forControlEvents:UIControlEventTouchUpInside];
    [contactFunctionView addSubview:changeCameraBtn];
    
    
    UILabel *timeLab = [[UILabel alloc] init];
    timeLab.textColor = [UIColor whiteColor];
    timeLab.font = [UIFont systemFontOfSize:14];
    timeLab.textAlignment = NSTextAlignmentCenter;
    [contactFunctionView addSubview:timeLab];
    self.timeLab = timeLab;
    
    [self.containView bringSubviewToFront:self.foldBtn];
    //视频通话允许横屏
    if (self.showType == KDVLineRTCShowType_Video_Passive || self.showType == KDVLineRTCShowType_Video_Active) {
        [contactFunctionView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self.containView);
        }];
    } else {
        [contactFunctionView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.equalTo(self.containView);
            make.top.equalTo(self.containView).offset(122);
        }];
    }
    if (direction == SxtDeviceDirection_Vertical || (self.showType == KDVLineRTCShowType_Voice_Active || self.showType == KDVLineRTCShowType_Voice_Passive)) {
        
        [self.foldBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.containView).offset(10);
            make.top.equalTo(self.containView).offset(TopStatuHeight + 25);
            make.size.mas_equalTo(CGSizeMake(26, 26));
        }];
        
        cancelLab.text = @"挂断";
        [cancelLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(contactFunctionView);
            make.size.mas_equalTo(CGSizeMake(100, 12));
            make.bottom.equalTo(contactFunctionView).offset(-46);
        }];
        
        [cancelBtn removeAllSubviews];
        cancelBtn.clipsToBounds = NO;
        [cancelBtn setBackgroundColor:[UIColor clearColor]];
        [cancelBtn setImage:[KDUtil getImage:@"KD_cancel"] forState:UIControlStateNormal];
        [cancelBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(contactFunctionView);
            make.bottom.equalTo(cancelLab.mas_top).offset(-10);
            make.size.mas_equalTo(CGSizeMake(48, 48));
        }];
        
        [noSoundLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.containView.mas_left).offset(SxtScreenWidth/6);
            make.size.mas_equalTo(CGSizeMake(40, 12));
            make.bottom.equalTo(contactFunctionView).offset(-46);
        }];
        
        [noSoundBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(noSoundLab);
            make.bottom.equalTo(noSoundLab.mas_top).offset(-10);
            make.size.mas_equalTo(CGSizeMake(48, 48));
        }];
        
        [handFreeLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.containView.mas_right).offset( - SxtScreenWidth /6);
            make.size.mas_equalTo(CGSizeMake(40, 12));
            make.bottom.equalTo(contactFunctionView).offset(-46);
        }];
        
        [handFreeBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(handFreeLab);
            make.bottom.equalTo(handFreeLab.mas_top).offset(-10);
            make.size.mas_equalTo(CGSizeMake(48, 48));
        }];
        
        [changeLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.containView.mas_left).offset(SxtScreenWidth/3);
            make.size.mas_equalTo(CGSizeMake(120, 12));
            make.bottom.equalTo(cancelBtn.mas_top).offset(-37);
        }];
        
        [changeBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(changeLab);
            make.bottom.equalTo(changeLab.mas_top).offset(-5);;
            make.size.mas_equalTo(CGSizeMake(48, 48));
        }];
        
        [changeCameraLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.containView.mas_right).offset(-SxtScreenWidth/3);
            make.size.mas_equalTo(CGSizeMake(100, 12));
            make.bottom.equalTo(cancelBtn.mas_top).offset(-37);
        }];
        
        [changeCameraBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(changeCameraLab);
            make.bottom.equalTo(changeCameraLab.mas_top).offset(-5);;
            make.size.mas_equalTo(CGSizeMake(48, 48));
        }];
        
        [timeLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(changeCameraBtn.mas_top).offset(-10);
            make.height.mas_equalTo(20);
            make.centerX.equalTo(contactFunctionView);
            make.width.mas_equalTo(120);
        }];
    } else {
        
        [self.foldBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.containView).offset(-10);
            make.top.equalTo(self.containView).offset(TopStatuHeight + 10);
            make.size.mas_equalTo(CGSizeMake(26, 26));
        }];
        
        [noSoundBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(contactFunctionView).offset(TopStatuHeight + 30);
            make.right.equalTo(contactFunctionView).offset(-40);
            make.size.mas_equalTo(CGSizeMake(48, 48));
        }];
        noSoundBtn.transform = CGAffineTransformMakeRotation((90) / 180.0 * M_PI);
        
        [noSoundLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(noSoundBtn);
            make.right.equalTo(noSoundBtn.mas_left).offset(-3);
        }];
        noSoundLab.transform = CGAffineTransformMakeRotation((90) / 180.0 * M_PI);
        
        [handFreeBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(noSoundBtn);
            make.right.equalTo(noSoundLab.mas_left).offset(-10);
            make.size.mas_equalTo(CGSizeMake(48, 48));
        }];
        handFreeBtn.transform = CGAffineTransformMakeRotation((90) / 180.0 * M_PI);
        
        [handFreeLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(noSoundBtn);
            make.right.equalTo(handFreeBtn.mas_left).offset(-3);
        }];
        handFreeLab.transform = CGAffineTransformMakeRotation((90) / 180.0 * M_PI);
        
        [changeCameraBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(noSoundBtn);
            make.right.equalTo(handFreeLab.mas_left).offset(-10);
            make.size.mas_equalTo(CGSizeMake(48, 48));
        }];
        changeCameraBtn.transform = CGAffineTransformMakeRotation((90) / 180.0 * M_PI);
        
        [changeCameraLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(noSoundBtn);
            make.right.equalTo(changeCameraBtn.mas_left).offset(20);
        }];
        changeCameraLab.transform = CGAffineTransformMakeRotation((90) / 180.0 * M_PI);
        
        [changeBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(noSoundBtn);
            make.right.equalTo(changeCameraLab.mas_left).offset(5);
            make.size.mas_equalTo(CGSizeMake(48, 48));
        }];
        changeBtn.transform = CGAffineTransformMakeRotation((90) / 180.0 * M_PI);
        
        [changeLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(changeBtn);
            make.right.equalTo(changeBtn.mas_left).offset(25);
        }];
        changeLab.transform = CGAffineTransformMakeRotation((90) / 180.0 * M_PI);
        
        [cancelBtn setImage:nil forState:UIControlStateNormal];
        [cancelBtn setBackgroundColor:[UIColor colorWithRed:213.0/255.0 green:25.0/255.0 blue:25.0/255.0 alpha:1]];
        cancelBtn.layer.cornerRadius = 16;
        cancelBtn.clipsToBounds = YES;
        [cancelBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(contactFunctionView).offset(20);
            make.bottom.equalTo(contactFunctionView).offset(-20-kBottomSafeHeight);
            make.size.mas_equalTo(CGSizeMake(32, 88));
        }];
        
        cancelLab.text = @"";
        UIImageView *cancelImageVIew = [[UIImageView alloc]initWithImage:[KDUtil getImage:@"KD_handup_icon"]];
        [cancelBtn addSubview:cancelImageVIew];
        [cancelImageVIew mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(cancelBtn);
            make.top.equalTo(cancelBtn).offset(10);
            make.size.mas_equalTo(CGSizeMake(24, 24));
        }];
        cancelImageVIew.transform = CGAffineTransformMakeRotation((90) / 180.0 * M_PI);

        [timeLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(cancelBtn);
            make.centerY.equalTo(cancelBtn).offset(13);
        }];
        timeLab.transform = CGAffineTransformMakeRotation((90) / 180.0 * M_PI);
    }
    self.timeLab.text = [self timeCountToTimeStr:self.timeCount];
    [self disposeTimer:NO];
    [self createTimer];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    [KDConfigManager sharedInstance].isVideoOnline = NO;
    [UIApplication sharedApplication].idleTimerDisabled = false;
    Log(@"---------dealloc-------");
}

- (void)show
{
    UIWindow *rootWindow = [UIApplication sharedApplication].keyWindow;
    [rootWindow endEditing:YES];
    [rootWindow addSubview:self];
}

- (void)dismiss
{
    if (self.dismissBlock) {
        self.dismissBlock();
    }
    [[UIApplication sharedApplication]setStatusBarHidden:NO];
    [[SxtAppDelegate shareInstance]nativeToFlutterWithMethodName:END_VIDEO_CALLING arguments:nil result:nil];
    [self disposeTimer:YES];
    self.delegate = nil;
    self.videoHandle.delegate = nil;
    [self removeFromSuperview];
}


@end
