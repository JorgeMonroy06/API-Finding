//
//  KDConferenceSingleUserView.h
//  KDVLine_Example
//
//  Created by samuel on 2021/5/19.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WebRTC/RTCVideoRenderer.h"
#import "WebRTC/RTCCameraPreviewView.h"
#import "KDConferenceSingleUserView.h"
#import <sxt_flutter_plugin/SxtUserModel.h>

NS_ASSUME_NONNULL_BEGIN

@interface KDConferenceSingleUserView : UIView
@property (nonatomic, strong) SxtUserModel *userModel;

@property (nonatomic, assign) NSInteger count;

//@property (nonatomic, assign) BOOL isUsed;

@property (nonatomic, assign) MultiState state;
@property (nonatomic, assign) BOOL isVoice;

@property (nonatomic,copy) void(^newUserBlock)(NSMutableArray<SxtUserModel *> *);

@property (nonatomic, strong)  UIView<RTC_OBJC_TYPE(RTCVideoRenderer)> *remoteVideoView;

@property (nonatomic, strong)  RTC_OBJC_TYPE(RTCCameraPreviewView) * localVideoView;

-(void)showCallBtn:(BOOL)isShow;
-(void)startInvite;
-(void)stopLoad;
@end

NS_ASSUME_NONNULL_END
