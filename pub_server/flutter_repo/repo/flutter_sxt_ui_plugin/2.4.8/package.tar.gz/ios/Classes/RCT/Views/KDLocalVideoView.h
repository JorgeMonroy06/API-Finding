//
//  KDLocalVideoView.h
//  KDVLine_Example
//
//  Created by samuel on 2021/3/30.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KDLocalVideoView : UIView

@end

NS_ASSUME_NONNULL_END
