//
//  KDConferenceMemberCollectionViewCell.m
//  KDVLine_Example
//
//  Created by samuel on 2021/5/19.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import "KDConferenceMemberCollectionViewCell.h"
#import <Masonry/Masonry.h>
#import <SDWebImage/SDWebImage.h>
@interface KDConferenceMemberCollectionViewCell()

@property (nonatomic, weak) UIImageView *imgView;

@end

@implementation KDConferenceMemberCollectionViewCell


+ (instancetype) collectionCellWithCollectionView:(UICollectionView *) collectionView WithIndexPath:(NSIndexPath *) indexPath {
    static NSString *cellID = @"KDConferenceMemberCollectionViewCellID";
    KDConferenceMemberCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    return cell;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        UIImageView *image = [[UIImageView alloc] init];
        image.layer.cornerRadius = 5;
        image.clipsToBounds = YES;
        [self.contentView addSubview:image];
        self.imgView = image;
        [image mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self.contentView);
        }];
    }
    return self;
}

//- (void)setUserCode:(NSString *)userCode
//{
//    _userCode = userCode;
//    KDAccountModel *account = [KDAccountHandle queryUserbyUserCode:userCode];
//    KDFileHandle *fileHandle = [[KDFileHandle alloc] init];
//    NSString *wholeUrl = [fileHandle getWholeurlWithUrl:account.headImage];
//    [self.imgView sd_setImageWithURL:[NSURL URLWithString:wholeUrl] placeholderImage:[UIImage imageNamed:@"KD_user_default"]];
//}

- (void)setImageUrl:(NSString *)imageUrl
{
    _imageUrl = imageUrl;
    NSBundle *bundle = [NSBundle bundleForClass:[self class]];
    NSString *path = [bundle pathForResource:@"MediaResource" ofType:@"bundle"];
    bundle = [NSBundle bundleWithPath:path];
    [self.imgView sd_setImageWithURL:[NSURL URLWithString:imageUrl] placeholderImage:[UIImage imageNamed:@"KD_user_default"
                                                                                                inBundle: bundle
                                                                                              compatibleWithTraitCollection:nil]];
}

@end
