//
//  SxtAppDelegate.h
//  Runner
//
//  Created by xzc on 2021/6/18.
//

#import <Foundation/Foundation.h>
#import "KDConferenceMainView.h"
#import "KDInvitView.h"
#import <KDVLine/KDVLine.h>
#import <Flutter/Flutter.h>
#import "KDMessageModel.h"
@interface SxtAppDelegate : NSObject
@property (nonatomic, strong) KDConferenceMainView *conferenceMainView;
@property (nonatomic, strong) KDInvitView *invitView;
@property (nonatomic, strong) KDMessageModel *pushMsg;
+ (instancetype)shareInstance;
-(void)registerSxtAppDelegate:(UIApplication *)application appDelegate:(FlutterAppDelegate *)appDelegate;
-(void)jumpControllerWithMessage:(KDMessageModel *)messageModel ;
- (void)applicationWillEnterForeground:(UIApplication *)application;
- (void)applicationWillResignActive:(UIApplication *)application;
- (void)applicationDidEnterBackground:(UIApplication *)application;
- (void)applicationDidBecomeActive:(UIApplication *)application;
-(void)nativeToFlutterWithMethodName:(NSString *)methodName arguments:(id)arguments result:(FlutterResult _Nullable)callback;
-(UIViewController *)rootViewController;
@end
