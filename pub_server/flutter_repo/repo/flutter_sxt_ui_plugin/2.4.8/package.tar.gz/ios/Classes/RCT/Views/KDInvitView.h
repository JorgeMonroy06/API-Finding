//
//  KDInvitView.h
//  Runner
//
//  Created by samuel on 2021/4/28.
//

#import <UIKit/UIKit.h>
#import "KDVLineEnums.h"
#import "KDMessageModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface KDInvitView : UIView
@property (nonatomic,copy) void(^dismissBlock)(void);
- (instancetype)initInitViewWithMessage:(KDMessageModel *)message showType:(KDVLineRTCShowType)showType;

- (void)show;

- (void)dismiss;

@end

NS_ASSUME_NONNULL_END
