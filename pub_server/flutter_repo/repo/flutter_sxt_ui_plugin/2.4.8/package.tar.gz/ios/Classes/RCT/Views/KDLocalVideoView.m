//
//  KDLocalVideoView.m
//  KDVLine_Example
//
//  Created by samuel on 2021/3/30.
//  Copyright © 2021 984603904@qq.com. All rights reserved.
//

#import "KDLocalVideoView.h"
#import <AVFoundation/AVFoundation.h>
#import "SxtConfigConstant.h"
@interface KDLocalVideoView()


@end

@implementation KDLocalVideoView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self renderView];
    }
    return self;
}

- (void)renderView
{
    
    AVCaptureSession * captureSession = [[AVCaptureSession alloc] init];
//    AVCaptureDevice * photoCaptureDevice = [AVCaptureDevice defaultDeviceWithDeviceType:AVCaptureDeviceTypeBuiltInDuoCamera mediaType:AVMediaTypeVideo position:AVCaptureDevicePositionBack];
//    AVCaptureDevice * photoCaptureDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
//    NSArray *deviceArray = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    AVCaptureDeviceDiscoverySession *deviceDiscoverySession =  [AVCaptureDeviceDiscoverySession discoverySessionWithDeviceTypes:@[AVCaptureDeviceTypeBuiltInWideAngleCamera] mediaType:AVMediaTypeVideo position:AVCaptureDevicePositionFront];
    AVCaptureDevice *photoCaptureDevice;
    for (AVCaptureDevice *device in deviceDiscoverySession.devices) {
        if (AVCaptureDevicePositionFront == device.position) {
            photoCaptureDevice = device;
        }
    }
    if (!photoCaptureDevice) {
        return;
    }
  
    NSError * error = nil;
    AVCaptureDeviceInput *videoInput = [AVCaptureDeviceInput deviceInputWithDevice:photoCaptureDevice error:&error];
    if(videoInput){
        [captureSession addInput:videoInput];
        [captureSession startRunning];
        NSLog(@"ok");
    }
//    AVCaptureVideoPreviewLayer *previewLayer = [AVCaptureVideoPreviewLayer layerWithSession:captureSession];
//    previewLayer.frame = self.bounds;
//    previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    CGRect rectpreviewLayer = CGRectMake(0, 0,SxtScreenWidth, SxtScreenHeight);

    AVCaptureVideoPreviewLayer *localLayer = [AVCaptureVideoPreviewLayer layerWithSession:captureSession];
    [localLayer setFrame:rectpreviewLayer];
    [localLayer setCornerRadius:0.0f];
    [localLayer setBorderWidth:0.0f];
    localLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    [self.layer addSublayer:localLayer];
}




@end
