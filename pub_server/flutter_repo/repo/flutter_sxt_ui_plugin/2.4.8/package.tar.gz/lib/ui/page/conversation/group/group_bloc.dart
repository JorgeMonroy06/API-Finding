import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:contact_sdk_flutter/model/contact.dart';
import 'package:contact_ui_flutter/ui/contact_select/contact_select_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/loading_dialog.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/group/model/group_create_param.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';

part 'group_event.dart';
part 'group_state.dart';

class GroupBloc extends Bloc<GroupEvent, GroupState> {
  GroupBloc() : super(GroupState());

  @override
  Stream<GroupState> mapEventToState(GroupEvent event) async* {
    if (event is GroupCreateEvent) {
      _createGroupChat(event.context);
    }
  }

  void _createGroupChat(BuildContext context) async {
    final data =
        await Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
      return ContactSelectPage(title: "选择联系人");
    }));
    if (data != null) {
      final List<Contact> list = data;
      showDialog(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => LoadingDialog("创建群组中...", () => {}));

      final List<String> userCodes = [];
      for (var element in list) {
        userCodes.add(element.code! + "@" + element.originCode!);
      }

      final GroupCreateParam param = GroupCreateParam();
      param.userCodes = userCodes;
      SxtGroupPlugin.createGroup(param).then((value) {
        Future.delayed(const Duration(milliseconds: 500), () {
          Navigator.popUntil(
            context,
            (route) {
              if (!route.willHandlePopInternally &&
                  route is ModalRoute &&
                  route.settings.name == '/MainPage') {
                return true;
              }
              return false;
            },
          );
          Navigator.push(
              context,
              CupertinoPageRoute(
                  settings: const RouteSettings(name: '/ChatPage'),
                  builder: (context) {
                    final SessionEntity sessionEntity = SessionEntity(
                        code: value.data?.groupCode,
                        sessionType: SessionType.GROUP);
                    return ChatPage(sessionEntity: sessionEntity);
                  }));
        });
      }).onError((e, stackTrace) {
        Navigator.pop(context);
        if (e is PlatformException) {
          ToastUtil.showToast(e.message ?? "创建群组失败");
        } else {
          ToastUtil.showToast("创建群组失败");
        }
      });
    }
  }
}
