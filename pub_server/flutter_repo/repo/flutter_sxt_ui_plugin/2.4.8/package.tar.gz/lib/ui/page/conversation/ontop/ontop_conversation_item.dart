import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/ontop/ontop_conversation_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/switch_item.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

class OnTopConversationItem extends StatelessWidget {
  const OnTopConversationItem(this.sessionEntity, {Key? key}) : super(key: key);

  final SessionEntity sessionEntity;

  @override
  Widget build(BuildContext context) =>
      BlocBuilder<OnTopConversationBloc, OnTopConversationState>(
        builder: (context, state) => SwitchItem(
          title: '置顶聊天',
          value: context
              .read<OnTopConversationBloc>()
              .isOnTopConversation(sessionEntity),
          onChanged: (value) => context
              .read<OnTopConversationBloc>()
              .add(OnTopConversationSwitchEvent(sessionEntity, value)),
        ),
      );
}
