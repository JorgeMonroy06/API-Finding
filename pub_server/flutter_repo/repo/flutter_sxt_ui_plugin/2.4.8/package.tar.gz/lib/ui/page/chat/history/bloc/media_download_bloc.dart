import 'package:dartx/dartx.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/bloc/media_download_event.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/bloc/media_download_state.dart';
import 'package:sxt_flutter_plugin/manager/sxt_manager.dart';
import 'package:sxt_flutter_plugin/message/listener/file_progress_listener.dart';
import 'package:sxt_flutter_plugin/message/listener/message_state_update_listener.dart';
import 'package:sxt_flutter_plugin/message/model/im_event_type.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';

class MediaDownloadBloc extends Bloc<MediaDownloadEvent, MediaDownloadState> {
  MediaDownloadBloc(this.item) : super(MediaDownloadState(item));
  final Message item;

  int? _progressJobId;
  int? _statusJobId;

  @override
  Future<void> close() {
    SxtManager.instance.cancelJob(_progressJobId);
    SxtManager.instance.cancelJob(_statusJobId);
    return super.close();
  }

  @override
  Stream<MediaDownloadState> mapEventToState(MediaDownloadEvent event) async* {
    if (event is MediaDownloadInitEvent) {
      _listenDownloadProgress();
      _listenDownloadState();
    } else if (event is MediaDownloadProgressEvent) {
      yield MediaDownloadState(event.message, event.progress);
    }
  }

  void _listenDownloadProgress() {
    SxtMessagePlugin.setNotifyFileProgressListener(
            FileProgressListener(onChanged: (event) {
      if (event.message?.code == item.code &&
          event.progress != state.progress) {
        add(MediaDownloadProgressEvent(state.message, event.progress));
        if (event.progress == 100) {
          Future.delayed(500.milliseconds, () {
            add(MediaDownloadProgressEvent(state.message, null));
          });
        }
      }
    }), item.talker!)
        .then((job) => _progressJobId = job.jobId);
  }

  void _listenDownloadState() {
    SxtMessagePlugin.setMessageStateUpdateListener(
            MessageStateUpdateListener(onChanged: (event) {
      if (event.message?.code == item.code &&
          event.type == IMEventType.DOWNLOAD_SUCCESS) {
        add(MediaDownloadProgressEvent(event.message!, null));
      }
    }), item.talker!)
        .then((job) => _statusJobId = job.jobId);
  }
}
