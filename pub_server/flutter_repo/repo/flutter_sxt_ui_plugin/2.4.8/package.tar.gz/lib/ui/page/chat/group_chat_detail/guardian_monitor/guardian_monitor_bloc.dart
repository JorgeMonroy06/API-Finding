import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/guardian_monitor/guardian_monitor_event.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/guardian_monitor/guardian_monitor_state.dart';
import 'package:sxt_flutter_plugin/group/model/set_group_watch_param.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

class GuardianMonitorBloc
    extends Bloc<GuardianMonitorEvent, GuardianMonitorState> {
  GuardianMonitorBloc() : super(GuardianMonitorState([]));

  @override
  Stream<GuardianMonitorState> mapEventToState(
      GuardianMonitorEvent event) async* {
    if (event is GuardianMonitorInitEvent) {
      yield* _getGuardianMonitorState();
    } else if (event is GuardianMonitorSettingEvent) {
      yield* _updateGuardianMonitorState(event.param);
    }
  }

  bool isListening(SessionEntity sessionEntity) {
    return state.sessionEntityList.any((e) => e.code == sessionEntity.code);
  }

  Stream<GuardianMonitorState> _getGuardianMonitorState() async* {
    final job = await SxtGroupPlugin.getGroupWatchList();
    yield GuardianMonitorState(job.data ?? []);
  }

  Stream<GuardianMonitorState> _updateGuardianMonitorState(
      SetGroupWatchParam param) async* {
    if (param.isWatch! && state.sessionEntityList.length >= 2) {
      EasyLoading.showInfo('已达监听上限');
      return;
    }

    if (param.isWatch!) {
      state.sessionEntityList.add(param.sessionEntity!);
    } else {
      state.sessionEntityList
          .removeWhere((e) => e.code == param.sessionEntity!.code);
    }
    yield GuardianMonitorState(state.sessionEntityList);

    await SxtGroupPlugin.setGroupWatch(param);
    yield* _getGuardianMonitorState();
  }
}
