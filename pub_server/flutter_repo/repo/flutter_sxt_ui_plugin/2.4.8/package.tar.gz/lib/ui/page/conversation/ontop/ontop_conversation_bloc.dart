import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:flutter_sxt_ui_plugin/utils/prefrence_util.dart';
import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

part 'ontop_conversation_event.dart';
part 'ontop_conversation_state.dart';

class OnTopConversationBloc
    extends Bloc<OnTopConversationEvent, OnTopConversationState> {
  OnTopConversationBloc() : super(OnTopConversationState([]));

  @override
  Stream<OnTopConversationState> mapEventToState(
      OnTopConversationEvent event) async* {
    if (event is OnTopConversationInitEvent) {
      yield* _getOnTopConversationState();
    } else if (event is OnTopConversationSwitchEvent) {
      yield* _switchOnTopConversationState(event);
    }
  }

  bool isOnTopConversation(SessionEntity sessionEntity) {
    return state.onTopConversationList.contains(sessionEntity.code);
  }

  Stream<OnTopConversationState> _switchOnTopConversationState(
      OnTopConversationSwitchEvent event) async* {
    if (event.isOnTop) {
      state.onTopConversationList.add(event.sessionEntity.code!);
    } else {
      state.onTopConversationList.remove(event.sessionEntity.code);
    }
    PreferenceUtil.setOnTopConversationList(state.onTopConversationList);
    yield OnTopConversationState(state.onTopConversationList);
  }

  Stream<OnTopConversationState> _getOnTopConversationState() async* {
    final onTopConversationList =
        await PreferenceUtil.getOnTopConversationList();
    yield OnTopConversationState(onTopConversationList);
  }
}
