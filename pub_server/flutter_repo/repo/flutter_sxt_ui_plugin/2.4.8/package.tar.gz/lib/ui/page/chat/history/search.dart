import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';

class Search extends StatelessWidget {
  const Search({Key? key, this.onTap}) : super(key: key);

  final GestureTapCallback? onTap;

  @override
  Widget build(BuildContext context) => Container(
        color: Colors.grey[100],
        padding: const EdgeInsets.all(10),
        child: Material(
          color: Colors.white,
          borderRadius: BorderRadius.circular(6),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(6),
            child: SizedBox(
              height: 34,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    'images/ic_search_grey.png',
                    package: PACKAGE_NAME,
                  ),
                  const SizedBox(width: 4),
                  const Text(
                    '搜索',
                    style: TextStyle(color: Color(0xFFAAAAAA)),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}
