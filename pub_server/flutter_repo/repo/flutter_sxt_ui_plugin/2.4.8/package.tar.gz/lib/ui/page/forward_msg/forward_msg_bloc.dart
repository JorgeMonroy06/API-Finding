import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/ui/contact_list.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/message/model/conversation.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';
import 'package:sxt_flutter_plugin/model/job.dart';

part 'forward_msg_event.dart';

part 'forward_msg_state.dart';

class ForwardMsgBloc extends Bloc<ForwardMsgEvent, ForwardMsgState> {
  ForwardMsgBloc() : super(ForwardMsgState.initial());

  void inital() {
    add(Init());
  }

  @override
  Stream<ForwardMsgState> mapEventToState(ForwardMsgEvent event) async* {
    if (event is Init) {
      yield* _mapInitEventState(event);
    } else if (event is MultiSelectChange) {
      yield* _mapMultiSelectChangeEventState(event);
    } else if (event is Search) {
      yield* _mapSearchEventState(event);
    } else if (event is CheckChanged) {
      yield* _mapCheckChangedEventState(event);
    }
  }

  Stream<ForwardMsgState> _mapInitEventState(Init event) async* {
    Job<List<Conversation>> job = await SxtMessagePlugin.getConversationList();
    if (null != job.data && job.data!.length > 0) {
      List<String> codes = [];

      job.data?.forEach((element) {
        codes.add(DomainUtil.toCode(element.talker!.code!));
      });

      List<Contact> contactList = await ContactManager.instance
          .getContactsByCodes(codes, DataFilterBuilder())
          .take(2)
          .last;
      List<ContactListItem> list = [];
      contactList.forEach((element) {
        list.add(ContactListItem()
          ..contact = element
          ..isChecked = false);
      });
      yield state.copyWith(contactListItem: list);
    } else {
      yield state.copyWith(contactListItem: []);
    }
  }

  Stream<ForwardMsgState> _mapMultiSelectChangeEventState(
      MultiSelectChange event) async* {
    state.contactListItem?.forEach((element) {
      element.isChecked = false;
    });

    yield state.copyWith(
        isMultiSelectState: !state.isMultiSelectState!, selectContactList: []);
  }

  Stream<ForwardMsgState> _mapSearchEventState(Search event) async* {
    if (StringUtil.isEmpty(event.keyword)) {
      yield state.copyWith(searchedContactListItem: []);
      return;
    }

    List<ContactListItem> list = [];

    state.contactListItem?.forEach((element) {
      if ((element.contact?.name ?? "").contains(event.keyword) ||
          (element.contact?.nameSpell ?? "").contains(event.keyword)) {
        list.add(element);
      }
    });

    yield state.copyWith(searchedContactListItem: list);
  }

  Stream<ForwardMsgState> _mapCheckChangedEventState(
      CheckChanged event) async* {
    Contact contact = event.contact;
    if (event.isCheck) {
      if (!state.selectContactList!.contains(contact)) {
        state.selectContactList!.add(contact);
      }
    } else {
      for (final element in state.selectContactList!) {
        if (element.code == contact.code) {
          state.selectContactList!.remove(element);
          break;
        }
      }
    }
    for (final element in state.contactListItem!) {
      if (null != element.contact && element.contact!.code == contact.code) {
        element.isChecked = event.isCheck;
        break;
      }
    }
    List<Contact> newList = [];
    newList.addAll(state.selectContactList!);

    yield state.copyWith(selectContactList: newList);
  }
}
