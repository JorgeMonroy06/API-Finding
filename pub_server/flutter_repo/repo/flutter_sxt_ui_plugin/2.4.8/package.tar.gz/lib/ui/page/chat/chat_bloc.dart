import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter_imagepicker_plugin/flutter_imagepicker_plugin.dart';
import 'package:flutter_sxt_ui_plugin/bean/message_list_bean.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/event/receive_msg_event.dart';
import 'package:flutter_sxt_ui_plugin/manager/eventbus_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/flutter_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/log/logger.dart';
import 'package:flutter_sxt_ui_plugin/manager/multimeeting_listener.dart';
import 'package:flutter_sxt_ui_plugin/manager/smart_trans/tarns_voice_to_text_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/file_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/account/model/sxt_account.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';
import 'package:sxt_flutter_plugin/group/listener/group_info_update_listener.dart';
import 'package:sxt_flutter_plugin/group/listener/group_member_update_listener.dart';
import 'package:sxt_flutter_plugin/group/model/get_group_member_param.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/group/model/group_member.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_manager.dart';
import 'package:sxt_flutter_plugin/message/listener/file_progress_listener.dart';
import 'package:sxt_flutter_plugin/message/listener/message_state_update_listener.dart';
import 'package:sxt_flutter_plugin/message/listener/message_update_listener.dart';
import 'package:sxt_flutter_plugin/message/model/attachment.dart';
import 'package:sxt_flutter_plugin/message/model/audio_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/file_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/im_event_type.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/pic_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/query_msg_param.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';
import 'package:sxt_flutter_plugin/message/model/set_conv_unread_count_param.dart';
import 'package:sxt_flutter_plugin/message/model/state_type.dart';
import 'package:sxt_flutter_plugin/message/model/video_attachment.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';
import 'package:sxt_flutter_plugin/model/job.dart';
import 'package:sxt_flutter_plugin/model/modification_event.dart';
import 'package:sxt_flutter_plugin/model/modification_event_type.dart';
import 'package:sxt_flutter_plugin/ptt/listener/ptt_talk_listener.dart';
import 'package:sxt_flutter_plugin/ptt/model/ptt_talk_type.dart';
import 'package:sxt_flutter_plugin/ptt/sxt_ptt_plugin.dart';

part 'chat_event.dart';

part 'chat_state.dart';

class ChatBloc extends Bloc<ChatEvent, ChatState> {
  bool isPoped = false;
  bool isFromRecord = false;
  SessionEntity sessionEntity;
  int? pttListenerJobId;
  int? conversationUpdateJobId;
  int? groupInfoUpdateJobId;
  int? groupMemberUpdateJobId;
  int? notifyFileProgressJobId;
  int? msgStateUpdateJobId;
  int? msgUpdateJobId;
  BuildContext buildContext;
  Map<String, dynamic>? meetingInfo;

  ChatBloc(this.sessionEntity, this.buildContext) : super(ChatState().init());

  void inital(bool? isFromRecord, int? msgTime, int? msgId) {
    SxtLogger.instance.info("ChatBloc get data :" + jsonEncode(this.sessionEntity.toJson()));

    add(InitEvent());
    if (isFromRecord ?? false) {
      // add(LoadNextPageMessageEvent(msgId ?? 0, msgTime ?? 0));
      add(LoadNextPageMessageEvent(0, msgTime ?? 0));
    } else {
      add(LoadCurrentPageMessageEvent());
    }

    //消息监听，用于更新最新消息
    SxtMessagePlugin.setMessageUpdateListener(MessageUpdateListener(onChanged: (event) {
      if (event.data!.msgType == MsgType.AUDIO) return;

      print("aaaa send UpdateMsgListEvent msg code : ${event.data!.code!} ");
      add(UpdateMsgListEvent(event));
    }), sessionEntity)
        .then((value) {
      msgUpdateJobId = value.jobId;
    });

    if (sessionEntity.sessionType == SessionType.USER) {
    } else {
      //群组设置
      SxtGroupPlugin.setGroupInfoUpdateListener(GroupInfoUpdateListener(onChanged: (ModificationEvent<Group> event) {
        if (DomainUtil.toCode(event.data!.groupCode) != DomainUtil.toCode(sessionEntity.code!)) return; //如果群组code不一致直接返回

        if (event.type == ModificationEventType.DATA_UPDATE) {
          add(InitEvent());
        } else if (event.type == ModificationEventType.DATA_DELETE) {
          //视信通SDK的bug，会回调两次，所以必须要用isPoped变量记录，防止多次pop
          if (!isPoped) {
            isPoped = true;
            print("aaaa ChatBloc PopEvent");
            add(PopEvent("当前群组已被删除"));

            FlutterManager.instance.notifyGroupDelete(event.data!.groupCode);
          }
        }
      })).then((value) {
        groupInfoUpdateJobId = value.jobId;
      });

      SxtGroupPlugin.setGroupMemberUpdateListener(GroupMemberUpdateListener(onChanged: (List<GroupMember> groupMemberList) {
        for (int i = 0; i < groupMemberList.length; i++) {
          GroupMember groupMember = groupMemberList[i];
          if (groupMember.groupCode != sessionEntity.code!) {
            return;
          }
          if (null != state.currentAccount && state.currentAccount!.code == groupMemberList[i].code) {
            continue;
          }
        }
        add(InitEvent());
      })).then((value) {
        groupMemberUpdateJobId = value.jobId;
      });

      FlutterManager.instance.multiMeetingListener = MultiMeetingListener(onStart: () {
        SxtLogger.instance.info("ChatBloc MultiMeetingUpdate onStart");

        Future.delayed(Duration(milliseconds: 500), () {
          add(MultiMeetingUpdate());
        });
      }, onStop: () {
        SxtLogger.instance.info("ChatBloc MultiMeetingUpdate onStop");
        Future.delayed(Duration(milliseconds: 500), () {
          add(MultiMeetingUpdate());
        });
      }, onChanged: () {
        SxtLogger.instance.info("ChatBloc MultiMeetingUpdate onChanged");
        Future.delayed(Duration(milliseconds: 500), () {
          add(MultiMeetingUpdate());
        });
      });
    }
    //文件下载监听
    SxtMessagePlugin.setNotifyFileProgressListener(FileProgressListener(onChanged: (event) {
      Message currentMsg = event.message!;
      for (int i = 0; i < state.msgList.list.length; i++) {
        Message msg = state.msgList.list[i];
        if (msg.code == currentMsg.code) {
          if (event.progress == state.fileProgressMap[msg.code!]) {
            // print("aaaa send UpdateProgressEvent filter progress :  ${event.progress!.toDouble()}");
            break;
          }
          print("aaaa send UpdateProgressEvent progress :  ${event.progress!.toDouble()}");
          add(UpdateProgressEvent(currentMsg, event.progress!.toDouble()));
          break;
        }
      }
    }), sessionEntity)
        .then((value) {
      notifyFileProgressJobId = value.jobId;
    });
    //消息状态变化监听
    SxtMessagePlugin.setMessageStateUpdateListener(MessageStateUpdateListener(onChanged: (event) {
      if (event.message!.msgType == MsgType.AUDIO) return;

      Message currentMsg = event.message!;
      for (int i = 0; i < state.msgList.list.length; i++) {
        Message msg = state.msgList.list[i];
        if (msg.code == currentMsg.code) {
          state.msgList.list[i] = currentMsg;
          switch (event.type) {
            case IMEventType.SENDING:
            case IMEventType.SEND_SUCCESS:
            case IMEventType.SEND_FAILURE:
            case IMEventType.DOWNLOAD_FAILURE:
            case IMEventType.DOWNLOADING:
            case IMEventType.THUMB_DOWNLOAD_FAILURE:
            case IMEventType.THUMB_DOWNLOAD_SUCCESS:
              print("aaaa send UpdateMessageEvent event.type : ${event.type} , msg code : ${currentMsg.code}");
              add(UpdateMessageEvent(currentMsg));
              break;
            case IMEventType.DOWNLOAD_SUCCESS:
              print("aaaa send UpdateMessageEvent event.type : ${event.type} ,  msg code : ${currentMsg.code}");
              add(UpdateMessageEvent(currentMsg));
              add(OpenFileEvent(currentMsg));
              break;
          }
          break;
        }
      }
    }), sessionEntity)
        .then((value) {
      msgStateUpdateJobId = value.jobId;
    });

    //设置PTT对讲监听
    SxtPttPlugin.setPttTalkListener(PttTalkListener(onEvent: (event) {
      if (event.room?.talker?.code != sessionEntity.code) {
        return;
      }
      switch (event.type) {
        case PttTalkType.CALLEE_START_SPEAK:
        case PttTalkType.LISTEN_INSERT:
          if ((event.room?.isSpeakingState) ?? false) {
            //开始讲话
            add(SpeakStartEvent(event.room!.speaker!));
          }
          break;
        case PttTalkType.LISTEN_INTERRUPTED:
        case PttTalkType.CALLEE_END_SPEAK:
        case PttTalkType.STOP_SPEAK_ERR:
          //讲话结束
          add(SpeakEndEvent());
          break;
        case PttTalkType.SPEAK_INTERRUPTED:
          ToastUtil.showToast("讲话被打断");
          break;
      }
    })).then((value) {
      pttListenerJobId = value.jobId;
    });
  }

  @override
  Future<void> close() {
    SxtManager.instance.cancelJob(pttListenerJobId);
    SxtManager.instance.cancelJob(conversationUpdateJobId);
    SxtManager.instance.cancelJob(groupInfoUpdateJobId);
    SxtManager.instance.cancelJob(groupMemberUpdateJobId);
    SxtManager.instance.cancelJob(notifyFileProgressJobId);
    SxtManager.instance.cancelJob(msgStateUpdateJobId);
    SxtManager.instance.cancelJob(msgUpdateJobId);
    FlutterManager.instance.multiMeetingListener = null;

    SetConvUnreadCountParam param = SetConvUnreadCountParam();
    param.sessionEnitity = sessionEntity;
    param.count = 0;
    SxtMessagePlugin.setConvUnreadCount(param).then((value) {});
    return super.close();
  }

  @override
  Stream<ChatState> mapEventToState(ChatEvent event) async* {
    if (event is LoadCurrentPageMessageEvent) {
      yield* loadCurrentPageMessage(event);
    } else if (event is LoadNextPageMessageEvent) {
      yield* loadNextPageMessage(event);
    } else if (event is LoadPreviousPageMessageEvent) {
      yield* loadPreviousPageMessage(event);
    } else if (event is InitEvent) {
      yield* init(event);
    } else if (event is UpdateUnreadCount) {
      yield* updateUnreadCount(event);
    } else if (event is PopEvent) {
      yield* popEvent(event);
    } else if (event is UpdateMessageEvent) {
      yield* updateMessage(event);
    } else if (event is OpenFileEvent) {
      yield* openFile(event);
    } else if (event is UpdateProgressEvent) {
      yield* updateProgress(event);
    } else if (event is UpdateMsgListEvent) {
      yield* updateMsgList(event);
    } else if (event is MultiMeetingUpdate) {
      yield* multiMeetingUpdate(event);
    } else if (event is DeleteMsg) {
      yield* deleteMsg(event);
    } else if (event is TransVoiceToText) {
      yield* transVoiceToText(event);
    } else if (event is HideTrans) {
      yield* hideTrans(event);
    } else if (event is SpeakStartEvent) {
      yield* speakStartEvent(event);
    } else if (event is SpeakEndEvent) {
      yield* speakEndEvent(event);
    }
  }

  Stream<ChatState> loadCurrentPageMessage(LoadCurrentPageMessageEvent event) async* {
    SxtLogger.instance.info("ChatBloc loadMessage start");
    Job<List<Message>> job = await SxtMessagePlugin.getMsgDesc(QueryMsgParam()
      ..userCode = sessionEntity.code
      ..sessionType = sessionEntity.sessionType
      ..msgCode = 0
      ..msgCount = 50);

    List<Message> list = [];
    List<Message> newList = List.from(job.data!);
    for (int i = 0; i < newList.length; i++) {
      if (newList[i].msgType != MsgType.AUDIO) {
        list.add(newList[i]);
      }
    }

    SxtLogger.instance.info("ChatBloc loadMessage success ");
    yield state.clone()
      ..msgList = MessageListBean(list)
      ..hasNextPageMessage = false
      ..hasPreviousPageMessage = true;
  }

  Stream<ChatState> loadPreviousPageMessage(LoadPreviousPageMessageEvent event) async* {
    List<Message> list = [];
    list.addAll(state.historyMsgList.list);

    Job<List<Message>> job = await SxtMessagePlugin.getMsgDesc(QueryMsgParam()
      ..userCode = sessionEntity.code
      ..sessionType = sessionEntity.sessionType
      ..msgCode = event.firstMsg.code
      ..msgTime = event.firstMsg.createTime
      ..msgCount = 50);

    List<Message> newList = List.from(job.data!.reversed);
    for (int i = 0; i < newList.length; i++) {
      if (newList[i].msgType != MsgType.AUDIO) {
        list.add(newList[i]);
      }
    }

    yield state.clone()
      ..historyMsgList = MessageListBean(list)
      ..isLoadHistoryMessageOperate = true
      ..hasPreviousPageMessage = job.data?.length == 50;
  }

  Stream<ChatState> loadNextPageMessage(LoadNextPageMessageEvent event) async* {
    SxtLogger.instance.info("ChatBloc loadNextPageMessage start");
    List<Message> list = [];
    list.addAll(state.msgList.list);

    Job<List<Message>> job = await SxtMessagePlugin.getMsgAsc(QueryMsgParam()
      ..userCode = sessionEntity.code
      ..sessionType = sessionEntity.sessionType
      ..msgCount = 50
      ..msgCode = event.msgId
      ..msgTime = event.msgTime);

    List<Message> newList = List.from(job.data!);
    for (int i = 0; i < newList.length; i++) {
      if (newList[i].msgType != MsgType.AUDIO) {
        list.add(newList[i]);
      }
    }

    SxtLogger.instance.info("ChatBloc loadNextPageMessage success ");
    yield state.clone()
      ..msgList = MessageListBean(list)
      ..hasNextPageMessage = job.data!.length >= 50
      ..isLoadNextPageMessageOperate = true;
  }

  Stream<ChatState> updateUnreadCount(UpdateUnreadCount event) async* {
    yield state.clone()..unReadCount = event.unreadCount;
  }

  Stream<ChatState> popEvent(PopEvent event) async* {
    yield state.clone()
      ..status = EventStatus.popPage
      ..message = event.message;
  }

  Stream<ChatState> init(InitEvent event) async* {
    SxtLogger.instance.info("ChatBloc init start ");
    //设置已读
    SetConvUnreadCountParam param = SetConvUnreadCountParam();
    param.sessionEnitity = sessionEntity;
    param.count = 0;
    SxtMessagePlugin.setConvUnreadCount(param).then((value) {
      SxtLogger.instance.info("ChatBloc setConvUnreadCount success ");
    });

    SxtLogger.instance.info("ChatBloc getRoom start ");
    SxtPttPlugin.getRoom(sessionEntity).then((value) {
      SxtLogger.instance.info("ChatBloc getRoom success ");
      var room = value.data;
      if ((room?.isSpeakingState ?? false) && (null != room?.speaker)) {
        add(SpeakStartEvent(room!.speaker!));
      }
      SxtPttPlugin.joinAudioRoom(room!.roomCode!).then((value) {
        DataManager.instance.setLastActiveRoomCode(room.roomCode!);
        SxtLogger.instance.info("ChatBloc joinAudioRoom success ");
      }).onError((error, stackTrace) {
        SxtLogger.instance.error("ChatBloc joinAudioRoom failed ", error);
      });
    }).onError((error, stackTrace) {
      SxtLogger.instance.error("ChatBloc getRoom failed ", error);
    });

    if (sessionEntity.sessionType == SessionType.USER) {
      //获取当前用户
      SxtAccountPlugin.getCurrentUser().then((value) {
        state.currentAccount = value;

        //删除当前用户和聊天人缓存，防止信息未及时更新
        DataManager.instance.removeCache(DomainUtil.toCode(sessionEntity.code));
        DataManager.instance.removeCache(DomainUtil.toCode(value.code));
      });

      List<Contact> contactList = await ContactManager.instance
          .getContactsByCodes([DomainUtil.toCode(sessionEntity.code)], DataFilterBuilder())
          .where((event) {
            return event != null && event.length > 0;
          })
          .take(1)
          .first;

      Contact contact = contactList[0];
      yield state.clone()..contact = contact;
    } else if (sessionEntity.sessionType == SessionType.GROUP) {
      //获取当前用户
      state.currentAccount = await SxtAccountPlugin.getCurrentUser();
      //删除当前用户和聊天人缓存，防止信息未及时更新
      DataManager.instance.removeCache(DomainUtil.toCode(state.currentAccount!.code));

      Job<Group> job = await SxtGroupPlugin.getGroupInfo(sessionEntity.code!);
      if (job.data!.stateType != StateType.NORMAL) {
        if (!isPoped) {
          isPoped = true;
          print("aaaa getGroupInfo PopEvent");
          add(PopEvent("当前群组已被删除"));

          FlutterManager.instance.notifyGroupDelete(sessionEntity.code!);
        }
        SxtLogger.instance.info("ChatBloc group deleted");
        return;
      }

      try {
        GetGroupMemberParam param = GetGroupMemberParam(groupCode: sessionEntity.code!, count: 10000);
        Job<List<GroupMember>> job2 = await SxtGroupPlugin.getGroupMember(param);

        bool containsSelf = false;
        List<String> codes = [];
        job2.data?.forEach((element) {
          codes.add(DomainUtil.toCode(element.code));
          if (DomainUtil.toCode(element.code) == DomainUtil.toCode(state.currentAccount!.code)) {
            containsSelf = true;
          }
        });
        if (!containsSelf) {
          if (!isPoped) {
            isPoped = true;
            print("aaaa getGroupMember PopEvent");
            add(PopEvent("您已被移出该群组"));

            FlutterManager.instance.notifyGroupDelete(sessionEntity.code!);
          }
          SxtLogger.instance.info("ChatBloc group removed");
          return;
        }

        yield* ContactManager.instance.getContactsByCodes(codes, DataFilterBuilder()).where((element) {
          return null != element && element.isNotEmpty;
        }).map((event) {
          return state.clone()
            ..group = job.data
            ..groupMemberCount = event.length;
        });
      } catch (e) {
        print(e);
      }

      SxtLogger.instance.info("ChatBloc getMultiMeetingInfo start");
      try {
        meetingInfo = await FlutterManager.instance.getMultiMeetingInfo(sessionEntity.code!);
        String startName = "";
        if (null != meetingInfo && !StringUtil.isEmpty(meetingInfo!["code"])) {
          String? code = DomainUtil.toCode(meetingInfo!["code"]);
          List<Contact> contactList =
              await ContactManager.instance.getContactsByCodes([code], DataFilterBuilder()).where((event) => (null != event && event.isNotEmpty)).take(1).first;

          if (null != contactList) {
            startName = contactList[0].name!;
          }
        }
        SxtLogger.instance.info("ChatBloc getMultiMeetingInfo success");
        bool isCalling = false;
        if (meetingInfo != null) {
          isCalling = meetingInfo!["isCalling"];
        }
        print("aaaa isCalling:$isCalling");
        yield state.clone()
          ..isAcceptCalling = isCalling
          ..isMultiCalling = meetingInfo != null
          ..multiMeetingCode = meetingInfo == null ? "" : startName
          ..isMultiMeetingVideo = meetingInfo == null ? false : meetingInfo!["isVideo"];
      } catch (e) {
        SxtLogger.instance.error("ChatBloc getMultiMeetingInfo failed", e);
      }
    }

    // SxtMessagePlugin.getAllConvUnreadCount().then((value) {
    //   add(UpdateUnreadCount(value.data ?? 0));
    // });
  }

  Stream<ChatState> updateMessage(UpdateMessageEvent event) async* {
    yield state.clone()
      ..refreshMessage = event.message
      ..canScrollList = event.canScrollList
      ..status = EventStatus.update;
  }

  Stream<ChatState> updateMsgList(UpdateMsgListEvent event) async* {
    List<Message<Attachment>> list = [];
    list.addAll(state.msgList.list);

    ModificationEvent<Message> modificationEvent = event.event;
    Message currentMsg = modificationEvent.data!;
    switch (modificationEvent.type) {
      case ModificationEventType.DATA_ADD:
        // if (state.hasNextPageMessage) {
        //   return;
        // }

        //先过滤，防止有重复消息，Android视信通SDK的bug
        for (int i = 0; i < state.msgList.list.length; i++) {
          Message msg = state.msgList.list[i];
          if (msg.code == currentMsg.code) {
            return;
          }
        }
        for (int i = 0; i < state.historyMsgList.list.length; i++) {
          Message msg = state.historyMsgList.list[i];
          if (msg.code == currentMsg.code) {
            return;
          }
        }
        list.add(currentMsg);
        yield state.clone()..msgList = MessageListBean(list);

        // SxtEventBusManager.instance.eventBus?.fire(ReceiveMsgEvent());
        break;
      case ModificationEventType.DATA_DELETE:
        for (int i = 0; i < state.msgList.list.length; i++) {
          Message msg = state.msgList.list[i];
          if (msg.code == currentMsg.code) {
            list.remove(msg);
            yield state.clone()..msgList = MessageListBean(list);
            break;
          }
        }
        break;
      case ModificationEventType.DATA_UPDATE:
        for (int i = 0; i < state.msgList.list.length; i++) {
          Message msg = state.msgList.list[i];
          if (msg.code == currentMsg.code) {
            list[i] = currentMsg;
            yield state.clone()
              ..refreshMessage = currentMsg
              ..status = EventStatus.update;
            break;
          }
        }
        break;
    }
  }

  Stream<ChatState> updateProgress(UpdateProgressEvent event) async* {
    state.fileProgressMap[event.message.code!] = event.progress;
    yield state.clone()
      ..refreshMessage = event.message
      ..status = EventStatus.update;
  }

  Stream<ChatState> deleteMsg(DeleteMsg event) async* {
    Message message = event.message;
    for (int i = 0; i < state.msgList.list.length; i++) {
      if (message.code == state.msgList.list[i].code) {
        state.msgList.list.removeAt(i);
        break;
      }
    }
    for (int i = 0; i < state.historyMsgList.list.length; i++) {
      if (message.code == state.historyMsgList.list[i].code) {
        state.historyMsgList.list.removeAt(i);
        break;
      }
    }
    yield state.clone()
      ..msgList = MessageListBean(state.msgList.list)
      ..historyMsgList = MessageListBean(state.historyMsgList.list);
  }

  Stream<ChatState> multiMeetingUpdate(MultiMeetingUpdate event) async* {
    try {
      SxtLogger.instance.info("ChatBloc getMultiMeetingInfo start");
      meetingInfo = await FlutterManager.instance.getMultiMeetingInfo(sessionEntity.code!);
      SxtLogger.instance.info("ChatBloc getMultiMeetingInfo success");
    } catch (e) {
      SxtLogger.instance.error("ChatBloc getMultiMeetingInfo failed", e);
    }
    print("aaaa meetingInfo:$meetingInfo");

    if (meetingInfo == null) {
      yield state.clone()
        ..isAcceptCalling = false
        ..isMultiCalling = false
        ..multiMeetingCode = "";
      return;
    }

    String startName = "";
    String code = meetingInfo!['code'];
    if (code != state.currentAccount?.code) {
      if (!StringUtil.isEmpty(code)) {
        List<Contact> contactList = await ContactManager.instance
            .getContactsByCodes([DomainUtil.toCode(code)], DataFilterBuilder())
            .where((event) => (null != event && event.isNotEmpty))
            .take(1)
            .first;

        if (null != contactList) {
          startName = contactList[0].name!;
        }
      }
    }
    bool isCalling = false;
    if (meetingInfo != null) {
      isCalling = meetingInfo!["isCalling"];
    }
    print("aaaa isCalling:$isCalling");
    yield state.clone()
      ..isAcceptCalling = isCalling
      ..isMultiCalling = meetingInfo != null
      ..multiMeetingCode = startName
      ..isMultiMeetingVideo = meetingInfo!['isVideo'];
  }

  Stream<ChatState> openFile(OpenFileEvent event) async* {
    yield state.clone();
    Message message = event.message;
    switch (message.msgType) {
      case MsgType.OTHERS:
        FileAttachment attachment = message.attachment as FileAttachment;
        FileUtil.openFile(attachment.path!);
        break;
      case MsgType.PICTURE:
        PicAttachment attachment = message.attachment as PicAttachment;
        KDAssetPicker.playImage(buildContext, attachment.path!, isLocal: true);
        break;
      case MsgType.VIDEO_FILE:
        VideoAttachment attachment = message.attachment as VideoAttachment;
        KDAssetPicker.playVideo(buildContext, attachment.path!, true);
        break;
      case MsgType.VOICE_FILE:
        //如果是语音转文字的下载则直接继续转文字
        if (state.smartTransList.containsKey(message.code)) {
          add(TransVoiceToText(message));
        }
        break;
    }
  }

  //语音转文字
  Stream<ChatState> transVoiceToText(TransVoiceToText event) async* {
    Message message = event.message;

    SmartTransBean smartTransBean = SmartTransBean();
    smartTransBean.state = 0;
    smartTransBean.text = ".";
    state.smartTransList[message.code!] = smartTransBean;

    add(UpdateMessageEvent(message, canScrollList: true));

    final AudioAttachment attachment = message.attachment as AudioAttachment;

    if (!File(attachment.path!).existsSync()) {
      SxtMessagePlugin.downloadMsgAttachment(message);
      DataManager.instance.addDownloading(message.code!);
      return;
    }

    int index = 4;
    final Timer _timer = Timer.periodic(const Duration(milliseconds: 800), (timer) {
      smartTransBean.state = 0;
      final int length = index % 3;
      smartTransBean.text = "";
      for (int i = 0; i <= length; i++) {
        smartTransBean.text = (smartTransBean.text ?? "") + ".";
      }

      index++;
      add(UpdateMessageEvent(message));
    });

    //调用接口
    TransVoiceToTextHelper().runSxtMethod((message) {
      _timer.cancel();
      //成功
      smartTransBean.state = 1;
      smartTransBean.text = (message.attachment as AudioAttachment).content;
      add(UpdateMessageEvent(message));
    }, (text) {
      _timer.cancel();
      print(text);
      state.smartTransList.removeWhere((key, value) => (key == message.code!));
      ToastUtil.showToast(text);
      add(UpdateMessageEvent(message));
    }, message);
  }

  Stream<ChatState> hideTrans(HideTrans event) async* {
    Message message = event.message;
    state.smartTransList.removeWhere((key, value) => (key == message.code!));
    add(UpdateMessageEvent(message));
  }

  Stream<ChatState> speakStartEvent(SpeakStartEvent event) async* {
    SxtLogger.instance.info("ChatBloc speakStartEvent event code: ${event.sessionEntity.code}");
    String startName = "";
    if (!StringUtil.isEmpty(event.sessionEntity.code)) {
      //是自己
      if (state.currentAccount!.code == event.sessionEntity.code) {
        return;
      }
      List<Contact> contactList = await ContactManager.instance
          .getContactsByCodes([DomainUtil.toCode(event.sessionEntity.code)], DataFilterBuilder())
          .where((event) => (null != event && event.isNotEmpty))
          .take(1)
          .first;

      if (null != contactList && contactList.isNotEmpty) {
        startName = contactList[0].name!;
        event.sessionEntity.name = startName;
        yield state.clone()..pttSpeaker = event.sessionEntity;
      }
    }
  }

  Stream<ChatState> speakEndEvent(SpeakEndEvent event) async* {
    SxtLogger.instance.info("ChatBloc speakEndEvent event ");
    if (state.pttSpeaker != null) {
      yield state.clone()..pttSpeaker = null;
    }
  }
}
