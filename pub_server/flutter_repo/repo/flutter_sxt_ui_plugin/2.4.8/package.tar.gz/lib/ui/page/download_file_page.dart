import 'dart:io';
import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/utils/file_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/forward_msg_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/favorite/model/favorite.dart';
import 'package:sxt_flutter_plugin/favorite/model/favorite_event.dart';
import 'package:sxt_flutter_plugin/favorite/model/favorite_event_listener.dart';
import 'package:sxt_flutter_plugin/favorite/model/favorite_event_type.dart';
import 'package:sxt_flutter_plugin/favorite/model/favorite_form.dart';
import 'package:sxt_flutter_plugin/favorite/model/favorite_progress_listener.dart';
import 'package:sxt_flutter_plugin/favorite/sxt_favorite_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_manager.dart';
import 'package:sxt_flutter_plugin/message/listener/file_progress_listener.dart';
import 'package:sxt_flutter_plugin/message/listener/message_state_update_listener.dart';
import 'package:sxt_flutter_plugin/message/model/attachment.dart';
import 'package:sxt_flutter_plugin/message/model/file_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/im_event.dart';
import 'package:sxt_flutter_plugin/message/model/im_event_type.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';
import 'package:sxt_flutter_plugin/message/model/send_state.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';
import 'package:sxt_flutter_plugin/model/job.dart';

/// @author newtab on 2021/9/17

class DownloadFilePage extends StatefulWidget {
  final Message<Attachment>? msg;
  final Favorite<Attachment>? favorite;

  const DownloadFilePage({Key? key, this.msg, this.favorite}) : super(key: key);

  @override
  _DownloadFilePageState createState() => _DownloadFilePageState();
}

class _DownloadFilePageState extends State<DownloadFilePage> {
  String? title;
  FileAttachment? fileAttachment;

  @override
  void initState() {
    if (widget.msg == null && widget.favorite == null) {
      ToastUtil.showToast("参数为空");
      WidgetsBinding.instance?.addPostFrameCallback((timeStamp) {
        Navigator.of(context).pop();
      });
      return;
    }

    if (widget.msg != null) {
      fileAttachment = widget.msg!.attachment as FileAttachment;
    } else {
      fileAttachment = widget.favorite!.attachment as FileAttachment;
    }
    title = fileAttachment?.filename;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.of(context).pop(fileAttachment?.path);
        return true;
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: BackgroundImageAppbar(
          title: title ?? "",
          leadingWidget: Container(
            padding: const EdgeInsets.only(left: 12, right: 16, top: 8, bottom: 8),
            child: InkWell(
              child: ImageHelper.assetImage(
                "ic_back.png",
              ),
              onTap: () {
                Navigator.of(context).pop(fileAttachment?.path);
              },
            ),
          ),
          trailingWidget: GestureDetector(
            onTap: () {
              if (widget.msg != null) {
                _showMore();
              } else {
                _showMoreByFav();
              }
            },
            child: Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: const Icon(
                CupertinoIcons.ellipsis,
                color: Colors.white,
                size: 22,
              ),
            ),
          ),
        ),
        body: Container(
          child: Column(
            children: [
              Expanded(
                child: Container(
                  alignment: Alignment.topLeft,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 50,
                    vertical: 50,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Image.asset(
                        FileUtil.getIconByFileType(
                          _getFileName(),
                        ),
                        width: 58,
                        height: 58,
                        package: PACKAGE_NAME,
                        fit: BoxFit.cover,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        _getFileName(),
                        style: const TextStyle(
                          color: Color(0xff333333),
                          fontSize: 20,
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        formatBytes(_getFileSize(), 2),
                        style: const TextStyle(
                          color: Color(0xff999999),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              DownloadingWidget(
                msg: widget.msg,
                favorite: widget.favorite,
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 6,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showMore() {
    Widget forward = GestureDetector(
      onTap: () async {
        Navigator.of(context).pop();
        if (widget.favorite != null) {
          ForwardMsgHelper.forwardMsg(
            context,
            widget.favorite!.attachment!,
          );
        } else {
          ForwardMsgHelper.forwardMsg(
            context,
            widget.msg!.attachment!,
          );
        }
      },
      child: Container(
        margin: const EdgeInsets.only(right: 30),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(
              ImageHelper.wrapAssets("icon_forward.png"),
              package: PACKAGE_NAME,
              width: 56,
              height: 56,
            ),
            const SizedBox(
              height: 5,
            ),
            const Text(
              "转发",
              style: TextStyle(
                fontSize: 12,
                color: Color(0xff6D6D6E),
              ),
            ),
          ],
        ),
      ),
    );

    Widget fav = GestureDetector(
      onTap: () async {
        Navigator.of(context).pop();
        try {
          final FavoriteForm favoriteForm = FavoriteForm(
            talker: widget.msg!.talker,
            sender: widget.msg!.sender,
            srcSvrId: widget.msg!.serverId,
            msgCode: widget.msg!.code,
            extra: widget.msg!.extension,
          );

          await SxtFavoritePlugin.addFavorite(favoriteForm);
          ToastUtil.showToast("已收藏");
        } catch (e) {
          ToastUtil.showToast("收藏失败");
        }
      },
      child: Container(
        margin: const EdgeInsets.only(right: 30),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              color: Colors.white,
              child: Image.asset(
                ImageHelper.wrapAssets("icon_collect_untransparent.png"),
                package: PACKAGE_NAME,
                width: 56,
                height: 56,
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            const Text(
              "收藏",
              style: TextStyle(
                fontSize: 12,
                color: Color(0xff6D6D6E),
              ),
            ),
          ],
        ),
      ),
    );

    showModalBottomSheet<bool>(
      isDismissible: true,
      enableDrag: false,
      context: context,
      builder: (context) {
        return Container(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                  height: 120,
                  padding: const EdgeInsets.symmetric(
                    vertical: 20,
                    horizontal: 24,
                  ),
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(10),
                    ),
                    color: Color(0xffF6F7F8),
                  ),
                  child: ListView(
                    physics: const BouncingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    children: [
                      forward,
                      fav,
                    ],
                  )),
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Container(
                  color: Colors.white,
                  width: MediaQuery.of(context).size.width,
                  padding: const EdgeInsets.symmetric(
                    vertical: 15,
                  ),
                  alignment: Alignment.center,
                  child: const Text(
                    "取消",
                    style: TextStyle(
                      color: Color(0xff333333),
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showMoreByFav() {
    showModalBottomSheet<bool>(
      isDismissible: true,
      enableDrag: false,
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(10),
        ),
      ),
      backgroundColor: Colors.white,
      builder: (context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            InkWell(
              onTap: () {
                Navigator.pop(context);

                if (widget.favorite != null && widget.favorite!.attachment != null) {
                  ForwardMsgHelper.forwardMsg(
                    context,
                    widget.favorite!.attachment!,
                  );
                }
              },
              child: Container(
                width: MediaQuery.of(context).size.width,
                padding: const EdgeInsets.symmetric(
                  vertical: 15,
                ),
                alignment: Alignment.center,
                child: const Text(
                  "转发",
                  style: TextStyle(
                    color: Color(0xff000000),
                    fontSize: 16,
                  ),
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: 1,
              color: const Color(0xffF5F5F5),
            ),
            InkWell(
              onTap: () async {
                try {
                  await SxtFavoritePlugin.deleteFavorite(widget.favorite!.favoriteId!);
                  Navigator.of(context).popUntil((route) {
                    if (route.settings.name == "/fav_home_page") {
                      (route.settings.arguments as Map)["result"] = widget.favorite!.favoriteId;
                      return true;
                    } else {
                      return false;
                    }
                  });
                } catch (e) {
                  ToastUtil.showToast("取消收藏失败");
                }
              },
              child: Container(
                width: MediaQuery.of(context).size.width,
                padding: const EdgeInsets.symmetric(
                  vertical: 15,
                ),
                alignment: Alignment.center,
                child: const Text(
                  "取消收藏",
                  style: TextStyle(
                    color: Color(0xffFF4B34),
                    fontSize: 16,
                  ),
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: 5,
              color: Color(0xffF5F5F5),
            ),
            InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Container(
                width: MediaQuery.of(context).size.width,
                padding: const EdgeInsets.symmetric(
                  vertical: 15,
                ),
                alignment: Alignment.center,
                child: const Text(
                  "取消",
                  style: TextStyle(
                    color: Color(0xff333333),
                    fontSize: 16,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  int _getFileSize() {
    if (widget.msg != null) {
      return (widget.msg!.attachment as FileAttachment).size!;
    }
    return (widget.favorite!.attachment as FileAttachment).size!;
  }

  String _getFileName() {
    if (widget.msg != null) {
      return (widget.msg!.attachment as FileAttachment).filename!;
    }
    return (widget.favorite!.attachment as FileAttachment).filename!;
  }
}

class DownloadingWidget extends StatefulWidget {
  final Message<Attachment>? msg;
  final Favorite<Attachment>? favorite;

  const DownloadingWidget({
    Key? key,
    this.msg,
    this.favorite,
  }) : super(key: key);

  @override
  _DownloadingWidgetState createState() => _DownloadingWidgetState();
}

enum FileState {
  DOWNLOADING,
  SUCCESS,
  NO,
  CONTINUE,
}

class _DownloadingWidgetState extends State<DownloadingWidget> {
  FileState currentState = FileState.NO;
  FileAttachment? fileAttachment;
  double progress = 0;
  Job? job;
  Job? jobState;

  @override
  void initState() {
    if (widget.msg != null) {
      fileAttachment = widget.msg!.attachment as FileAttachment;
    } else {
      fileAttachment = widget.favorite!.attachment as FileAttachment;
    }

    if (fileAttachment!.path == null || !File(fileAttachment!.path!).existsSync()) {
      currentState = FileState.NO;
    } else {
      currentState = FileState.SUCCESS;
    }

    super.initState();

    initListener();
  }

  @override
  void dispose() {
    SxtManager.instance.cancelJob(job?.jobId);
    SxtManager.instance.cancelJob(jobState?.jobId);
    super.dispose();
  }

  void _update(int? progress) {
    setState(() {
      progress ??= 0;
      this.progress = progress! * 1.0 / 100;
      if (this.progress == 1) {
        currentState = FileState.SUCCESS;
      }
    });
  }

  void _cancelDownload() {
    if (widget.msg != null) {
      WidgetsBinding.instance?.addPostFrameCallback((timeStamp) {
        setState(() {
          currentState = FileState.CONTINUE;
        });
      });
    }
  }

  void _download() {
    currentState = FileState.DOWNLOADING;

    _update(0);
    if (widget.msg != null) {
      SxtMessagePlugin.downloadMsgAttachment(widget.msg!);
    } else {
      try {
        SxtFavoritePlugin.downloadAttachment(widget.favorite!.favoriteId!);
      } catch (e) {
        ToastUtil.showToast("下载失败");
        setState(() {
          progress = 0;
          currentState = FileState.NO;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (currentState == FileState.DOWNLOADING) {
      return Container(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "正在下载 ${formatBytes((fileAttachment!.size! * progress).toInt(), 2)}/${formatBytes(fileAttachment!.size!, 2)}",
              style: const TextStyle(
                color: Color(0xff666666),
                fontSize: 12,
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            DownLoadProgressWidget(
              progress,
              widget.msg != null,
              _cancelDownload,
            ),
          ],
        ),
      );
    }
    return GestureDetector(
      onTap: _stateClicked,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xff2E6AFD),
          borderRadius: BorderRadius.circular(10),
        ),
        margin: const EdgeInsets.symmetric(
          horizontal: 40,
        ),
        padding: const EdgeInsets.symmetric(
          vertical: 10,
        ),
        alignment: Alignment.center,
        child: Text(
          _getNameByState(),
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
          ),
        ),
      ),
    );
  }

  String _getNameByState() {
    switch (currentState) {
      case FileState.CONTINUE:
        return "继续下载";
      case FileState.SUCCESS:
        return "使用第三方打开";
      case FileState.NO:
        return "开始下载";
      case FileState.DOWNLOADING:
        break;
    }
    return "";
  }

  void _stateClicked() {
    switch (currentState) {
      case FileState.CONTINUE:
      case FileState.NO:
        _download();
        break;
      case FileState.SUCCESS:
        _openByOther();
        break;
      case FileState.DOWNLOADING:
        break;
    }
  }

  void _openByOther() {
    FileUtil.openFile(fileAttachment!.path!);
  }

  void initListener() async {
    if (widget.msg != null) {
      job = await SxtMessagePlugin.setNotifyFileProgressListener(FileProgressListener(
        onChanged: (event) {
          _update(event.progress);
        },
      ), widget.msg!.talker!);

      jobState = await SxtMessagePlugin.setMessageStateUpdateListener(MessageStateUpdateListener(
        onChanged: (IMEvent event) {
          switch (event.type) {
            case IMEventType.DOWNLOAD_FAILURE:
              _failed();
              break;
            case IMEventType.DOWNLOADING:
              _startDownload();
              break;
            case IMEventType.DOWNLOAD_SUCCESS:
              _success((event.message?.attachment as FileAttachment).path);
              break;
          }
        },
      ), widget.msg!.talker!);
    } else {
      job = await SxtFavoritePlugin.setNotifyFavoriteProgressListener(
        FavoriteProgressListener(
          onChanged: (event) {
            _update(event.progress);
          },
        ),
      );

      jobState = await SxtFavoritePlugin.setFavoriteEventListener(FavoriteEventListener(
        onChanged: (FavoriteEvent state) {
          switch (state.favoriteEventType) {
            case FavoriteEventType.DOWNLOADING:
              _startDownload();
              break;
            case FavoriteEventType.DOWNLOAD_FAILURE:
              _failed();
              break;
            case FavoriteEventType.DOWNLOAD_SUCCESS:
              _success((state.favorite?.attachment as FileAttachment).path);
              break;
          }
        },
      ));
    }
  }

  void _failed() {
    if (currentState != FileState.NO) {
      ToastUtil.showToast("下载失败,请重试");
      WidgetsBinding.instance?.addPostFrameCallback((timeStamp) {
        currentState = FileState.NO;
      });
    }
  }

  void _startDownload() {
    if (currentState == FileState.NO || currentState == FileState.CONTINUE) {
      _update(0);
    }
  }

  void _success(String? path) {
    fileAttachment?.path = path;
    if (widget.favorite != null) {
      (widget.favorite?.attachment as FileAttachment).path = path;
    } else {
      (widget.msg?.attachment as FileAttachment).path = path;
    }
    if (currentState != FileState.SUCCESS) {
      _update(100);
    }
  }
}

class DownLoadProgressWidget extends StatelessWidget {
  final double progress;
  final bool canStop;
  final VoidCallback cancelDownload;

  const DownLoadProgressWidget(this.progress, this.canStop, this.cancelDownload, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 15,
      ),
      child: Row(
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.all(
                Radius.circular(10),
              ),
              child: LinearProgressIndicator(
                value: progress,
                backgroundColor: Color(0xffDADADA),
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xff2E6AFD)),
              ),
            ),
          ),
          canStop
              ? InkWell(
                  onTap: () {
                    cancelDownload();
                  },
                  child: Container(
                    child: Image.asset(
                      ImageHelper.wrapAssets(
                        "icon_downloadfile_close.png",
                      ),
                      width: 24,
                      height: 24,
                      package: PACKAGE_NAME,
                    ),
                  ),
                )
              : const SizedBox.shrink(),
        ],
      ),
    );
  }
}

String formatBytes(int bytes, int decimals) {
  if (bytes <= 0) return "0 B";
  const suffixes = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
  var i = (log(bytes) / log(1000)).floor();
  return ((bytes / pow(1000, i)).toStringAsFixed(decimals)) + ' ' + suffixes[i];
}
