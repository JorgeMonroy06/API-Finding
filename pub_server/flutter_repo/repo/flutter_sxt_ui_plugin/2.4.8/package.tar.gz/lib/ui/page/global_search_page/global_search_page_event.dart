part of 'global_search_page_bloc.dart';

@immutable
abstract class GlobalSearchPageEvent {
  const GlobalSearchPageEvent();
}

class Search extends GlobalSearchPageEvent {
  final String keyword;

  const Search(this.keyword);
}

class Initial extends GlobalSearchPageEvent {
  const Initial();
}
