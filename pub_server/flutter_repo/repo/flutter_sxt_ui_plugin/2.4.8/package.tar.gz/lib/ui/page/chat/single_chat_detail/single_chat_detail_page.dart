import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/ui/contact_detail/contact_detail_page.dart';
import 'package:contact_ui_flutter/ui/contact_select/contact_select_page.dart';
import 'package:contact_ui_flutter/widget/image_loader.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/chat_history_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/message_free/message_free_item.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/single_chat_detail/single_chat_detail_page_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/strong_reminder/strong_reminder_item.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/ontop/ontop_conversation_item.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/loading_dialog.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/pressed_item.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/group/model/group_create_param.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';

class SingleChatDetailPage extends StatefulWidget {
  final SessionEntity sessionEntity;

  SingleChatDetailPage({required this.sessionEntity});

  @override
  _SingleChatDetailState createState() => _SingleChatDetailState();
}

class _SingleChatDetailState extends State<SingleChatDetailPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (_) => SingleChatDetailPageBloc(widget.sessionEntity.code!),
        child: Scaffold(
          backgroundColor: CustomColors.cl_F5F5F5,
          appBar: BackgroundImageAppbar(
            title: "聊天详情",
            leadingWidget: Container(
              padding: EdgeInsets.only(left: 12, right: 16, top: 8, bottom: 8),
              child: InkWell(
                child: ImageHelper.assetImage("ic_back.png"),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            ),
          ),
          body: BlocListener<SingleChatDetailPageBloc, SingleChatDetailPageState>(
              listener: (context, state) {
                switch (state.status) {
                  case EventStatus.loading:
                    showDialog(context: context, barrierDismissible: false, builder: (ctx) => LoadingDialog("创建群组中...", () => {}));
                    break;
                  case EventStatus.failure:
                    Navigator.pop(context);
                    ToastUtil.showToast(state.failedMessage ?? "");
                    break;
                  case EventStatus.loadingSuccess:
                    Navigator.pop(context);
                    break;
                  case EventStatus.nothing:
                    break;
                  default:
                    break;
                }
              },
              child: Container(
                child: Column(
                  children: [
                    BlocBuilder<SingleChatDetailPageBloc, SingleChatDetailPageState>(builder: (context, state) {
                      return ContactList(
                        contact: state.contact,
                        onItemClick: () {
                          Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
                            return ContactDetailPage(state.contact!);
                          }));
                        },
                      );
                    }),
                    const Divider(
                      height: 0.6,
                      thickness: 0.6,
                      color: Color(0xFFE0E0E0),
                    ),
                    BlocBuilder<SingleChatDetailPageBloc, SingleChatDetailPageState>(builder: (context, state) {
                      return InkWell(
                        onTap: () async {
                          var data = await Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
                            return ContactSelectPage(
                              title: "选择联系人",
                              unSelectCodes: [DomainUtil.toCode(widget.sessionEntity.code)],
                            );
                          }));
                          if (data != null) {
                            List<Contact> list = data;
                            SingleChatDetailPageBloc bloc = BlocProvider.of<SingleChatDetailPageBloc>(context);
                            bloc.add(Loading());

                            List<String> userCodes = [];
                            list.forEach((element) {
                              userCodes.add(element.code! + "@" + element.originCode!);
                            });
                            userCodes.add(widget.sessionEntity.code!);

                            GroupCreateParam param = GroupCreateParam();
                            param.userCodes = userCodes;
                            SxtGroupPlugin.createGroup(param).then((value) {
                              Navigator.popUntil(
                                context,
                                (route) {
                                  if (!route.willHandlePopInternally && route is ModalRoute && route.settings.name == '/MainPage') {
                                    return true;
                                  }
                                  return false;
                                },
                              );
                              Navigator.push(
                                  context,
                                  new CupertinoPageRoute(
                                      settings: RouteSettings(name: '/ChatPage'),
                                      builder: (context) {
                                        SessionEntity sessionEntity = new SessionEntity(code: value.data?.groupCode, sessionType: SessionType.GROUP);
                                        return ChatPage(sessionEntity: sessionEntity);
                                      }));
                            }).onError((e, stackTrace) {
                              if (e is PlatformException) {
                                ToastUtil.showToast(e.message ?? "创建群组失败");
                              } else {
                                ToastUtil.showToast("创建群组失败");
                              }
                            });
                          }
                        },
                        child: Container(
                          color: Colors.white,
                          height: 56,
                          padding: EdgeInsets.only(left: 20),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Row(
                              children: [
                                Container(
                                  width: 18,
                                  height: 18,
                                  child: ImageHelper.assetImage("ic_add_blue.png"),
                                ),
                                Expanded(
                                  child: Container(
                                    margin: EdgeInsets.only(left: 6),
                                    child: Text(
                                      "添加成员",
                                      style: TextStyle(fontSize: 16, color: ColorUtil.color333333, height: 1.2, fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }),
                    const SizedBox(height: 10),
                    PressedItem(
                      title: '查找聊天记录',
                      onTap: () => Navigator.of(context).push(
                        CupertinoPageRoute(
                          builder: (context) => ChatHistoryPage(widget.sessionEntity),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    // 消息免打扰
                    MessageFreeItem(widget.sessionEntity),
                    const Divider(
                      height: 0.6,
                      thickness: 0.6,
                      color: Color(0xFFE0E0E0),
                    ),
                    // 置顶聊天
                    OnTopConversationItem(widget.sessionEntity),
                    const Divider(
                      height: 0.6,
                      thickness: 0.6,
                      color: Color(0xFFE0E0E0),
                    ),
                    // 强提醒
                    StrongReminderItem(widget.sessionEntity),
                  ],
                ),
              )),
        ));
  }
}

class ContactList extends StatelessWidget {
  final Contact? contact;
  final Function? onItemClick;

  ContactList({this.contact, this.onItemClick});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: ThemeData.light().splashColor,
      highlightColor: ThemeData.light().highlightColor,
      onTap: () {
        onItemClick!();
      },
      child: Container(
        color: Colors.white,
        height: 80,
        padding: EdgeInsets.only(left: 20),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Row(
            children: [
              ImageLoader(
                url: contact == null ? "" : StringUtil.getAvatarUrl(contact!),
                defaultAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                errorAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                borderRadius: 4,
                width: 48,
                height: 48,
                package: PACKAGE_NAME,
              ),
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(left: 10),
                  child: Text(
                    contact?.name ?? "",
                    style: TextStyle(fontSize: 16, color: ColorUtil.color333333, fontWeight: FontWeight.w600),
                  ),
                ),
              ),
              Container(
                width: 7,
                height: 13,
                margin: EdgeInsets.only(right: 15, left: 15),
                child: ImageHelper.assetImage("ic_arrow_right.png"),
              )
            ],
          ),
        ),
      ),
    );
  }
}
