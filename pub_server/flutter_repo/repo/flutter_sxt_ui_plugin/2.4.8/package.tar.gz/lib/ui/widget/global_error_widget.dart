import 'package:flutter/material.dart';

/// @author newtab on 2021/5/14
class GlobalErrorWidget extends StatelessWidget {
  final String error;

  GlobalErrorWidget(this.error);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Center(
        child: Text(
          "出现异常:" + error,
          style: TextStyle(
            color: Color(0xff333333),
            fontSize: 14,
          ),
        ),
      ),
    );
  }
}
