import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/ui/contact_select/contact_select_page.dart';
import 'package:contact_ui_flutter/widget/image_loader.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/manager/app_manager.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/group_chat_detail_page_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/group_member_page/group_member_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/guardian_monitor/guardian_monitor_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/guardian_monitor/guardian_monitor_event.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/guardian_monitor/guardian_monitor_item.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/rename_group_page/rename_group_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/chat_history_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/message_free/message_free_item.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/strong_reminder/strong_reminder_item.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/ontop/ontop_conversation_item.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/loading_dialog.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/pressed_item.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/group/model/group_add_user_param.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

class GroupChatDetailPage extends StatefulWidget {
  final SessionEntity sessionEntity;

  GroupChatDetailPage(this.sessionEntity);

  @override
  _GroupChatDetailState createState() => _GroupChatDetailState();
}

class _GroupChatDetailState extends State<GroupChatDetailPage> {
  var pageContext;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
            create: (context) => GroupChatDetailPageBloc(widget.sessionEntity.code!),
          ),
          BlocProvider(
            create: (context) => GuardianMonitorBloc()..add(GuardianMonitorInitEvent()),
          ),
        ],
        child: BlocBuilder<GroupChatDetailPageBloc, GroupChatDetailPageState>(builder: (context, state) {
          pageContext = context;

          double width = MediaQuery.of(context).size.width;
          int maxCount = (width.toInt() - 68) ~/ 58;
          List<Widget> userWidgetList = [];
          if (state.groupMemberList != null) {
            int count = state.groupMemberList!.length;
            if (maxCount < state.groupMemberList!.length) {
              count = maxCount;
            }
            print("count:" + count.toString());
            for (int i = 0; i < count; i++) {
              userWidgetList.add(UserWidget(state.groupMemberList![i]));
            }
          }
          return Scaffold(
            backgroundColor: CustomColors.cl_F5F5F5,
            appBar: BackgroundImageAppbar(
              title: "聊天详情(${state.groupMemberList?.length ?? ""})",
              leadingWidget: IconButton(
                icon: ImageIcon(
                  AssetImage(ImageHelper.wrapAssets("ic_back.png"), package: PACKAGE_NAME),
                  color: Colors.white,
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            ),
            body: BlocListener<GroupChatDetailPageBloc, GroupChatDetailPageState>(
                listener: (context, state) {
                  switch (state.status) {
                    case EventStatus.loading:
                      showDialog(
                          context: context,
                          routeSettings: RouteSettings(name: '/LoadingDialog'),
                          barrierDismissible: false,
                          builder: (ctx) => LoadingDialog(state.loadingMessage ?? "", () => {}));
                      break;
                    case EventStatus.failure:
                      if (!StringUtil.isEmpty(state.failedMessage)) {
                        ToastUtil.showToast(state.failedMessage ?? "");
                      }
                      break;
                    case EventStatus.popPage:
                      print("aaaa groupChatDetail EventStatus.popPage");
                      // Navigator.popUntil(
                      //   context,
                      //   (route) {
                      //     if (!route.willHandlePopInternally &&
                      //         route is ModalRoute &&
                      //         (route.settings.name == '/ChatPage' || route.settings.name == '/MainPage')) {
                      //       return true;
                      //     }
                      //     return false;
                      //   },
                      // );
                      Navigator.pop(context);
                      break;
                    case EventStatus.loadingSuccess:
                      break;
                    case EventStatus.update:
                      break;
                    case EventStatus.nothing:
                      break;
                    default:
                      break;
                  }
                },
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      InkWell(
                        splashColor: ThemeData.light().splashColor,
                        highlightColor: ThemeData.light().highlightColor,
                        onTap: () {
                          if (AppManager.instance.uiOptions.enableUpdateGroupName) {
                            //跳转修改群名称界面
                            Navigator.push(context, new CupertinoPageRoute(builder: (context) {
                              return RenameGroupPage(state.group!);
                            }));
                          }
                        },
                        child: Container(
                          color: Colors.white,
                          height: 56,
                          padding: EdgeInsets.only(left: 14),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Row(
                              children: [
                                Container(
                                  child: Text(
                                    "群聊名称",
                                    style: TextStyle(fontSize: 16, color: ColorUtil.COLOR_FF353F4A, fontWeight: FontWeight.bold),
                                  ),
                                ),
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.centerRight,
                                    child: Container(
                                      margin: EdgeInsets.only(left: 10),
                                      child: Text(
                                        state.group?.groupName ?? "",
                                        style: TextStyle(fontSize: 16, color: ColorUtil.color999999),
                                      ),
                                    ),
                                  ),
                                ),
                                (AppManager.instance.uiOptions.enableUpdateGroupName)
                                    ? Container(
                                        width: 7,
                                        height: 13,
                                        margin: EdgeInsets.only(right: 15, left: 15),
                                        child: ImageHelper.assetImage("ic_arrow_right.png"),
                                      )
                                    : Container(margin: EdgeInsets.only(right: 15, left: 15))
                              ],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        height: 10,
                        color: CustomColors.cl_F5F5F5,
                      ),
                      InkWell(
                        splashColor: ThemeData.light().splashColor,
                        highlightColor: ThemeData.light().highlightColor,
                        onTap: () {
                          Navigator.push(context, new CupertinoPageRoute(builder: (context) {
                            return GroupMemberPage(state.group!);
                          }));
                        },
                        child: Container(
                          color: Colors.white,
                          height: 56,
                          padding: EdgeInsets.only(left: 14),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Row(
                              children: [
                                Container(
                                  child: Text(
                                    "群成员",
                                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: CustomColors.cl_333333),
                                  ),
                                ),
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.centerRight,
                                    child: Container(
                                      margin: EdgeInsets.only(left: 10),
                                      child: Text(
                                        (state.groupMemberList?.length ?? "").toString() + "人",
                                        style: TextStyle(fontSize: 16, color: ColorUtil.color999999),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 7,
                                  height: 13,
                                  margin: EdgeInsets.only(right: 15, left: 4),
                                  child: ImageHelper.assetImage("ic_arrow_right.png"),
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                      InkWell(
                          onTap: () {
                            Navigator.push(context, new CupertinoPageRoute(builder: (context) {
                              return GroupMemberPage(state.group!);
                            }));
                          },
                          child: Container(
                            color: Colors.white,
                            padding: EdgeInsets.only(bottom: 20, left: 20, right: 20, top: 4),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Row(
                                    children: userWidgetList,
                                  ),
                                ),
                                ((state.groupMemberList?.length ?? 0) > maxCount)
                                    ? Container(
                                        width: 28,
                                        height: 28,
                                        child: Align(
                                          alignment: Alignment.bottomLeft,
                                          child: ImageHelper.assetImage("ic_more_grey.png"),
                                        ),
                                      )
                                    : Container()
                              ],
                            ),
                          )),
                      const Divider(
                        height: 0.6,
                        thickness: 0.6,
                        color: Color(0xFFE0E0E0),
                      ),
                      AppManager.instance.uiOptions.enableUpdateGroupMember
                          ? InkWell(
                              onTap: () async {
                                List<String> unSelectCodes = [];
                                state.groupMemberList?.forEach((element) {
                                  unSelectCodes.add(element.code!);
                                });
                                var data = await Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
                                  return ContactSelectPage(
                                    title: "选择联系人",
                                    unSelectCodes: unSelectCodes,
                                  );
                                }));
                                if (data != null) {
                                  List<Contact> list = data;
                                  GroupChatDetailPageBloc bloc = BlocProvider.of<GroupChatDetailPageBloc>(context);
                                  bloc.add(Loading("加载中..."));

                                  List<String> userCodes = [];
                                  list.forEach((element) {
                                    userCodes.add(element.code! + "@" + element.originCode!);
                                  });

                                  showDialog(context: context, barrierDismissible: false, builder: (ctx) => LoadingDialog("加载中...", () => {}));
                                  GroupAddUserParam groupAddUserParam = GroupAddUserParam();
                                  groupAddUserParam.groupCode = widget.sessionEntity.code;
                                  groupAddUserParam.userCodes = userCodes;
                                  SxtGroupPlugin.addUserToGroup(groupAddUserParam).then((value) {
                                    Navigator.pop(context);
                                    bloc.add(LoadingSuccess());
                                  }).onError((e, stackTrace) {
                                    Navigator.pop(context);
                                    if (e is PlatformException) {
                                      bloc.add(LoadingFailed(failedMessage: e.message));
                                    } else {
                                      bloc.add(LoadingFailed(failedMessage: e.toString()));
                                    }
                                  });
                                }
                              },
                              child: Container(
                                color: Colors.white,
                                height: 56,
                                padding: EdgeInsets.only(left: 20),
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 18,
                                        height: 18,
                                        child: ImageHelper.assetImage("ic_add_blue.png"),
                                      ),
                                      Expanded(
                                        child: Container(
                                          margin: EdgeInsets.only(left: 6),
                                          child: Text(
                                            "添加成员",
                                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: ColorUtil.color333333, height: 1.2),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            )
                          : Container(),
                      const SizedBox(height: 10),
                      PressedItem(
                        title: '查找聊天记录',
                        onTap: () {
                          final bloc = context.read<GroupChatDetailPageBloc>();
                          Navigator.of(context).push(
                            CupertinoPageRoute(
                              builder: (context) => ChatHistoryPage(
                                widget.sessionEntity,
                                groupLeaderCode: bloc.state.group?.userCode,
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 10),
                      // 消息免打扰
                      MessageFreeItem(widget.sessionEntity),
                      const Divider(
                        height: 0.6,
                        thickness: 0.6,
                        color: Color(0xFFE0E0E0),
                      ),
                      // 置顶聊天
                      OnTopConversationItem(widget.sessionEntity),
                      const Divider(
                        height: 0.6,
                        thickness: 0.6,
                        color: Color(0xFFE0E0E0),
                      ),
                      // 守护监听
                      GuardianMonitorItem(widget.sessionEntity),
                      const Divider(
                        height: 0.6,
                        thickness: 0.6,
                        color: Color(0xFFE0E0E0),
                      ),
                      // 强提醒
                      StrongReminderItem(widget.sessionEntity),
                      const SizedBox(height: 10),
                      InkWell(
                        onTap: () async {
                          showCupertinoDialog(
                              context: context,
                              builder: (context) {
                                return CupertinoAlertDialog(
                                  content: Container(
                                    padding: EdgeInsets.fromLTRB(0, 20, 0, 16),
                                    child: Text(
                                      '确定要${state.group!.isMaster! ? "解散" : "退出"}群组吗？',
                                      style: TextStyle(color: ColorUtil.color333333, fontWeight: FontWeight.bold, fontSize: 16),
                                    ),
                                  ),
                                  actions: <Widget>[
                                    CupertinoDialogAction(
                                      child: Text(
                                        '取消',
                                        style: TextStyle(fontSize: 16, color: ColorUtil.colorFF666666),
                                      ),
                                      onPressed: () {
                                        Navigator.of(context).pop(false);
                                      },
                                    ),
                                    CupertinoDialogAction(
                                      child: Text('确认'),
                                      onPressed: () {
                                        Navigator.of(context).pop(false);
                                        GroupChatDetailPageBloc bloc = BlocProvider.of<GroupChatDetailPageBloc>(pageContext);
                                        if (state.group!.isMaster!) {
                                          bloc.add(Loading("解散群组中..."));
                                          SxtGroupPlugin.deleteGroup(widget.sessionEntity.code!).then((value) {
                                            bloc.add(LoadingSuccess());
                                            if (!bloc.isPoped) {
                                              bloc.isPoped = true;
                                              bloc.add(PopPage("解散群组成功")); //关闭界面
                                            }
                                          }).onError((e, stackTrace) {
                                            if (e is PlatformException) {
                                              bloc.add(LoadingFailed(failedMessage: e.message));
                                            } else {
                                              bloc.add(LoadingFailed(failedMessage: e.toString()));
                                            }
                                          });
                                        } else {
                                          bloc.add(Loading("退出群组中..."));
                                          SxtGroupPlugin.quitGroup(widget.sessionEntity.code!).then((value) {
                                            bloc.add(LoadingSuccess());
                                            if (!bloc.isPoped) {
                                              bloc.isPoped = true;
                                              bloc.add(PopPage("退出群组成功")); //关闭界面
                                            }
                                          }).onError((e, stackTrace) {
                                            if (e is PlatformException) {
                                              bloc.add(LoadingFailed(failedMessage: e.message));
                                            } else {
                                              bloc.add(LoadingFailed(failedMessage: e.toString()));
                                            }
                                          });
                                        }
                                      },
                                    ),
                                  ],
                                );
                              });
                        },
                        child: state.group == null || !AppManager.instance.uiOptions.enableDeleteGroup
                            ? Container()
                            : Container(
                                color: Colors.white,
                                height: 56,
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    state.group!.isMaster! ? "解散群组" : "退出群聊",
                                    style: TextStyle(fontSize: 16, color: ColorUtil.colorFF85152, fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ),
                      ),
                    ],
                  ),
                )),
          );
        }));
  }
}

class UserWidget extends StatelessWidget {
  final Contact contact;

  UserWidget(this.contact);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(right: 10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ImageLoader(
            url: StringUtil.getAvatarUrl(contact),
            defaultAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
            errorAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
            borderRadius: 4,
            width: 48,
            height: 48,
            package: PACKAGE_NAME,
          ),
          Container(
            margin: EdgeInsets.only(top: 6),
            padding: EdgeInsets.only(left: 2, right: 2),
            height: 25,
            width: 48,
            child: Center(
              child: Text(
                contact.name ?? "",
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 12, color: CustomColors.cl_666666),
              ),
            ),
          )
        ],
      ),
    );
  }
}
