import 'package:contact_ui_flutter/widget/image_loader.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/manager/audio_manager.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/favourite/msg_delegate.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/utils/date_time_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/forward_msg_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/favorite/model/favorite.dart';
import 'package:sxt_flutter_plugin/favorite/sxt_favorite_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';

/// @author newtab on 2021/9/16

class FavouriteDetailPage extends StatefulWidget {
  final Favorite favorite;
  final String userName;
  final String department;
  final String avator;

  const FavouriteDetailPage(
    this.favorite,
    this.userName,
    this.department,
    this.avator, {
    Key? key,
  }) : super(key: key);

  @override
  _FavouriteDetailPageState createState() => _FavouriteDetailPageState();
}

class _FavouriteDetailPageState extends State<FavouriteDetailPage> {
  BaseMsgDelegate? baseMsgDelegate;

  @override
  void initState() {
    AudioManager.instance.init();
    baseMsgDelegate = BaseMsgDelegate.getMsgDelegate(
      widget.favorite,
      widget.userName,
      widget.department,
      widget.avator,
    );
    super.initState();
  }

  @override
  void dispose() {
    baseMsgDelegate?.dispose();
    AudioManager.instance.destroy();
    baseMsgDelegate!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: BackgroundImageAppbar(
        title: "详情",
        leadingWidget: Container(
          padding: EdgeInsets.only(left: 12, right: 16, top: 8, bottom: 8),
          child: InkWell(
            child: ImageHelper.assetImage(
              "ic_back.png",
            ),
            onTap: () {
              Navigator.pop(context);
            },
          ),
        ),
        trailingWidget: GestureDetector(
          onTap: showMore,
          child: Container(
              alignment: Alignment.center,
              padding: EdgeInsets.symmetric(horizontal: 15),
              child: Icon(
                CupertinoIcons.ellipsis,
                color: Colors.white,
                size: 22,
              )),
        ),
      ),
      body: Container(
        padding: EdgeInsets.only(
          left: 15,
          top: 15,
          bottom: 15,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildUserInfo(),
              SizedBox(
                height: 15,
              ),
              Divider(
                color: Color(0xffe0e0e0),
                height: 1,
              ),
              SizedBox(
                height: 15,
              ),
              Padding(
                padding: const EdgeInsets.only(
                  right: 15,
                ),
                child: baseMsgDelegate?.buildDetail(context),
              ),
              SizedBox(
                height: 15,
              ),
              Text(
                "收藏于 ${DateTimeUtil.formatMessageTime2(widget.favorite.createTime!)}",
                style: TextStyle(
                  color: Color(0xff999999),
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void showMore() {
    showModalBottomSheet<bool>(
      isDismissible: true,
      enableDrag: false,
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(10),
        ),
      ),
      backgroundColor: Colors.white,
      builder: (context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            GestureDetector(
              onTap: () {
                Navigator.pop(context);

                if (widget.favorite.msgType == MsgType.VOICE_FILE ||
                    widget.favorite.msgType == MsgType.AUDIO) {
                  ToastUtil.showToast("语音消息不支持转发");
                  return;
                }

                ForwardMsgHelper.forwardMsg(
                  context,
                  widget.favorite.attachment!,
                );
              },
              child: Container(
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.symmetric(
                  vertical: 15,
                ),
                alignment: Alignment.center,
                child: Text(
                  "转发",
                  style: TextStyle(
                    color: Color(0xff000000),
                    fontSize: 16,
                  ),
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: 1,
              color: Color(0xffF5F5F5),
            ),
            GestureDetector(
              onTap: () async {
                await SxtFavoritePlugin.deleteFavorite(
                    widget.favorite.favoriteId!);
                Navigator.of(context).popUntil((route) {
                  if (route.settings.name == "/fav_home_page") {
                    (route.settings.arguments as Map)["result"] =
                        widget.favorite.favoriteId;
                    return true;
                  } else {
                    return false;
                  }
                });
              },
              child: Container(
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.symmetric(
                  vertical: 15,
                ),
                alignment: Alignment.center,
                child: Text(
                  "取消收藏",
                  style: TextStyle(
                    color: Color(0xffFF4B34),
                    fontSize: 16,
                  ),
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: 5,
              color: Color(0xffF5F5F5),
            ),
            GestureDetector(
              onTap: () {
                Navigator.pop(context);
              },
              child: Container(
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.symmetric(
                  vertical: 15,
                ),
                alignment: Alignment.center,
                child: Text(
                  "取消",
                  style: TextStyle(
                    color: Color(0xff333333),
                    fontSize: 16,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildUserInfo() {
    return Container(
      child: Row(
        children: [
          ImageLoader(
            defaultAssetImg:
                ImageHelper.wrapAssets("icon_person_placeholder.png"),
            package: PACKAGE_NAME,
            width: 36,
            url: widget.avator,
            height: 36,
            borderRadius: 4,
          ),
          SizedBox(
            width: 8,
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  widget.userName,
                  style: TextStyle(
                    color: Color(
                      0xff333333,
                    ),
                    fontSize: 16,
                  ),
                ),
                Text(
                  widget.department,
                  style: TextStyle(
                    color: Color(
                      0xff999999,
                    ),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
