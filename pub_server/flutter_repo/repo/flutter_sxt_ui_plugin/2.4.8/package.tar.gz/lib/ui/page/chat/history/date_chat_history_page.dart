import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/bloc/date_chat_history_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

class DateChatHistoryPage extends StatelessWidget {
  const DateChatHistoryPage(this.sessionEntity, {Key? key}) : super(key: key);

  final SessionEntity sessionEntity;

  @override
  Widget build(BuildContext context) => AnnotatedRegion(
        value: SystemUiOverlayStyle.light,
        child: Scaffold(
          backgroundColor: Colors.white,
          appBar: BackgroundImageAppbar(
            title: "按日期查找",
            leadingWidget: _buildBackButton(context),
          ),
          body: BlocProvider(
            create: (context) => DateChatHistoryBloc(sessionEntity)..add(DateChatHistoryInitEvent()),
            child: BlocBuilder<DateChatHistoryBloc, DateChatHistoryState>(
              builder: (context, state) => SfDateRangePicker(
                monthFormat: 'M月',
                selectionRadius: 20,
                enableMultiView: true,
                minDate: state.minDate,
                maxDate: DateTime.now(),
                selectionMode: DateRangePickerSelectionMode.single,
                navigationMode: DateRangePickerNavigationMode.scroll,
                navigationDirection: DateRangePickerNavigationDirection.vertical,
                headerStyle: DateRangePickerHeaderStyle(
                  backgroundColor: Colors.grey[100],
                  textStyle: TextStyle(
                    color: Colors.grey[900],
                    fontSize: 14,
                  ),
                ),
                monthCellStyle: DateRangePickerMonthCellStyle(
                  textStyle: TextStyle(color: Colors.grey[900]),
                  blackoutDateTextStyle: TextStyle(color: Colors.grey[400]),
                ),
                monthViewSettings: DateRangePickerMonthViewSettings(
                  viewHeaderHeight: 33,
                  viewHeaderStyle: const DateRangePickerViewHeaderStyle(
                    textStyle: TextStyle(
                      color: Colors.grey,
                      fontSize: 12,
                    ),
                  ),
                  blackoutDates: state.blackoutDates,
                ),
                onSelectionChanged: (args) {
                  if (args.value is DateTime) {
                    _jumpChatPage(context, args.value);
                  }
                },
              ),
            ),
          ),
        ),
      );

  void _jumpChatPage(BuildContext context, DateTime date) => Navigator.of(context).push(
        CupertinoPageRoute(
          settings: const RouteSettings(name: '/ChatPage'),
          builder: (context) => ChatPage(
            sessionEntity: sessionEntity,
            isFromRecord: true,
            msgId: 0,
            msgTime: date.millisecondsSinceEpoch,
            normalBack: true,
          ),
        ),
      );

  Widget _buildBackButton(BuildContext context) => IconButton(
        onPressed: Navigator.of(context).pop,
        icon: ImageIcon(
          AssetImage(
            ImageHelper.wrapAssets("ic_back.png"),
            package: PACKAGE_NAME,
          ),
          color: Colors.white,
        ),
      );
}
