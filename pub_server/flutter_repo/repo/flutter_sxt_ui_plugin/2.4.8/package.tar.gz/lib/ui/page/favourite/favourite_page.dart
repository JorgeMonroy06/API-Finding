import 'package:contact_sdk_flutter/logic/data_filter_builder.dart';
import 'package:contact_sdk_flutter/manager/contact_manager.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/manager/LazyLoadState.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/favourite/msg_delegate.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:sxt_flutter_plugin/favorite/model/favorite.dart';
import 'package:sxt_flutter_plugin/favorite/model/favorite_event_listener.dart';
import 'package:sxt_flutter_plugin/favorite/model/favorite_event_type.dart';
import 'package:sxt_flutter_plugin/favorite/sxt_favorite_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_manager.dart';
import 'package:sxt_flutter_plugin/message/model/audio_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/location_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/pic_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/video_attachment.dart';
import 'package:sxt_flutter_plugin/model/job.dart';

/// @author newtab on 2021/9/13

class FavouritePage extends StatefulWidget {
  const FavouritePage({Key? key}) : super(key: key);

  @override
  _FavouritePageState createState() => _FavouritePageState();
}

class _FavouritePageState extends State<FavouritePage> with LazyLoadState<FavouritePage> {
  List<Favorite> list = [];
  List<BaseMsgDelegate> widgets = [];
  bool loading = true;
  TextEditingController? controller;
  FocusNode? focusNode;
  Map<String, String> contacts = {};
  Map<String, String> department = {};
  Map<String, String> userIcon = {};
  Job? job;

  @override
  void initState() {
    initFavStateListener();

    focusNode = FocusNode();
    controller = TextEditingController()
      ..addListener(() {
        if (widgets.isNotEmpty) {
          setState(() {});
        }
      });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        if (focusNode?.hasFocus ?? false) {
          focusNode?.unfocus();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xfff5f5f5),
        resizeToAvoidBottomInset: false,
        appBar: BackgroundImageAppbar(
          title: "收藏",
          leadingWidget: Container(
            padding: EdgeInsets.only(left: 12, right: 16, top: 8, bottom: 8),
            child: InkWell(
              child: ImageHelper.assetImage(
                "ic_back.png",
              ),
              onTap: () {
                Navigator.pop(context);
              },
            ),
          ),
        ),
        body: loading
            ? Center(
                child: CupertinoActivityIndicator(),
              )
            : (list.isEmpty
                ? Stack(
                    children: [
                      _buildEmptyState(),
                      search(),
                    ],
                  )
                : ListView.builder(
                    keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                    itemBuilder: (context, index) {
                      if (index == 0) {
                        return Stack(
                          children: [
                            search(),
                            controller?.text.isNotEmpty ?? false
                                ? Positioned(
                                    child: GestureDetector(
                                      child: const Center(
                                        child: Icon(
                                          CupertinoIcons.clear_circled_solid,
                                          color: Color(0xffaaaaaa),
                                          size: 16,
                                        ),
                                      ),
                                      onTap: () {
                                        controller?.clear();
                                      },
                                    ),
                                    height: 60,
                                    right: 20,
                                  )
                                : SizedBox.shrink(),
                          ],
                        );
                      }

                      return GestureDetector(
                        onTap: () {
                          widgets[index - 1].clicked(context).then((value) {
                            final arguments = ModalRoute.of(context)?.settings.arguments as Map;
                            int? id = arguments["result"];
                            if (id != null) {
                              int index = list.indexWhere((element) => element.favoriteId == id);
                              if (index >= 0) {
                                BaseMsgDelegate delegate = widgets.removeAt(index);
                                delegate.dispose();
                                list.removeAt(index);
                                setState(() {});
                              }
                            }
                          });
                        },
                        child: widgets[index - 1].build(
                          context,
                          searchKey: controller?.text,
                        ),
                      );
                    },
                    itemCount: widgets.length + 1,
                  )),
      ),
    );
  }

  Widget search() {
    return GestureDetector(
      onTap: () {
        if (focusNode?.hasFocus ?? false) return;
        focusNode?.requestFocus();
      },
      child: Container(
        height: 40.0,
        margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Row(
          children: [
            Expanded(
              child: Center(
                child: IntrinsicWidth(
                  child: TextField(
                    focusNode: focusNode,
                    controller: controller,
                    textAlignVertical: TextAlignVertical.center,
                    cursorColor: Color(0xff2E6AFD),
                    decoration: InputDecoration(
                      prefixIcon: Image.asset(
                        "images/icon_search_mark.png",
                        width: 14,
                        package: PACKAGE_NAME,
                        height: 14,
                        fit: BoxFit.fitHeight,
                      ),
                      prefixIconConstraints: BoxConstraints(minWidth: 23, maxHeight: 20),
                      hintText: '搜索',
                      hintStyle: TextStyle(
                        color: Color(0xffaaaaaa),
                        fontSize: 14,
                      ),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void loadData() async {
    Job<List<Favorite>> job = await SxtFavoritePlugin.getFavorites();
    list.clear();
    if (job.data != null && job.data!.isNotEmpty) {
      list.addAll(job.data!);
    }

    if (list.isEmpty) {
      setState(() {
        loading = false;
      });
      return;
    }
    List<String> codes = [];

    list.forEach((element) {
      codes.add(DomainUtil.toCode(element.sender!.code));
    });

    ///通过code拿人信息
    var tempContact = await ContactManager.instance.getContactsByCodes(codes, DataFilterBuilder()).where((element) {
      return element.isNotEmpty;
    }).first;

    tempContact.forEach(
      (element) {
        if (element.code != null) {
          contacts[element.code!] = element.name ?? element.code!;
          department[element.code!] = element.deptId_name ?? "";
          userIcon[element.code!] = StringUtil.getAvatarUrl(element);
        }
      },
    );

    widgets.clear();
    widgets.addAll(list
        .map(
          (e) => BaseMsgDelegate.getMsgDelegate(
            e,
            contacts[DomainUtil.toCode(e.sender!.code!)] ?? "",
            department[DomainUtil.toCode(e.sender!.code!)] ?? "",
            userIcon[DomainUtil.toCode(e.sender!.code!)] ?? "",
          ),
        )
        .toList());

    setState(
      () {
        loading = false;
      },
    );
  }

  @override
  void onLazyLoad() {
    loadData();
  }

  Widget _buildEmptyState() {
    return Container(
      alignment: Alignment.center,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            ImageHelper.wrapAssets("icon_fav_empty.png"),
            package: PACKAGE_NAME,
            width: 142,
            height: 140,
          ),
          SizedBox(
            height: 15,
          ),
          Text(
            "暂无任何收藏",
            style: TextStyle(
              color: Color(
                0xff999999,
              ),
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  void initFavStateListener() async {
    job = await SxtFavoritePlugin.setFavoriteEventListener(FavoriteEventListener(onChanged: (event) {
      ///找到fav id
      if (event.favoriteEventType == FavoriteEventType.DOWNLOAD_SUCCESS) {
        int? id = event.favorite?.favoriteId;

        if (id == null) return;

        int index = list.indexWhere((element) => element.favoriteId == id);
        if (index < 0) return;

        try {
          if (list[index].msgType == MsgType.PICTURE) {
            final delegate = widgets[index] as ImageMsgDelegate;
            final PicAttachment picAttachment = event.favorite?.attachment as PicAttachment;
            list[index].attachment = picAttachment;
            delegate.updateImgPath(picAttachment.path);
          }
          if (list[index].msgType == MsgType.VIDEO_FILE || list[index].msgType == MsgType.VIDEO) {
            final delegate = widgets[index] as VideoMsgDelegate;
            final VideoAttachment videoAttachment = event.favorite?.attachment as VideoAttachment;
            list[index].attachment = videoAttachment;
            delegate.updateImgPath(videoAttachment.thumbPath);
          }

          if (list[index].msgType == MsgType.AUDIO) {
            final AudioAttachment audioAttachment = event.favorite?.attachment as AudioAttachment;
            list[index].attachment = audioAttachment;
            final delegate = widgets[index] as AudioMsgDelegate;
            delegate.updateAudioPath(audioAttachment.path);
          }
          if (list[index].msgType == MsgType.LOCATION) {
            final LocationAttachment locationAttachment = event.favorite?.attachment as LocationAttachment;
            list[index].attachment = locationAttachment;
            final delegate = widgets[index] as LocationMsgDelegate;
            delegate.updateImagePath(locationAttachment.path);
          }
        } catch (e) {
          print(e);
        }
      }
    }));
  }

  @override
  void dispose() {
    if (job != null) {
      SxtManager.instance.cancelJob(job?.jobId);
    }

    widgets.forEach((element) {
      element.dispose();
    });

    super.dispose();
  }
}
