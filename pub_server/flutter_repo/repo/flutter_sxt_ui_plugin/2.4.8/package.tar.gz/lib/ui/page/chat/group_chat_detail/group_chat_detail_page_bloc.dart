import 'dart:async';
import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/manager/flutter_manager.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/account/model/sxt_account.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';
import 'package:sxt_flutter_plugin/group/listener/group_info_update_listener.dart';
import 'package:sxt_flutter_plugin/group/listener/group_member_update_listener.dart';
import 'package:sxt_flutter_plugin/group/model/get_group_member_param.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/group/model/group_member.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_manager.dart';
import 'package:sxt_flutter_plugin/message/model/state_type.dart';
import 'package:sxt_flutter_plugin/model/job.dart';
import 'package:sxt_flutter_plugin/model/modification_event.dart';
import 'package:sxt_flutter_plugin/model/modification_event_type.dart';

part 'group_chat_detail_page_event.dart';

part 'group_chat_detail_page_state.dart';

class GroupChatDetailPageBloc
    extends Bloc<GroupChatDetailPageEvent, GroupChatDetailPageState> {
  String groupCode;
  int? groupMemberUpdateListenerJobId;
  int? groupUpdateListenerJobId;
  bool isPoped = false;

  GroupChatDetailPageBloc(this.groupCode)
      : super(GroupChatDetailPageState.initial()) {
    add(Initial(groupCode));

    SxtGroupPlugin.setGroupMemberUpdateListener(GroupMemberUpdateListener(
        onChanged: (List<GroupMember> groupMemberList) async {
      if (groupMemberList.isNotEmpty &&
          DomainUtil.toCode(groupMemberList[0].groupCode) !=
              DomainUtil.toCode(groupCode)) return;

      bool containSelf = true;
      SxtAccount sxtAccount = await SxtAccountPlugin.getCurrentUser();
      if (null != groupMemberList) {
        groupMemberList.forEach((element) {
          if (element.code == sxtAccount.code) {
            containSelf = true;
            if (element.state == StateType.DELETE ||
                element.state == StateType.DISABLED) {
              containSelf = false;
            }
          }
        });
      }
      if (containSelf) {
        add(Update(groupCode));
      } else {
        if (!isPoped) {
          isPoped = true;
          add(PopPage(""));

          FlutterManager.instance.notifyGroupDelete(groupCode);
        }
      }
    })).then((value) {
      groupMemberUpdateListenerJobId = value.jobId;
    });

    SxtGroupPlugin.setGroupInfoUpdateListener(
        GroupInfoUpdateListener(onChanged: (ModificationEvent<Group> event) {
      if (event.data!.groupCode != groupCode) return;

      if (event.type == ModificationEventType.DATA_DELETE) {
        if (Platform.isIOS && !isPoped) {
          isPoped = true;
          add(PopPage("群组已解散"));
          FlutterManager.instance.notifyGroupDelete(groupCode);
        }
      } else {
        if (event.data!.stateType == StateType.DELETE ||
            event.data!.stateType == StateType.DISABLED) {
          if (Platform.isIOS && !isPoped) {
            isPoped = true;
            add(PopPage("群组已解散"));
            FlutterManager.instance.notifyGroupDelete(groupCode);
          }
        } else {
          add(Initial(groupCode));
        }
      }
    })).then((value) {
      groupUpdateListenerJobId = value.jobId;
    });
  }

  @override
  Future<void> close() {
    if (null != groupMemberUpdateListenerJobId) {
      SxtManager.instance.cancelJob(groupMemberUpdateListenerJobId!);
    }
    if (null != groupUpdateListenerJobId) {
      SxtManager.instance.cancelJob(groupUpdateListenerJobId!);
    }
    return super.close();
  }

  @override
  Stream<GroupChatDetailPageState> mapEventToState(
      GroupChatDetailPageEvent event) async* {
    if (event is Initial) {
      yield* _mapInitialEventState(event);
    } else if (event is Update) {
      yield* _mapUpdateEventState(event);
    } else if (event is Loading) {
      yield* _mapLoadingEventState(event);
    } else if (event is LoadingFailed) {
      yield* _mapLoadingFailedEventState(event);
    } else if (event is LoadingSuccess) {
      yield* _mapLoadingSuccessEventState(event);
    } else if (event is PopPage) {
      yield* _mapPopPageEventState(event);
    }
  }

  Stream<GroupChatDetailPageState> _mapInitialEventState(Initial event) async* {
    Job<Group> job = await SxtGroupPlugin.getGroupInfo(event.groupCode);
    yield state.copyWith(group: job.data);

    GetGroupMemberParam getGroupMemberParam = GetGroupMemberParam();
    getGroupMemberParam.groupCode = event.groupCode;
    getGroupMemberParam.count = 10000;
    Job<List<GroupMember>> job2 =
        await SxtGroupPlugin.getGroupMember(getGroupMemberParam);

    List<String> codeList = [];
    if (null != job2.data) {
      job2.data!.forEach((element) {
        codeList.add(DomainUtil.toCode(element.code));
      });
      List<Contact> contactList = await ContactManager.instance
          .getContactsByCodes(codeList, DataFilterBuilder())
          .where((event) => event != null && event.isNotEmpty)
          .take(1)
          .first;

      List<Contact> contactList2 = [];
      Contact contact;
      for (int i = 0; i < contactList.length; i++) {
        if (contactList[i].code == DomainUtil.toCode(state.group!.userCode)) {
          contact = contactList[i];
          contactList.remove(contact);
          contactList2.add(contact);
          break;
        }
      }
      contactList2.addAll(contactList);
      yield state.copyWith(groupMemberList: contactList2);
    }
  }

  Stream<GroupChatDetailPageState> _mapUpdateEventState(Update event) async* {
    Job<Group> job = await SxtGroupPlugin.getGroupInfo(event.groupCode);
    yield state.copyWith(group: job.data);

    GetGroupMemberParam getGroupMemberParam = GetGroupMemberParam();
    getGroupMemberParam.groupCode = event.groupCode;
    getGroupMemberParam.count = 10000;
    Job<List<GroupMember>> job2 =
        await SxtGroupPlugin.getGroupMember(getGroupMemberParam);

    List<String> codeList = [];
    if (null != job2.data) {
      job2.data!.forEach((element) {
        codeList.add(DomainUtil.toCode(element.code));
      });
      List<Contact> contactList = await ContactManager.instance
          .getContactsByCodes(codeList, DataFilterBuilder())
          .where((event) => event != null && event.isNotEmpty)
          .take(1)
          .first;

      List<Contact> contactList2 = [];
      Contact contact;
      for (int i = 0; i < contactList.length; i++) {
        if (contactList[i].code == DomainUtil.toCode(state.group!.userCode)) {
          contact = contactList[i];
          contactList.remove(contact);
          contactList2.add(contact);
          break;
        }
      }
      contactList2.addAll(contactList);
      yield state.copyWith(
          groupMemberList: contactList2, status: EventStatus.update);
    }
  }

  Stream<GroupChatDetailPageState> _mapLoadingEventState(Loading event) async* {
    yield state.copyWith(
        status: EventStatus.nothing, loadingMessage: event.message);
  }

  Stream<GroupChatDetailPageState> _mapLoadingFailedEventState(
      LoadingFailed event) async* {
    yield state.copyWith(
        status: EventStatus.failure, failedMessage: event.failedMessage);
  }

  Stream<GroupChatDetailPageState> _mapPopPageEventState(PopPage event) async* {
    yield state.copyWith(
        status: EventStatus.popPage, failedMessage: event.message);
  }

  Stream<GroupChatDetailPageState> _mapLoadingSuccessEventState(
      LoadingSuccess event) async* {
    yield state.copyWith(status: EventStatus.loadingSuccess);
  }
}
