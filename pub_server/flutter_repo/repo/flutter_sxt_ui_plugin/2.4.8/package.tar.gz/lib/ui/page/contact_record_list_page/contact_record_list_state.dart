part of 'contact_record_list_bloc.dart';

class ContactRecordListState {
  final List<Message>? messageList;
  final bool? isLoading;

  const ContactRecordListState({
    @required this.messageList,
    @required this.isLoading,
  });

  ContactRecordListState.initial() : this(messageList: null, isLoading: false);

  ContactRecordListState copyWith(
      {List<Message>? messageList, bool? isLoading}) {
    return ContactRecordListState(
        messageList: messageList ?? this.messageList,
        isLoading: isLoading ?? this.isLoading);
  }
}
