import 'package:contact_sdk_flutter/model/contact.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:dartx/dartx.dart';
import 'package:extended_image/extended_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/bloc/group_member_chat_history_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/group_member_message_chat_history_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/search.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/search_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/search_empty.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/indent_divider.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:sxt_flutter_plugin/group/model/group_member.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

class GroupMemberChatHistoryPage extends StatelessWidget {
  const GroupMemberChatHistoryPage(
    this.sessionEntity, {
    Key? key,
    this.groupLeaderCode,
  }) : super(key: key);

  final SessionEntity sessionEntity;
  final String? groupLeaderCode;

  @override
  Widget build(BuildContext context) => BlocProvider(
        create: (context) =>
            GroupMemberChatHistoryBloc(sessionEntity, groupLeaderCode)
              ..add(GroupMemberChatHistoryInitEvent()),
        child: Container(
          color: Colors.white,
          child: BlocBuilder<GroupMemberChatHistoryBloc,
              GroupMemberChatHistoryState>(
            builder: (context, state) => Column(
              children: [
                if (state.keyword == null)
                  AnnotatedRegion(
                    value: SystemUiOverlayStyle.light,
                    child: SizedBox(
                      width: double.infinity,
                      child: BackgroundImageAppbar(
                        title: '按群成员查找',
                        leadingWidget: _buildBackButton(context),
                      ),
                    ),
                  ),
                if (state.keyword != null)
                  SearchAppBar(
                    autofocus: true,
                    onChanged: (keyword) => context
                        .read<GroupMemberChatHistoryBloc>()
                        .add(GroupMemberChatHistoryKeywordEvent(keyword)),
                    onPressed: () => context
                        .read<GroupMemberChatHistoryBloc>()
                        .add(GroupMemberChatHistorySearchEvent(false)),
                  ),
                Expanded(
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      state.memberList == null
                          ? const Center(
                              child: CupertinoActivityIndicator(radius: 12),
                            )
                          : state.memberList!.isEmpty
                              ? SearchEmpty(keyword: state.keyword!)
                              : CustomScrollView(
                                  slivers: [
                                    if (state.keyword == null)
                                      SliverToBoxAdapter(
                                        key: const ValueKey('search'),
                                        child: Search(
                                          onTap: () => context
                                              .read<
                                                  GroupMemberChatHistoryBloc>()
                                              .add(
                                                  GroupMemberChatHistorySearchEvent(
                                                      true)),
                                        ),
                                      ),
                                    if (state.keyword.isNotNullOrEmpty)
                                      SliverToBoxAdapter(
                                        key: const ValueKey('count'),
                                        child: _MemberCount(
                                            state.memberList!.length),
                                      ),
                                    SliverList(
                                      delegate: SliverChildBuilderDelegate(
                                        (context, index) => _MemberItem(
                                          state.memberList![index],
                                          sessionEntity: sessionEntity,
                                          groupLeaderCode: groupLeaderCode,
                                        ),
                                        childCount: state.memberList!.length,
                                      ),
                                    ),
                                  ],
                                ),
                      if (state.keyword != null && state.keyword!.isEmpty)
                        Container(
                          color: const Color(0x33000000),
                          child: InkWell(
                            onTap: () => context
                                .read<GroupMemberChatHistoryBloc>()
                                .add(GroupMemberChatHistorySearchEvent(false)),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );

  Widget _buildBackButton(BuildContext context) => IconButton(
        onPressed: Navigator.of(context).pop,
        icon: ImageIcon(
          AssetImage(
            ImageHelper.wrapAssets("ic_back.png"),
            package: PACKAGE_NAME,
          ),
          color: Colors.white,
        ),
      );
}

class _MemberItem extends StatelessWidget {
  const _MemberItem(
    this.item, {
    Key? key,
    required this.sessionEntity,
    this.groupLeaderCode,
  }) : super(key: key);

  final MapEntry<GroupMember, Contact> item;
  final SessionEntity sessionEntity;
  final String? groupLeaderCode;

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.white,
        child: InkWell(
          onTap: () => Navigator.of(context).push(
            CupertinoPageRoute(
              builder: (context) => GroupMemberMessageChatHistoryPage(
                  sessionEntity, item.key.code!),
            ),
          ),
          child: Column(
            children: [
              Container(
                height: 54,
                padding: const EdgeInsets.only(left: 15, right: 10),
                child: Row(
                  children: [
                    _buildAvatar(),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        item.value.name ?? '',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Color(0xFF333333),
                          fontSize: 16,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    if (item.key.code == groupLeaderCode)
                      const Text(
                        '群主',
                        style: TextStyle(
                          color: Color(0xFF999999),
                          fontSize: 12,
                        ),
                      ),
                  ],
                ),
              ),
              const IndentDivider(indent: 60),
            ],
          ),
        ),
      );

  Widget _buildAvatar() => ExtendedImage.network(
        StringUtil.getAvatarUrl(item.value),
        width: 36,
        height: 36,
        fit: BoxFit.cover,
        shape: BoxShape.rectangle,
        borderRadius: BorderRadius.circular(2),
        loadStateChanged: (state) {
          switch (state.extendedImageLoadState) {
            case LoadState.loading:
            case LoadState.failed:
              return Image.asset(
                'images/icon_person_placeholder.png',
                package: PACKAGE_NAME,
              );
            default:
              return state.completedWidget;
          }
        },
      );
}

class _MemberCount extends StatelessWidget {
  const _MemberCount(this.count, {Key? key}) : super(key: key);

  final int count;

  @override
  Widget build(BuildContext context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: 30,
            color: Colors.white,
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.only(left: 15),
            child: Text(
              '$count 位成员',
              style: const TextStyle(
                color: Color(0xFF999999),
                fontSize: 12,
              ),
            ),
          ),
          const IndentDivider(indent: 15),
        ],
      );
}
