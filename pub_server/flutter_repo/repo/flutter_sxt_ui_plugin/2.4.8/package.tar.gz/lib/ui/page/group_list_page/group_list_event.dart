part of 'group_list_bloc.dart';

@immutable
abstract class GroupListEvent {
  const GroupListEvent();
}

class SearchGroup extends GroupListEvent {
  final String keyword;

  const SearchGroup(this.keyword);
}

class Initial extends GroupListEvent {
  const Initial();
}

class UpdateGroup extends GroupListEvent {
  final Group group;

  const UpdateGroup(this.group);
}
