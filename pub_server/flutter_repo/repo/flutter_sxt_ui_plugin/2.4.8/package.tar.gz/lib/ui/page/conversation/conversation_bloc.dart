import 'dart:async';

import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:dartx/dartx.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/strong_reminder/strong_reminder_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/conversation_event.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/conversation_state.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/ontop/ontop_conversation_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/message_banner.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/sxt_status_listener.dart';
import 'package:sprintf/sprintf.dart';
import 'package:sxt_flutter_plugin/account/model/sxt_account.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';
import 'package:sxt_flutter_plugin/group/listener/group_avatar_state_update_listener.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/message/listener/conversation_update_listener.dart';
import 'package:sxt_flutter_plugin/message/model/conversation.dart';
import 'package:sxt_flutter_plugin/message/model/prompt_type.dart';
import 'package:sxt_flutter_plugin/message/model/send_state.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';
import 'package:sxt_flutter_plugin/message/model/set_conv_unread_count_param.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';
import 'package:sxt_flutter_plugin/model/modification_event.dart';
import 'package:sxt_flutter_plugin/ptt/listener/ptt_talk_listener.dart';
import 'package:sxt_flutter_plugin/ptt/model/monitor_ptt_talk_status_event.dart';
import 'package:sxt_flutter_plugin/ptt/sxt_ptt_plugin.dart';

class ConversationBloc extends Bloc<ConversationEvent, ConversationState> {
  ConversationBloc(this.context)
      : _onTopBloc = context.read(),
        _strongReminderBloc = context.read(),
        super(ConversationState());

  final BuildContext context;
  final OnTopConversationBloc _onTopBloc;
  final StrongReminderBloc _strongReminderBloc;

  int _onTopLength = 0;
  SxtAccount? _currentAccount;
  final List<String> _pttTalkingList = [];

  @override
  Stream<ConversationState> mapEventToState(ConversationEvent event) async* {
    if (event is ConversationInitialEvent) {
      _listenPttTalk();
      _listenGroupAvatarState();
      _listenConversationUpdate();
      await _getCurrentUser();
      yield* _loadConversationList();
    } else if (event is ConversationUpdateEvent) {
      yield* _updateConversation(event.data);
    } else if (event is ConversationUnreadCountEvent) {
      _setConversationUnreadCount(event);
    } else if (event is ConversationDeleteEvent) {
      _deleteConversation(event);
    } else if (event is GroupAvatarUpdateEvent) {
      yield* _updateGroupAvatar(event.data);
    } else if (event is PttTalkStateUpdateEvent) {
      yield* _updatePttTalkingList(event.data);
    } else if (event is MessageFreeUpdateEvent) {
      yield state.copyWith();
    } else if (event is OnTopConversationListUpdateEvent) {
      yield* _handleOnTopConversation();
    }
  }

  bool isPttTalking(Conversation conversation) {
    return _pttTalkingList.contains(conversation.talker?.code);
  }

  Future<void> _getCurrentUser() async {
    _currentAccount = await SxtAccountPlugin.getCurrentUser();
  }

  void _deleteConversation(ConversationDeleteEvent event) {
    SxtMessagePlugin.delConversation(event.conversation);
  }

  void _setConversationUnreadCount(ConversationUnreadCountEvent event) {
    final params = SetConvUnreadCountParam();
    params.count = event.unreadCount;
    params.sessionEnitity = event.conversation.talker;
    SxtMessagePlugin.setConvUnreadCount(params);
  }

  Stream<ConversationState> _updatePttTalkingList(
      MonitorPttTalkStatusEvent pttTalk) async* {
    if (pttTalk.room?.isSpeakingState == true) {
      _pttTalkingList.add(pttTalk.room!.talker!.code!);
    } else {
      _pttTalkingList.remove(pttTalk.room?.talker?.code);
    }
    yield state.copyWith();
  }

  Stream<ConversationState> _updateGroupAvatar(Group group) async* {
    final conversation = state.conversations!.firstWhere((e) =>
        e.talker?.sessionType == SessionType.GROUP &&
        e.talker?.code == group.groupCode);
    conversation.talker!.avatarThumbPath = group.avatarThumbPath;
    yield state.copyWith();
  }

  void _listenPttTalk() {
    SxtPttPlugin.setPttTalkListener(PttTalkListener(onEvent: (event) {
      add(PttTalkStateUpdateEvent(event));
    })).then((job) => StatusChangeLister.setJobId(job.jobId!));
  }

  void _listenGroupAvatarState() {
    SxtGroupPlugin.setGroupAvatarStateUpdateListener(
        GroupAvatarStateUpdateListener(onChanged: (event) {
      if (event.group?.avatarThumbState == SendState.SUCCESS) {
        add(GroupAvatarUpdateEvent(event.group!));
      }
    })).then((job) => StatusChangeLister.setJobId(job.jobId!));
  }

  void _listenConversationUpdate() {
    SxtMessagePlugin.setConversationUpdateListener(
        ConversationUpdateListener(onChanged: (event) {
      add(ConversationUpdateEvent(event));
    })).then((job) => StatusChangeLister.setJobId(job.jobId!));
  }

  Stream<ConversationState> _updateConversation(
      ModificationEvent<Conversation> event) async* {
    final conversation = event.data!;
    switch (event.type) {
      case 0:
        await _updateConversationInfo(conversation);
        await _updateGroupSenderName(conversation);
        await _updateConversationContent(conversation);
        final index = state.conversations!
            .indexWhere((e) => e.convCode == conversation.convCode);
        if (conversation.receiverTime ==
            state.conversations![index].receiverTime) {
          state.conversations!.removeAt(index);
          state.conversations!.insert(index, conversation);
        } else {
          state.conversations!.removeAt(index);
          final isOnTop = _onTopBloc.isOnTopConversation(conversation.talker!);
          if (isOnTop) {
            state.conversations!.insert(0, conversation);
          } else {
            state.conversations!.insert(_onTopLength, conversation);
          }
        }
        break;
      case 1:
        state.conversations!
            .removeWhere((e) => e.convCode == conversation.convCode);
        _onTopBloc.state.onTopConversationList
            .remove(conversation.talker?.code);
        break;
      case 2:
        await _updateConversationInfo(conversation);
        await _updateGroupSenderName(conversation);
        await _updateConversationContent(conversation);
        _downloadGroupAvatar(conversation);
        state.conversations!.insert(_onTopLength, conversation);
    }
    _showStrongReminder(conversation);
    yield state.copyWith();
  }

  void _showStrongReminder(Conversation conversation) {
    final milliseconds =
        _strongReminderBloc.state.strongReminder[conversation.talker?.code];
    if (milliseconds == null) return;

    final now = DateTime.now();
    final date = DateTime.fromMillisecondsSinceEpoch(milliseconds);
    if (date.isBefore(now)) {
      _strongReminderBloc
          .add(StrongReminderSwitchEvent(conversation.talker!, false));
      return;
    }

    if (conversation.isNewUnreadIncoming == true &&
        conversation.sender?.code != _currentAccount?.code &&
        conversation.talker?.code != _strongReminderBloc.currentChat?.code) {
      _strongReminderBloc
          .add(StrongReminderSwitchEvent(conversation.talker!, false));
      MessageBanner.show(
        conversation.talker!.avatarThumbUrl!,
        conversation.talker!.name!,
        conversation.talker!,
        context,
        (msg) {
          Navigator.of(context).push(CupertinoPageRoute(
            settings: const RouteSettings(name: '/ChatPage'),
            builder: (context) => ChatPage(sessionEntity: msg),
          ));
        },
      );
    }
  }

  Stream<ConversationState> _loadConversationList() async* {
    final job = await SxtMessagePlugin.getConversationList();
    state.conversations = job.data;
    _sortConversationByOnTop();

    for (var conversation in state.conversations!) {
      await _updateConversationInfo(conversation);
      await _updateGroupSenderName(conversation);
      await _updateConversationContent(conversation);
    }

    for (var conversation in state.conversations!) {
      _downloadGroupAvatar(conversation);
    }

    yield state.copyWith();
  }

  Stream<ConversationState> _handleOnTopConversation() async* {
    _sortConversationByOnTop();
    _sortConversationByTime();
    yield state.copyWith();
  }

  void _sortConversationByOnTop() {
    final onTopConversationList = _onTopBloc.state.onTopConversationList;
    _onTopLength = 0;
    for (var onTopConversation in onTopConversationList) {
      final index = state.conversations!
          .indexWhere((e) => e.talker?.code == onTopConversation);
      if (index != -1) {
        final conversation = state.conversations!.removeAt(index);
        state.conversations!.insert(0, conversation);
        _onTopLength++;
      }
    }
  }

  void _sortConversationByTime() {
    final noOnTopList = state.conversations!.sublist(_onTopLength);
    final sortedList =
        noOnTopList.sortedByDescending((e) => e.receiverTime!).toList();
    state.conversations!.removeRange(_onTopLength, state.conversations!.length);
    state.conversations!.addAll(sortedList);
  }

  void _downloadGroupAvatar(Conversation conversation) {
    if (conversation.talker?.sessionType == SessionType.GROUP &&
        conversation.talker?.avatarThumbState != SendState.SUCCESS) {
      SxtGroupPlugin.downloadGroupThumbAvatar(conversation.talker!.code!);
    }
  }

  Future<void> _updateConversationContent(Conversation conversation) async {
    String? prefix;
    switch (conversation.talker?.sessionType) {
      case SessionType.GROUP:
        final name = conversation.sender?.name;
        if (conversation.promptType == PromptType.REVOKE) {
          if (conversation.sender?.code == _currentAccount?.code) {
            prefix = '你';
          } else {
            if (name != null) prefix = name;
          }
        } else if (conversation.promptType == PromptType.GROUP) {
          if (conversation.memberList?.isNotEmpty == true) {
            final contactList = await DataManager.instance.getContactList(
                conversation.memberList!.map((e) => e.userCode!).toList());
            conversation.content = sprintf.call(
                conversation.content!, contactList.map((e) => e.name).toList());
          }
        } else {
          if (name != null) prefix = name + ': ';
        }
        break;
      case SessionType.USER:
        if (conversation.promptType == PromptType.REVOKE) {
          if (conversation.sender?.code == _currentAccount?.code) {
            prefix = '你';
          } else {
            prefix = '对方';
          }
        }
    }
    if (prefix != null) conversation.content = prefix + conversation.content!;
  }

  Future<void> _updateGroupSenderName(Conversation conversation) async {
    if (conversation.talker?.sessionType != SessionType.GROUP) return;
    if (DomainUtil.toCode(conversation.sender?.code).isNullOrEmpty) return;
    final contact =
        await DataManager.instance.getContact(conversation.sender!.code!);
    conversation.sender?.name = contact?.name;
  }

  Future<void> _updateConversationInfo(Conversation conversation) async {
    switch (conversation.talker?.sessionType) {
      case SessionType.GROUP:
        if (conversation.talker!.name.isNotNullOrEmpty) return;
        final job =
            await SxtGroupPlugin.getGroupInfo(conversation.talker!.code!);
        conversation.talker!.name = job.data!.groupName;
        conversation.talker!.avatarThumbState = job.data!.avatarThumbState;
        conversation.talker!.avatarThumbPath = job.data!.avatarThumbPath;
        break;
      case SessionType.USER:
        final contact =
            await DataManager.instance.getContact(conversation.talker!.code!);
        final avatarUrl = StringUtil.getAvatarUrl(contact!);
        conversation.talker!.name = contact.name;
        conversation.talker!.avatarThumbUrl = avatarUrl;
    }
  }
}
