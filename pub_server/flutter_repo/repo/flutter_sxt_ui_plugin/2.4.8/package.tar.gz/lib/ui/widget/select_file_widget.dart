import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/ui/round_checkbox.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/select_file/select_file_bloc.dart';
import 'package:flutter_sxt_ui_plugin/utils/file_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';

class SelectFileWidget extends StatelessWidget {
  bool? isSelectable;
  bool? isCheckable;
  SelectFileModel? file;
  Function? onFavClick;
  Function? onItemClick;
  Function(SelectFileModel)? onSelected;

  SelectFileWidget(
      {this.isSelectable,
      this.isCheckable,
      this.file,
      this.onItemClick,
      this.onFavClick,
      this.onSelected});

  AssetImage getFileIcon(String path) {
    if (path.endsWith("txt")) {
      return ImageHelper.getAssetImage("ic_txt.png");
    } else if (path.endsWith("zip")) {
      return ImageHelper.getAssetImage("ic_zip.png");
    } else if (path.endsWith("rar")) {
      return ImageHelper.getAssetImage("ic_rar.png");
    } else if (path.endsWith("doc") || path.endsWith("docx")) {
      return ImageHelper.getAssetImage("ic_word.png");
    } else if (path.endsWith("xlsx")) {
      return ImageHelper.getAssetImage("ic_xls.png");
    } else if (path.endsWith("mp3") || path.endsWith("m4a") || path.endsWith("mp4")) {
      return ImageHelper.getAssetImage("ic_mp3.png");
    } else if (path.endsWith("ppt") || path.endsWith("pptx")) {
      return ImageHelper.getAssetImage("ic_ppt.png");
    } else if (path.endsWith("pdf")) {
      return ImageHelper.getAssetImage("ic_pdf.png");
    } else {
      return ImageHelper.getAssetImage("ic_file_large.png");
    }
  }

  @override
  Widget build(BuildContext context) {
    final DateTime chatTime = DateTime.fromMillisecondsSinceEpoch(file!.fileModel!.timeStamp ?? 0);
    final String timeStr = "${chatTime.year}/${chatTime.month}/${chatTime.day}";
    return InkWell(
      // splashColor: (isSelectable ?? false && file != null) ? Colors.transparent : ThemeData.light().splashColor,
      // highlightColor: (isSelectable ?? false && file != null) ? Colors.transparent : ThemeData.light().highlightColor,
      onTap: () {
        onItemClick!();
      },
      child: Container(
        color: Colors.white,
        height: 86,
        padding: EdgeInsets.only(left: 10),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Row(
            children: [
              Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(right: 6, top: 15),
                    child: RoundCheckBox(
                        this.file!.isChecked!, isCheckable ?? true,
                        (isChecked) {
                      this.file!.isChecked = isChecked;
                      onSelected!(this.file!);
                    }),
                  )
                ],
              ),
              Expanded(
                  child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        margin: EdgeInsets.only(right: 21, top: 15),
                        child: Image(
                          image: getFileIcon(file?.fileModel?.path ?? ""),
                          width: 36,
                          height: 36,
                          fit: BoxFit.contain,
                        ),
                      ),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.only(top: 15),
                              child: Text(this.file?.fileModel?.name ?? "",
                                  style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis),
                            ),
                            Container(
                              // alignment: Alignment.centerLeft,
                              child: Text(
                                FileUtil.getFileSize(
                                    this.file?.fileModel?.size ?? 0),
                                style: TextStyle(
                                    fontSize: 12,
                                    color: CustomColors.cl_999999),
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 10),
                        child: Text(
                          this.file?.detailStr ?? "",
                          style: TextStyle(
                              fontSize: 12, color: CustomColors.cl_999999),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 10,left: 5),
                        child: Text(
                          timeStr,
                          style: TextStyle(
                              fontSize: 12, color: CustomColors.cl_999999),
                        ),
                      )
                    ],
                  )

                ],
              )),
              Align(
                alignment: Alignment.centerRight,
                child: InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Container(
                      margin: EdgeInsets.only(right: 10),
                      child: Image(
                        image: ImageHelper.getAssetImage("ic_more_grey.png"),
                        width: 22,
                        height: 22,
                        fit: BoxFit.contain,
                      ),
                    )),
              )
            ],
          ),
        ),
      ),
    );
  }
}
