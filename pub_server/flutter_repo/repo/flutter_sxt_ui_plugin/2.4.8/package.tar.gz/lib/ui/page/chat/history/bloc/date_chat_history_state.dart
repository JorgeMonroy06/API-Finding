part of 'date_chat_history_bloc.dart';

class DateChatHistoryState {
  DateTime? minDate;
  List<DateTime>? blackoutDates;

  DateChatHistoryState([this.minDate, this.blackoutDates]);
}
