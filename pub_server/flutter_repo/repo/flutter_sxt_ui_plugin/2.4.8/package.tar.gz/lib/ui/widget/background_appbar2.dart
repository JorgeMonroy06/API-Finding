import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';

class BackgroundImageAppbar extends StatefulWidget
    implements PreferredSizeWidget {
  final double contentHeight; //从外部指定高度
  Color navigationBarBackgroundColor; //设置导航栏背景的颜色
  Widget? leadingWidget;
  Widget? trailingWidget;
  Widget? titleWidget;

  BackgroundImageAppbar({
    this.leadingWidget,
    this.titleWidget,
    this.contentHeight = 56,
    this.navigationBarBackgroundColor = Colors.white,
    this.trailingWidget,
  }) : super();

  @override
  State<StatefulWidget> createState() {
    return BackgroundImageAppbarState();
  }

  @override
  Size get preferredSize => Size.fromHeight(contentHeight);
}

class BackgroundImageAppbarState extends State<BackgroundImageAppbar> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(gradient: ColorUtil.titleGradient),
      child: SafeArea(
        top: true,
        child: Container(
            decoration: UnderlineTabIndicator(
              borderSide: BorderSide(width: 1.0, color: Color(0xFFeeeeee)),
            ),
            height: widget.contentHeight,
            child: Stack(
              alignment: Alignment.center,
              children: <Widget>[
                Positioned(
                  left: 0,
                  child: Container(
                    child: widget.leadingWidget,
                  ),
                ),
                Container(
                  width: MediaQuery.of(context).size.width - 110,
                  child: Align(
                    alignment: Alignment.center,
                    child: widget.titleWidget,
                  ),
                ),
                Positioned(
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.only(right: 5),
                    child: widget.trailingWidget,
                  ),
                ),
              ],
            )),
      ),
    );
  }
}
