library popup_menu;

import 'dart:core';
import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/msg_pop_menu.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';

typedef PopupMenuStateChanged = Function(PopupMenu menu, bool isShow);

class PopupMenu {
  late OverlayEntry _entry;
  late List<MenuItemProvider> items;

  /// Menu will show at above or under this rect
  late Rect _showRect;

  /// The max column count, default is 4.
  late int _maxColumn;

  /// callback
  late VoidCallback dismissCallback;
  late MenuClickCallback onClickMenu;
  late PopupMenuStateChanged stateChanged;

  /// Cannot be null
  late BuildContext context;

  /// style
  late Color _backgroundColor;
  late Color _highlightColor;
  late Color _lineColor;

  /// It's showing or not.
  late bool _isShow = false;

  bool get isShow => _isShow;

  PopupMenu(
      {required MenuClickCallback onClickMenu,
      required BuildContext context,
      required VoidCallback onDismiss,
      required int maxColumn,
      required Color backgroundColor,
      required Color highlightColor,
      required Color lineColor,
      required PopupMenuStateChanged stateChanged,
      required List<MenuItemProvider> items}) {
    this.onClickMenu = onClickMenu;
    this.dismissCallback = onDismiss;
    this.stateChanged = stateChanged;
    this.items = items;
    this._maxColumn = maxColumn;
    this._backgroundColor = backgroundColor;
    this._lineColor = lineColor;
    this._highlightColor = highlightColor;
    this.context = context;
  }

  void show({Rect? rect, GlobalKey? widgetKey}) {
    if (rect == null && widgetKey == null) {
      print("'rect' and 'key' can't be both null");
      return;
    }

    this._showRect = rect ?? PopupMenu.getWidgetGlobalRect(widgetKey!);

    _entry = OverlayEntry(builder: (context) {
      return Container(
          color: Colors.transparent,
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTap: () {
              dismiss();
            },
            onVerticalDragStart: (DragStartDetails details) {
              dismiss();
            },
            onHorizontalDragStart: (DragStartDetails details) {
              dismiss();
            },
            child: MsgPopMenu(
              buildContext: context,
              showRect: _showRect,
              backgroundColor: _backgroundColor,
              onClickMenu: (item) {
                onClickMenu(item);
                dismiss();
              },
              highlightColor: _highlightColor,
              items: items,
              lineColor: _lineColor,
              maxColumn: _maxColumn,
            ),
          ));
    });

    Overlay.of(this.context)?.insert(_entry);
    _isShow = true;
    if (this.stateChanged != null) {
      this.stateChanged(this, true);
    }
  }

  static Rect getWidgetGlobalRect(GlobalKey key) {
    RenderBox renderBox = key.currentContext?.findRenderObject() as RenderBox;
    var offset = renderBox.localToGlobal(Offset.zero);
    return Rect.fromLTWH(offset.dx, offset.dy, renderBox.size.width, renderBox.size.height);
  }

  void dismiss() {
    if (!_isShow) {
      // Remove method should only be called once
      return;
    }

    _entry.remove();
    _isShow = false;
    if (dismissCallback != null) {
      dismissCallback();
    }

    if (this.stateChanged != null) {
      this.stateChanged(this, false);
    }
  }

  static MenuItem getMenuItem(String title, String img) {
    return MenuItem(
        title: title,
        image: Image.asset(
          ImageHelper.wrapAssets(img),
          package: PACKAGE_NAME,
          fit: BoxFit.fill,
          width: 16,
          height: 16,
        ),
        textAlign: TextAlign.center,
        textStyle: TextStyle(fontSize: 12, color: Colors.white));
  }
}
