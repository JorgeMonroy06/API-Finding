part of 'global_search_page_bloc.dart';

class GlobalSearchPageState {
  final List<Group>? groupList;
  final List<Contact>? contactList;
  final List<Org>? orgList;
  final List<GroupMessage>? groupMessageList;

  const GlobalSearchPageState({
    @required this.orgList,
    @required this.groupList,
    @required this.contactList,
    @required this.groupMessageList,
  });

  GlobalSearchPageState.initial()
      : this(
            orgList: null,
            groupList: null,
            contactList: null,
            groupMessageList: null);

  GlobalSearchPageState copyWith(
      {List<Org>? orgList,
      List<Group>? groupList,
      List<Contact>? contactList,
      List<GroupMessage>? groupMessageList}) {
    return GlobalSearchPageState(
        orgList: orgList ?? this.orgList,
        groupList: groupList ?? this.groupList,
        contactList: contactList ?? this.contactList,
        groupMessageList: groupMessageList ?? this.groupMessageList);
  }
}
