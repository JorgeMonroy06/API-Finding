import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:meta/meta.dart';

part 'rename_group_page_event.dart';

part 'rename_group_page_state.dart';

class RenameGroupPageBloc
    extends Bloc<RenameGroupPageEvent, RenameGroupPageState> {
  RenameGroupPageBloc() : super(RenameGroupPageState.initial());

  @override
  Stream<RenameGroupPageState> mapEventToState(
      RenameGroupPageEvent event) async* {
    if (event is Update) {
      yield state.copyWith(status: EventStatus.loading);
    } else if (event is UpdateFailed) {
      yield state.copyWith(
          status: EventStatus.failure, failedMessage: event.failedMessage);
    } else if (event is UpdateSuccess) {
      yield state.copyWith(status: EventStatus.loadingSuccess);
    }
  }
}
