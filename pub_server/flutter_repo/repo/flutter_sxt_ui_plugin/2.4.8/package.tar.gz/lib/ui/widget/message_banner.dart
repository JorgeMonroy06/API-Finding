import 'dart:async';

import 'package:contact_ui_flutter/widget/image_loader.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:vibration/vibration.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';

/// @author newtab on 2021/10/11

typedef MessageCall = void Function(SessionEntity msg);

///消息弹窗横幅
class MessageBanner {
  static void show(
    String avator,
    String name,
    SessionEntity sessionEntity,
    BuildContext context,
    MessageCall call, {
    int? seconds,
    bool? rootNavigator,
  }) async {
    if (await Vibration.hasVibrator() ?? false) {
      Vibration.vibrate(amplitude: 128);
    }
    FlutterRingtonePlayer.playNotification();

    MessageBannerView().createView(
      avator,
      name,
      sessionEntity,
      context,
      seconds ?? 5,
      call,
      rootNavigator,
    );
  }
}

class MessageBannerView {
  void createView(
    String avator,
    String name,
    SessionEntity msg,
    BuildContext context,
    int duration,
    MessageCall call,
    bool? rootNavigator,
  ) {
    OverlayEntry? _overlayEntry;
    final OverlayState? overlayState = Overlay.of(context, rootOverlay: rootNavigator ?? false);
    bool _isVisible = false;

    void closeSelfImmediately() {
      if (_isVisible) {
        _isVisible = false;
        dismiss(_overlayEntry);
      }
    }

    _overlayEntry = OverlayEntry(
      builder: (BuildContext context) => MessageViewWidget(
        finished: closeSelfImmediately,
        duration: duration,
        widget: GestureDetector(
          onTap: () {
            call(msg);
            closeSelfImmediately();
          },
          child: SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Container(
              padding: const EdgeInsets.only(
                left: 15,
                top: 10,
                bottom: 10,
              ),
              margin: const EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(6),
                boxShadow: const [
                  BoxShadow(
                    spreadRadius: 0,
                    color: Color(0x4d000000),
                    blurRadius: 15,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "消息提醒",
                          style: TextStyle(
                            color: Color(
                              0xff666666,
                            ),
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          children: [
                            ImageLoader(
                              url: avator,
                              defaultAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                              errorAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                              borderRadius: 4,
                              width: 36,
                              fit: BoxFit.cover,
                              height: 36,
                              package: PACKAGE_NAME,
                            ),
                            const SizedBox(
                              width: 8,
                            ),
                            ConstrainedBox(
                              constraints: BoxConstraints(
                                minWidth: 10,
                                maxWidth: MediaQuery.of(context).size.width / 2.7,
                              ),
                              child: Text(
                                name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Color(
                                    0xff333333,
                                  ),
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            const Text(
                              "发来一条消息",
                              style: TextStyle(
                                color: Color(
                                  0xff333333,
                                ),
                                fontSize: 14,
                              ),
                            ),
                            const Spacer(),
                          ],
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    onTap: closeSelfImmediately,
                    child: const Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: 15,
                      ),
                      child: Icon(
                        CupertinoIcons.clear_circled_solid,
                        size: 16,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
    _isVisible = true;
    overlayState!.insert(_overlayEntry);
  }

  dismiss(OverlayEntry? overlayEntry) {
    overlayEntry?.remove();
  }
}

class MessageViewWidget extends StatefulWidget {
  const MessageViewWidget({
    Key? key,
    required this.finished,
    required this.duration,
    required this.widget,
  }) : super(key: key);

  final Widget widget;
  final int duration;
  final VoidCallback finished;

  @override
  State<MessageViewWidget> createState() => _MessageViewWidgetState();
}

class _MessageViewWidgetState extends State<MessageViewWidget> with SingleTickerProviderStateMixin {
  AnimationController? _playController;
  double _offset = -120;
  static const double begin = -120;
  static const double end = 30;
  Animation<double>? _offsetAnimation;
  bool _reversed = false;
  Timer? _t;

  @override
  void dispose() {
    _playController?.dispose();
    _cancelT();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _play();
    _ready2DismissOverlay();
  }

  void _play() {
    _playController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _offsetAnimation = Tween<double>(
      begin: begin,
      end: end,
    ).animate(
      CurvedAnimation(
        parent: _playController!,
        curve: Curves.easeOutBack,
      ),
    );
    _playController?.addListener(
      () {
        if (mounted) {
          setState(() {
            _offset = _offsetAnimation!.value;
          });
        }
      },
    );
    _playController?.forward();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: _offset,
      child: GestureDetector(
        onVerticalDragUpdate: (DragUpdateDetails details) {
          _cancelT();
          final double temp = _offset + details.delta.dy;
          if (temp > end * 4) {
            return;
          }
          _offset = temp;
          setState(() {});
        },
        onVerticalDragEnd: (details) {
          if (_offset < end / 2) {
            _close();
          } else {
            _reset2Target();
            _cancelT();
            _ready2DismissOverlay();
          }
        },
        child: Material(
          color: Colors.transparent,
          child: widget.widget,
        ),
      ),
    );
  }

  void _reset2Target() {
    if (_reversed) {
      _offsetAnimation = Tween<double>(
        begin: _offset,
        end: end,
      ).animate(
        CurvedAnimation(
          parent: _playController!,
          curve: Curves.easeOutBack,
        ),
      );
      _playController?.forward();
      _reversed = false;
    } else {
      _offsetAnimation = Tween<double>(
        begin: end,
        end: _offset,
      ).animate(
        CurvedAnimation(
          parent: _playController!,
          curve: Curves.easeInBack,
        ),
      );
      _playController?.reverse();
      _reversed = true;
    }
  }

  void _close() {
    _cancelT();
    if (_reversed) {
      _offsetAnimation = Tween<double>(
        begin: _offset,
        end: begin,
      ).animate(
        CurvedAnimation(
          parent: _playController!,
          curve: Curves.linear,
        ),
      );
      _playController?.forward().then(
        (value) {
          widget.finished();
        },
      ).catchError(
        (_) {
          widget.finished();
        },
      );
    } else {
      _offsetAnimation = Tween<double>(
        begin: begin,
        end: _offset,
      ).animate(
        CurvedAnimation(
          parent: _playController!,
          curve: Curves.linear,
        ),
      );
      _playController?.reverse().then(
        (value) {
          widget.finished();
        },
      ).catchError(
        (_) {
          widget.finished();
        },
      );
    }
  }

  void _ready2DismissOverlay() {
    _t = Timer(Duration(seconds: widget.duration), _close);
  }

  void _cancelT() {
    if (_t == null) return;
    _t?.cancel();
    _t = null;
  }
}
