part of 'single_chat_detail_page_bloc.dart';

class SingleChatDetailPageState {
  final Contact? contact;
  final EventStatus? status;
  final String? failedMessage;

  const SingleChatDetailPageState({
    @required this.contact,
    @required this.status,
    @required this.failedMessage,
  });

  SingleChatDetailPageState.initial()
      : this(contact: null, status: EventStatus.nothing, failedMessage: null);

  SingleChatDetailPageState copyWith(
      {Contact? contact, EventStatus? status, String? failedMessage}) {
    return SingleChatDetailPageState(
        contact: contact ?? this.contact,
        status: status ?? this.status,
        failedMessage: failedMessage ?? this.failedMessage);
  }
}
