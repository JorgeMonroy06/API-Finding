import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

class GuardianMonitorState {
  final List<SessionEntity> sessionEntityList;

  GuardianMonitorState(this.sessionEntityList);
}
