import 'dart:convert';

import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/manager/LazyLoadState.dart';
import 'package:contact_ui_flutter/widget/background_image_appbar.dart';
import 'package:contact_ui_flutter/widget/image_loader.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_sxt_ui_plugin/manager/flutter_manager.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/ptt/scroll_to_index.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/ptt_audio_ripple_widget.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/account/model/sxt_account.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';
import 'package:sxt_flutter_plugin/group/model/get_group_member_param.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_manager.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';
import 'package:sxt_flutter_plugin/ptt/listener/ptt_talk_listener.dart';
import 'package:sxt_flutter_plugin/ptt/model/audio_chat_room.dart';
import 'package:sxt_flutter_plugin/ptt/model/monitor_ptt_talk_status_event.dart';
import 'package:sxt_flutter_plugin/ptt/model/ptt_active_param.dart';
import 'package:sxt_flutter_plugin/ptt/sxt_ptt_plugin.dart';
import 'package:vibration/vibration.dart';

/// @author newtab on 2021/9/8

class PttPage extends StatefulWidget {
  final SessionEntity? sessionEntity;
  final String? title;

  const PttPage(
    this.sessionEntity,
    this.title, {
    Key? key,
  }) : super(key: key);

  @override
  _PttPageState createState() => _PttPageState();
}

class _PttPageState extends State<PttPage> with LazyLoadState<PttPage> {
  SxtAccount? account;
  List<UserIconBean> contacts = [];

  @override
  Widget build(BuildContext context) {
    if (account == null || contacts.isEmpty) {
      return Scaffold(
        appBar: BackgroundImageAppbar(
          title: widget.title,
          leadingWidget: IconButton(
            icon: ImageIcon(
              AssetImage(ImageHelper.wrapAssets("ic_back.png"), package: PACKAGE_NAME),
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        body: const Center(
          child: CupertinoActivityIndicator(),
        ),
      );
    }
    return UsersWidget(
      widget.sessionEntity,
      account?.code,
      contacts,
      widget.title,
    );
  }

  void init() async {
    ///获取当前用户
    account = await SxtAccountPlugin.getCurrentUser();
    final List<String> codes = [];
    if (widget.sessionEntity?.sessionType == SessionType.GROUP) {
      ///获取群组信息
      final GetGroupMemberParam param = GetGroupMemberParam(groupCode: widget.sessionEntity!.code!, count: 10000);
      final members = await SxtGroupPlugin.getGroupMember(param);
      if (members.data != null && members.data!.isNotEmpty) {
        for (var element in members.data!) {
          codes.add(DomainUtil.toCode(element.code!));
        }
      }
    } else if (widget.sessionEntity?.sessionType == SessionType.USER) {
      codes.addAll([
        DomainUtil.toCode(widget.sessionEntity!.code),
        DomainUtil.toCode(account!.code),
      ]);
    }

    ///通过code拿人信息
    final tempContact = await ContactManager.instance.getContactsByCodes(codes, DataFilterBuilder()).where((element) {
      return element.isNotEmpty;
    }).first;

    if (tempContact.isNotEmpty) {
      for (var element in tempContact) {
        print("获取到的code:${element.code}");
        contacts.add(UserIconBean(element.code, element.name, StringUtil.getAvatarUrl(element)));
      }
    }
    setState(() {});
  }

  @override
  void onLazyLoad() {
    init();
  }
}

typedef IsMeSpeaking = void Function(bool isSpeaking);

class PressWidget extends StatefulWidget {
  final IsMeSpeaking isMeSpeaking;
  final SessionEntity? sessionEntity;

  const PressWidget(this.isMeSpeaking, this.sessionEntity, {Key? key}) : super(key: key);

  @override
  _PressWidgetState createState() => _PressWidgetState();
}

///下方手势页面
class _PressWidgetState extends State<PressWidget> {
  AudioChatRoom? audioChatRoom;
  bool isSpeaking = false;
  bool isVoiceLarge = true;

  @override
  void initState() {
    super.initState();
  }

  void updateAudioChatRoom(AudioChatRoom audioChatRoom) {
    this.audioChatRoom = audioChatRoom;
    setState(() {});
  }

  @override
  void dispose() {
    if (isSpeaking) {
      SxtPttPlugin.stopSpeak(
        PttActiveParam(
          talker: widget.sessionEntity,
          roomCode: audioChatRoom!.roomCode!,
        ),
      );
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (audioChatRoom == null) return Container();
    return Row(
      children: [
        const Spacer(),
        Expanded(
          child: GestureDetector(
            onLongPressStart: (_) async {
              if (audioChatRoom != null && audioChatRoom!.roomCode != null) {
                SxtPttPlugin.startSpeak(
                  PttActiveParam(
                    talker: widget.sessionEntity,
                    roomCode: audioChatRoom!.roomCode!,
                  ),
                ).then((value) async {
                  widget.isMeSpeaking(true);

                  if (await Vibration.hasVibrator() ?? false) {
                    Vibration.vibrate(amplitude: 128);
                  }

                  setState(() {
                    isSpeaking = true;
                  });
                }).onError((e, stackTrace) {
                  isSpeaking = false;

                  if (e is PlatformException) {
                    if (e.code == '7011') {
                      PTTToastView.createView(
                        e.message ?? "其他人正在讲话",
                        context,
                        1,
                      );
                    } else {
                      PTTToastView.createView(
                        "发起对讲失败",
                        context,
                        1,
                      );
                    }
                  } else {
                    PTTToastView.createView(
                      "发起对讲失败",
                      context,
                      1,
                    );
                  }

                  print(e);
                });
              }
            },
            onLongPressEnd: (_) {
              if (isSpeaking) {
                widget.isMeSpeaking(false);
                if (audioChatRoom != null && audioChatRoom!.roomCode != null) {
                  SxtPttPlugin.stopSpeak(
                    PttActiveParam(
                      talker: widget.sessionEntity,
                      roomCode: audioChatRoom!.roomCode!,
                    ),
                  );
                }
              }
              setState(() {
                isSpeaking = false;
              });
            },
            child: Container(
              alignment: Alignment.center,
              child: Image.asset(
                ImageHelper.wrapAssets(isSpeaking ? "ptt_speaking.png" : "ptt_no_speak.png"),
                package: PACKAGE_NAME,
                width: 80,
                height: 80,
              ),
            ),
          ),
        ),
        Expanded(
          child: GestureDetector(
            onTap: () {
              isVoiceLarge = !isVoiceLarge;
              FlutterManager.instance.setSpeakerphoneOn(isVoiceLarge);
              setState(() {});
            },
            child: Container(
              alignment: Alignment.center,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset(
                    ImageHelper.wrapAssets(isVoiceLarge ? "ptt_voice_large.png" : "ptt_voice_small.png"),
                    package: PACKAGE_NAME,
                    width: 40,
                    height: 40,
                  ),
                  const SizedBox(
                    height: 2,
                  ),
                  const Text(
                    "免提",
                    style: TextStyle(
                      color: Color(0xff666666),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class RoomWidget extends StatefulWidget {
  final List<UserIconBean> contacts;

  const RoomWidget(this.contacts, {Key? key}) : super(key: key);

  @override
  _RoomWidgetState createState() => _RoomWidgetState();
}

///顶部用户头像相关样式
class _RoomWidgetState extends State<RoomWidget> {
  AudioChatRoom? audioChatRoom;
  String? meCode;
  AutoScrollController? listScrollController;

  @override
  void initState() {
    listScrollController = AutoScrollController(
        viewportBoundaryGetter: () => Rect.fromLTRB(
              0,
              0,
              MediaQuery.of(context).padding.right,
              0,
            ),
        axis: Axis.horizontal);
    super.initState();
  }

  void updateAudioChatRoom(AudioChatRoom? audioChatRoom) {
    this.audioChatRoom = audioChatRoom;
    if (audioChatRoom != null) {
      meCode = null;
    }
    setState(() {});
  }

  void updateMeIsSpeaking(String? meCode) {
    this.meCode = meCode;
    if (meCode != null) {
      audioChatRoom = null;
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    String who;
    String? avatar;

    if (audioChatRoom?.isSpeakingState ?? false) {
      who = "${getNameByCode(audioChatRoom!.speaker?.code) ?? ""}正在讲话…";
      avatar = getAvatorByCode(audioChatRoom!.speaker?.code);
    } else if (meCode != null) {
      who = "我正在讲话…";
      avatar = getAvatorByCode(meCode);
    } else {
      who = "当前无人讲话";
    }

    Color textColor;
    if (who == "当前无人讲话") {
      textColor = const Color(0xff677DB1);
    } else {
      textColor = const Color(0xff29AF74);
    }

    return Container(
      margin: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 10,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: const [
          BoxShadow(
            blurRadius: 8, //阴影范围
            spreadRadius: 2, //阴影浓度
            color: Color(0xff14000000), //阴影颜色
          ),
        ],
      ),
      child: Column(
        children: [
          Expanded(
            flex: 6,
            child: Column(
              children: [
                Expanded(
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ImageLoader(
                          url: avatar,
                          defaultAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                          errorAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                          borderRadius: 4,
                          width: 44,
                          height: 44,
                          package: PACKAGE_NAME,
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        Center(
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Align(
                                alignment: Alignment.centerRight,
                                child: Image.asset(
                                  ImageHelper.wrapAssets("ptt_audio_wave.png"),
                                  package: PACKAGE_NAME,
                                  width: 20,
                                  height: 20,
                                ),
                              ),
                              const SizedBox(
                                width: 20,
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: Text(
                                  who,
                                  style: TextStyle(
                                    color: textColor,
                                    fontSize: 14,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              const SizedBox(
                                width: 20,
                              ),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Image.asset(
                                  ImageHelper.wrapAssets("ptt_audio_wave.png"),
                                  package: PACKAGE_NAME,
                                  width: 20,
                                  height: 20,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(
                  color: Color(0xffe0e0e0),
                ),
              ],
            ),
          ),
          Expanded(
            flex: 4,
            child: _buildUserList(),
          ),
        ],
      ),
    );
  }

  Widget _buildUserList() {
    int speakingIndex = -1;
    final Widget result = Container(
      width: MediaQuery.of(context).size.width,
      alignment: Alignment.center,
      child: ListView.separated(
        controller: listScrollController,
        separatorBuilder: (context, index) {
          return const SizedBox(
            width: 15,
          );
        },
        shrinkWrap: true,
        scrollDirection: Axis.horizontal,
        itemBuilder: (context, index) {
          final bool isSpeaking =
              (DomainUtil.toCode(audioChatRoom?.speaker?.code) == widget.contacts[index].code) || (DomainUtil.toCode(meCode) == widget.contacts[index].code);

          if (isSpeaking) {
            speakingIndex = index;
          }
          return AutoScrollTag(
            key: ValueKey(index),
            controller: listScrollController!,
            index: index,
            child: Container(
              alignment: Alignment.center,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    decoration:
                        BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(isSpeaking ? 5 : 0)), color: isSpeaking ? Colors.green : Colors.white),
                    padding: EdgeInsets.all(isSpeaking ? 2 : 0),
                    child: ImageLoader(
                      url: widget.contacts[index].icon,
                      defaultAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                      errorAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                      borderRadius: 4,
                      width: 30,
                      height: 30,
                      package: PACKAGE_NAME,
                    ),
                  ),
                  const SizedBox(
                    height: 6,
                  ),
                  Text(
                    widget.contacts[index].name ?? "",
                    style: const TextStyle(
                      color: Color(
                        0xff666666,
                      ),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
        itemCount: widget.contacts.length,
      ),
    );
    WidgetsBinding.instance?.addPostFrameCallback((timeStamp) async {
      if (speakingIndex >= 0) {
        await listScrollController?.scrollToIndex(speakingIndex, preferPosition: AutoScrollPosition.middle);
        listScrollController?.highlight(speakingIndex);
      }
    });

    return result;
  }

  String? getNameByCode(String? code) {
    final list = widget.contacts.where((element) => DomainUtil.toCode(element.code) == DomainUtil.toCode(code));
    if (list.isNotEmpty) {
      return list.first.name;
    }
    return "";
  }

  String getAvatorByCode(String? code) {
    final list = widget.contacts.where((element) => DomainUtil.toCode(element.code) == DomainUtil.toCode(code));
    if (list.isNotEmpty) {
      return list.first.icon;
    }
    return "";
  }
}

class UsersWidget extends StatefulWidget {
  final SessionEntity? sessionEntity;
  final String? meCode;
  final List<UserIconBean> contacts;
  final String? title;

  const UsersWidget(this.sessionEntity, this.meCode, this.contacts, this.title, {Key? key}) : super(key: key);

  @override
  _UsersWidgetState createState() => _UsersWidgetState();
}

///整体页面
class _UsersWidgetState extends State<UsersWidget> {
  GlobalKey<PTTAudioRippleWidgetState> pttAudioKey = GlobalKey();
  GlobalKey<_RoomWidgetState> roomKey = GlobalKey();
  GlobalKey<_PressWidgetState> pressKey = GlobalKey();
  bool isMeSpeaking = false;
  int? pttListenerJobId;

  @override
  void initState() {
    super.initState();
    init();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff5f5f5),
      appBar: BackgroundImageAppbar(
        title: widget.title,
        leadingWidget: IconButton(
          icon: ImageIcon(
            AssetImage(ImageHelper.wrapAssets("ic_back.png"), package: PACKAGE_NAME),
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Column(
        children: [
          Expanded(
            flex: 9,
            child: Column(
              children: [
                Expanded(
                  flex: 52,
                  child: RoomWidget(
                    widget.contacts,
                    key: roomKey,
                  ),
                ),
                Expanded(
                  flex: 60,
                  child: PTTAudioRippleWidget(
                    key: pttAudioKey,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            flex: 3,
            child: PressWidget(
              (bool isSpeaking) async {
                imSpeaking(isSpeaking);
              },
              widget.sessionEntity,
              key: pressKey,
            ),
          ),
        ],
      ),
    );
  }

  void imSpeaking(bool speaking) {
    isMeSpeaking = speaking;
    updateUserData(null);
  }

  Future<void> getRoomInfo() async {
    final audioChatRoom = (await SxtPttPlugin.getRoom(widget.sessionEntity!)).data;
    if (audioChatRoom == null) {
      ToastUtil.showToast("room获取失败,请退出重进");
      return;
    }
    print("getRoomInfo:${jsonEncode(audioChatRoom.toJson())}");
    pressKey.currentState?.updateAudioChatRoom(audioChatRoom);
    updateUserData(audioChatRoom);

    setState(() {});
  }

  void _updatePttAudioRipple({bool isMeSpeaking = false, bool? isOtherSpeaking}) {
    if (isMeSpeaking || (isOtherSpeaking != null && isOtherSpeaking)) {
      pttAudioKey.currentState?.play(isMeSpeaking: isMeSpeaking, isOtherSpeaking: isOtherSpeaking);
    } else {
      pttAudioKey.currentState?.stop(isMeSpeaking: isMeSpeaking, isOtherSpeaking: isOtherSpeaking);
    }
  }

  void pttTalkListen() async {
    final PttTalkListener pttTalkListener = PttTalkListener(onEvent: (MonitorPttTalkStatusEvent event) {
      print("PttTalkListener:${jsonEncode(event.room?.toJson())}");
      updateUserData(event.room);
    });
    pttListenerJobId = (await SxtPttPlugin.setPttTalkListener(pttTalkListener)).jobId;
  }

  @override
  void dispose() {
    if (pttListenerJobId != null) {
      SxtManager.instance.cancelJob(pttListenerJobId);
    }
    super.dispose();
  }

  void updateUserData(AudioChatRoom? audioChatRoom) {
    if (audioChatRoom == null) {
      roomKey.currentState?.updateMeIsSpeaking(isMeSpeaking ? widget.meCode : null);
      _updatePttAudioRipple(isMeSpeaking: isMeSpeaking);
      return;
    }
    roomKey.currentState?.updateAudioChatRoom(audioChatRoom);
    _updatePttAudioRipple(isMeSpeaking: isMeSpeaking, isOtherSpeaking: audioChatRoom.isSpeakingState ?? false);
  }

  void init() async {
    await getRoomInfo();
    pttTalkListen();
  }
}

class UserIconBean {
  String? code;
  String? name;
  String icon;

  UserIconBean(this.code, this.name, this.icon);
}

class PTTToastView {
  static final PTTToastView _singleton = PTTToastView._internal();

  factory PTTToastView() {
    return _singleton;
  }

  PTTToastView._internal();

  static OverlayState? overlayState;
  static OverlayEntry? _overlayEntry;
  static bool _isVisible = false;

  static void createView(String msg, BuildContext context, int duration) async {
    _overlayEntry = OverlayEntry(
      builder: (BuildContext context) => ToastWidget(
          widget: SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Container(
              alignment: Alignment.center,
              width: MediaQuery.of(context).size.width,
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xff000000),
                  borderRadius: BorderRadius.circular(24),
                ),
                margin: const EdgeInsets.symmetric(horizontal: 20),
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 8,
                ),
                child: Text(
                  msg,
                  softWrap: true,
                  style: const TextStyle(fontSize: 12, color: Colors.white),
                ),
              ),
            ),
          ),
          gravity: 0),
    );
    _isVisible = true;
    Overlay.of(context)?.insert(_overlayEntry!);
    await Future.delayed(Duration(seconds: duration));
    dismiss();
  }

  static dismiss() async {
    if (!_isVisible) {
      return;
    }
    _isVisible = false;
    _overlayEntry?.remove();
  }
}

class ToastWidget extends StatelessWidget {
  const ToastWidget({
    Key? key,
    required this.widget,
    required this.gravity,
  }) : super(key: key);

  final Widget widget;
  final int? gravity;

  @override
  Widget build(BuildContext context) {
    return Positioned(
        bottom: (MediaQuery.of(context).size.height - MediaQuery.of(context).padding.top - 120) / 4,
        child: Material(
          color: Colors.transparent,
          child: widget,
        ));
  }
}
