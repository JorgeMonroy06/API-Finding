part of 'media_chat_history_bloc.dart';

class MediaChatHistoryState {
  String? keyword;
  Map<String, List<Message>>? msgList;
  bool noMore;

  MediaChatHistoryState([this.keyword, this.msgList, this.noMore = false]);
}
