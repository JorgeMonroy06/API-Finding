import 'package:sxt_flutter_plugin/message/model/conversation.dart';

class ConversationState {
  List<Conversation>? conversations;

  ConversationState({
    this.conversations,
  });

  ConversationState copyWith({
    List<Conversation>? conversations,
  }) =>
      ConversationState(
        conversations: conversations ?? this.conversations,
      );
}
