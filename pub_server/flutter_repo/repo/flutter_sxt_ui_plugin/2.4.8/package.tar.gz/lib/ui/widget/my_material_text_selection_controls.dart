import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/msg_pop_menu.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';

class MyMaterialTextSelectionControls extends MaterialTextSelectionControls {
  Function? onDeleteMsg;
  Function? onFavMsg;
  Function? onForwardMsg;
  Function? onRevokeMsg;
  BuildContext buildContext;
  int textLength;

  MyMaterialTextSelectionControls({required this.textLength, required this.buildContext, this.onDeleteMsg, this.onFavMsg, this.onForwardMsg, this.onRevokeMsg});

  /// Builder for material-style copy/paste text selection toolbar.
  @override
  Widget buildToolbar(
    BuildContext context,
    Rect globalEditableRegion,
    double textLineHeight,
    Offset selectionMidpoint,
    List<TextSelectionPoint> endpoints,
    TextSelectionDelegate delegate,
    ClipboardStatusNotifier clipboardStatus,
    Offset? lastSecondaryTapDownPosition,
  ) {
    if (delegate.textEditingValue.selection.baseOffset == delegate.textEditingValue.selection.extentOffset) {
      WidgetsBinding.instance?.addPostFrameCallback((timeStamp) {
        delegate.userUpdateTextEditingValue(
            delegate.textEditingValue.copyWith(
              selection: delegate.textEditingValue.selection.copyWith(
                baseOffset: 0,
                extentOffset: textLength,
              ),
            ),
            SelectionChangedCause.longPress);
      });
    }

    return MyTextSelectionToolbar(
        buildContext: buildContext,
        clipboardStatus: clipboardStatus,
        handleCopy: (canCopy(delegate) && handleCopy != null) ? (() => handleCopy(delegate, clipboardStatus)) : null,
        handleDeleteMessage: () {
          onDeleteMsg!();
          delegate.hideToolbar();
        },
        handleCut: canCut(delegate) && handleCut != null ? () => handleCut(delegate) : null,
        handlePaste: canPaste(delegate) && handlePaste != null ? () => handlePaste(delegate) : null,
        handleSelectAll: canSelectAll(delegate) && handleSelectAll != null ? () => handleSelectAll(delegate) : null,
        handleFavMessage: () {
          onFavMsg!();
          delegate.hideToolbar();
          FocusScope.of(context).requestFocus(FocusNode());
        },
        handleForwardMessage: () {
          onForwardMsg!();
          delegate.hideToolbar();
          FocusScope.of(context).requestFocus(FocusNode());
        },
        handleRevokeMessage: onRevokeMsg == null
            ? null
            : () {
                onRevokeMsg!();
                delegate.hideToolbar();
                FocusScope.of(context).requestFocus(FocusNode());
              });
  }
}

class MyTextSelectionToolbar extends StatefulWidget {
  const MyTextSelectionToolbar({
    required this.buildContext,
    required this.clipboardStatus,
    this.handleCopy,
    this.handleDeleteMessage,
    this.handleCut,
    this.handlePaste,
    this.handleSelectAll,
    this.handleFavMessage,
    this.handleForwardMessage,
    this.handleRevokeMessage,
  }) : super();

  final BuildContext buildContext;
  final ClipboardStatusNotifier clipboardStatus;
  final VoidCallback? handleCopy;
  final VoidCallback? handleDeleteMessage;
  final VoidCallback? handleFavMessage;
  final VoidCallback? handleForwardMessage;
  final VoidCallback? handleCut;
  final VoidCallback? handlePaste;
  final VoidCallback? handleSelectAll;
  final VoidCallback? handleRevokeMessage;

  @override
  MyTextSelectionToolbarState createState() => MyTextSelectionToolbarState();
}

class MyTextSelectionToolbarState extends State<MyTextSelectionToolbar> {
  void _onChangedClipboardStatus() {
    setState(() {
// Inform the widget that the value of clipboardStatus has changed.
    });
  }

  @override
  void initState() {
    super.initState();
    widget.clipboardStatus.addListener(_onChangedClipboardStatus);
    widget.clipboardStatus.update();
  }

  @override
  void didUpdateWidget(MyTextSelectionToolbar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.clipboardStatus != oldWidget.clipboardStatus) {
      widget.clipboardStatus.addListener(_onChangedClipboardStatus);
      oldWidget.clipboardStatus.removeListener(_onChangedClipboardStatus);
    }
    widget.clipboardStatus.update();
  }

  @override
  void dispose() {
    super.dispose();
    if (!widget.clipboardStatus.disposed) {
      widget.clipboardStatus.removeListener(_onChangedClipboardStatus);
    }
  }

  @override
  Widget build(BuildContext context) {
    RenderBox renderBox = widget.buildContext.findRenderObject() as RenderBox;
    var offset = renderBox.localToGlobal(Offset.zero);
    Rect rect = Rect.fromLTWH(offset.dx, offset.dy, renderBox.size.width, renderBox.size.height);

    List<MenuItem> itemList = [];
    if (null != widget.handleRevokeMessage) itemList.add(getMenuItem("撤销", "ic_msg_revoke.png"));
    itemList.add(getMenuItem("删除", "ic_delete_msg.png"));
    if (widget.handleCopy != null) itemList.add(getMenuItem("复制", "ic_msg_copy.png"));
    if (widget.handleSelectAll != null) itemList.add(getMenuItem("全选", "ic_msg_select_all.png"));
    itemList.add(getMenuItem("收藏", "ic_msg_fav.png"));
    itemList.add(getMenuItem("转发", "ic_msg_forward.png"));

    return MsgPopMenu(
      buildContext: context,
      showRect: rect,
      backgroundColor: ColorUtil.COLOR_FF4C4C4C,
      onClickMenu: (MenuItemProvider item) {
        switch (item.menuTitle) {
          case "撤销":
            widget.handleRevokeMessage!();
            break;
          case "复制":
            widget.handleCopy!();
            ToastUtil.showToast("已复制");
            break;
          case "全选":
            widget.handleSelectAll!();
            break;
          case "删除":
            widget.handleDeleteMessage!();
            break;
          case "收藏":
            widget.handleFavMessage!();
            break;
          case "转发":
            widget.handleForwardMessage!();
            break;
        }
      },
      highlightColor: Color(0x55000000),
      items: itemList,
      lineColor: Colors.transparent,
      maxColumn: itemList.length,
    );
  }

  MenuItem getMenuItem(String title, String img) {
    return MenuItem(
        title: title,
        image: Image.asset(
          ImageHelper.wrapAssets(img),
          package: PACKAGE_NAME,
          fit: BoxFit.fill,
          width: 16,
          height: 16,
        ),
        textAlign: TextAlign.center,
        textStyle: TextStyle(fontSize: 12, color: Colors.white));
  }
}
