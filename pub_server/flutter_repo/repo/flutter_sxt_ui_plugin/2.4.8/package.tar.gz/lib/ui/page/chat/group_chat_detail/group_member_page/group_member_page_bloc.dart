import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/manager/flutter_manager.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/group_member_page/group_member_page.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/account/model/sxt_account.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';
import 'package:sxt_flutter_plugin/group/listener/group_info_update_listener.dart';
import 'package:sxt_flutter_plugin/group/listener/group_member_update_listener.dart';
import 'package:sxt_flutter_plugin/group/model/get_group_member_param.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/group/model/group_member.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_manager.dart';
import 'package:sxt_flutter_plugin/message/model/state_type.dart';
import 'package:sxt_flutter_plugin/model/job.dart';
import 'package:sxt_flutter_plugin/model/modification_event.dart';
import 'package:sxt_flutter_plugin/model/modification_event_type.dart';

part 'group_member_page_event.dart';

part 'group_member_page_state.dart';

class GroupMemberPageBloc
    extends Bloc<GroupMemberPageEvent, GroupMemberPageState> {
  Group group;
  bool isPoped = false;
  int? groupInfoUpdateJobId;
  int? groupMemberUpdateListenerJobId;

  GroupMemberPageBloc(this.group) : super(GroupMemberPageState.initial()) {
    add(Initial());

    SxtGroupPlugin.setGroupMemberUpdateListener(GroupMemberUpdateListener(
        onChanged: (List<GroupMember> groupMemberList) async {
      if (groupMemberList.isNotEmpty &&
          DomainUtil.toCode(groupMemberList.first.groupCode) !=
              DomainUtil.toCode(group.groupCode!)) return;
      bool containSelf = true;
      SxtAccount sxtAccount = await SxtAccountPlugin.getCurrentUser();
      if (null != groupMemberList) {
        groupMemberList.forEach((element) {
          if (element.code == sxtAccount.code) {
            containSelf = true;
            if (element.state == StateType.DELETE ||
                element.state == StateType.DISABLED) {
              containSelf = false;
            }
          }
        });
      }
      print("_______________containSelf:${containSelf}");
      if (containSelf) {
        add(Initial());
      } else {
        if (!isPoped) {
          isPoped = true;
          add(PopPage("退出成员列表"));
          FlutterManager.instance.notifyGroupDelete(group.groupCode!);
        }
      }
    })).then((value) {
      groupMemberUpdateListenerJobId = value.jobId;
    });

    SxtGroupPlugin.setGroupInfoUpdateListener(
        GroupInfoUpdateListener(onChanged: (ModificationEvent<Group> event) {
      if (DomainUtil.toCode(event.data!.groupCode) !=
          DomainUtil.toCode(group.groupCode!)) return; //如果群组code不一致直接返回
      if (event.type == ModificationEventType.DATA_DELETE) {
        //视信通SDK的bug，会回调两次，所以必须要用isPoped变量记录，防止多次pop
        if (!isPoped) {
          isPoped = true;
          print("aaaa ChatBloc PopEvent");
          add(PopPage("退出成员列表"));
          FlutterManager.instance.notifyGroupDelete(group.groupCode!);
        }
      } else {
        add(Update(group.groupCode!));
      }
    })).then((value) {
      groupInfoUpdateJobId = value.jobId;
    });
  }

  @override
  Future<void> close() {
    if (null != groupInfoUpdateJobId) {
      SxtManager.instance.cancelJob(groupInfoUpdateJobId!);
    }
    if (null != groupMemberUpdateListenerJobId) {
      SxtManager.instance.cancelJob(groupMemberUpdateListenerJobId!);
    }
    return super.close();
  }

  @override
  Stream<GroupMemberPageState> mapEventToState(
      GroupMemberPageEvent event) async* {
    if (event is Initial) {
      yield* _mapInitialEventState(event);
    } else if (event is Initial) {
      yield state.copyWith(status: EventStatus.loading);
    } else if (event is DeleteUser) {
      yield* _mapDeleteEventState(event);
    } else if (event is PopPage) {
      yield* _mapPopPageEventState(event);
    }
  }

  Stream<GroupMemberPageState> _mapPopPageEventState(PopPage event) async* {
    yield state.copyWith(
        status: EventStatus.popPage, failedMessage: event.message);
  }

  Stream<GroupMemberPageState> _mapInitialEventState(Initial event) async* {
    GetGroupMemberParam getGroupMemberParam = GetGroupMemberParam();
    getGroupMemberParam.groupCode = group.groupCode;
    getGroupMemberParam.count = 10000;
    Job<List<GroupMember>> job =
        await SxtGroupPlugin.getGroupMember(getGroupMemberParam);

    List<String> codeList = [];
    if (null != job.data) {
      job.data!.forEach((element) {
        codeList.add(DomainUtil.toCode(element.code));
      });
      List<Contact> contactList = await ContactManager.instance
          .getContactsByCodes(codeList, DataFilterBuilder())
          .where((event) => event != null && event.isNotEmpty)
          .take(1)
          .first;

      List<Contact> contactList2 = [];
      Contact contact;
      for (int i = 0; i < contactList.length; i++) {
        if (contactList[i].code == DomainUtil.toCode(group.userCode)) {
          contact = contactList[i];
          contactList.remove(contact);
          contactList2.add(contact);
          break;
        }
      }
      contactList2.addAll(contactList);
      print("________________contactList2:${contactList2.length}");
      yield state.copyWith(
          groupMemberList: contactList2,
          indexedGroupMemberList: _sort(contactList2));
    }
  }

  Stream<GroupMemberPageState> _mapDeleteEventState(DeleteUser event) async* {
    print("aaaa _mapDeleteEventState start");
    for (int i = 0; i < state.groupMemberList!.length; i++) {
      Contact contact = state.groupMemberList![i];
      if (contact.code == DomainUtil.toCode(event.code)) {
        state.groupMemberList!.remove(contact);
        break;
      }
    }
    print("aaaa _mapDeleteEventState groupMemberList!.remove");
    yield state.copyWith(indexedGroupMemberList: _sort(state.groupMemberList!));
    print("aaaa _mapDeleteEventState sort success");
  }

  List<IndexedGroupMember> _sort(List<Contact> contactList) {
    List<IndexedGroupMember> indexedGroupMemberList = [];
    if (contactList.length > 20) {
      String lastPinYin = "";
      Map<String, List<Contact>?> contactMap = {};
      for (int i = 0; i < contactList.length; i++) {
        Contact contact = contactList[i];
        if (i == 0) {
          //群主先加入集合
          IndexedGroupMember indexedGroupMember = IndexedGroupMember();
          indexedGroupMember.groupMember = contact;
          indexedGroupMemberList.add(indexedGroupMember);
        } else {
          //拼音首字母加入map
          lastPinYin = (contact.nameSpell?.substring(0, 1) ?? "").toUpperCase();

          List<Contact>? list = contactMap[lastPinYin];
          if (null == list) {
            list = [];
            contactMap[lastPinYin] = list;
          }
          list.add(contact);
        }
      }
      //map排序
      List<String> keys = contactMap.keys.toList();
      // key排序
      keys.sort((a, b) {
        List<int> al = a.codeUnits;
        List<int> bl = b.codeUnits;
        for (int i = 0; i < al.length; i++) {
          if (bl.length <= i) return 1;
          if (al[i] > bl[i]) {
            return 1;
          } else if (al[i] < bl[i]) return -1;
        }
        return 0;
      });
      var newMap = Map();
      keys.forEach((element) {
        newMap[element] = contactMap[element];
      });

      //生成加载的UI上的实体类集合
      newMap.forEach((key, value) {
        IndexedGroupMember indexedGroupMember = IndexedGroupMember();
        indexedGroupMember.word = key;
        indexedGroupMemberList.add(indexedGroupMember);

        List<Contact> contactList = value;
        contactList.forEach((element) {
          IndexedGroupMember indexedGroupMember = IndexedGroupMember();
          indexedGroupMember.groupMember = element;
          indexedGroupMemberList.add(indexedGroupMember);
        });
      });
    }

    return indexedGroupMemberList;
  }
}
