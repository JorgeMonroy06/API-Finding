part of 'select_file_bloc.dart';

@immutable
class SelectFileState {
  late List<SelectFileModel>? selectfileModelList;
  late List<SelectFileModel>? fileModelList;
  late List<SelectFileModel>? searchfileModelList;
  late bool? hasMoreData;
  late bool? isRefreshFinish;
  late bool? isLoadFinish;
  SelectFileState(
      {this.selectfileModelList,
      this.fileModelList,
      this.hasMoreData,
      this.isRefreshFinish,
      this.isLoadFinish,
      this.searchfileModelList});

  SelectFileState init() {
    return SelectFileState()
      ..selectfileModelList = []
      ..fileModelList = []
      ..searchfileModelList = []
      ..hasMoreData = true
      ..isRefreshFinish = true
      ..isLoadFinish = true;
  }

  SelectFileState clone() {
    return SelectFileState()
      ..selectfileModelList = this.selectfileModelList
      ..fileModelList = this.fileModelList
      ..searchfileModelList = this.searchfileModelList
      ..hasMoreData = this.hasMoreData
      ..isRefreshFinish = this.isRefreshFinish
      ..isLoadFinish = this.isLoadFinish;
  }
}

class IndexedContactMember {
  String? word;
  FileModel? fileModel;
}

class SelectFileModel {
  bool? isChecked;
  String? detailStr;
  FileModel? fileModel;
  SelectFileModel({this.isChecked, this.fileModel, this.detailStr});
}
