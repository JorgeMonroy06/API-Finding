class MessageFreeState {
  final List<String> messageFreeList;

  MessageFreeState(this.messageFreeList);
}
