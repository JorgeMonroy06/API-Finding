import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/widget/image_loader.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/date_time_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:sxt_flutter_plugin/message/model/file_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/location_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/share_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/text_attachment.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';

class RecordMsgItem extends StatelessWidget {
  Message? message;
  Function? onItemClick;
  String? keyword;

  String avatarUrl = "";
  String name = "";
  StateSetter? nameStateSetter;
  StateSetter? avatarStateSetter;

  RecordMsgItem({this.message, this.onItemClick, this.keyword});

  @override
  Widget build(BuildContext context) {
    String code = DomainUtil.toCode(message!.sender!.code!);

    DataManager.instance.getContact(code).then((value) {
      name = value!.name ?? "";
      avatarUrl = StringUtil.getAvatarUrl(value);

      if (nameStateSetter != null) {
        nameStateSetter!(() {});
      }
      if (avatarStateSetter != null) {
        avatarStateSetter!(() {});
      }
    });

    String fileType = "";
    String content = "";
    if (message!.msgType == MsgType.OTHERS) {
      fileType = "[文件] ";
      content = (message!.attachment as FileAttachment).filename!;
    } else if (message!.msgType == MsgType.LOCATION) {
      fileType = "[位置] ";
      content = (message!.attachment as LocationAttachment).name!;
    } else if (message!.msgType == MsgType.SHARE) {
      fileType = "[分享] ";
      content = (message!.attachment as ShareAttachment).title!;
    } else if (message!.msgType == MsgType.PICTURE) {
      fileType = "";
      content = "[图片]";
    } else if (message!.msgType == MsgType.VIDEO_FILE) {
      fileType = "";
      content = "[视频]";
    } else if (message!.msgType == MsgType.VOICE_FILE) {
      fileType = "";
      content = "[语音]";
    } else if (message!.msgType == MsgType.PROMPT) {
      fileType = "";
      content = "[戳一戳]";
    } else if (message!.msgType == MsgType.TEXT) {
      content = (message!.attachment as TextAttachment).text!;
    }
    List<String> wordList = content.split(keyword ?? "");
    List<TextSpan> spanList = [];
    int totalLength = 0;
    for (int i = 0; i < wordList.length; i++) {
      if (i == wordList.length) {
        break;
      }

      String word = wordList[i];

      String firstWord = (i == 0 ? fileType : "") + word;
      TextSpan textSpan = TextSpan(text: firstWord, style: TextStyle(fontSize: 12, color: CustomColors.cl_999999));
      spanList.add(textSpan);
      TextSpan textSpan2 = TextSpan(text: keyword, style: TextStyle(fontSize: 12, color: CustomColors.cl_0F77FE));
      spanList.add(textSpan2);

      totalLength = totalLength + firstWord.length + (keyword ?? "").length;
    }

    if (!content.endsWith(keyword ?? "") || wordList.length > content.length || totalLength > content.length) {
      spanList.removeLast();
    }

    return Material(
      color: Colors.white,
      child: InkWell(
        onTap: () => onItemClick!(),
        child: SizedBox(
          height: 60,
          child: Align(
            alignment: Alignment.centerLeft,
            child: Row(
              children: [
                const SizedBox(width: 16),
                StatefulBuilder(builder: (BuildContext context, StateSetter stateSetter) {
                  avatarStateSetter = stateSetter;
                  return ImageLoader(
                    isLocal: false,
                    url: avatarUrl,
                    defaultAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                    errorAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                    borderRadius: 4,
                    width: 36,
                    height: 36,
                    cacheWidth: 36,
                    cacheHeight: 36,
                    package: PACKAGE_NAME,
                  );
                }),
                Expanded(
                  child: Container(
                    margin: EdgeInsets.only(left: 10, right: 16),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(child: Container(
                              child: StatefulBuilder(builder: (BuildContext context, StateSetter stateSetter) {
                                nameStateSetter = stateSetter;
                                return Text(
                                  name,
                                  style: TextStyle(fontSize: 16, color: ColorUtil.color333333),
                                );
                              }),
                            )),
                            Container(
                              margin: EdgeInsets.only(left: 16),
                              child: Text(
                                DateTimeUtil.formatMessageTime(message!.createTime!),
                                style: TextStyle(fontSize: 12, color: ColorUtil.COLOR_FFBCBCBE),
                              ),
                            )
                          ],
                        ),
                        Container(
                            child: Text.rich(
                          TextSpan(children: spanList),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ))
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
