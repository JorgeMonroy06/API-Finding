import 'package:flutter/cupertino.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

@immutable
abstract class MessageFreeEvent {}

class MessageFreeInitEvent extends MessageFreeEvent {}

class MessageFreeSwitchEvent extends MessageFreeEvent {
  final SessionEntity sessionEntity;
  final bool isMessageFree;

  MessageFreeSwitchEvent(this.sessionEntity, this.isMessageFree);
}
