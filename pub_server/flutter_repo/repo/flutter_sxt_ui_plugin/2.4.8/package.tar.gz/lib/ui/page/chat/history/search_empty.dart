import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';

class SearchEmpty extends StatelessWidget {
  const SearchEmpty({Key? key, required this.keyword}) : super(key: key);

  final String keyword;

  @override
  Widget build(BuildContext context) => Container(
    color: Colors.white,
    alignment: Alignment.center,
    padding: const EdgeInsets.symmetric(horizontal: 60),
    child: Column(
      children: [
        const Spacer(flex: 190),
        Image.asset(
          'images/bg_empty_holder.png',
          package: PACKAGE_NAME,
        ),
        Text.rich(TextSpan(
          style: const TextStyle(color: Colors.grey),
          children: [
            const TextSpan(text: '没有找到“'),
            TextSpan(
              text: keyword,
              style: const TextStyle(color: Color(0xFF007AFF)),
            ),
            const TextSpan(text: '”的相关结果'),
          ],
        )),
        const Spacer(flex: 345),
      ],
    ),
  );
}
