import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:flutter_sxt_ui_plugin/utils/prefrence_util.dart';
import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

part 'strong_reminder_event.dart';
part 'strong_reminder_state.dart';

class StrongReminderBloc
    extends Bloc<StrongReminderEvent, StrongReminderState> {
  StrongReminderBloc() : super(StrongReminderState({}));

  SessionEntity? currentChat;

  @override
  Stream<StrongReminderState> mapEventToState(
      StrongReminderEvent event) async* {
    if (event is StrongReminderInitEvent) {
      yield* _getStrongReminderState();
    } else if (event is StrongReminderSwitchEvent) {
      yield* _switchStrongReminderState(event);
    }
  }

  bool isStrongReminder(SessionEntity sessionEntity) {
    return state.strongReminder.containsKey(sessionEntity.code);
  }

  Stream<StrongReminderState> _switchStrongReminderState(
      StrongReminderSwitchEvent event) async* {
    if (event.isStrongReminder) {
      state.strongReminder[event.sessionEntity.code!] =
          event.date!.millisecondsSinceEpoch;
    } else {
      state.strongReminder.remove(event.sessionEntity.code);
    }
    PreferenceUtil.setStrongReminder(state.strongReminder);
    yield StrongReminderState(state.strongReminder);
  }

  Stream<StrongReminderState> _getStrongReminderState() async* {
    final strongReminder = await PreferenceUtil.getStrongReminder();
    yield StrongReminderState(strongReminder);
  }
}
