import 'package:flutter/material.dart';

class IndentDivider extends StatelessWidget {
  const IndentDivider({
    Key? key,
    this.indent,
    this.endIndent,
  }) : super(key: key);

  final double? indent;
  final double? endIndent;

  @override
  Widget build(BuildContext context) => Container(
        color: Colors.white,
        child: Divider(
          indent: indent,
          endIndent: endIndent,
          height: 1,
          thickness: 1,
          color: const Color(0xFFEEEEEE),
        ),
      );
}
