import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/manager/LazyLoadState.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/contact_record_list_page/contact_record_list_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/record_msg_list.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

class ContactRecordListPage extends StatefulWidget {
  String keyword;
  SessionEntity sessionEntity;

  ContactRecordListPage(this.keyword, this.sessionEntity);

  @override
  _ContactRecordListState createState() => _ContactRecordListState();
}

class _ContactRecordListState extends State<ContactRecordListPage> with LazyLoadState<ContactRecordListPage> {
  late ContactRecordListBloc chatRecordListBloc;

  _ContactRecordListState();

  @override
  void prepareData() {
    super.prepareData();
    chatRecordListBloc = ContactRecordListBloc();
  }

  @override
  void onLazyLoad() {
    chatRecordListBloc.inital(widget.keyword, widget.sessionEntity);
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
        value: chatRecordListBloc,
        child: Scaffold(
          backgroundColor: CustomColors.cl_F5F5F5,
          appBar: BackgroundImageAppbar(
            title: widget.sessionEntity.name,
            leadingWidget: Container(
              padding: EdgeInsets.only(left: 12, right: 16, top: 8, bottom: 8),
              child: InkWell(
                child: ImageHelper.assetImage("ic_back.png"),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            ),
          ),
          body: Container(
            child: BlocBuilder<ContactRecordListBloc, ContactRecordListState>(builder: (context, state) {
              return NotificationListener(
                  onNotification: (ScrollNotification scrollInfo) {
                    // print("aaaa scrollInfo.metrics.pixels ${scrollInfo.metrics.pixels}");
                    // print("aaaa scrollInfo.metrics.maxScrollExtent ${scrollInfo.metrics.maxScrollExtent}");
                    if (!(state.isLoading ?? false) && (scrollInfo.metrics.pixels >= scrollInfo.metrics.maxScrollExtent) && state.messageList?.length == 20) {
                      print("aaaa onNotification start search ");
                      chatRecordListBloc.add(Search(widget.keyword, widget.sessionEntity));
                    }
                    return true;
                  },
                  child: ListView.separated(
                    padding: EdgeInsets.zero,
                    itemCount: state.messageList?.length ?? 0,
                    itemBuilder: (context, index) {
                      return RecordMsgItem(
                        message: state.messageList![index],
                        onItemClick: () {
                          Navigator.push(
                              context,
                              CupertinoPageRoute(
                                  builder: (context) {
                                    return ChatPage(
                                        normalBack: true,
                                        sessionEntity: widget.sessionEntity,
                                        isFromRecord: true,
                                        msgId: state.messageList![index].code,
                                        msgTime: state.messageList![index].createTime);
                                  },
                                  settings: RouteSettings(name: '/ChatPage')));
                        },
                        keyword: widget.keyword,
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) {
                      return Container(
                        height: 1,
                        color: Colors.white,
                        child: Container(
                          margin: EdgeInsets.only(left: 16),
                          color: CustomColors.cl_EEEEEE,
                        ),
                      );
                    },
                  ));
            }),
          ),
        ));
  }
}
