import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:loading_indicator/loading_indicator.dart';

class LoadingAnimDialog extends StatelessWidget {
  final String content;
  final Function() listener;

  LoadingAnimDialog(this.content, this.listener);

  @override
  Widget build(BuildContext context) {
    /// 禁止按返回键,不然回退栈会无法控制
    return WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: Material(
        type: MaterialType.transparency,
        child: Center(
          child: SizedBox(
            width: 140.0,
            height: 140.0,
            child: Container(
              decoration: ShapeDecoration(
                color: ColorUtil.color99000000,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(10.0),
                  ),
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Container(
                    margin: EdgeInsets.only(top: 10),
                    width: 45,
                    height: 45,
                    child: LoadingIndicator(
                      indicatorType: Indicator.lineScalePulseOutRapid,
                      color: Colors.white,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                      top: 20.0,
                    ),
                    child: Text(
                      content,
                      style: TextStyle(fontSize: 14, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
