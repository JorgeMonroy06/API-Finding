part of 'single_chat_detail_page_bloc.dart';

@immutable
abstract class SingleChatDetailPageEvent {
  const SingleChatDetailPageEvent();
}

class Initial extends SingleChatDetailPageEvent {
  final String userCode;

  const Initial(this.userCode);
}

class Loading extends SingleChatDetailPageEvent {
  const Loading();
}

class LoadingSuccess extends SingleChatDetailPageEvent {
  const LoadingSuccess();
}
