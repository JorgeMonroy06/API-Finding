/// @author newtab on 2021/8/26

import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:kd_flutter_map/widget/kd_map_appbar.dart';

class MapAppbar extends KdMapAppBar {
  MapAppbar(
    Key? key,
    String titleStr,
    Function()? backAction,
    Function()? action,
    String? actionStr,
    bool? actionEnable,
  ) : super(key, titleStr, backAction, action, actionStr, actionEnable);

  @override
  Widget buildWidget(BuildContext context) {
    Widget? rightWidget;
    bool enableAction = true;

    if (actionEnable != null) {
      enableAction = actionEnable!;
    }

    if (actionStr != null) {
      rightWidget = IgnorePointer(
        ignoring: !enableAction,
        child: CupertinoButton(
          child: Text(
            "发送",
            style: TextStyle(
              color: !enableAction ? const Color(0xff9b9b9b) : const Color(0xffffffff),
            ),
          ),
          onPressed: action,
        ),
      );
    }

    return BackgroundImageAppbar(
      title: titleStr,
      trailingWidget: rightWidget,
      leadingWidget: Container(
        padding: EdgeInsets.only(left: 12, right: 16, top: 8, bottom: 8),
        child: InkWell(
          child: Text(
            "取消",
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
            ),
          ),
          onTap: backAction ??
              () {
                Navigator.of(context).pop();
              },
        ),
      ),
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(54);
}
