import 'dart:async';

import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/manager/LazyLoadState.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/contact_record_list_page/contact_record_list_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/record_list_page/chat_record_list_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/record_list_widget.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/search_appbar.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:sxt_flutter_plugin/message/model/group_message.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

class ChatRecordListPage extends StatefulWidget {
  String keyword;

  ChatRecordListPage(this.keyword);

  @override
  _ChatRecordListState createState() => _ChatRecordListState(this.keyword);
}

class _ChatRecordListState extends State<ChatRecordListPage> with LazyLoadState<ChatRecordListPage> {
  late ChatRecordListBloc chatRecordListBloc;
  Timer? cancelTask;
  var lastKeyword = "";
  FocusNode? focus;
  TextEditingController textController = TextEditingController();

  _ChatRecordListState(this.lastKeyword);

  @override
  void prepareData() {
    super.prepareData();
    chatRecordListBloc = ChatRecordListBloc();
  }

  @override
  void onLazyLoad() {
    chatRecordListBloc.inital(widget.keyword);
    textController.text = widget.keyword;
    textController.selection = TextSelection.fromPosition(TextPosition(affinity: TextAffinity.downstream, offset: widget.keyword.length));
  }

  @override
  void initState() {
    super.initState();
    focus = FocusNode();
  }

  @override
  void dispose() {
    super.dispose();
    if (cancelTask != null && cancelTask!.isActive) {
      cancelTask?.cancel();
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
        value: chatRecordListBloc,
        child: BlocBuilder<ChatRecordListBloc, ChatRecordListState>(builder: (context, state) {
          return Scaffold(
            backgroundColor: ((state.groupMessageList?.length ?? 0) == 0 && !StringUtil.isEmpty(lastKeyword)) ? Colors.white : CustomColors.cl_F5F5F5,
            appBar: SearchAppbar(
                textController: textController,
                onSearch: (keyWord) {
                  if (null != cancelTask && cancelTask!.isActive) {
                    print('ChatRecordListPage search cancel');
                    cancelTask?.cancel();
                  }
                  print('ChatRecordListPage onChanged $keyWord');
                  print('ChatRecordListPage lastKeyword $lastKeyword');
                  if (keyWord == lastKeyword) {
                    print('ChatRecordListPage same words');
                    return;
                  }
                  print('ChatRecordListPage search start');
                  cancelTask = Timer(Duration(milliseconds: 1500), () {
                    print('ChatRecordListPage search end');
                    lastKeyword = keyWord;
                    chatRecordListBloc.add(Search(keyWord));
                  });
                },
                focus: focus),
            body: ((state.groupMessageList?.length ?? 0) == 0 && !StringUtil.isEmpty(lastKeyword))
                ? Container(
                    margin: EdgeInsets.only(top: 135),
                    child: Stack(
                      children: [
                        Center(
                          child: Column(
                            children: [
                              ImageHelper.assetImage("bg_empty_holder.png"),
                              Text.rich(TextSpan(children: [
                                TextSpan(text: "没有找到“", style: TextStyle(color: CustomColors.cl_999999)),
                                TextSpan(text: lastKeyword, style: TextStyle(color: CustomColors.cl_0F77FE)),
                                TextSpan(text: "”相关的结果", style: TextStyle(color: CustomColors.cl_999999))
                              ]))
                            ],
                          ),
                        )
                      ],
                    ),
                  )
                : Container(
                    child: Column(
                      children: [
                        Align(
                          child: Container(
                            color: Colors.white,
                            alignment: Alignment.centerLeft,
                            padding: EdgeInsets.only(top: 10, bottom: 10, left: 16),
                            child: Text(
                              '聊天记录',
                              style: TextStyle(fontSize: 12, color: CustomColors.cl_999999),
                            ),
                          ),
                        ),
                        Container(
                          height: 1,
                          color: Colors.white,
                          child: Container(
                            margin: EdgeInsets.only(left: 16),
                            color: CustomColors.cl_EEEEEE,
                          ),
                        ),
                        Expanded(
                            child: ListView.separated(
                          padding: EdgeInsets.zero,
                          itemCount: state.groupMessageList?.length ?? 0,
                          itemBuilder: (context, index) {
                            return RecordList(
                              groupMessage: state.groupMessageList![index],
                              onItemClick: (String name) {
                                if ((state.groupMessageList![index].count ?? 0) == 1) {
                                  //跳转到聊天界面
                                  GroupMessage groupMessage = state.groupMessageList![index];
                                  SessionEntity sessionEntity = SessionEntity(code: groupMessage.talkerCode, sessionType: groupMessage.talkerType);
                                  Navigator.push(
                                      context,
                                      CupertinoPageRoute(
                                          builder: (context) {
                                            return ChatPage(
                                                normalBack: true,
                                                sessionEntity: sessionEntity,
                                                isFromRecord: true,
                                                msgId: groupMessage.msgId,
                                                msgTime: groupMessage.msgTime);
                                          },
                                          settings: RouteSettings(name: '/ChatPage')));
                                } else {
                                  Navigator.push(context, new CupertinoPageRoute(builder: (context) {
                                    return ContactRecordListPage(
                                        lastKeyword,
                                        SessionEntity(
                                            code: state.groupMessageList![index].talkerCode,
                                            sessionType: state.groupMessageList![index].talkerType,
                                            name: name));
                                  }));
                                }
                              },
                              keyword: lastKeyword,
                            );
                          },
                          separatorBuilder: (BuildContext context, int index) {
                            return Container(
                              height: 1,
                              color: Colors.white,
                              child: Container(
                                margin: EdgeInsets.only(left: 16),
                                color: CustomColors.cl_EEEEEE,
                              ),
                            );
                          },
                        )),
                      ],
                    ),
                  ),
          );
        }));
  }
}
