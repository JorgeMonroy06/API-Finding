import 'dart:convert';
import 'dart:io';

import 'package:dartx/dartx_io.dart';
import 'package:extended_image/extended_image.dart';
import 'package:filesize/filesize.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_imagepicker_plugin/flutter_imagepicker_plugin.dart';
import 'package:flutter_sticky_header/flutter_sticky_header.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/bloc/contact_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/bloc/media_download_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/bloc/media_download_event.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/bloc/media_download_state.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/download_file_page.dart';
import 'package:flutter_sxt_ui_plugin/utils/file_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:intl/intl.dart';
import 'package:sxt_flutter_plugin/message/model/file_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/pic_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/send_state.dart';
import 'package:sxt_flutter_plugin/message/model/video_attachment.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';

class SliverDateHeaderChatHistory extends StatelessWidget {
  const SliverDateHeaderChatHistory({
    Key? key,
    required this.headerHeight,
    required this.headerColor,
    required this.headerStyle,
    required this.date,
    required this.list,
  }) : super(key: key);

  final double headerHeight;
  final Color headerColor;
  final TextStyle headerStyle;
  final String date;
  final List<Message> list;

  @override
  Widget build(BuildContext context) => SliverStickyHeader(
        header: _DateHeader(
          height: headerHeight,
          color: headerColor,
          style: headerStyle,
          date: date,
        ),
        sliver: list.first.msgType == MsgType.OTHERS
            ? SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => index.isEven
                      ? _FileHistoryItem(list[index ~/ 2])
                      : const Divider(
                          height: 1,
                          thickness: 1,
                          color: Color(0xFFEEEEEE),
                        ),
                  childCount: list.length * 2 - 1,
                ),
              )
            : SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                sliver: SliverGrid(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) => _HistoryGridItem(list[index]),
                    childCount: list.length,
                  ),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    mainAxisSpacing: 4,
                    crossAxisSpacing: 4,
                  ),
                ),
              ),
      );
}

class _DateHeader extends StatelessWidget {
  const _DateHeader({
    Key? key,
    required this.height,
    required this.color,
    required this.style,
    required this.date,
  }) : super(key: key);

  final double height;
  final Color color;
  final TextStyle style;
  final String date;

  @override
  Widget build(BuildContext context) => Container(
        height: height,
        color: color,
        alignment: Alignment.centerLeft,
        padding: const EdgeInsets.only(left: 10),
        child: Text(
          date,
          style: style,
        ),
      );
}

class _FileHistoryItem extends StatelessWidget {
  _FileHistoryItem(
    this.item, {
    Key? key,
  }) : super(key: key);

  final Message item;

  final _dateFormat = DateFormat('yyyy/M/d');

  FileAttachment get _attachment => item.attachment as FileAttachment;

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.white,
        child: InkWell(
          onTap: () => Navigator.of(context)
              .push(
            CupertinoPageRoute(
              builder: (context) => DownloadFilePage(msg: item),
            ),
          )
              .then((result) {
            if (result is! String) return;
            (item.attachment as FileAttachment).path = result;
          }),
          child: SizedBox(
            height: 86,
            child: Padding(
              padding: const EdgeInsets.only(left: 12, right: 10),
              child: DefaultTextStyle(
                style: const TextStyle(
                  color: Color(0xFF999999),
                  fontSize: 12,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        _buildFileTypeImage(),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _attachment.filename!,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Color(0xFF333333),
                                  fontSize: 16,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                _getFileExtension().toUpperCase() +
                                    '  ' +
                                    filesize(_attachment.size),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: BlocProvider(
                            create: (context) => ContactBloc(item.sender!.code!)
                              ..add(ContactInitEvent()),
                            child: BlocBuilder<ContactBloc, ContactState>(
                              builder: (context, state) => Text(
                                state.contact?.name ?? '',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ),
                        ),
                        Text(_dateFormat.format(
                          DateTime.fromMillisecondsSinceEpoch(item.createTime!),
                        )),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );

  Widget _buildFileTypeImage() {
    final extension = _getFileExtension();
    String name = 'ic_file_large';
    if (FileUtil.isDOC(extension)) {
      name = 'ic_word_large';
    } else if (FileUtil.isXLS(extension)) {
      name = 'ic_excel_large';
    } else if (FileUtil.isPPT(extension)) {
      name = 'ic_ppt_large';
    } else if (FileUtil.isPDF(extension)) {
      name = 'ic_pdf_large';
    } else if (FileUtil.isTXT(extension)) {
      name = 'ic_txt_large';
    } else if (FileUtil.isZIP(extension)) {
      name = 'ic_zip_large';
    } else if (extension == 'rar') {
      name = 'ic_rar_large';
    } else if (FileUtil.isMusic(extension)) {
      name = 'ic_music_large';
    }
    return Image.asset('images/$name.png', package: PACKAGE_NAME);
  }

  String _getFileExtension() {
    final extension = File(_attachment.path!).extension;
    if (extension.isEmpty) return 'file';
    return extension.substring(1);
  }
}

class _HistoryGridItem extends StatelessWidget {
  const _HistoryGridItem(this.item, {Key? key}) : super(key: key);

  final Message item;

  @override
  Widget build(BuildContext context) => BlocProvider(
        create: (context) =>
            MediaDownloadBloc(item)..add(MediaDownloadInitEvent()),
        child: Stack(
          fit: StackFit.expand,
          children: [
            _buildImage(),
            _buildDownloadProgress(),
          ],
        ),
      );

  Widget _buildImage() => BlocBuilder<MediaDownloadBloc, MediaDownloadState>(
        buildWhen: (previous, current) => previous.message != current.message,
        builder: (context, state) {
          switch (item.msgType) {
            case MsgType.PICTURE:
              return _ImageHistory(state.message);
            case MsgType.VIDEO_FILE:
              return _VideoHistory(state.message);
            default:
              return const SizedBox();
          }
        },
      );

  Widget _buildDownloadProgress() =>
      BlocBuilder<MediaDownloadBloc, MediaDownloadState>(
        buildWhen: (previous, current) => previous.progress != current.progress,
        builder: (context, state) => state.progress == null
            ? const SizedBox()
            : Container(
                color: Colors.black26,
                alignment: Alignment.center,
                child: SizedBox(
                  width: 24,
                  height: 24,
                  child:
                      CircularProgressIndicator(value: state.progress! / 100),
                ),
              ),
      );
}

class _VideoHistory extends StatelessWidget {
  _VideoHistory(this.item, {Key? key}) : super(key: key);

  final Message item;

  final _dateFormat = DateFormat('mm:ss');

  VideoAttachment get _attachment => item.attachment as VideoAttachment;

  String get _path => Platform.isIOS
      ? _attachment.thumbPath!
      : _attachment.path!.removeSuffix('.mp4') + '_thumb.png';

  @override
  Widget build(BuildContext context) => Material(
        child: InkWell(
          onTap: () => _playMedia(context, item),
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              ExtendedImage.file(
                File(_path),
                fit: BoxFit.cover,
                width: double.infinity,
                height: double.infinity,
                loadStateChanged: (state) {
                  switch (state.extendedImageLoadState) {
                    case LoadState.loading:
                    case LoadState.failed:
                      return Image.asset(
                        'images/img_video_default.png',
                        package: PACKAGE_NAME,
                      );
                    default:
                      return state.completedWidget;
                  }
                },
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Image.asset(
                      'images/ic_video_white.png',
                      package: PACKAGE_NAME,
                    ),
                    Text(
                      _dateFormat.format(DateTime.fromMillisecondsSinceEpoch(
                          _attachment.duration!)),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}

class _ImageHistory extends StatelessWidget {
  const _ImageHistory(this.item, {Key? key}) : super(key: key);

  final Message item;

  PicAttachment get _attachment => item.attachment as PicAttachment;

  @override
  Widget build(BuildContext context) => Material(
        child: InkWell(
          onTap: () => _playMedia(context, item),
          child: ExtendedImage.file(
            File(_attachment.thumbPath!),
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
            loadStateChanged: (state) {
              switch (state.extendedImageLoadState) {
                case LoadState.loading:
                case LoadState.failed:
                  return Image.asset(
                    'images/img_image_default.png',
                    package: PACKAGE_NAME,
                  );
                default:
                  return state.completedWidget;
              }
            },
          ),
        ),
      );
}

void _playMedia(BuildContext context, Message item) {
  final state = item.msgType == MsgType.PICTURE
      ? (item.attachment as PicAttachment).fileState
      : (item.attachment as VideoAttachment).fileState;
  final path = item.msgType == MsgType.PICTURE
      ? (item.attachment as PicAttachment).path
      : (item.attachment as VideoAttachment).path;

  var isDownload = false;
  if (state == SendState.SUCCESS && path.isNotNullOrEmpty) {
    final file = File(path!);
    if (file.existsSync()) isDownload = true;
  }

  if (!isDownload) {
    SxtMessagePlugin.downloadMsgAttachment(item);
    context.read<MediaDownloadBloc>().add(MediaDownloadProgressEvent(item, 5));
  } else {
    final message = jsonEncode(item.toJson()
      ..['attachment'] = item.msgType == MsgType.PICTURE
          ? (item.attachment as PicAttachment).toJson()
          : (item.attachment as VideoAttachment).toJson());
    switch (item.msgType) {
      case MsgType.PICTURE:
        KDAssetPicker.playImage(
          context,
          path!,
          isLocal: true,
          favouriteExtraJson: message,
          forwardExtraJson: message,
        );
        break;
      case MsgType.VIDEO_FILE:
        KDAssetPicker.playVideo(
          context,
          path!,
          true,
          favouriteExtraJson: message,
          forwardExtraJson: message,
        );
    }
  }
}
