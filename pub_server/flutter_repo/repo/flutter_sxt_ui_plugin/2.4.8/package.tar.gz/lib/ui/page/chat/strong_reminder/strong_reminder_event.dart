part of 'strong_reminder_bloc.dart';

@immutable
abstract class StrongReminderEvent {}

class StrongReminderInitEvent extends StrongReminderEvent {}

class StrongReminderSwitchEvent extends StrongReminderEvent {
  final SessionEntity sessionEntity;
  final bool isStrongReminder;
  final DateTime? date;

  StrongReminderSwitchEvent(
    this.sessionEntity,
    this.isStrongReminder, [
    this.date,
  ]);
}
