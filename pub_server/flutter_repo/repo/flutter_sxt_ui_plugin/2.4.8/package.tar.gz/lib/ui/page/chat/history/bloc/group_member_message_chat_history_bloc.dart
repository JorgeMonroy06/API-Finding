import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/query_msg_param.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';

part 'group_member_message_chat_history_event.dart';
part 'group_member_message_chat_history_state.dart';

class GroupMemberMessageChatHistoryBloc extends Bloc<
    GroupMemberMessageChatHistoryEvent, GroupMemberMessageChatHistoryState> {
  GroupMemberMessageChatHistoryBloc(
    SessionEntity sessionEntity,
    String memberCode,
  ) : super(GroupMemberMessageChatHistoryState()) {
    on<GroupMemberMessageChatHistoryInitEvent>((event, emit) async {
      final params = QueryMsgParam();
      params.msgCount = 9999;
      params.keyword = '';
      params.userCode = sessionEntity.code;
      params.sessionType = sessionEntity.sessionType;
      params.memberCode = memberCode;
      params.msgCode = 0;
      params.msgTime = 0;

      final job = await SxtMessagePlugin.getMsgsByGroupMember(params);
      final list = (job.data ?? [])
          .where(
              (e) => e.msgType != MsgType.AUDIO && e.msgType != MsgType.PROMPT)
          .toList();
      emit(GroupMemberMessageChatHistoryState(list));
    });
  }
}
