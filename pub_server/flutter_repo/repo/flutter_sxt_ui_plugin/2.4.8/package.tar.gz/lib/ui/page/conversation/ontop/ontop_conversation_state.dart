part of 'ontop_conversation_bloc.dart';

class OnTopConversationState {
  final List<String> onTopConversationList;

  OnTopConversationState(this.onTopConversationList);
}
