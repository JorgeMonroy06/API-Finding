import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/widget/image_loader.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/group_message.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';

class RecordList extends StatelessWidget {
  GroupMessage? groupMessage;
  Function(String name)? onItemClick;
  String? keyword;

  String avatarUrl = "";
  String name = "";
  StateSetter? nameStateSetter;
  StateSetter? avatarStateSetter;
  late List<String> wordList;
  String? fileType;
  List<TextSpan> spanList = [];

  RecordList({this.groupMessage, this.onItemClick, this.keyword});

  @override
  Widget build(BuildContext context) {
    if (groupMessage!.talkerType == SessionType.GROUP) {
      SxtGroupPlugin.getGroupInfo(groupMessage!.talkerCode!).then((value) {
        name = value.data?.groupName ?? "";
        nameStateSetter!(() {});
      });
    } else {
      String code = DomainUtil.toCode(groupMessage!.talkerCode!);
      DataManager.instance.getContact(code).then((value) {
        name = value!.name ?? "";
        avatarUrl = StringUtil.getAvatarUrl(value);

        nameStateSetter!(() {});
        avatarStateSetter!(() {});
      });
    }

    if (groupMessage?.count == 1) {
      wordList = groupMessage!.content!.split(keyword!);

      if (groupMessage!.msgType == MsgType.OTHERS) {
        fileType = "[文件] ";
      } else if (groupMessage!.msgType == MsgType.LOCATION) {
        fileType = "[位置] ";
      } else if (groupMessage!.msgType == MsgType.SHARE ||
          groupMessage!.msgType == MsgType.SHARE2) {
        fileType = "[分享] ";
      }

      spanList = [];
      int totalLength = 0;
      for (int i = 0; i < wordList.length; i++) {
        if (i == wordList.length) {
          break;
        }

        String word = wordList[i];

        String firstWord = (i == 0 ? (fileType ?? "") : "") + word;
        TextSpan textSpan = TextSpan(
            text: firstWord,
            style: TextStyle(fontSize: 12, color: CustomColors.cl_999999));
        spanList.add(textSpan);
        TextSpan textSpan2 = TextSpan(
            text: keyword,
            style: TextStyle(fontSize: 12, color: CustomColors.cl_0F77FE));
        spanList.add(textSpan2);

        totalLength = totalLength + firstWord.length + keyword!.length;
      }

      if (!groupMessage!.content!.endsWith(keyword!) ||
          wordList.length > groupMessage!.content!.length ||
          totalLength > groupMessage!.content!.length) {
        spanList.removeLast();
      }
    }

    return InkWell(
      splashColor: ThemeData.light().splashColor,
      highlightColor: ThemeData.light().highlightColor,
      onTap: () {
        onItemClick!(name);
      },
      child: Container(
        color: Colors.white,
        height: 56,
        padding: EdgeInsets.only(left: 16),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Row(
            children: [
              StatefulBuilder(
                  builder: (BuildContext context, StateSetter stateSetter) {
                avatarStateSetter = stateSetter;
                return ImageLoader(
                  isLocal: false,
                  url: avatarUrl,
                  defaultAssetImg: ImageHelper.wrapAssets(
                      groupMessage!.talkerType == SessionType.GROUP
                          ? "ic_group.png"
                          : "icon_person_placeholder.png"),
                  errorAssetImg: ImageHelper.wrapAssets(
                      groupMessage!.talkerType == SessionType.GROUP
                          ? "ic_group.png"
                          : "icon_person_placeholder.png"),
                  borderRadius: 4,
                  width: 36,
                  height: 36,
                  cacheWidth: 36,
                  cacheHeight: 36,
                  package: PACKAGE_NAME,
                );
              }),
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(left: 10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        child: StatefulBuilder(builder:
                            (BuildContext context, StateSetter stateSetter) {
                          nameStateSetter = stateSetter;
                          return Text(
                            name,
                            style: TextStyle(
                                fontSize: 16, color: ColorUtil.color333333),
                          );
                        }),
                      ),
                      Container(
                        child: (groupMessage?.count ?? 0) == 1
                            ? Text.rich(
                                TextSpan(children: spanList),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              )
                            : Text(
                                "${groupMessage?.count}条相关聊天记录",
                                style: TextStyle(
                                    fontSize: 12, color: ColorUtil.color999999),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
