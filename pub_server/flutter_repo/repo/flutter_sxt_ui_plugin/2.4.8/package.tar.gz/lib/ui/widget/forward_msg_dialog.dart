import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/widget/image_loader.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/date_time_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:sxt_flutter_plugin/message/model/attachment.dart';
import 'package:sxt_flutter_plugin/message/model/file_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/location_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/pic_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/text_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/video_attachment.dart';

class ForwardMsgDialog extends StatelessWidget {
  final List<Contact>? contactList;
  final String? groupName;
  final Attachment attachment;
  final Function onSendFunction;

  ForwardMsgDialog(this.contactList, this.groupName, this.attachment, this.onSendFunction);

  @override
  Widget build(BuildContext context) {
    return UnconstrainedBox(
        child: WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: Container(
        width: MediaQuery.of(context).size.width - 2 * 24,
        decoration: ShapeDecoration(
          color: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
              Radius.circular(10.0),
            ),
          ),
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.start, crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          Container(
            margin: EdgeInsets.only(bottom: 16, top: 18, left: 16, right: 16),
            child: Text(
              "发送给:",
              style: TextStyle(fontSize: 16, color: ColorUtil.color333333, fontWeight: FontWeight.bold),
            ),
          ),
          Container(
              margin: EdgeInsets.only(bottom: 12, left: 16, right: 16),
              child: (contactList == null || contactList!.isEmpty)
                  ? Container(
                      child: Row(
                        children: [
                          Image.asset(ImageHelper.wrapAssets("ic_group.png"), width: 36, height: 36, package: PACKAGE_NAME, fit: BoxFit.fill),
                          SizedBox(
                            width: 8,
                          ),
                          Expanded(
                              child: Text(
                            groupName ?? "",
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 16, color: ColorUtil.colorFF666666),
                          ))
                        ],
                      ),
                    )
                  : contactList!.length == 1
                      ? _contactSingle(contactList![0])
                      : ConstrainedBox(
                          constraints: BoxConstraints(
                            maxHeight: 200,
                            // minWidth: double.infinity, // //宽度尽可能大
                          ),
                          child: SingleChildScrollView(
                            child: Wrap(
                                spacing: 10,
                                runSpacing: 12,
                                children: this.contactList!.map((e) {
                                  return _contactWidget(e);
                                }).toList()),
                          ))),
          Divider(
            color: ColorUtil.COLOR_FFEEEEEE,
            height: 1,
          ),
          Container(
            margin: EdgeInsets.only(left: 16, right: 16, top: 13, bottom: 16),
            child: _attachmentWidget(context),
          ),
          Divider(
            color: ColorUtil.COLOR_FFEEEEEE,
            height: 1,
          ),
          Container(
              margin: EdgeInsets.only(left: 16, right: 16),
              height: 48,
              child: Row(
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).pop();
                      },
                      child: Text("取消", style: TextStyle(fontSize: 18, color: ColorUtil.colorFF666666), textAlign: TextAlign.center),
                    ),
                  ),
                  VerticalDivider(
                    color: ColorUtil.COLOR_FFEEEEEE,
                    width: 1,
                  ),
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).pop();
                        onSendFunction();
                      },
                      child: Text("发送", style: TextStyle(fontSize: 18, color: ColorUtil.colorFF0F77FE), textAlign: TextAlign.center),
                    ),
                  )
                ],
              ))
        ]),
      ),
    ));
  }

  Widget _attachmentWidget(BuildContext context) {
    if (attachment is TextAttachment) {
      TextAttachment textAttachment = attachment as TextAttachment;
      return Container(
        child: Text(
          textAttachment.text ?? "",
          style: TextStyle(fontSize: 14, color: ColorUtil.colorFF666666),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
      );
    } else if (attachment is PicAttachment) {
      PicAttachment picAttachment = attachment as PicAttachment;
      return Center(
          child: Container(
        width: 120,
        height: 120,
        child: ImageLoader(
          defaultAssetImg: ImageHelper.wrapAssets("ic_image_holder.png"),
          errorAssetImg: ImageHelper.wrapAssets("ic_image_holder.png"),
          url: picAttachment.path!,
          borderRadius: 4,
          isLocal: true,
          cacheWidth: (143 * MediaQuery.of(context).devicePixelRatio).round(),
          package: PACKAGE_NAME,
        ),
      ));
    } else if (attachment is FileAttachment) {
      FileAttachment fileAttachment = attachment as FileAttachment;
      return Container(
        child: Text(
          "[文件] ${fileAttachment.filename ?? ""}",
          style: TextStyle(fontSize: 14, color: ColorUtil.colorFF666666),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
      );
    } else if (attachment is LocationAttachment) {
      LocationAttachment locationAttachment = attachment as LocationAttachment;
      return Container(
        child: Text(
          "[位置] ${locationAttachment.address ?? ""}",
          style: TextStyle(fontSize: 14, color: ColorUtil.colorFF666666),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
      );
    } else if (attachment is VideoAttachment) {
      VideoAttachment videoAttachment = attachment as VideoAttachment;
      return Center(
          child: Container(
              width: 100,
              height: 143,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    child: ImageLoader(
                      defaultAssetImg: ImageHelper.wrapAssets("ic_image_holder.png"),
                      errorAssetImg: ImageHelper.wrapAssets("ic_image_holder.png"),
                      url: videoAttachment.thumbPath!,
                      borderRadius: 4,
                      isLocal: true,
                      cacheWidth: (143 * MediaQuery.of(context).devicePixelRatio).round(),
                      package: PACKAGE_NAME,
                    ),
                  ),
                  Container(
                    width: 30,
                    height: 30,
                    alignment: Alignment.center,
                    child: ImageHelper.assetImage("ic_video.png"),
                  ),
                  Container(
                    alignment: Alignment.bottomCenter,
                    margin: EdgeInsets.only(bottom: 8),
                    child: Text(
                      DateTimeUtil.getDuration(DateTimeUtil.formatLongTime(videoAttachment.duration ?? 0)),
                      style: TextStyle(fontSize: 12, color: Colors.white),
                    ),
                  )
                ],
              )));
    } else
      return Container();
  }

  Widget _contactSingle(Contact contact) {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ImageLoader(
            url: StringUtil.getAvatarUrl(contact),
            defaultAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
            errorAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
            package: PACKAGE_NAME,
            borderRadius: 2,
            width: 36,
            height: 36,
          ),
          Container(
            margin: EdgeInsets.only(left: 10),
            child: Center(
              child: Text(
                contact.name ?? "",
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 16, color: CustomColors.cl_333333),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _contactWidget(Contact contact) {
    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ImageLoader(
            url: StringUtil.getAvatarUrl(contact),
            defaultAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
            errorAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
            package: PACKAGE_NAME,
            borderRadius: 2,
            width: 36,
            height: 36,
          ),
          Container(
            margin: EdgeInsets.only(top: 4),
            padding: EdgeInsets.only(left: 1, right: 1),
            width: 36,
            child: Center(
              child: Text(
                contact.name ?? "",
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 12, color: CustomColors.cl_666666),
              ),
            ),
          )
        ],
      ),
    );
  }
}
