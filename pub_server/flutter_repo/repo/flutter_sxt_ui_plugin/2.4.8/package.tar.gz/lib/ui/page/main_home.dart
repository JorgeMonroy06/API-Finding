import 'dart:async';
import 'dart:ui';

import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/ui/contact_main/contact_main_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/event/update_main_page_index_event.dart';
import 'package:flutter_sxt_ui_plugin/manager/eventbus_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/flutter_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/my_navigator.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/conversation_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/mine.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/message_banner.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/sxt_status_listener.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

///视信通主页
class MainPage extends StatefulWidget {
  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  late int _currentIndex;
  late List<Widget> _pageOptions;
  int _msgCount = 0;
  StreamSubscription? updateMainPageIndexEventSubscription;

  String _getMsgCount() {
    if (_msgCount > 0 && _msgCount < 100) {
      return "$_msgCount";
    } else if (_msgCount >= 100) {
      return "99+";
    }
    return "";
  }

  @override
  void initState() {
    StatusChangeLister.getCurrentLoginUser();
    super.initState();
    _currentIndex = 0;
    MyNavigator.getInstance().mainPageCurrentIndex = _currentIndex;
    _pageOptions = [
      // MessagePage((int count) async {
      //   if (mounted) {
      //     setState(() {
      //       _msgCount = count;
      //     });
      //   }
      // }),
      ConversationPage(
        onUnreadMessageCountChanged: (count) => setState(() {
          _msgCount = count;
        }),
      ),
      ContactMainPage(),
      MinePage()
    ];
    updateMainPageIndexEventSubscription = SxtEventBusManager.instance.eventBus
        ?.on<UpdateMainPageIndexEvent>()
        .listen((event) {
      if (_currentIndex != 0) {
        if (mounted) {
          setState(() {
            _currentIndex = 0;
            MyNavigator.getInstance().mainPageCurrentIndex = _currentIndex;
          });
        }
      }
    });
    SxtAccountPlugin.getCurrentUser().then((value) {
      if (null != value) {
        ContactManager.instance
            .getContactsByCodes(
                [DomainUtil.toCode(value.code)], DataFilterBuilder())
            .where((event) => null != event && event.isNotEmpty)
            .first
            .then((value) {
              DataManager.instance.currentUser = value[0];
              DataManager.instance.isDisconnected = false;
            });
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
    updateMainPageIndexEventSubscription?.cancel();
  }

  @override
  Widget build(BuildContext context) {
    final List<BottomNavigationBarItem> _bottomItems = [
      BottomNavigationBarItem(
        tooltip: "",
        icon: Container(
          width: 68,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Image.asset(
                'images/icon_message_normal.png',
                width: 25,
                height: 25,
                package: PACKAGE_NAME,
              ),
              _getMsgCount().isEmpty
                  ? new Container()
                  : Positioned(
                      right: 16.0 - (_getMsgCount().length * 5),
                      top: 1,
                      child: Container(
                        height: 16,
                        alignment: Alignment.center,
                        padding: EdgeInsets.symmetric(horizontal: 4),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            color: ColorUtil.colorFF85152),
                        child: Text(
                          _getMsgCount(),
                          style: TextStyle(fontSize: 12, color: Colors.white),
                        ),
                      ),
                    )
            ],
          ),
        ),
        activeIcon: Container(
          width: 68,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Image.asset(
                'images/icon_message_selected.png',
                width: 25,
                height: 25,
                package: PACKAGE_NAME,
              ),
              _getMsgCount().isEmpty
                  ? new Container()
                  : Positioned(
                      right: 16.0 - (_getMsgCount().length * 5),
                      top: 1,
                      child: Container(
                        height: 16,
                        alignment: Alignment.center,
                        padding: EdgeInsets.symmetric(horizontal: 4),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            color: ColorUtil.colorFF85152),
                        child: Text(
                          _getMsgCount(),
                          style: TextStyle(fontSize: 12, color: Colors.white),
                        ),
                      ),
                    )
            ],
          ),
        ),
        label: "消息",
      ),
      BottomNavigationBarItem(
        tooltip: "",
        icon: Image.asset(
          'images/icon_contact_normal.png',
          width: 25,
          height: 25,
          package: PACKAGE_NAME,
        ),
        activeIcon: Image.asset(
          'images/icon_contact_selected.png',
          width: 25,
          height: 25,
          package: PACKAGE_NAME,
        ),
        label: "通讯录",
      ),
      BottomNavigationBarItem(
        tooltip: "",
        icon: Image.asset(
          'images/icon_me_normal.png',
          width: 25,
          height: 25,
          package: PACKAGE_NAME,
        ),
        activeIcon: Image.asset(
          'images/icon_me_selected.png',
          width: 25,
          height: 25,
          package: PACKAGE_NAME,
        ),
        label: "我",
      ),
    ];
    return WillPopScope(
      onWillPop: () async {
        FlutterManager.instance.gotoDesktop();
        return false; //一定要return false
      },
      child: AnnotatedRegion<SystemUiOverlayStyle>(
          value: SystemUiOverlayStyle.light,
          child: Scaffold(
            body: Stack(
              alignment: Alignment.topLeft,
              children: [
                IndexedStack(
                  children: _pageOptions,
                  index: _currentIndex,
                ),
                Positioned(
                  bottom: 0,
                  left: 0,
                  width: MediaQuery.of(context).size.width,
                  height: 0.5,
                  child: Container(
                    color: ColorUtil.dividerColor,
                  ),
                )
              ],
            ),
            bottomNavigationBar: BottomNavigationBar(
              backgroundColor: const Color(0xFFF7F7F7),
              elevation: 0,
              items: _bottomItems,
              type: BottomNavigationBarType.fixed,
              currentIndex: _currentIndex,
              selectedLabelStyle:
                  TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
              selectedItemColor: ColorUtil.color3D7DFF,
              unselectedLabelStyle: TextStyle(
                fontSize: 12,
              ),
              unselectedItemColor: ColorUtil.color333333,
              onTap: (index) {
                // MessageBanner.show(
                //   "https://www.baidu.com/link?url=-nUzYFIziGhGzK8z8G7PadOPK-jGzjj_vK8RVZf-cP7P_wapcH4xwn7P4jQ0b1wSqkfFbZAkGQxq-EMURQ9ULqJ4RSYHSOQt9qRupQVfmuljgm5KQqc0MDV9MDpLp9zJ4ChHKOw2YrOBGT5WyH2jCdDQbQtxqz-9ypr-wAmCfx-5pal6JS_Gihi3wqverlkolmf_dXu__PAP_ZlbykLJXc86JX766aDjhkfdX4_Fk3tk3GCMrwhV79j3mtuOP2n2kWSCWSHsfOZWBnVMyLGiRsDVZF3RVpEraUjbsIEeVBHnOfsQGPo3a19h7Aol3k4FRQIgWfEjpHzyfQiJpAvv7IYjPueNg5C2J5OmcuBhHxr6e5xsnLxNaIYaiVFQ0luR6a6c8IKtmn6CtvsXlx82-FPkmatGb7bQ-P9f6lRoWePGFl7a2WQf2vdKGAITO1QZXNMunuCgFxotKJvDmspeF6Xea9YlzKhKx6QbuuefiMYKKIL94pnBlQ7zlKAJvertFOFLjxIoCiXofh13uT0TH8H9VoTlTwPwLJvfMC3H31oV6EC9FZMo09p6pZ2BMOhFzwBoEBsw6wHhXOsV5-KLrK&wd=&eqid=d4b26314000142d6000000066163f942",
                //   "姜跃松",
                //   SessionEntity(),
                //   context,
                //   (msg) {
                //     print("................你点击了");
                //   },
                // );

                //点击导航栏的item
                setState(() {
                  //改变状态
                  _currentIndex = index;
                  MyNavigator.getInstance().mainPageCurrentIndex =
                      _currentIndex;
                });
              },
            ),
          )),
    );
  }
}
