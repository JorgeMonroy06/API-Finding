import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:contact_sdk_flutter/model/contact.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:meta/meta.dart';

part 'contact_event.dart';
part 'contact_state.dart';

class ContactBloc extends Bloc<ContactEvent, ContactState> {
  ContactBloc(this.code) : super(ContactState());

  final String code;

  @override
  Stream<ContactState> mapEventToState(ContactEvent event) async* {
    if (event is ContactInitEvent) {
      yield* _getContactState();
    }
  }

  Stream<ContactState> _getContactState() async* {
    final contact = await DataManager.instance.getContact(code);
    yield ContactState(contact);
  }
}
