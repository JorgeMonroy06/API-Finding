import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter_imagepicker_plugin/flutter_imagepicker_plugin.dart';
import 'package:flutter_sxt_ui_plugin/utils/fav_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/forward_msg_helper.dart';
import 'package:kd_flutter_map/widget/toast.dart';
import 'package:sxt_flutter_plugin/message/model/attachment.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/pic_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/video_attachment.dart';

/// @author newtab on 2021/9/14

///转发,收藏,下载图片和视频工具类

class MediaOperation {
  bool forward = true;
  bool favorite = true;
  bool download = true;

  void init(
    BuildContext context, {
    bool forward = false,
    bool favorite = false,
    bool download = false,
  }) {
    this.forward = forward;
    this.favorite = favorite;
    this.download = download;

    KDAssetPicker.supportForward(
      this.forward,
      _forward,
    );

    KDAssetPicker.supportFavourite(
      this.favorite,
      _favorite,
    );

    KDAssetPicker.supportDownload(true);
  }

  void dispose() {
    KDAssetPicker.resetSupportedOperates();
  }

  Future<bool> _forward(context, url, isLocal, functionType, extraJson) async {
    Map<String, dynamic> map = jsonDecode(extraJson);
    Message<Attachment> msg = Message.fromJson(map);

    if (msg.msgType == MsgType.PICTURE) {
      msg.attachment = PicAttachment.fromJson(map["attachment"]);
    } else if (msg.msgType == MsgType.VIDEO) {
      msg.attachment = VideoAttachment.fromJson(map["attachment"]);
    }
    ForwardMsgHelper.forwardMsg(
      context,
      msg.attachment!,
    );

    return false;
  }

  Future<bool> _favorite(context, url, isLocal, functionType, extraJson) async {
    if (extraJson != null) {
      try {
        Map<String, dynamic> map = jsonDecode(extraJson);
        Message<Attachment> msg = Message.fromJson(map);

        if (msg.msgType == MsgType.PICTURE) {
          msg.attachment = PicAttachment.fromJson(map["attachment"]);
        } else if (msg.msgType == MsgType.VIDEO) {
          msg.attachment = VideoAttachment.fromJson(map["attachment"]);
        }

        FavMsgHelper.favMsg(msg);
      } catch (e) {
        Toast.show("extraJson格式转换错误", context);
      }
    } else {
      Toast.show("未配置extraJson,找不到可以收藏的内容", context);
    }

    return false;
  }
}
