part of 'group_member_message_chat_history_bloc.dart';

@immutable
abstract class GroupMemberMessageChatHistoryEvent {}

class GroupMemberMessageChatHistoryInitEvent
    extends GroupMemberMessageChatHistoryEvent {}
