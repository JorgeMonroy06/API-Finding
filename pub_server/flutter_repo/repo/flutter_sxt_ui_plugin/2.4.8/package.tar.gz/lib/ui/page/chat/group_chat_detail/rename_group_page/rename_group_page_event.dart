part of 'rename_group_page_bloc.dart';

@immutable
abstract class RenameGroupPageEvent {
  const RenameGroupPageEvent();
}

class Update extends RenameGroupPageEvent {
  final String name;

  const Update(this.name);
}

class UpdateFailed extends RenameGroupPageEvent {
  final String? failedMessage;

  const UpdateFailed({this.failedMessage});
}

class UpdateSuccess extends RenameGroupPageEvent {
  const UpdateSuccess();
}
