import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:dartx/dartx.dart';
import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';

part 'date_chat_history_event.dart';
part 'date_chat_history_state.dart';

class DateChatHistoryBloc
    extends Bloc<DateChatHistoryEvent, DateChatHistoryState> {
  DateChatHistoryBloc(this.sessionEntity) : super(DateChatHistoryState());

  final SessionEntity sessionEntity;

  @override
  Stream<DateChatHistoryState> mapEventToState(
      DateChatHistoryEvent event) async* {
    if (event is DateChatHistoryInitEvent) {
      yield* _getDateChatHistoryState();
    }
  }

  Stream<DateChatHistoryState> _getDateChatHistoryState() async* {
    final job = await SxtMessagePlugin.getMsgsDate(sessionEntity);
    state.blackoutDates = [];

    if (job.data!.length >= 2) {
      for (var i = 1; i < job.data!.length; i++) {
        final previous = job.data![i - 1];
        final current = job.data![i];
        final days = Duration(milliseconds: current - previous).inDays;
        _addBlackoutDates(DateTime.fromMillisecondsSinceEpoch(previous), days);
      }
    }

    if (job.data!.isEmpty) {
      state.minDate = DateTime.now();
      state.blackoutDates!.add(DateTime.now());
    } else {
      state.minDate = DateTime.fromMillisecondsSinceEpoch(job.data![0]);

      final last = job.data!.last;
      final now = DateTime.now();
      final tomorrow =
          DateTime(now.year, now.month, now.day + 1).millisecondsSinceEpoch;
      final days = Duration(milliseconds: tomorrow - last).inDays;
      _addBlackoutDates(DateTime.fromMillisecondsSinceEpoch(last), days);
    }

    yield DateChatHistoryState(state.minDate, state.blackoutDates);
  }

  void _addBlackoutDates(DateTime startDate, int days) {
    for (var i = 1; i < days; i++) {
      state.blackoutDates!.add(startDate.add(i.days));
    }
  }
}
