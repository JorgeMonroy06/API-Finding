import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_easyrefresh/easy_refresh.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/bloc/media_chat_history_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/search.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/search_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/sliver_date_header_chat_history.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/media_operation.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/empty.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

class MediaChatHistoryPage extends StatefulWidget {
  const MediaChatHistoryPage(this.sessionEntity, this.type, {Key? key})
      : super(key: key);

  final SessionEntity sessionEntity;
  final MediaType type;

  @override
  State<MediaChatHistoryPage> createState() => _MediaChatHistoryPageState();
}

class _MediaChatHistoryPageState extends State<MediaChatHistoryPage> {
  final _mediaOperation = MediaOperation();

  @override
  void initState() {
    _mediaOperation.init(context,
        forward: true, favorite: true, download: true);
    super.initState();
  }

  @override
  void dispose() {
    _mediaOperation.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => BlocProvider(
        create: (context) =>
            MediaChatHistoryBloc(widget.sessionEntity, widget.type)
              ..add(MediaChatHistoryInitEvent()),
        child: Container(
          color: Colors.white,
          child: BlocBuilder<MediaChatHistoryBloc, MediaChatHistoryState>(
            builder: (context, state) => Column(
              children: [
                if (state.keyword == null)
                  AnnotatedRegion(
                    value: SystemUiOverlayStyle.light,
                    child: SizedBox(
                      width: double.infinity,
                      child: BackgroundImageAppbar(
                        title: widget.type == MediaType.file ? '文件' : "图片及视频",
                        leadingWidget: _buildBackButton(context),
                      ),
                    ),
                  ),
                if (state.keyword != null)
                  SearchAppBar(
                    autofocus: true,
                    onChanged: (keyword) => context
                        .read<MediaChatHistoryBloc>()
                        .add(MediaChatHistoryKeywordEvent(keyword)),
                    onPressed: () => context
                        .read<MediaChatHistoryBloc>()
                        .add(MediaChatHistorySearchEvent(false)),
                  ),
                Expanded(
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      state.msgList == null
                          ? const Center(
                              child: CupertinoActivityIndicator(radius: 12),
                            )
                          : state.msgList!.isEmpty
                              ? const Empty()
                              : EasyRefresh.custom(
                                  controller: context
                                      .read<MediaChatHistoryBloc>()
                                      .refreshController,
                                  enableControlFinishLoad: true,
                                  onLoad: state.noMore
                                      ? null
                                      : () async => context
                                          .read<MediaChatHistoryBloc>()
                                          .add(MediaChatHistoryLoadEvent()),
                                  slivers: [
                                    if (widget.type == MediaType.file &&
                                        state.keyword == null)
                                      SliverToBoxAdapter(
                                        child: Search(
                                          onTap: () => context
                                              .read<MediaChatHistoryBloc>()
                                              .add(MediaChatHistorySearchEvent(
                                                  true)),
                                        ),
                                      ),
                                    ...state.msgList!.entries
                                        .map((e) => SliverDateHeaderChatHistory(
                                              headerHeight:
                                                  widget.type == MediaType.file
                                                      ? 30
                                                      : 36,
                                              headerColor:
                                                  widget.type == MediaType.file
                                                      ? Colors.grey[100]!
                                                      : Colors.white,
                                              headerStyle: TextStyle(
                                                color: const Color(0xFF666666),
                                                fontSize: widget.type ==
                                                        MediaType.file
                                                    ? 12
                                                    : 14,
                                              ),
                                              date: e.key,
                                              list: e.value,
                                            ))
                                        .toList(),
                                  ],
                                ),
                      if (state.keyword != null && state.keyword!.isEmpty)
                        Container(
                          color: const Color(0x33000000),
                          child: InkWell(
                            onTap: () => context
                                .read<MediaChatHistoryBloc>()
                                .add(MediaChatHistorySearchEvent(false)),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );

  Widget _buildBackButton(BuildContext context) => IconButton(
        onPressed: Navigator.of(context).pop,
        icon: ImageIcon(
          AssetImage(
            ImageHelper.wrapAssets("ic_back.png"),
            package: PACKAGE_NAME,
          ),
          color: Colors.white,
        ),
      );
}
