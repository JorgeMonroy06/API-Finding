import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/rename_group_page/rename_group_page_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/loading_dialog.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';

class RenameGroupPage extends StatefulWidget {
  Group group;

  RenameGroupPage(this.group);

  @override
  State<StatefulWidget> createState() {
    return RenameGroupState();
  }
}

class RenameGroupState extends State<RenameGroupPage> {
  TextEditingController textController = TextEditingController();
  StateSetter? renameStateSetter;
  StateSetter? sureStateSetter;

  @override
  void initState() {
    super.initState();
    textController.text = widget.group.groupName ?? "";
  }

  @override
  Widget build(BuildContext context) {
    print("textController.text.trim()" + textController.text.trim());
    return BlocProvider(
        create: (_) => RenameGroupPageBloc(),
        child: Scaffold(
            backgroundColor: CustomColors.cl_F5F5F5,
            appBar: BackgroundImageAppbar(
                title: "群聊名称",
                leadingWidget: Container(
                  padding:
                      EdgeInsets.only(left: 12, right: 16, top: 8, bottom: 8),
                  child: InkWell(
                    child: ImageHelper.assetImage("ic_back.png"),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                ),
                trailingWidget:
                    BlocBuilder<RenameGroupPageBloc, RenameGroupPageState>(
                        builder: (context, state) {
                  return Container(
                    margin: EdgeInsets.only(right: 16),
                    child: InkWell(onTap: () {
                      RenameGroupPageBloc bloc =
                          BlocProvider.of<RenameGroupPageBloc>(context);
                      bloc.add(Update(textController.text));

                      SxtGroupPlugin.renameGroup(
                              widget.group.groupCode!, textController.text)
                          .then((value) {
                        bloc.add(UpdateSuccess());
                      }).onError((e, stackTrace) {
                        if (e is PlatformException) {
                          bloc.add(UpdateFailed(failedMessage: e.message));
                        } else {
                          bloc.add(UpdateFailed(failedMessage: e.toString()));
                        }
                      });
                    }, child: StatefulBuilder(
                      builder: (BuildContext context, StateSetter stateSetter) {
                        sureStateSetter = stateSetter;
                        return Text(
                          '确定',
                          style: TextStyle(
                              fontSize: 16,
                              color: (textController.text ==
                                          widget.group.groupName ||
                                      StringUtil.isEmpty(
                                          textController.text.trim()))
                                  ? ColorUtil.hintColorAAAAAA
                                  : Colors.white),
                        );
                      },
                    )),
                  );
                })),
            body: BlocListener<RenameGroupPageBloc, RenameGroupPageState>(
              listener: (context, state) {
                switch (state.status) {
                  case EventStatus.loading:
                    showDialog(
                        context: context,
                        barrierDismissible: false,
                        builder: (ctx) => LoadingDialog("修改群名称中...", () => {}));
                    break;
                  case EventStatus.failure:
                    Navigator.pop(context);
                    ToastUtil.showToast(state.failedMessage ?? "");
                    break;
                  case EventStatus.loadingSuccess:
                    Navigator.pop(context);
                    ToastUtil.showToast("修改成功");
                    Navigator.pop(context);
                    break;
                  case EventStatus.nothing:
                    break;
                  default:
                    break;
                }
              },
              child: Container(
                height: 56,
                color: Colors.white,
                child: Row(
                  children: [
                    StatefulBuilder(builder:
                        (BuildContext context, StateSetter stateSetter) {
                      bool isEdit =
                          textController.text != widget.group.groupName;
                      renameStateSetter = stateSetter;
                      return Expanded(
                        child: Container(
                          height: 32,
                          padding: EdgeInsets.only(right: 16),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(4)),
                            color: Colors.white,
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Expanded(
                                child: TextField(
                                  // inputFormatters: [
                                  //   FilteringTextInputFormatter.deny(RegExp("[`~!@#\$\%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“'。，、？]")),
                                  //   //只能输入汉字或者字母或数字
                                  // ],
                                  onChanged: (v) {
                                    renameStateSetter!(() {});
                                    sureStateSetter!(() {});
                                  },
                                  decoration: InputDecoration(
                                    contentPadding:
                                        EdgeInsets.only(left: 20, top: 2),
                                    fillColor: Colors.white,
                                    filled: true,
                                    border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(4),
                                        borderSide: BorderSide.none),
                                  ),
                                  controller: textController,
                                  textAlign: TextAlign.left,
                                  maxLines: 1,
                                  style: TextStyle(
                                      fontSize: 16,
                                      color: isEdit
                                          ? CustomColors.cl_333333
                                          : CustomColors.cl_999999),
                                ),
                              ),
                              (isEdit && (textController.text.length != 0))
                                  ? InkWell(
                                      onTap: () {
                                        textController.text = "";
                                        renameStateSetter!(() {});
                                        sureStateSetter!(() {});
                                      },
                                      child: Container(
                                        width: 23,
                                        height: 23,
                                        child: ImageHelper.assetImage(
                                            "ic_clear.png"),
                                      ))
                                  : Container()
                            ],
                          ),
                        ),
                      );
                    })
                  ],
                ),
              ),
            )));
  }
}
