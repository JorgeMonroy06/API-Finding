import 'dart:io';

import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/widget/image_loader.dart';
import 'package:extended_image/extended_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_imagepicker_plugin/flutter_imagepicker_plugin.dart';
import 'package:flutter_sxt_ui_plugin/manager/audio_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/log/logger.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/download_file_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/favourite/favourite_detail_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/images_animation.dart';
import 'package:flutter_sxt_ui_plugin/utils/date_time_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/file_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/forward_msg_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:kd_flutter_map/amap_location_option.dart';
import 'package:kd_flutter_map/bean/poi_bean.dart';
import 'package:kd_flutter_map/flutter_map_manager.dart';
import 'package:kd_flutter_map/widget/gcoord.dart';
import 'package:sxt_flutter_plugin/favorite/model/favorite.dart';
import 'package:sxt_flutter_plugin/favorite/sxt_favorite_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_manager.dart';
import 'package:sxt_flutter_plugin/message/model/attachment.dart';
import 'package:sxt_flutter_plugin/message/model/audio_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/file_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/location_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/pic_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/text_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/video_attachment.dart';
import 'package:sxt_flutter_plugin/model/job.dart';

/// @author newtab on 2021/9/14

class EmptyMsgWidget extends StatelessWidget {
  const EmptyMsgWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const SizedBox.shrink();
  }
}

abstract class BaseMsgDelegate {
  Favorite favorite;
  String name;
  String department;
  String avator;

  BaseMsgDelegate(this.favorite, this.name, this.department, this.avator);

  bool containSearchKey(String? searchKey) {
    if (searchKey == null || searchKey.isEmpty) return true;
    return name.contains(searchKey) || department.contains(searchKey);
  }

  Widget emptyWidget() {
    return const EmptyMsgWidget();
  }

  Widget build(BuildContext context, {String? searchKey}) {
    final Widget result = buildAttachment(context, searchKey);

    if (result is EmptyMsgWidget) {
      return result;
    }
    return Container(
      margin: const EdgeInsets.only(
        left: 10,
        bottom: 10,
        right: 10,
      ),
      padding: const EdgeInsets.symmetric(
        horizontal: 20,
        vertical: 15,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          result,
          const SizedBox(
            height: 15,
          ),
          Row(
            children: [
              Text(
                name,
                style: const TextStyle(
                  color: Color(0xff999999),
                  fontSize: 12,
                ),
              ),
              const SizedBox(
                width: 8,
              ),
              Container(
                width: (department.isNotEmpty) ? 1 : 0,
                height: 13,
                color: const Color(0xff999999),
              ),
              const SizedBox(
                width: 8,
              ),
              Text(
                department,
                style: const TextStyle(
                  color: Color(0xff999999),
                  fontSize: 12,
                ),
              ),
              const Spacer(),
              Text(
                DateTimeUtil.formatMessageTime2(favorite.createTime!),
                style: const TextStyle(
                  color: Color(0xff999999),
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<dynamic> clicked(BuildContext context) async {
    if (favorite.msgType == MsgType.OTHER || favorite.msgType == MsgType.OTHERS) {
      return Navigator.of(context)
          .push(
        CupertinoPageRoute(
          builder: (context) => DownloadFilePage(
            favorite: favorite,
          ),
        ),
      )
          .then(
        (value) {
          if (value != null && favorite.attachment is FileAttachment) {
            (favorite.attachment as FileAttachment).path = value.toString();
          }
        },
      );
    }
    if (favorite.msgType == MsgType.LOCATION) {
      final LocationAttachment attachment = favorite.attachment as LocationAttachment;

      KdFlutterMapManager.getInstance().initLocationOptions(AMapLocationOption(locationInterval: 5000));

      ///wgs转换成高德坐标
      final GcoordResult result = CoordTransform.transformWGS84toGCJ02(attachment.longitude ?? 0, attachment.latitude ?? 0);

      return KdFlutterMapManager.getInstance().showMyLocation(
        context,
        PoiBean(
          name: attachment.name,
          address: attachment.address,
          la: result.lat.toString(),
          lo: result.lon.toString(),
        ),
        forwardMapFunc: (context) {
          ForwardMsgHelper.forwardMsg(
            context,
            favorite.attachment!,
          );
        },
        cancelFavMapFunc: (context) async {
          SxtFavoritePlugin.deleteFavorite(favorite.favoriteId!).then((value) {
            print("deleteFavorite success");
          }).onError((error, stackTrace) {
            print("deleteFavorite error");
            ToastUtil.showToast("取消收藏失败");
          });
          try {
            Navigator.of(context).popUntil((route) {
              if (route.settings.name == "/fav_home_page") {
                (route.settings.arguments as Map)["result"] = favorite.favoriteId;
                return true;
              } else {
                return false;
              }
            });
          } catch (e) {}
        },
      );
    }

    return Navigator.of(context).push(
      CupertinoPageRoute(
        builder: (context) => FavouriteDetailPage(
          favorite,
          name,
          department,
          avator,
        ),
      ),
    );
  }

  Widget buildDetail(BuildContext context) {
    return buildDetailAttachment(context);
  }

  Widget buildAttachment(BuildContext context, String? searchKey);

  Widget buildDetailAttachment(BuildContext context);

  static BaseMsgDelegate getMsgDelegate(
    Favorite favorite,
    String name,
    String department,
    String avator,
  ) {
    BaseMsgDelegate delegate;
    switch (favorite.msgType) {
      case MsgType.AUDIO:
      case MsgType.VOICE_FILE:
        delegate = AudioMsgDelegate(
          favorite,
          name,
          department,
          avator,
        );
        break;
      case MsgType.VIDEO:
      case MsgType.VIDEO_FILE:
        delegate = VideoMsgDelegate(
          favorite,
          name,
          department,
          avator,
        );
        break;
      case MsgType.OTHER:
      case MsgType.OTHERS:
        delegate = FileMsgDelegate(
          favorite,
          name,
          department,
          avator,
        );
        break;
      case MsgType.TEXT:
        delegate = TextMsgDelegate(
          favorite,
          name,
          department,
          avator,
        );
        break;
      case MsgType.LOCATION:
        delegate = LocationMsgDelegate(
          favorite,
          name,
          department,
          avator,
        );
        break;
      case MsgType.PICTURE:
        delegate = ImageMsgDelegate(
          favorite,
          name,
          department,
          avator,
        );
        break;
      default:
        delegate = FileMsgDelegate(
          favorite,
          name,
          department,
          avator,
        );
    }
    return delegate;
  }

  void dispose() {}
}

class VideoMsgDelegate extends BaseMsgDelegate {
  VideoMsgDelegate(Favorite<Attachment> favorite, String name, String department, String avator) : super(favorite, name, department, avator);
  StateSetter? setter;
  bool isDownload = false;

  String? imgPath;

  void updateImgPath(String? thumbPath) {
    imgPath = thumbPath;
    setter?.call(() {});
  }

  @override
  Widget buildAttachment(BuildContext context, String? searchKey) {
    final attachment = favorite.attachment as VideoAttachment;

    if (!containSearchKey(searchKey)) {
      if (attachment.filename == null || !attachment.filename!.contains(searchKey!)) {
        return emptyWidget();
      }
    }
    imgPath ??= attachment.thumbPath;
    if (!StringUtil.isEmpty(imgPath)) {
      final File file = File(imgPath!);
      if (!file.existsSync() && isDownload == false) {
        isDownload = true;
        if (Platform.isIOS) {
          SxtFavoritePlugin.downloadAttachmentThumb(favorite.favoriteId!);
        }
        SxtFavoritePlugin.downloadAttachment(favorite.favoriteId!);
      }
    }

    return StatefulBuilder(builder: (context, state) {
      setter = state;

      return SizedBox(
        width: 80,
        height: 80,
        child: Stack(
          children: [
            Positioned.fill(
              child: ImageLoader(
                isLocal: true,
                url: imgPath,
                width: 80,
                height: 80,
                defaultAssetImg: ImageHelper.wrapAssets(
                  "icon_fav_empty.png",
                ),
                package: PACKAGE_NAME,
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: Image.asset(
                ImageHelper.wrapAssets(
                  "icon_video_play.png",
                ),
                package: PACKAGE_NAME,
                width: 30,
                height: 30,
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Text(
                getTime(
                  Duration(
                    milliseconds: attachment.duration ?? 0,
                  ),
                ),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
      );
    });
  }

  String getTime(Duration duration) {
    try {
      final List<String> parts = duration.toString().split(':');
      //part2里的秒要去掉小数点后面的值
      final String result = '${parts[0]}:${parts[1]}:${parts[2].substring(0, parts[2].indexOf("."))}';
      return result;
    } catch (e) {
      return "0:00:00";
    }
  }

  @override
  void dispose() {
    if (job != null) {
      SxtManager.instance.cancelJob(job?.jobId);
    }
    super.dispose();
  }

  Job? job;

  @override
  Widget buildDetailAttachment(BuildContext context) {
    final VideoAttachment attachment = favorite.attachment as VideoAttachment;

    return GestureDetector(
      onTap: () async {
        bool isDownload = false;
        if (!StringUtil.isEmpty(attachment.path)) {
          final File file = File(attachment.path!);
          if (file.existsSync()) {
            isDownload = true;
          }
        }

        if (isDownload == false) {
          ToastUtil.showToast("文件不存在");
        } else {
          KDAssetPicker.playVideo(context, attachment.path!, true);
        }
      },
      child: Container(
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width - 30,
          maxHeight: MediaQuery.of(context).size.height / 2,
        ),
        child: Stack(
          children: [
            Positioned.fill(
              child: ImageLoader(
                url: attachment.thumbPath,
                isLocal: true,
                defaultAssetImg: ImageHelper.wrapAssets("icon_fav_empty.png"),
                package: PACKAGE_NAME,
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: Image.asset(
                ImageHelper.wrapAssets(
                  "icon_video_play.png",
                ),
                package: PACKAGE_NAME,
                width: 45,
                height: 45,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TextMsgDelegate extends BaseMsgDelegate {
  TextMsgDelegate(Favorite<Attachment> favorite, String name, String department, String avator) : super(favorite, name, department, avator);

  @override
  Widget buildAttachment(BuildContext context, String? searchKey) {
    final TextAttachment attachment = favorite.attachment as TextAttachment;
    if (!containSearchKey(searchKey)) {
      if (attachment.text == null || !attachment.text!.contains(searchKey!)) {
        return emptyWidget();
      }
    }
    return Container(
      alignment: Alignment.centerLeft,
      child: Text(
        attachment.text ?? "",
        maxLines: 2,
        style: const TextStyle(
          color: Color(0xff333333),
          fontSize: 16,
        ),
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  @override
  Widget buildDetailAttachment(BuildContext context) {
    final TextAttachment attachment = favorite.attachment as TextAttachment;

    return Container(
      alignment: Alignment.centerLeft,
      child: Text(
        attachment.text ?? "",
        style: const TextStyle(
          color: Color(0xff333333),
          fontSize: 16,
        ),
      ),
    );
  }
}

class FileMsgDelegate extends BaseMsgDelegate {
  FileMsgDelegate(Favorite<Attachment> favorite, String name, String department, String avator) : super(favorite, name, department, avator);

  @override
  Widget buildAttachment(BuildContext context, String? searchKey) {
    final FileAttachment attachment = favorite.attachment as FileAttachment;

    if (!containSearchKey(searchKey)) {
      if (attachment.filename == null || !attachment.filename!.contains(searchKey!)) {
        return emptyWidget();
      }
    }

    String suffix = "";
    if (attachment.filename!.contains(".")) {
      suffix = attachment.filename!.split(".").last;
    }
    suffix = suffix.toLowerCase();
    return Row(
      children: [
        Image.asset(FileUtil.getIconByFileType(attachment.filename!), width: 48, height: 48, fit: BoxFit.cover, package: PACKAGE_NAME),
        const SizedBox(
          width: 10,
        ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                attachment.filename ?? "",
                style: const TextStyle(
                  color: Color(0xff333333),
                  fontSize: 16,
                ),
              ),
              const SizedBox(
                height: 5,
              ),
              Text(
                "$suffix ${formatBytes(attachment.size!, 2)}",
                style: const TextStyle(
                  color: Color(0xff999999),
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  @override
  Widget buildDetailAttachment(BuildContext context) {
    return Container();
  }
}

class AudioMsgDelegate extends BaseMsgDelegate {
  AudioMsgDelegate(Favorite<Attachment> favorite, String name, String department, String avator) : super(favorite, name, department, avator);

  bool isDownload = false;

  @override
  Widget buildAttachment(BuildContext context, String? searchKey) {
    ///所有的下载操作全部在列表页完成
    final AudioAttachment attachment = favorite.attachment as AudioAttachment;

    if (audioPath == null || audioPath!.isEmpty) {
      audioPath = attachment.path;
    }

    final File audioFile = File(audioPath ?? "");
    if (!audioFile.existsSync() && !isDownload) {
      isDownload = true;
      SxtLogger.instance.info("favDetailWidget downloadMsgAttachment  ${favorite.toString()}");
      SxtFavoritePlugin.downloadAttachment(favorite.favoriteId!);
    }

    if (!containSearchKey(searchKey)) {
      if (attachment.filename == null || !attachment.filename!.contains(searchKey!)) {
        return emptyWidget();
      }
    }
    return SizedBox(
      height: 50,
      child: Row(
        children: [
          Image.asset(
            ImageHelper.wrapAssets(
              "icon_fav_audio.png",
            ),
            width: 48,
            height: 48,
            package: PACKAGE_NAME,
          ),
          const SizedBox(
            width: 10,
          ),
          Text(
            DateTimeUtil.fromeLongTime(attachment.duration!),
            style: const TextStyle(
              color: Color(0xff333333),
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    AudioManager.instance.destroy();
    super.dispose();
  }

  bool isPlaying = false;
  String? audioPath;

  void updateAudioPath(String? path) {
    audioPath = path;
  }

  @override
  Widget buildDetailAttachment(BuildContext context) {
    final AudioAttachment attachment = favorite.attachment as AudioAttachment;
    StateSetter? stateSetter;
    return GestureDetector(
      onTap: () {
        if (AudioManager.instance.isPlaying(attachment.path!)) {
          SxtLogger.instance.info("favDetailWidget stop play audio");
          AudioManager.instance.stop();
          isPlaying = false;
          stateSetter?.call(() {});
        } else {
          SxtLogger.instance.info("favDetailWidget start play audio ");
          AudioManager.instance.play(
            attachment.path!,
            PlayListener(
              onCompleted: () {
                SxtLogger.instance.info("PlayListener onCompleted " + attachment.path!);
                isPlaying = false;
                AudioManager.instance.stop();
                stateSetter?.call(() {});
              },
              onLoading: () {
                SxtLogger.instance.info("PlayListener onLoading " + attachment.path!);
                isPlaying = true;
                stateSetter?.call(() {});
              },
              onIdled: () {
                SxtLogger.instance.info("PlayListener onIdled " + attachment.path!);
                isPlaying = false;
                stateSetter?.call(() {});
              },
            ),
          );
        }
      },
      child: Container(
        color: const Color(0xffF7F7F7),
        height: 50,
        child: Row(
          children: [
            const SizedBox(
              width: 15,
            ),
            StatefulBuilder(
              builder: (context, setState) {
                stateSetter = setState;
                return Container(
                  width: 20,
                  height: 20,
                  margin: const EdgeInsets.only(right: 4),
                  child: isPlaying
                      ? ImagesAnimation(
                          entry: ImagesAnimationEntry(1, 3, "images/icon_fav_audio_playing_"),
                        )
                      : ImageHelper.assetImage("icon_fav_audio_playing_3.png"),
                );
              },
            ),
            const SizedBox(
              width: 10,
            ),
            Text(
              DateTimeUtil.fromeLongTime(attachment.duration!),
              style: const TextStyle(
                color: Color(0xff333333),
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class LocationMsgDelegate extends BaseMsgDelegate {
  LocationMsgDelegate(Favorite<Attachment> favorite, String name, String department, String avator) : super(favorite, name, department, avator);

  String? imgPath;
  bool isDownload = false;

  void updateImagePath(String? path) {
    imgPath = path;
  }

  @override
  Widget buildAttachment(BuildContext context, String? searchKey) {
    final LocationAttachment attachment = favorite.attachment as LocationAttachment;

    if (!containSearchKey(searchKey)) {
      if ((attachment.name == null || !attachment.name!.contains(searchKey!)) && (attachment.address == null || !attachment.address!.contains(searchKey!))) {
        return emptyWidget();
      }
    }
    if (imgPath == null || imgPath!.isEmpty) {
      imgPath = attachment.path;
    }
    if (!StringUtil.isEmpty(imgPath)) {
      final File file = File(imgPath!);
      if (!file.existsSync() && isDownload == false) {
        isDownload = true;
        SxtFavoritePlugin.downloadAttachment(favorite.favoriteId!);
      }
    }

    return Row(
      children: [
        Image.asset(
          ImageHelper.wrapAssets(
            "icon_fav_location.png",
          ),
          width: 48,
          height: 48,
          package: PACKAGE_NAME,
        ),
        const SizedBox(
          width: 10,
        ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                attachment.name ?? "",
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Color(0xff333333),
                  fontSize: 16,
                ),
              ),
              Text(
                attachment.address ?? "",
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Color(0xff999999),
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  @override
  Widget buildDetailAttachment(BuildContext context) {
    return Container();
  }
}

class ImageMsgDelegate extends BaseMsgDelegate {
  ImageMsgDelegate(Favorite<Attachment> favorite, String name, String department, String avator) : super(favorite, name, department, avator);

  StateSetter? setter;
  String? imgPath;
  bool isDownload = false;

  void updateImgPath(String? path) {
    imgPath = path;
    setter?.call(() {});
  }

  @override
  Widget buildAttachment(BuildContext context, String? searchKey) {
    final PicAttachment attachment = favorite.attachment as PicAttachment;
    if (!containSearchKey(searchKey)) {
      if (attachment.filename == null || !attachment.filename!.contains(searchKey!)) {
        return emptyWidget();
      }
    }
    imgPath ??= attachment.path;

    if (!StringUtil.isEmpty(imgPath)) {
      final File file = File(imgPath!);
      if (!file.existsSync() && isDownload == false) {
        isDownload = true;
        SxtFavoritePlugin.downloadAttachment(favorite.favoriteId!);
      }
    }

    return StatefulBuilder(builder: (context, state) {
      setter = state;

      return ImageLoader(
        url: imgPath,
        isLocal: true,
        width: 80,
        height: 80,
        defaultAssetImg: ImageHelper.wrapAssets("icon_fav_empty.png"),
        package: PACKAGE_NAME,
      );
    });
  }

  @override
  Widget buildDetailAttachment(BuildContext context) {
    final PicAttachment attachment = favorite.attachment as PicAttachment;
    return Container(
      constraints: BoxConstraints(
        maxWidth: MediaQuery.of(context).size.width - 30,
        maxHeight: MediaQuery.of(context).size.height / 2,
      ),
      child: ImageLoader(
        showPreviewWhenClick: true,
        url: attachment.path,
        isLocal: true,
        defaultAssetImg: ImageHelper.wrapAssets("icon_fav_empty.png"),
        package: PACKAGE_NAME,
      ),
    );
  }
}
