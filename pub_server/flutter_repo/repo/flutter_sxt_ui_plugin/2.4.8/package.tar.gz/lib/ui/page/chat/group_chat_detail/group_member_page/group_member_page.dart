import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/manager/contact_module_manager.dart';
import 'package:contact_ui_flutter/ui/contact_detail/contact_detail_page.dart';
import 'package:contact_ui_flutter/widget/image_loader.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_swipe_action_cell/flutter_swipe_action_cell.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/manager/app_manager.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/group_member_page/group_member_page_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/loading_dialog.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/group/model/group_remove_user_param.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';

class GroupMemberPage extends StatefulWidget {
  Group group;

  GroupMemberPage(this.group);

  @override
  State<StatefulWidget> createState() {
    return GroupMemberState();
  }
}

class GroupMemberState extends State<GroupMemberPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (_) => GroupMemberPageBloc(widget.group),
        child: BlocBuilder<GroupMemberPageBloc, GroupMemberPageState>(
            builder: (context, state) {
          return Scaffold(
              key: _scaffoldKey,
              backgroundColor: Colors.white,
              appBar: BackgroundImageAppbar(
                title: "群成员(${state.groupMemberList?.length ?? 0})",
                leadingWidget: Container(
                  padding:
                      EdgeInsets.only(left: 12, right: 16, top: 8, bottom: 8),
                  child: InkWell(
                    child: ImageHelper.assetImage("ic_back.png"),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                ),
              ),
              body: BlocListener<GroupMemberPageBloc, GroupMemberPageState>(
                listener: (context, state) {
                  switch (state.status) {
                    case EventStatus.loading:
                      showDialog(
                          context: context,
                          barrierDismissible: false,
                          builder: (ctx) =>
                              LoadingDialog("修改群名称中...", () => {}));
                      break;
                    case EventStatus.failure:
                      Navigator.pop(context);
                      ToastUtil.showToast(state.failedMessage ?? "");
                      break;
                    case EventStatus.loadingSuccess:
                      Navigator.pop(context);
                      ToastUtil.showToast("修改成功");
                      Navigator.pop(context);
                      break;
                    case EventStatus.nothing:
                      break;
                    case EventStatus.popPage:
                      Navigator.pop(context);
                      break;
                    case EventStatus.update:
                      break;
                    default:
                      break;
                  }
                },
                child: Container(
                  child: BlocBuilder<GroupMemberPageBloc, GroupMemberPageState>(
                      builder: (context, state) {
                    bool isIndex = (state.groupMemberList?.length ?? 0) > 20;
                    GroupMemberPageBloc bloc =
                        BlocProvider.of<GroupMemberPageBloc>(context);
                    return ListView.separated(
                      itemBuilder: (context, index) {
                        bool isWord = isIndex &&
                            state.indexedGroupMemberList != null &&
                            !StringUtil.isEmpty(
                                state.indexedGroupMemberList![index].word);
                        return isWord
                            ? Container(
                                padding: EdgeInsets.only(left: 16),
                                height: 30,
                                color: CustomColors.cl_F5F5F5,
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    state.indexedGroupMemberList![index].word!
                                        .toUpperCase(),
                                    style: TextStyle(
                                        fontSize: 12,
                                        color: CustomColors.cl_666666),
                                  ),
                                ),
                              )
                            : (isIndex
                                ? ContactList(
                                    index: index,
                                    contact: state
                                        .indexedGroupMemberList![index]
                                        .groupMember,
                                    group: widget.group,
                                    onItemClick: () {
                                      if (!AppManager.instance.uiOptions
                                          .enableChatPageClickMember) return;

                                      var contact = state
                                          .indexedGroupMemberList![index]
                                          .groupMember!;
                                      Navigator.push(context,
                                          new CupertinoPageRoute(
                                              builder: (context) {
                                        return ContactDetailPage(contact);
                                      }));
                                    },
                                    onRemoveClick: (userCode) {
                                      onRemoveClick(userCode, bloc);
                                    },
                                  )
                                : ContactList(
                                    index: index,
                                    group: widget.group,
                                    contact: state.groupMemberList![index],
                                    onItemClick: () {
                                      if (!AppManager.instance.uiOptions
                                          .enableChatPageClickMember) return;

                                      var contact =
                                          state.groupMemberList![index];
                                      Navigator.push(context,
                                          new CupertinoPageRoute(
                                              builder: (context) {
                                        return ContactDetailPage(contact);
                                      }));
                                    },
                                    onRemoveClick: (userCode) {
                                      onRemoveClick(userCode, bloc);
                                    },
                                  ));
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        bool isIndex =
                            (state.groupMemberList?.length ?? 0) > 20;
                        bool isWord = isIndex &&
                            state.indexedGroupMemberList != null &&
                            !StringUtil.isEmpty(
                                state.indexedGroupMemberList![index].word);
                        bool nextIsWord = isIndex &&
                            state.indexedGroupMemberList != null &&
                            state.indexedGroupMemberList!.length > index &&
                            !StringUtil.isEmpty(
                                state.indexedGroupMemberList![index + 1].word);
                        return !isIndex
                            ? Container(
                                height: 0.5,
                                margin: EdgeInsets.only(left: 60),
                                color: ColorUtil.COLOR_FFE0E0E0,
                              )
                            : (isWord
                                ? Container()
                                : (nextIsWord
                                    ? Container()
                                    : Container(
                                        height: 0.5,
                                        margin: EdgeInsets.only(left: 60),
                                        color: ColorUtil.COLOR_FFE0E0E0,
                                      )));
                      },
                      itemCount: isIndex
                          ? (state.indexedGroupMemberList?.length ?? 0)
                          : (state.groupMemberList?.length ?? 0),
                    );
                  }),
                ),
              ));
        }));
  }

  onRemoveClick(String userCode, GroupMemberPageBloc bloc) {
    bool isMaster = DomainUtil.toCode(widget.group.userCode) == userCode;
    if (isMaster) {
      showModalBottomSheet(
          backgroundColor: Colors.transparent,
          context: context,
          builder: (context) => Container(
                height: 138,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10))),
                child: Column(
                  children: <Widget>[
                    Container(
                      height: 44,
                      child: Align(
                        alignment: Alignment.center,
                        child: Text(
                          "退出后不会通知群聊中其他成员，且不再接收此群消息",
                          style: TextStyle(
                              fontSize: 12, color: CustomColors.cl_666666),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                    Container(
                      height: 0.5,
                      color: ColorUtil.COLOR_FFE0E0E0,
                    ),
                    InkWell(
                        onTap: () {
                          Navigator.maybePop(context).then((value) {
                            showDialog(
                                context: _scaffoldKey.currentContext!,
                                barrierDismissible: false,
                                builder: (ctx) {
                                  return LoadingDialog("退出群聊", () => {});
                                });
                            SxtGroupPlugin.deleteGroup(widget.group.groupCode!)
                                .then((value) {
                              bloc.add(DeleteUser(userCode));
                              ToastUtil.showToast("退出群组成功");
                              Navigator.of(_scaffoldKey.currentContext!).pop();
                              Navigator.of(_scaffoldKey.currentContext!).pop();
                            }).onError((e, stackTrace) {
                              Navigator.of(_scaffoldKey.currentContext!).pop();
                              if (e is PlatformException) {
                                ToastUtil.showToast("退出群组失败: ${e.message}");
                              } else {
                                ToastUtil.showToast("退出群组失败: ${e.toString()}");
                              }
                            });
                          });
                        },
                        child: Container(
                          height: 44,
                          child: Align(
                            alignment: Alignment.center,
                            child: Text(
                              "确认退出群聊",
                              style: TextStyle(
                                  fontSize: 16, color: CustomColors.cl_333333),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        )),
                    Container(
                      height: 5,
                      color: ColorUtil.COLOR_FFE0E0E0,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        height: 44,
                        child: Align(
                          alignment: Alignment.center,
                          child: Text(
                            "取消",
                            style: TextStyle(
                                fontSize: 16, color: CustomColors.cl_333333),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ));
    } else {
      showDialog(
          context: _scaffoldKey.currentContext!,
          barrierDismissible: false,
          builder: (ctx) {
            return LoadingDialog("移除成员", () => {});
          });
      GroupRemoveUserParam param = GroupRemoveUserParam();
      param.groupCode = widget.group.groupCode;
      param.userCodes = [userCode];
      SxtGroupPlugin.removeUserFromGroup(param).then((value) {
        print("aaaa  bloc.add(DeleteUser start");
        bloc.add(DeleteUser(userCode));
        print("aaaa  bloc.add(DeleteUser start) success");
        ToastUtil.showToast("移除群组成员成功");
        Navigator.of(_scaffoldKey.currentContext!).pop();
      }).onError((e, stackTrace) {
        Navigator.of(_scaffoldKey.currentContext!).pop();
        if (e is PlatformException) {
          ToastUtil.showToast("移除群组成员失败: ${e.message}");
        } else {
          ToastUtil.showToast("移除群组成员失败: ${e.toString()}");
        }
      });
    }
  }
}

class IndexedGroupMember {
  String? word;
  Contact? groupMember;
}

class ContactList extends StatelessWidget {
  SwipeActionController? slidAbleController = SwipeActionController();
  int? index;
  Group? group;
  Contact? contact;
  Function? onItemClick;
  Function? onRemoveClick;

  ContactList(
      {this.index,
      this.contact,
      this.onItemClick,
      this.group,
      this.onRemoveClick});

  @override
  Widget build(BuildContext context) {
    bool isMaster = DomainUtil.toCode(group!.userCode) == contact!.code;
    bool isMeMaster = group!.isMaster!;
    bool isMe = contact!.code ==
        DomainUtil.toCode(
            ContactModuleManager.instance.getContactModuleOption()!.userCode);

    print("isMeMaster:" + isMeMaster.toString());
    print("isMe:" + isMe.toString());

    return SwipeActionCell(
        controller: slidAbleController,
        isDraggable: isMeMaster || isMe,
        index: index,
        key: ValueKey(index),
        fullSwipeFactor: 0.185 * 3,
        normalAnimationDuration: 500,
        deleteAnimationDuration: 400,
        performsFirstActionWithFullSwipe: false,
        child: InkWell(
          splashColor: ThemeData.light().splashColor,
          highlightColor: ThemeData.light().highlightColor,
          onTap: () {
            onItemClick!();
          },
          child: Container(
            color: Colors.white,
            height: 56,
            padding: EdgeInsets.only(left: 16),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Row(
                children: [
                  ImageLoader(
                    url: contact == null
                        ? ""
                        : StringUtil.getAvatarUrl(contact!),
                    defaultAssetImg:
                        ImageHelper.wrapAssets("icon_person_placeholder.png"),
                    errorAssetImg:
                        ImageHelper.wrapAssets("icon_person_placeholder.png"),
                    borderRadius: 4,
                    width: 36,
                    height: 36,
                    package: PACKAGE_NAME,
                  ),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.only(left: 12),
                      child: Text(
                        contact?.name ?? "",
                        style: TextStyle(
                            fontSize: 16, color: ColorUtil.color333333),
                      ),
                    ),
                  ),
                  isMaster
                      ? Container(
                          margin: EdgeInsets.only(right: 16),
                          child: Text(
                            '群主',
                            style: TextStyle(
                                fontSize: 12, color: CustomColors.cl_999999),
                          ),
                        )
                      : Container()
                ],
              ),
            ),
          ),
        ),
        trailingActions: [
          SwipeAction(
            title: "移除",
            style: TextStyle(
                fontSize: 14, color: Colors.white, fontWeight: FontWeight.w500),
            color: ColorUtil.colorFFEE4A37,
            onTap: (handler) async {
              onRemoveClick!(contact!.code);
              slidAbleController?.closeAllOpenCell();
            },
          ),
        ]);
  }
}
