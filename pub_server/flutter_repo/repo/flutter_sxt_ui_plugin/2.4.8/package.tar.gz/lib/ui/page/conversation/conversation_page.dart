import 'package:contact_ui_flutter/widget/search_bar.dart';
import 'package:extended_image/extended_image.dart';
import 'package:flutter/cupertino.dart' hide ConnectionState;
import 'package:flutter/material.dart' hide ConnectionState;
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_swipe_action_cell/flutter_swipe_action_cell.dart';
import 'package:flutter_sxt_ui_plugin/manager/app_manager.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/message_free/message_free_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/message_free/message_free_state.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/connection/connection_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/conversation_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/conversation_event.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/conversation_state.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/group/group_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/ontop/ontop_conversation_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/global_search_page/global_search_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/login_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/badge.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/indent_divider.dart';
import 'package:flutter_sxt_ui_plugin/utils/date_time_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/sxt_status_listener.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_manager.dart';
import 'package:sxt_flutter_plugin/message/model/conversation.dart';
import 'package:sxt_flutter_plugin/message/model/send_state.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';

class ConversationPage extends StatelessWidget {
  ConversationPage({Key? key, required this.onUnreadMessageCountChanged})
      : super(key: key);

  final ValueChanged<int> onUnreadMessageCountChanged;

  final _swipeController = SwipeActionController();

  @override
  Widget build(BuildContext context) => MultiBlocProvider(
        providers: [
          BlocProvider(
            create: (context) =>
                ConversationBloc(context)..add(ConversationInitialEvent()),
          ),
          BlocProvider(
            create: (context) =>
                ConnectionBloc()..add(ConnectionInitialEvent()),
          ),
          BlocProvider(
            create: (context) => GroupBloc(),
          ),
        ],
        child: Material(
          color: Colors.white,
          child: Column(
            children: [
              BlocBuilder<ConversationBloc, ConversationState>(
                builder: (context, state) {
                  final count = _getUnreadCount(context, state);
                  return SizedBox(
                    width: double.infinity,
                    child: BackgroundImageAppbar(
                      title:
                          '消息${count == 0 ? '' : '(' + count.toString() + ')'}',
                      trailingWidget: _buildTrailngButton(context),
                    ),
                  );
                },
              ),
              Expanded(
                child: Stack(
                  children: [
                    MultiBlocListener(
                      listeners: [
                        BlocListener<ConversationBloc, ConversationState>(
                          listener: _listenUnreadCountChange,
                        ),
                        BlocListener<MessageFreeBloc, MessageFreeState>(
                          listener: (context, state) => context
                              .read<ConversationBloc>()
                              .add(MessageFreeUpdateEvent()),
                        ),
                        BlocListener<OnTopConversationBloc,
                            OnTopConversationState>(
                          listener: (context, state) => context
                              .read<ConversationBloc>()
                              .add(OnTopConversationListUpdateEvent()),
                        ),
                      ],
                      child: BlocBuilder<ConversationBloc, ConversationState>(
                        builder: (context, state) {
                          final bloc = context.read<ConversationBloc>();
                          final messageFreeBloc =
                              context.read<MessageFreeBloc>();
                          final onTopConversationBloc =
                              context.read<OnTopConversationBloc>();
                          return state.conversations == null
                              ? const Center(
                                  child: CupertinoActivityIndicator(radius: 12),
                                )
                              : state.conversations!.isEmpty
                                  ? Column(
                                      children: [
                                        _buildSearch(context),
                                        const Expanded(
                                          child: _EmptyMessage(),
                                        ),
                                      ],
                                    )
                                  : ListView.builder(
                                      padding: EdgeInsets.zero,
                                      itemCount:
                                          state.conversations!.length + 1,
                                      itemBuilder: (context, index) =>
                                          index-- == 0
                                              ? _buildSearch(context)
                                              : _ConversationItem(
                                                  key: ValueKey(state
                                                      .conversations![index]),
                                                  controller: _swipeController,
                                                  index: index,
                                                  conversation: state
                                                      .conversations![index],
                                                  isOnTop: onTopConversationBloc
                                                      .isOnTopConversation(state
                                                          .conversations![index]
                                                          .talker!),
                                                  isMessageFree: messageFreeBloc
                                                      .isMessageFree(state
                                                          .conversations![index]
                                                          .talker!),
                                                  isPttTalking:
                                                      bloc.isPttTalking(
                                                          state.conversations![
                                                              index]),
                                                ),
                                    );
                        },
                      ),
                    ),
                    const _ConnectionTip(),
                  ],
                ),
              ),
            ],
          ),
        ),
      );

  Widget _buildTrailngButton(BuildContext context) => InkWell(
        onTap: () => context.read<GroupBloc>().add(GroupCreateEvent(context)),
        child: Container(
          alignment: Alignment.center,
          padding: const EdgeInsets.all(8),
          child: Image.asset(
            'images/icon_add_chat.png',
            height: 32,
            width: 32,
            package: PACKAGE_NAME,
          ),
        ),
      );

  Widget _buildSearch(BuildContext context) => SearchBar(
        onSearchClick: () => Navigator.of(context).push(CupertinoPageRoute(
          builder: (context) => GlobalSearchPage(),
        )),
      );

  void _listenUnreadCountChange(BuildContext context, ConversationState state) {
    final unreadCount = _getUnreadCount(context, state);
    onUnreadMessageCountChanged(unreadCount);
  }
}

int _getUnreadCount(BuildContext context, ConversationState state) {
  if (state.conversations == null) return 0;
  final bloc = context.read<MessageFreeBloc>();
  int unreadCount = 0;
  for (var conversation in state.conversations!) {
    if (!bloc.isMessageFree(conversation.talker!)) {
      unreadCount += conversation.unReadCount ?? 0;
    }
  }
  return unreadCount;
}

class _EmptyMessage extends StatelessWidget {
  const _EmptyMessage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(
              'images/icon_empty_bg.png',
              width: 200,
              package: PACKAGE_NAME,
            ),
            const SizedBox(height: 14),
            const Text(
              '当前没有消息',
              style: TextStyle(color: Color(0xFF999999)),
            ),
            const SizedBox(height: 60),
          ],
        ),
      );
}

class _ConversationItem extends StatelessWidget {
  const _ConversationItem({
    required Key key,
    required this.controller,
    required this.index,
    required this.conversation,
    this.isOnTop = false,
    this.isMessageFree = false,
    this.isPttTalking = false,
  }) : super(key: key);

  final SwipeActionController controller;
  final int index;
  final Conversation conversation;
  final bool isOnTop;
  final bool isMessageFree;
  final bool isPttTalking;

  @override
  Widget build(BuildContext context) => Column(
        children: [
          SwipeActionCell(
            key: key!,
            controller: controller,
            index: index,
            child: Material(
              color: isOnTop ? const Color(0xFFF7F7F7) : Colors.white,
              child: InkWell(
                onTap: () => _doOnItemTap(context),
                onLongPress: () =>
                    controller.openCellAt(index: index, trailing: true),
                child: Stack(
                  children: [
                    _buildMessage(),
                    _buildBadge(),
                  ],
                ),
              ),
            ),
            trailingActions: [
              SwipeAction(
                onTap: (handler) =>
                    _showDeleteConversationDialog(context, handler),
                color: const Color(0xFFEE4A37),
                content: const Text(
                  '删除',
                  style: TextStyle(color: Colors.white),
                ),
              ),
              SwipeAction(
                onTap: (handler) async {
                  await handler(false);
                  context.read<OnTopConversationBloc>().add(
                      OnTopConversationSwitchEvent(
                          conversation.talker!, !isOnTop));
                },
                color: const Color(0xFF0F77FE),
                content: Text(
                  isOnTop ? '取消置顶' : '置顶',
                  style: const TextStyle(color: Colors.white),
                ),
              ),
              SwipeAction(
                onTap: (handler) async {
                  await handler(false);
                  context.read<ConversationBloc>().add(
                      ConversationUnreadCountEvent(
                          conversation, conversation.unReadCount == 0 ? 1 : 0));
                },
                color: const Color(0xFFA2A3A7),
                content: Text(
                  conversation.unReadCount == 0 ? '标为未读' : '标为已读',
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
          const IndentDivider(indent: 75),
        ],
      );

  void _doOnItemTap(BuildContext context) {
    controller.closeAllOpenCell();
    if (conversation.unReadCount != 0) {
      context
          .read<ConversationBloc>()
          .add(ConversationUnreadCountEvent(conversation, 0));
    }

    Navigator.of(context).push(CupertinoPageRoute(
      settings: const RouteSettings(name: '/ChatPage'),
      builder: (context) => ChatPage(sessionEntity: conversation.talker!),
    ));
  }

  void _showDeleteConversationDialog(
      BuildContext context, CompletionHandler handler) {
    final bloc = context.read<ConversationBloc>();
    showCupertinoDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => CupertinoAlertDialog(
        title: const Text('将清空该会话的聊天记录，是否确认删除？'),
        actions: [
          CupertinoDialogAction(
            onPressed: Navigator.of(context).pop,
            child: const Text('取消'),
          ),
          CupertinoDialogAction(
            onPressed: () async {
              Navigator.of(context).pop();
              await handler(true);
              bloc.add(ConversationDeleteEvent(conversation));
            },
            isDefaultAction: true,
            child: const Text(
              '删除',
              style: TextStyle(color: Color(0xFFD74A49)),
            ),
          ),
        ],
      ),
    ).then((value) => controller.closeAllOpenCell());
  }

  Widget _buildMessage() => SizedBox(
        height: 68,
        child: Row(
          children: [
            const SizedBox(width: 15),
            _buildAvatar(),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildTitle(),
                      const SizedBox(width: 12),
                      _buildTime(),
                      const SizedBox(width: 15),
                    ],
                  ),
                  const SizedBox(height: 8),
                  _MessageContent(conversation),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _buildTime() => Text(
        DateTimeUtil.formatMessageTime(conversation.receiverTime!),
        style: const TextStyle(
          color: Color(0xFF9092A5),
          fontSize: 13,
        ),
      );

  Widget _buildTitle() => Expanded(
        child: Row(
          children: [
            Flexible(
              child: Text(
                conversation.talker!.name!,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Color(0xFF131D27),
                  fontSize: 16,
                ),
              ),
            ),
            if (isPttTalking) ...[
              const SizedBox(width: 4),
              Image.asset(
                'images/ic_ptt_wave.png',
                package: PACKAGE_NAME,
              ),
            ],
          ],
        ),
      );

  Widget _buildAvatar() {
    switch (conversation.talker!.sessionType) {
      case SessionType.GROUP:
        return _GroupAvatar(conversation.talker!.avatarThumbPath);
      case SessionType.USER:
        return _UserAvatar(conversation.talker!.avatarThumbUrl);
      default:
        return const _AssetAvatar('images/icon_person_placeholder.png');
    }
  }

  Widget _buildBadge() => Container(
        width: 116,
        height: 24,
        alignment: Alignment.center,
        child: Badge(
          conversation.unReadCount!,
          indeterminate: isMessageFree,
        ),
      );
}

class _GroupAvatar extends StatelessWidget {
  const _GroupAvatar(this.path, {Key? key}) : super(key: key);

  final String? path;

  @override
  Widget build(BuildContext context) => ExtendedImage.file(
        File(path ?? ''),
        width: 48,
        height: 48,
        fit: BoxFit.cover,
        shape: BoxShape.rectangle,
        borderRadius: BorderRadius.circular(4),
        loadStateChanged: (ExtendedImageState state) {
          switch (state.extendedImageLoadState) {
            case LoadState.loading:
            case LoadState.failed:
              return const _AssetAvatar('images/icon_group_placeholder.png');
            case LoadState.completed:
              return state.completedWidget;
          }
        },
      );
}

class _UserAvatar extends StatelessWidget {
  const _UserAvatar(this.url, {Key? key}) : super(key: key);

  final String? url;

  @override
  Widget build(BuildContext context) => ExtendedImage.network(
        url ?? '',
        width: 48,
        height: 48,
        fit: BoxFit.cover,
        shape: BoxShape.rectangle,
        borderRadius: BorderRadius.circular(4),
        loadStateChanged: (ExtendedImageState state) {
          switch (state.extendedImageLoadState) {
            case LoadState.loading:
            case LoadState.failed:
              return const _AssetAvatar('images/icon_person_placeholder.png');
            case LoadState.completed:
              return state.completedWidget;
          }
        },
      );
}

class _MessageContent extends StatelessWidget {
  const _MessageContent(this.conversation, {Key? key}) : super(key: key);

  final Conversation conversation;

  @override
  Widget build(BuildContext context) => Row(
        children: [
          _buildSendState(),
          _buildMention(),
          Expanded(
            child: Text(
              conversation.content ?? '',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF9092A5),
                fontSize: 13,
              ),
            ),
          )
        ],
      );

  Widget _buildMention() => conversation.isMention == true
      ? const Text(
          '[有人@我] ',
          style: TextStyle(
            color: Color(0xFFF85152),
            fontSize: 16,
          ),
        )
      : const SizedBox();

  Widget _buildSendState() {
    switch (conversation.lastMsgSendStatus) {
      case SendState.SENDING:
        return const _SendIcon('images/icon_message_sending.png');
      case SendState.FAILURE:
        return const _SendIcon('images/ic_chat_send_failed.png');
      default:
        return const SizedBox();
    }
  }
}

class _SendIcon extends StatelessWidget {
  const _SendIcon(this.name, {Key? key}) : super(key: key);

  final String name;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 2, right: 2),
        child: Image.asset(
          name,
          height: 16,
          width: 16,
          package: PACKAGE_NAME,
        ),
      );
}

class _AssetAvatar extends StatelessWidget {
  const _AssetAvatar(this.name, {Key? key}) : super(key: key);

  final String name;

  @override
  Widget build(BuildContext context) => Image.asset(
        name,
        width: 48,
        height: 48,
        package: PACKAGE_NAME,
      );
}

class _ConnectionTip extends StatelessWidget {
  const _ConnectionTip({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) =>
      BlocListener<ConnectionBloc, ConnectionState>(
        listenWhen: (previous, current) =>
            current.status == ConnectionStatus.kicked,
        listener: (context, state) => _showKickedDialog(context),
        child: BlocBuilder<ConnectionBloc, ConnectionState>(
          builder: (context, state) =>
              state.status == ConnectionStatus.disconnected
                  ? const _DisconnectedItem('当前网络不可用，请检查网络设置')
                  : state.status == ConnectionStatus.signout
                      ? const _DisconnectedItem('已掉线，请检查网络或重新登录')
                      : const SizedBox(),
        ),
      );

  void _showKickedDialog(BuildContext context) {
    showCupertinoDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: const Text('您已被踢下线，请重新登录'),
        actions: [
          CupertinoDialogAction(
            onPressed: () {
              _logout();
              _jumpLoginPage(context);
            },
            child: const Text('确定'),
          ),
        ],
      ),
    );
  }

  void _logout() {
    SxtAccountPlugin.logout();
    StatusChangeLister.setCurrentLoginUser(null);
    StatusChangeLister.getJobId()
        .forEach((jobId) => SxtManager.instance.cancelJob(jobId));
    StatusChangeLister.removeAllJobId();
    AppManager.instance.clear();
  }

  void _jumpLoginPage(BuildContext context) {
    Navigator.of(context).pushAndRemoveUntil(
      CupertinoPageRoute(builder: (context) => LoginPage()),
      (route) => false,
    );
  }
}

class _DisconnectedItem extends StatelessWidget {
  const _DisconnectedItem(this.text, {Key? key}) : super(key: key);

  final String text;

  @override
  Widget build(BuildContext context) => Container(
        color: const Color(0xFFFFEDED),
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'images/ic_chat_send_failed.png',
              height: 15,
              width: 15,
              package: PACKAGE_NAME,
            ),
            const SizedBox(width: 4),
            Text(
              text,
              style: const TextStyle(
                color: Color(0xFF353F4A),
                fontSize: 12,
              ),
            ),
          ],
        ),
      );
}
