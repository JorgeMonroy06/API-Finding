part of 'strong_reminder_bloc.dart';

class StrongReminderState {
  final Map<String, dynamic> strongReminder;

  StrongReminderState(this.strongReminder);
}
