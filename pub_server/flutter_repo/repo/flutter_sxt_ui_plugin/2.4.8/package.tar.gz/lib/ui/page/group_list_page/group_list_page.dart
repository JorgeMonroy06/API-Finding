import 'dart:async';
import 'dart:io';

import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/manager/LazyLoadState.dart';
import 'package:contact_ui_flutter/widget/image_loader.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/group_list_page/group_list_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/send_state.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';

class GroupListPage extends StatefulWidget {
  final String? initKeyword;

  GroupListPage({this.initKeyword});

  @override
  _GroupListState createState() => _GroupListState(initKeyword: initKeyword);
}

class _GroupListState extends State<GroupListPage>
    with LazyLoadState<GroupListPage> {
  final String? initKeyword;

  TextEditingController textController = TextEditingController();
  Timer? cancelTask;
  var lastKeyword = "";
  StateSetter? clearButtonStateSetter;
  StateSetter? searchBarStateSetter;

  _GroupListState({this.initKeyword});

  late GroupListBloc groupListBloc;

  @override
  void prepareData() {
    super.prepareData();
    groupListBloc = GroupListBloc(initKeyword);
  }

  @override
  void onLazyLoad() {
    groupListBloc.inital();
  }

  @override
  void initState() {
    super.initState();
    textController.text = initKeyword ?? "";
  }

  @override
  void dispose() {
    groupListBloc.close();
    super.dispose();
    if (cancelTask != null && cancelTask!.isActive) {
      cancelTask?.cancel();
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
        value: groupListBloc,
        child: BlocListener<GroupListBloc, GroupListState>(
            listener: (context, state) {
              switch (state.status) {
                case EventStatus.update:
                  setState(() {});
                  break;
                default:
                  break;
              }
            },
            child: Scaffold(
              backgroundColor: Colors.white,
              appBar: BackgroundImageAppbar(
                title: "我的群组",
                leadingWidget: Container(
                  padding:
                      EdgeInsets.only(left: 12, right: 16, top: 8, bottom: 8),
                  child: InkWell(
                    child: ImageHelper.assetImage("ic_back.png"),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                ),
              ),
              body: Container(
                child: Column(
                  children: [
                    StatefulBuilder(builder:
                        (BuildContext context, StateSetter stateSetter) {
                      bool isEditing = !StringUtil.isEmpty(textController.text);
                      searchBarStateSetter = stateSetter;
                      return Container(
                          color: CustomColors.cl_F5F5F5,
                          child: Padding(
                              padding: EdgeInsets.all(10),
                              child: Container(
                                  height: 34,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(6))),
                                  child: Container(
                                    child: Stack(
                                      children: [
                                        Align(
                                          alignment: Alignment.center,
                                          child: Visibility(
                                              visible: !isEditing,
                                              child: Container(
                                                margin: EdgeInsets.all(8),
                                                child: Row(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    Container(
                                                      width: 14,
                                                      height: 14,
                                                      margin: EdgeInsets.only(
                                                          top: 2),
                                                      child: ImageHelper.assetImage(
                                                          "icon_search_mark.png"),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.only(
                                                          left: 4),
                                                      child: Text(
                                                        "搜索",
                                                        style: TextStyle(
                                                            fontSize: 14,
                                                            color: CustomColors
                                                                .cl_AAAAAA),
                                                      ),
                                                    )
                                                  ],
                                                ),
                                              )),
                                        ),
                                        Align(
                                          alignment: Alignment.center,
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              SizedBox(
                                                width: 8,
                                              ),
                                              Visibility(
                                                  visible: false,
                                                  child: Container(
                                                    width: 14,
                                                    height: 14,
                                                    margin: EdgeInsets.all(8),
                                                    child: ImageHelper.assetImage(
                                                        "icon_search_mark.png"),
                                                  )),
                                              Expanded(child: BlocBuilder<
                                                      GroupListBloc,
                                                      GroupListState>(
                                                  builder: (context, state) {
                                                return TextField(
                                                  controller: textController,
                                                  maxLines: 1,
                                                  onChanged: (v) {
                                                    searchBarStateSetter!(
                                                        () {});

                                                    if (null != cancelTask &&
                                                        cancelTask!.isActive) {
                                                      print(
                                                          'ContactSelectPageState search cancel');
                                                      cancelTask?.cancel();
                                                    }
                                                    print(
                                                        'ContactSelectPageState onChanged $v');
                                                    print(
                                                        'ContactSelectPageState lastKeyword $lastKeyword');
                                                    if (v == lastKeyword) {
                                                      print(
                                                          'ContactSelectPageState same words');
                                                      return;
                                                    }
                                                    print(
                                                        'ContactSelectPageState search start');
                                                    cancelTask = Timer(
                                                        Duration(
                                                            milliseconds: 1500),
                                                        () {
                                                      print(
                                                          'ContactSelectPageState search end');
                                                      lastKeyword = v;
                                                      GroupListBloc bloc =
                                                          BlocProvider.of<
                                                                  GroupListBloc>(
                                                              context);
                                                      bloc.add(SearchGroup(v));
                                                    });
                                                  },
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      color: CustomColors
                                                          .cl_333333),
                                                  decoration:
                                                      InputDecoration.collapsed(
                                                          hintText: "",
                                                          hintStyle: TextStyle(
                                                              fontSize: 14,
                                                              color: CustomColors
                                                                  .cl_AAAAAA),
                                                          border:
                                                              InputBorder.none),
                                                );
                                              })),
                                              textController.text.length == 0
                                                  ? Container()
                                                  : InkWell(
                                                      onTap: () {
                                                        textController.text =
                                                            "";
                                                        searchBarStateSetter!(
                                                            () {});

                                                        lastKeyword = "";
                                                        GroupListBloc bloc =
                                                            BlocProvider.of<
                                                                    GroupListBloc>(
                                                                context);
                                                        bloc.add(
                                                            SearchGroup(""));
                                                      },
                                                      child: Container(
                                                        width: 23,
                                                        height: 23,
                                                        margin:
                                                            EdgeInsets.all(4),
                                                        child: ImageHelper
                                                            .assetImage(
                                                                "ic_clear.png"),
                                                      ))
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ))));
                    }),
                    Expanded(child: BlocBuilder<GroupListBloc, GroupListState>(
                        builder: (context, state) {
                      if (groupListBloc.isLoading) {
                        return Container(
                          alignment: Alignment.center,
                          child: CupertinoActivityIndicator(),
                        );
                      }
                      return (state.groupList?.length ?? 0) == 0
                          ? Container(
                              margin: EdgeInsets.only(top: 100),
                              child: Stack(
                                children: [
                                  Center(
                                    child: Column(
                                      children: [
                                        ImageHelper.assetImage(
                                            "bg_empty_holder.png"),
                                        Text.rich(TextSpan(children: [
                                          TextSpan(text: "暂无群组"),
                                        ]))
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            )
                          : ListView.separated(
                              itemBuilder: (context, index) {
                                return GroupList(
                                  group: state.groupList![index],
                                  onItemClick: () {
                                    Navigator.popUntil(
                                      context,
                                      (route) {
                                        if (!route.willHandlePopInternally &&
                                            route is ModalRoute &&
                                            route.settings.name ==
                                                '/MainPage') {
                                          return true;
                                        }
                                        return false;
                                      },
                                    );
                                    Navigator.push(
                                        context,
                                        new CupertinoPageRoute(
                                            settings: RouteSettings(
                                                name: '/ChatPage'),
                                            builder: (context) {
                                              SessionEntity sessionEntity =
                                                  new SessionEntity(
                                                      code: state
                                                          .groupList![index]
                                                          .groupCode,
                                                      sessionType:
                                                          SessionType.GROUP);
                                              return ChatPage(
                                                  sessionEntity: sessionEntity);
                                            }));
                                  },
                                );
                              },
                              separatorBuilder:
                                  (BuildContext context, int index) {
                                return Container(
                                  height: 0.5,
                                  margin: EdgeInsets.only(left: 60),
                                  color: ColorUtil.COLOR_FFE0E0E0,
                                );
                              },
                              itemCount: state.groupList?.length ?? 0,
                            );
                    }))
                  ],
                ),
              ),
            )));
  }
}

class GroupList extends StatelessWidget {
  Group? group;
  Function? onItemClick;

  GroupList({this.group, this.onItemClick});

  @override
  Widget build(BuildContext context) {
    bool isDownload = false;
    if (group!.avatarThumbState == SendState.SUCCESS) {
      if (!StringUtil.isEmpty(group!.avatarThumbPath)) {
        File file = File(group!.avatarThumbPath!);
        if (file.existsSync()) {
          isDownload = true;
        }
      }
    }

    if (!isDownload) {
      SxtGroupPlugin.downloadGroupThumbAvatar(group!.groupCode!);
    }
    return InkWell(
      splashColor: ThemeData.light().splashColor,
      highlightColor: ThemeData.light().highlightColor,
      onTap: () {
        onItemClick!();
      },
      child: Container(
        height: 56,
        padding: EdgeInsets.only(left: 16),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Row(
            children: [
              ImageLoader(
                isLocal: true,
                url: group!.avatarThumbPath,
                defaultAssetImg: ImageHelper.wrapAssets("ic_group.png"),
                errorAssetImg: ImageHelper.wrapAssets("ic_group.png"),
                borderRadius: 4,
                width: 36,
                height: 36,
                cacheWidth: 36,
                cacheHeight: 36,
                package: PACKAGE_NAME,
              ),
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(left: 10),
                  child: Text(
                    group?.groupName ?? "",
                    style:
                        TextStyle(fontSize: 16, color: ColorUtil.color333333),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
