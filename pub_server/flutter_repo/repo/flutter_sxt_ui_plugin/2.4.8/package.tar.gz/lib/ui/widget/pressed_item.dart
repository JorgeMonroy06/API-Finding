import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';

class PressedItem extends StatelessWidget {
  const PressedItem({
    Key? key,
    required this.title,
    this.onTap,
  }) : super(key: key);

  final String title;
  final GestureTapCallback? onTap;

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.white,
        child: InkWell(
          onTap: onTap,
          child: SizedBox(
            height: 56,
            child: Row(
              children: [
                const SizedBox(width: 14),
                Text(
                  title,
                  style: const TextStyle(
                    color: Color(0xFF333333),
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Image.asset(
                  'images/ic_arrow_right.png',
                  package: PACKAGE_NAME,
                ),
                const SizedBox(width: 15),
              ],
            ),
          ),
        ),
      );
}
