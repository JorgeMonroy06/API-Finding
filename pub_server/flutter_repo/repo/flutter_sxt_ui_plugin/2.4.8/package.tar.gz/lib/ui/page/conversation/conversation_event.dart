import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/message/model/conversation.dart';
import 'package:sxt_flutter_plugin/model/modification_event.dart';
import 'package:sxt_flutter_plugin/ptt/model/monitor_ptt_talk_status_event.dart';

@immutable
abstract class ConversationEvent {}

class ConversationInitialEvent extends ConversationEvent {}

class ConversationUpdateEvent extends ConversationEvent {
  final ModificationEvent<Conversation> data;

  ConversationUpdateEvent(this.data);
}

class ConversationUnreadCountEvent extends ConversationEvent {
  final Conversation conversation;
  final int unreadCount;

  ConversationUnreadCountEvent(this.conversation, this.unreadCount);
}

class ConversationDeleteEvent extends ConversationEvent {
  final Conversation conversation;

  ConversationDeleteEvent(this.conversation);
}

class GroupAvatarUpdateEvent extends ConversationEvent {
  final Group data;

  GroupAvatarUpdateEvent(this.data);
}

class PttTalkStateUpdateEvent extends ConversationEvent {
  final MonitorPttTalkStatusEvent data;

  PttTalkStateUpdateEvent(this.data);
}

class MessageFreeUpdateEvent extends ConversationEvent {}

class OnTopConversationListUpdateEvent extends ConversationEvent {}
