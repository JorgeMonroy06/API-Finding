import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';

class ListDialog extends StatelessWidget {
  final List<String?>? list;

  ListDialog(this.list);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(4))),
      child: ListView.builder(
          shrinkWrap: true,
          itemCount: list!.length,
          physics: BouncingScrollPhysics(),
          itemBuilder: (lastContext, index) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                FlatButton(
                    shape: null,
                    height: 48,
                    onPressed: () {
                      Navigator.pop(context, index);
                    },
                    child: Text(
                      list![index]!,
                      style: TextStyle(fontSize: 14, color: ColorUtil.COLOR_FF131D27),
                    )),
                Container(
                  color: ColorUtil.COLOR_FFEEEEEE,
                  height: list!.length - 1 == index ? 0 : 0.3,
                )
              ],
            );
          }),
      backgroundColor: Colors.white,
    );
  }
}
