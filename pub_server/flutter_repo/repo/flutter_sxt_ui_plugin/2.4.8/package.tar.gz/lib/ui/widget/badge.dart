import 'package:flutter/material.dart';

class Badge extends StatelessWidget {
  const Badge(
    this.count, {
    Key? key,
    this.indeterminate = false,
  })  : assert(count >= 0),
        super(key: key);

  final int count;
  final bool indeterminate;

  @override
  Widget build(BuildContext context) => count == 0
      ? const SizedBox()
      : indeterminate
          ? const SizedBox(
              width: 12,
              height: 12,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: Color(0xFFFF453A),
                  shape: BoxShape.circle,
                ),
              ),
            )
          : Container(
              width: _getWidth(),
              height: 16,
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                color: Color(0xFFFF453A),
                borderRadius: BorderRadius.all(Radius.circular(8)),
              ),
              child: Text(
                _handleCount(),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                ),
              ),
            );

  double _getWidth() {
    if (count > 99) return 24;
    if (count > 9) return 20;
    return 16;
  }

  String _handleCount() {
    if (count > 99) return '99+';
    return '$count';
  }
}
