part of 'chat_history_bloc.dart';

class ChatHistoryState {
  String keyword;
  List<Message> messages;
  bool noMore;

  ChatHistoryState([
    this.keyword = '',
    this.messages = const [],
    this.noMore = false,
  ]);
}
