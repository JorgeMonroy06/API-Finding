part of 'group_chat_detail_page_bloc.dart';

class GroupChatDetailPageState {
  final Group? group;
  final List<Contact>? groupMemberList;
  final EventStatus? status;
  final String? loadingMessage;
  final String? failedMessage;

  const GroupChatDetailPageState({
    @required this.group,
    @required this.groupMemberList,
    @required this.status,
    @required this.loadingMessage,
    @required this.failedMessage,
  });

  GroupChatDetailPageState.initial()
      : this(
            group: null,
            groupMemberList: null,
            status: EventStatus.nothing,
            failedMessage: null,
            loadingMessage: null);

  GroupChatDetailPageState copyWith({
    Group? group,
    List<Contact>? groupMemberList,
    EventStatus? status,
    String? failedMessage,
    String? loadingMessage,
  }) {
    return GroupChatDetailPageState(
      group: group ?? this.group,
      groupMemberList: groupMemberList ?? this.groupMemberList,
      status: status ?? EventStatus.nothing,
      failedMessage: failedMessage ?? this.failedMessage,
      loadingMessage: loadingMessage ?? this.loadingMessage,
    );
  }
}
