import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';

class Empty extends StatelessWidget {
  const Empty({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => Container(
        color: Colors.white,
        alignment: Alignment.center,
        child: Column(
          children: [
            const Spacer(flex: 190),
            Image.asset(
              'images/img_empty.png',
              package: PACKAGE_NAME,
            ),
            const SizedBox(height: 20),
            const Text(
              '当前没有内容',
              style: TextStyle(color: Colors.grey),
            ),
            const Spacer(flex: 345),
          ],
        ),
      );
}
