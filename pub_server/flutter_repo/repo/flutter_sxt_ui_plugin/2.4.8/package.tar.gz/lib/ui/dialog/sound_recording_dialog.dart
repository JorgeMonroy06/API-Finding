import 'dart:async';
import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/message.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/image_text_widget.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/record_state.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sxt_flutter_plugin/message/model/audio_attachment.dart';

class SoundRecordDialog extends StatefulWidget {
  final StreamController<RecordState> stateChangeController;

  SoundRecordDialog(this.stateChangeController);

  @override
  _SoundRecordDialogState createState() => _SoundRecordDialogState();
}

class _SoundRecordDialogState extends State<SoundRecordDialog> {
  final double _maxSize = 280;
  final double _minSize = 120;
  double _currentSize = 120;

  RecordState recordState = new RecordState();
  String? path;
  String? fileName;

  late FlutterSoundRecorder? _myRecorder;
  double _minHeight = 5;

  // ignore: cancel_subscriptions
  StreamSubscription? _recorderSubscription;

  StateSetter? sizeSetter;
  StateSetter? volumeSetter;
  double _wave = 0;

  /// 开始录音
  int duration = 0;

  Future<void> startRecord() async {
    await _myRecorder?.openAudioSession();
    await _myRecorder?.setSubscriptionDuration(Duration(milliseconds: 10));
    Directory tempDir = await getTemporaryDirectory();
    String tempPath = tempDir.path;
    fileName = "${DateTime.now().millisecondsSinceEpoch}.m4a";
    path = "$tempPath/$fileName";
    printLog("path:$path");
    await _myRecorder?.startRecorder(
      toFile: path,
      codec: Codec.aacMP4,
    );
    double lastChange = 0;
    if (_myRecorder == null || _myRecorder!.onProgress == null) {
      return;
    }
    _recorderSubscription = _myRecorder!.onProgress!.listen((e) {
      Duration maxDuration = e.duration;
      duration = maxDuration.inMilliseconds;
      double nowChange =
          maxDuration.inMilliseconds * (_maxSize - _minSize) / (1000 * 60);
      if (_currentSize <= _maxSize && nowChange != lastChange) {
        lastChange = nowChange;
        _currentSize = _minSize + nowChange;
        if (mounted) {
          sizeSetter!(() {});
        }
      }
      double decibels = e.decibels ?? 0;
      if (decibels > 0) {
        _wave = decibels;
      }
    });
  }

  Future<String?> stopRecorder() async {
    String? anURL;
    anURL = await _myRecorder?.stopRecorder();
    if (_recorderSubscription != null) {
      _recorderSubscription!.cancel();
      _recorderSubscription = null;
    }
    return anURL;
  }

  Future<bool> requestPermission() async {
    if (Platform.isIOS) {
      var permissions = [Permission.microphone];
      Map<Permission, PermissionStatus> map = await permissions.request();
      return map[Permission.microphone]!.isGranted;
    }
    return true;
  }

  @override
  void initState() {
    super.initState();
    requestPermission().then((value) {
      if (value) {
        _myRecorder = FlutterSoundRecorder();
        startRecord();
        widget.stateChangeController.stream.listen((event) {
          printLog("move_event_change:${event.toString()}");
          if (event.up) {
            if (event.cancelRecord) {
              Navigator.of(context).pop<AudioAttachment>();
            } else {
              stopRecorder().then((anURL) {
                if (anURL != null && duration < 1000) {
                  if (duration > 300) {
                    ToastUtil.showToast("录制时间太短");
                  }
                  Navigator.of(context).pop<AudioAttachment>();
                } else {
                  AudioAttachment attachment = AudioAttachment();
                  File file = File(path!);
                  attachment.duration = duration;
                  attachment.path = path;
                  attachment.filename = fileName ?? "";
                  attachment.size = file.lengthSync();
                  Navigator.of(context).pop<AudioAttachment>(attachment);
                }
              });
            }
          } else {
            setState(() {
              recordState = event;
            });
          }
        });
      } else {
        ToastUtil.showToast("需要麦克风权限，请先授权");
        Navigator.of(context).pop();
      }
    });
  }

  @override
  void dispose() {
    _myRecorder?.closeAudioSession();
    _myRecorder = null;
    widget.stateChangeController.close();
    // sizeController.close();
    // volumeController.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: _test(recordState),
    );
  }

  Widget _test(RecordState changeState) {
    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        Positioned(
          bottom: 0,
          child: Container(
              height: 114,
              width: MediaQuery.of(context).size.width,
              child: Image.asset(
                !changeState.cancelRecord
                    ? 'images/icon_audio_send_bg.png'
                    : 'images/icon_audio_cancel_bg.png',
                package: PACKAGE_NAME,
                fit: BoxFit.fill,
              )),
        ),
        Positioned(
            bottom: 136,
            child: ImageTextWidget(
              Text(
                !changeState.cancelRecord ? "松开 发送" : "松开 取消",
                style: TextStyle(fontSize: 14, color: ColorUtil.COLOR_FFAAAAAA),
              ),
              Image.asset(
                  !changeState.cancelRecord
                      ? 'images/icon_audio_send.png'
                      : 'images/icon_audio_cancel.png',
                  height: 64,
                  width: 64,
                  fit: BoxFit.fill,
                  package: PACKAGE_NAME),
              drawablePadding: 18,
              direction: Direction.top,
            )),
        Positioned(
          //child: Image.asset('images/icon_audio_send_bg.png')
          bottom: 322,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 70,
                alignment: Alignment.center,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    StatefulBuilder(builder: (context, setState) {
                      sizeSetter = setState;
                      return Container(
                        width: !changeState.cancelRecord ? _currentSize : 90.0,
                        alignment: Alignment.center,
                        height: 70,
                        decoration: BoxDecoration(
                          borderRadius: const BorderRadius.all(
                              const Radius.circular(8.0)),
                          color: !changeState.cancelRecord
                              ? ColorUtil.COLOR_FFCDE8FC
                              : ColorUtil.colorFF85152,
                        ),
                      );
                    }),
                    StreamBuilder(
                        initialData: 0,
                        stream: Stream.periodic(Duration(milliseconds: 300)),
                        builder: (context, snap) {
                          double wave = _wave;
                          return _getChild(changeState.cancelRecord, wave);
                        })
                  ],
                ),
              ),
              Image.asset(
                  !changeState.cancelRecord
                      ? 'images/icon_audio_send_arrow.png'
                      : 'images/icon_audio_cancel_arrow.png',
                  width: 16,
                  height: 8,
                  package: PACKAGE_NAME)
            ],
          ),
        ),
      ],
    );
  }

  Widget _getChild(bool cancelRecord, double wave) {
    printLog("_getChild_wave:${wave}");
    int count;
    if (cancelRecord) {
      count = 15;
    } else {
      count = 21;
    }
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: _getChildren(cancelRecord, count, wave),
    );
  }

  final _random = new Random();

  List<Widget> _getChildren(bool cancelRecord, int count, double wave) {
    List<Widget> widgets = List.empty(growable: true);
    Color color =
        cancelRecord ? ColorUtil.colorFF860102 : ColorUtil.colorFF0F77FE;
    int mid = count ~/ 2;
    double height = wave / 3;
    for (int index = 0; index < count; index++) {
      widgets.add(Container(
        width: 2.5,
        margin: EdgeInsets.symmetric(horizontal: 1),
        height: (_minHeight + _random.nextDouble() * height),
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.all(const Radius.circular(1.25)),
          color: color,
        ),
      ));
    }
    return widgets;
  }
}
