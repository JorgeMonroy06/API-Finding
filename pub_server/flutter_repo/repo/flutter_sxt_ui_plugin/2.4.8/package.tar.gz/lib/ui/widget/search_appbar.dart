import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/image_helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SearchAppbar extends StatefulWidget implements PreferredSizeWidget {
  final double contentHeight; //从外部指定高度
  Color navigationBarBackgroundColor; //设置导航栏背景的颜色
  Function(String)? onSearch;
  TextEditingController? textController;
  FocusNode? focus;

  SearchAppbar({
    this.contentHeight = 48,
    this.navigationBarBackgroundColor = Colors.white,
    this.onSearch,
    this.textController,
    this.focus,
  }) : super();

  @override
  State<StatefulWidget> createState() {
    return SearchAppbarState();
  }

  @override
  Size get preferredSize => Size.fromHeight(contentHeight);
}

class SearchAppbarState extends State<SearchAppbar> {
  StateSetter? clearButtonStateSetter;
  late TextEditingController textController;

  @override
  void initState() {
    super.initState();
    if (widget.textController == null) {
      textController = TextEditingController();
    } else {
      textController = widget.textController!;
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Container(
        color: CustomColors.cl_F5F5F5,
        child: SafeArea(
          top: true,
          child: Container(
              padding: EdgeInsets.only(left: 12, right: 12),
              decoration: UnderlineTabIndicator(
                borderSide: BorderSide(width: 1.0, color: Color(0xFFeeeeee)),
              ),
              height: widget.contentHeight,
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      height: 32,
                      padding: EdgeInsets.only(right: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                        color: Colors.white,
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            margin: EdgeInsets.only(left: 8, right: 8),
                            child: ImageHelper.assetImage("ic_search_grey.png"),
                          ),
                          Expanded(
                            child: TextField(
                              autofocus: true,
                              controller: textController,
                              onChanged: (v) {
                                widget.onSearch!(v);
                              },
                              style: TextStyle(
                                  fontSize: 14, color: CustomColors.cl_333333),
                              focusNode: widget.focus,
                              textAlign: TextAlign.left,
                              decoration: InputDecoration(
                                contentPadding: EdgeInsets.zero,
                                hintText: "搜索",
                                hintStyle: TextStyle(
                                    fontSize: 14,
                                    color: CustomColors.cl_AAAAAA),
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: Colors.transparent,
                                  ),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: Colors.transparent,
                                  ),
                                ),
                                disabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: Colors.transparent,
                                  ),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: Colors.transparent,
                                  ),
                                ),
                              ),
                              maxLines: 1,
                            ),
                          ),
                          StatefulBuilder(
                            builder: (BuildContext context,
                                StateSetter stateSetter) {
                              clearButtonStateSetter = stateSetter;
                              return textController.text.length == 0
                                  ? Container()
                                  : InkWell(
                                      onTap: () {
                                        textController.text = "";
                                        clearButtonStateSetter!(() {});

                                        widget.onSearch!("");
                                      },
                                      child: Container(
                                        child: ImageHelper.assetImage(
                                            "ic_clear.png"),
                                      ));
                            },
                          )
                        ],
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Container(
                        margin: EdgeInsets.only(left: 10),
                        child: Text(
                          '取消',
                          style: TextStyle(
                              fontSize: 14, color: CustomColors.cl_677DB1),
                        )),
                  )
                ],
              )),
        ),
      ),
    );
  }
}
