import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/group_message.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';
import 'package:sxt_flutter_plugin/model/job.dart';

part 'global_search_page_event.dart';

part 'global_search_page_state.dart';

class GlobalSearchPageBloc extends Bloc<GlobalSearchPageEvent, GlobalSearchPageState> {
  GlobalSearchPageBloc() : super(GlobalSearchPageState.initial());

  @override
  Stream<GlobalSearchPageState> mapEventToState(GlobalSearchPageEvent event) async* {
    if (event is Search) {
      yield* _mapSearchGroupEventState(event);
    }
  }

  Stream<GlobalSearchPageState> _mapSearchGroupEventState(Search event) async* {
    if (StringUtil.isEmpty(event.keyword)) {
      yield state.copyWith(orgList: [], groupList: [], contactList: [], groupMessageList: []);
      return;
    }
    try {
      List<Org> orgList = await ContactManager.instance
          .getOrgsByKeyword(event.keyword, 0, 10)
          .where((event) {
            return null != event && event.isNotEmpty;
          })
          .take(1)
          .first;
      yield state.copyWith(orgList: orgList);
    } catch (e) {
      print(e);
    }
    try {
      Job<List<Group>> job = await SxtGroupPlugin.searchGroup(event.keyword);
      yield state.copyWith(groupList: job.data);
    } catch (e) {
      print(e);
    }

    try {
      List<Contact> contactList = await ContactManager.instance
          .getContactsByKeyword(event.keyword, DataFilterBuilder(), 0, 10)
          .where((event) => (null != event && event.isNotEmpty))
          .take(1)
          .first;
      yield state.copyWith(contactList: contactList);
    } catch (e) {
      print(e);
    }

    try {
      Job<List<GroupMessage>> job = await SxtMessagePlugin.searchMessage(event.keyword);
      yield state.copyWith(groupMessageList: job.data);
    } catch (e) {
      print(e);
    }
  }
}
