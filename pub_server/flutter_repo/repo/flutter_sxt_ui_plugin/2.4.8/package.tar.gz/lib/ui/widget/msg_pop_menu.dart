import 'dart:math';
import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/popmenu/triangle_painter.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';

abstract class MenuItemProvider {
  String get menuTitle;

  Widget get menuImage;

  TextStyle get menuTextStyle;

  TextAlign get menuTextAlign;
}

class MenuItem extends MenuItemProvider {
  Widget image; // 图标名称
  String title; // 菜单标题
  var userInfo; // 额外的菜单荐信息
  TextStyle textStyle;
  TextAlign textAlign;

  MenuItem({required this.title, required this.image, this.userInfo, required this.textStyle, required this.textAlign});

  @override
  Widget get menuImage => image;

  @override
  String get menuTitle => title;

  @override
  TextStyle get menuTextStyle => textStyle;

  @override
  TextAlign get menuTextAlign => textAlign;
}

typedef MenuClickCallback = Function(MenuItemProvider item);

class MsgPopMenu extends StatelessWidget {
  static var itemWidth = 64.0;
  static var itemHeight = 56.0;
  static var arrowHeight = 8.0;

  Rect showRect;
  BuildContext buildContext;
  List<MenuItemProvider> items;
  int maxColumn;

  /// style
  Color highlightColor;
  Color lineColor;
  Color backgroundColor;

  late bool _isDown = true;

  /// The left top point of this menu.
  late Offset _offset;

  /// row count
  late int _row;

  /// col count
  late int _col;
  late Size _screenSize; // 屏幕的尺寸

  late MenuClickCallback onClickMenu;

  MsgPopMenu(
      {required this.buildContext,
      required this.showRect,
      required this.onClickMenu,
      required this.items,
      required this.maxColumn,
      required this.lineColor,
      required this.backgroundColor,
      required this.highlightColor});

  void init() {
    this._screenSize = window.physicalSize / window.devicePixelRatio;
    _calculatePosition(buildContext);
  }

  @override
  Widget build(BuildContext context) {
    init();
    return LayoutBuilder(builder: (context, constraints) {
      return Container(
        child: Stack(
          children: <Widget>[
            // triangle arrow
            Positioned(
              left: showRect.left + showRect.width / 2.0 - 7.5,
              top: _isDown ? _offset.dy + menuHeight() : _offset.dy - arrowHeight,
              child: CustomPaint(
                size: Size(15.0, arrowHeight),
                painter: TrianglePainter(isDown: _isDown, color: backgroundColor),
              ),
            ),
            // menu content
            Positioned(
              left: _offset.dx,
              top: _offset.dy,
              child: ClipRRect(
                  borderRadius: BorderRadius.circular(4.0),
                  child: Container(
                    decoration: BoxDecoration(color: backgroundColor, borderRadius: BorderRadius.circular(4.0)),
                    child: Column(
                      children: _createRows(),
                    ),
                  )),
            )
          ],
        ),
      );
    });
  }

  // 创建行
  List<Widget> _createRows() {
    List<Widget> rows = [];
    for (int i = 0; i < _row; i++) {
      Color color = (i < _row - 1 && _row != 1) ? lineColor : Colors.transparent;
      Widget rowWidget = Container(
        decoration: BoxDecoration(border: Border(bottom: BorderSide(color: color))),
        child: Row(
          children: _createRowItems(i),
        ),
      );
      rows.add(rowWidget);
      if (i != _row - 1) {
        rows.add(Container(
          margin: const EdgeInsets.only(left: 20, right: 20),
          height: 1,
          width: MsgPopMenu.itemWidth * _col - 40,
          color: ColorUtil.COLOR_F5A5A5A,
        ));
      }
    }
    return rows;
  }

  // 创建一行的item,  row 从0开始算
  List<Widget> _createRowItems(int row) {
    List<MenuItemProvider> subItems = items.sublist(row * _col, min(row * _col + _col, items.length));
    List<Widget> itemWidgets = [];
    int i = 0;
    for (var item in subItems) {
      itemWidgets.add(_createMenuItem(
        item,
        i < (_col - 1),
      ));
      i++;
    }
    return itemWidgets;
  }

  Widget _createMenuItem(MenuItemProvider item, bool showLine) {
    return _MenuItemWidget(
      item: item,
      showLine: showLine,
      clickCallback: itemClicked,
      lineColor: lineColor,
      backgroundColor: backgroundColor,
      highlightColor: highlightColor,
    );
  }

  void itemClicked(MenuItemProvider item) {
    if (onClickMenu != null) {
      onClickMenu(item);
    }
  }

  // This height exclude the arrow
  double menuHeight() {
    return itemHeight * _row;
  }

  double menuWidth() {
    return itemWidth * _col;
  }

  void _calculatePosition(BuildContext context) {
    _col = _calculateColCount();
    _row = _calculateRowCount();
    _offset = _calculateOffset(context);
  }

  // calculate row count
  int _calculateRowCount() {
    if (items == null || items.length == 0) {
      debugPrint('error menu items can not be null');
      return 0;
    }

    int itemCount = items.length;

    if (_calculateColCount() == 1) {
      return itemCount;
    }

    int row = (itemCount - 1) ~/ _calculateColCount() + 1;

    return row;
  }

  // calculate col count
  int _calculateColCount() {
    if (items == null || items.length == 0) {
      debugPrint('error menu items can not be null');
      return 0;
    }

    int itemCount = items.length;

    if (itemCount >= 6) {
      return 3;
    }
    if (maxColumn < 6) {
      return maxColumn;
    }
    if (maxColumn != 4 && maxColumn > 0) {
      return maxColumn;
    }

    if (itemCount == 4) {
      // 4个显示成两行
      return 2;
    }

    if (itemCount <= maxColumn) {
      return itemCount;
    }

    if (itemCount == 5) {
      return 3;
    }

    return maxColumn;
  }

  Offset _calculateOffset(BuildContext context) {
    double dx = showRect.left + showRect.width / 2.0 - menuWidth() / 2.0;
    if (dx < 10.0) {
      dx = 10.0;
    }

    if (dx + menuWidth() > _screenSize.width && dx > 10.0) {
      double tempDx = _screenSize.width - menuWidth() - 10;
      if (tempDx > 10) dx = tempDx;
    }

    double dy = showRect.top - menuHeight();
    if (dy <= MediaQuery.of(context).padding.top + 10) {
      // The have not enough space above, show menu under the widget.
      dy = arrowHeight + showRect.height + showRect.top;
      _isDown = false;
    } else {
      dy -= arrowHeight;
      _isDown = true;
    }

    return Offset(dx, dy);
  }
}

class _MenuItemWidget extends StatefulWidget {
  final MenuItemProvider item;

  // 是否要显示右边的分隔线
  final bool showLine;
  final Color lineColor;
  final Color backgroundColor;
  final Color highlightColor;

  final Function(MenuItemProvider item) clickCallback;

  _MenuItemWidget(
      {required this.item,
      this.showLine = false,
      required this.clickCallback,
      required this.lineColor,
      required this.backgroundColor,
      required this.highlightColor});

  @override
  State<StatefulWidget> createState() {
    return _MenuItemWidgetState();
  }
}

class _MenuItemWidgetState extends State<_MenuItemWidget> {
  var highlightColor = Color(0x55000000);
  var color = Color(0xff232323);

  @override
  void initState() {
    color = widget.backgroundColor;
    highlightColor = widget.highlightColor;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (details) {
        color = highlightColor;
        setState(() {});
      },
      onTapUp: (details) {
        color = widget.backgroundColor;
        setState(() {});
      },
      onLongPressEnd: (details) {
        color = widget.backgroundColor;
        setState(() {});
      },
      onTap: () {
        if (widget.clickCallback != null) {
          widget.clickCallback(widget.item);
        }
      },
      child: Container(
          width: MsgPopMenu.itemWidth,
          height: MsgPopMenu.itemHeight,
          decoration: BoxDecoration(color: color, border: Border(right: BorderSide(color: widget.showLine ? widget.lineColor : Colors.transparent))),
          child: _createContent()),
    );
  }

  Widget _createContent() {
    if (widget.item.menuImage != null) {
      // image and text
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Container(
            child: widget.item.menuImage,
          ),
          SizedBox(
            height: 3,
          ),
          Container(
            child: Material(
              color: Colors.transparent,
              child: Text(
                widget.item.menuTitle,
                style: widget.item.menuTextStyle,
              ),
            ),
          )
        ],
      );
    } else {
      // only text
      return Container(
        child: Center(
          child: Material(
            color: Colors.transparent,
            child: Text(
              widget.item.menuTitle,
              style: widget.item.menuTextStyle,
              textAlign: widget.item.menuTextAlign,
            ),
          ),
        ),
      );
    }
  }
}
