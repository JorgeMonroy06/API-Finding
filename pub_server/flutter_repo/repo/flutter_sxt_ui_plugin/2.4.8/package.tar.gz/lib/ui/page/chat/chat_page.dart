import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/manager/LazyLoadState.dart';
import 'package:contact_ui_flutter/manager/contact_module_manager.dart';
import 'package:contact_ui_flutter/ui/contact_select_list/contact_list_select_page.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_imagepicker_plugin/flutter_imagepicker_plugin.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/manager/app_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/audio_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/event/update_main_page_index_event.dart';
import 'package:flutter_sxt_ui_plugin/manager/eventbus_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/file_picker_listener.dart';
import 'package:flutter_sxt_ui_plugin/manager/flutter_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/video_calling_listener.dart';
import 'package:flutter_sxt_ui_plugin/ui/dialog/sound_recording_dialog.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/group_chat_detail_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/single_chat_detail/single_chat_detail_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/strong_reminder/strong_reminder_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/select_file/select_file_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/take_picture_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar2.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/chat_message_widget.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/loading_dialog.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/file_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/record_state.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:kd_flutter_map/amap_location_option.dart';
import 'package:kd_flutter_map/bean/poi_bean.dart';
import 'package:kd_flutter_map/flutter_map_manager.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';
import 'package:sxt_flutter_plugin/group/model/get_group_member_param.dart';
import 'package:sxt_flutter_plugin/group/model/group_member.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_manager.dart';
import 'package:sxt_flutter_plugin/message/model/audio_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/file_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/location_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/pic_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/prompt_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/prompt_type.dart';
import 'package:sxt_flutter_plugin/message/model/send_message_param.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';
import 'package:sxt_flutter_plugin/message/model/text_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/video_attachment.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';

import 'ptt/ptt_page.dart';

class ChatPage extends StatefulWidget {
  final SessionEntity sessionEntity;
  bool? normalBack;
  bool? isFromRecord;
  int? msgId;
  int? msgTime;

  ChatPage({Key? key, required this.sessionEntity, this.normalBack, this.isFromRecord, this.msgId, this.msgTime}) : super(key: key);

  @override
  State<StatefulWidget> createState() => ChatPageState();
}

class ChatPageState extends State<ChatPage> with LazyLoadState<ChatPage>, WidgetsBindingObserver, SingleTickerProviderStateMixin {
  static const String PHOTO = "照片";
  static const String TAKE_PHOTO = "拍摄";
  static const String VIDEO_CALL = "语音通话";
  static const String FILE = "文件";
  static const String LOCATION = "位置";
  static const String PTT = "对讲";
  static const String POKE = "戳一戳";

  var moreActionDrawable = {};

  String? _inputText;
  bool showMore = false;

  bool isKeyboardActived = false;
  Map<int, StateSetter> stateSetterMap = {};

  TextEditingController editingController = TextEditingController();
  final GlobalObjectKey bottomValueKey = GlobalObjectKey("bottom_value_key");

  // 滚动控制器
  late ScrollController _scrollController;
  late StreamController<RecordState> stateChangeController;
  late VideoCallingListener videoCallingListener;

  double _touchDy = 0;
  double _lastOffset = 0;
  double _midOffset = 90;

  bool _isSending = true;
  RecordState recordState = RecordState();

  var _focusNode = FocusNode();
  bool _isSpeaking = false;
  bool _isPressed = false;
  StateSetter? bottomLayoutState;

  late ChatBloc chatBloc;
  late StrongReminderBloc _strongReminderBloc;

  @override
  void prepareData() {
    super.prepareData();
    chatBloc = ChatBloc(widget.sessionEntity, context);
    _strongReminderBloc = context.read<StrongReminderBloc>();
    _strongReminderBloc.currentChat = widget.sessionEntity;
  }

  @override
  void onLazyLoad() {
    _midOffset = 90 - MediaQuery.of(context).padding.bottom;
    chatBloc.inital(widget.isFromRecord, widget.msgTime, widget.msgId);
    _focusNode.addListener(() {
      print("chatpage _focusNode hasFocus : ${_focusNode.hasFocus}");
      if (_focusNode.hasFocus) {
        if (showMore) {
          showMore = false;
          bottomLayoutState!(() {});
        }
        _scroll2lastedMessage();
      }
    });
  }

  @override
  void initState() {
    WidgetsBinding.instance?.addObserver(this);
    videoCallingListener = VideoCallingListener(
        onStart: () {
          print("aaaa VideoCallingListener onStart _isPressed : $_isPressed");
          if (_isPressed) {
            recordState.up = true;
            stateChangeController.add(recordState);
            _isPressed = false;
            bottomLayoutState!(() {});
          }
        },
        onStop: () {});
    FlutterManager.instance.addVideoCallingListener(videoCallingListener);

    FlutterManager.instance.filePickerListener = FilePickerListener(onPicked: (list) {
      list.forEach((element) async {
        int msgType;
        String fileSuffix = FileUtil.getFileSuffix(element.path ?? "");

        Map<String, dynamic>? attachmentMap;

        if (FileUtil.isVideo(fileSuffix)) {
          final VideoAttachment attachment = VideoAttachment(
            filename: element.name,
            path: element.path,
            size: element.size,
          )..duration = await FlutterManager.instance.getVideoDuration(element.path);
          msgType = MsgType.VIDEO_FILE;
          attachmentMap = attachment.toJson();
        } else if (FileUtil.isImage(fileSuffix)) {
          final PicAttachment attachment = PicAttachment(
            filename: element.name,
            path: element.path,
            size: element.size,
          );
          attachmentMap = attachment.toJson();
          msgType = MsgType.PICTURE;
        } else {
          FileAttachment attachment = FileAttachment();
          attachment.path = element.path;
          attachment.size = element.size;
          attachment.filename = element.name;
          attachmentMap = attachment.toJson();
          msgType = MsgType.OTHERS;
        }
        SendMessageParam param = SendMessageParam()
          ..userCode = widget.sessionEntity.code!
          ..sessionType = widget.sessionEntity.sessionType
          ..attachment = attachmentMap
          ..msgType = msgType;
        SxtMessagePlugin.sendMessage(param);
      });
    });

    super.initState();
    AudioManager.instance.init();
    _scrollController = ScrollController();

    moreActionDrawable = {};

    moreActionDrawable[PHOTO] = "images/ic_chat_send_pic.png";
    moreActionDrawable[TAKE_PHOTO] = "images/ic_chat_send_camera.png";

    if ((AppManager.instance.uiOptions.enableMultiGroupCalling && widget.sessionEntity.sessionType == SessionType.GROUP) ||
        widget.sessionEntity.sessionType == SessionType.USER) {
      moreActionDrawable[VIDEO_CALL] = "images/ic_chat_send_phone.png";
    }

    moreActionDrawable[FILE] = "images/ic_chat_file.png";

    if (AppManager.instance.uiOptions.enableSendLocation) {
      moreActionDrawable[LOCATION] = "images/ic_chat_send_location.png";
    }

    SxtAccountPlugin.getCurrentUser().then((value) {
      if (AppManager.instance.uiOptions.enablePTT && value.code != widget.sessionEntity.code) {
        moreActionDrawable[PTT] = "images/ic_chat_ptt.png";
        bottomLayoutState!(() {});
      }
    });

    if (widget.sessionEntity.sessionType == SessionType.USER) {
      moreActionDrawable[POKE] = "images/ic_chat_poke.png";
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    FlutterManager.instance.removeVideoCallingListener(videoCallingListener);
    FlutterManager.instance.filePickerListener = null;
    chatBloc.close();
    FileUtil.clearImageCache();
    DataManager.instance.clearDownloading();
    AudioManager.instance.destroy();
    WidgetsBinding.instance?.removeObserver(this);

    _focusNode.dispose();
    _scrollController.dispose();
    _strongReminderBloc.currentChat = null;
    super.dispose();
  }

  Future _scroll2lastedMessage({int million = 100, bool hasMessage = true}) async {
    if (!hasMessage) return null;
    if (_scrollController.hasClients) {
      await _scrollController.animateTo(_scrollController.position.maxScrollExtent, duration: Duration(milliseconds: million), curve: Curves.linear);
      if (hasMessage) {
        //下一帧之后再计算高度
        WidgetsBinding.instance?.addPostFrameCallback((timeStamp) {
          Future.delayed(const Duration(milliseconds: 50), () {
            if (_scrollController.offset != _scrollController.position.maxScrollExtent) {
              _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
            }
          });
        });
      }
    }
    return null;
  }

  @override
  void didChangeMetrics() {
    super.didChangeMetrics();
    WidgetsBinding.instance?.addPostFrameCallback((_) {
      if (mounted) {
        isKeyboardActived = !(MediaQuery.of(context).viewInsets.bottom == 0);
        print("isKeyboardActived$isKeyboardActived");
        if (isKeyboardActived && _scrollController.hasClients) {
          if (_scrollController.offset != _scrollController.position.maxScrollExtent) {
            _scroll2lastedMessage(million: 10);
          }
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
        value: chatBloc,
        child: Scaffold(
          appBar: BackgroundImageAppbar(
              leadingWidget: Container(
                child: InkWell(
                  child:
                      // Row(children: [
                      Container(
                    padding: EdgeInsets.only(left: 12, top: 8, bottom: 8),
                    child: ImageHelper.assetImage("ic_back.png"),
                  ),
                  // BlocBuilder<ChatBloc, ChatState>(
                  //   buildWhen: (previous, current) {
                  //     return previous.unReadCount != current.unReadCount;
                  //   },
                  //   builder: (context, state) {
                  //     return Visibility(
                  //         // visible: state.unReadCount > 0,
                  //         visible: false,
                  //         child: Text(
                  //           (state.unReadCount > 99) ? "(99+)" : "(${state.unReadCount.toString()})",
                  //           style: TextStyle(fontSize: 16, color: Colors.white),
                  //         ));
                  //   },
                  // )
                  // ]),
                  onTap: () {
                    if (widget.normalBack ?? false) {
                      Navigator.pop(context);
                    } else {
                      Navigator.popUntil(
                        context,
                        (route) {
                          if (!route.willHandlePopInternally && route is ModalRoute && route.settings.name == '/MainPage') {
                            SxtEventBusManager.instance.eventBus?.fire(UpdateMainPageIndexEvent());
                            return true;
                          }
                          return false;
                        },
                      );
                    }
                  },
                ),
              ),
              trailingWidget: IconButton(
                  iconSize: 32,
                  icon: ImageHelper.assetImage("ic_more.png"),
                  onPressed: () {
                    if (widget.sessionEntity.sessionType == SessionType.USER) {
                      Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
                        return SingleChatDetailPage(sessionEntity: widget.sessionEntity);
                      }));
                    } else if (widget.sessionEntity.sessionType == SessionType.GROUP) {
                      Navigator.of(context).push(CupertinoPageRoute(
                          settings: RouteSettings(name: '/GroupChatDetailPage'),
                          builder: (context) {
                            return GroupChatDetailPage(widget.sessionEntity);
                          }));
                    }
                  }),
              titleWidget: BlocBuilder<ChatBloc, ChatState>(buildWhen: (previous, current) {
                return (previous.contact != current.contact) || (previous.group != current.group || previous.groupMemberCount != current.groupMemberCount);
              }, builder: (context, state) {
                print("aaaa build chat name ");
                String name = "";
                if (widget.sessionEntity.sessionType == SessionType.GROUP) {
                  String groupName = state.group?.groupName ?? "";
                  if (groupName.length > 9) {
                    groupName = groupName.substring(0, 8) + "...";
                  }
                  name = groupName;
                  if ((state.groupMemberCount ?? 0) > 0) {
                    name += "(${state.groupMemberCount})";
                  }
                } else {
                  name = state.contact?.name ?? "";
                }
                return Text(
                  name,
                  style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                );
              })),
          backgroundColor: ColorUtil.COLOR_FFECEDEE,
          body: Listener(
            onPointerDown: (event) {
              // print("outer__point_down");
            },
            onPointerMove: (event) {
              // print("outer__point_onPointerMove${(_otherTouchDy-_otherMoveDy).abs()}");
              if (!_isPressed) {
              } else {
                double _moveDy = event.position.dy;
                double _currentOffset = _touchDy - _moveDy;
                if (_currentOffset > _lastOffset) {
                  //向上
                  if (_currentOffset > _midOffset && _isSending) {
                    recordState.cancelRecord = true;
                    recordState.up = false;
                    stateChangeController.add(recordState);
                    _isSending = false;
                  }
                } else {
                  //想下
                  if (_currentOffset < _midOffset && !_isSending) {
                    recordState.cancelRecord = false;
                    recordState.up = false;
                    stateChangeController.add(recordState);
                    _isSending = true;
                  }
                }
                _lastOffset = _currentOffset;
              }
              //如果向上滑动到mid，并且是第一次大于改变量则取消；
              //如果向下滑动到mid，并且是第一白干则继续；
            },
            onPointerUp: (event) {
              if (_isPressed) {
                recordState.up = true;
                stateChangeController.add(recordState);
                _isPressed = false;
                bottomLayoutState!(() {});
              }
            },
            child: BlocListener<ChatBloc, ChatState>(
              listener: (context, state) {
                switch (state.status) {
                  case EventStatus.loading:
                    showDialog(context: context, barrierDismissible: false, builder: (ctx) => LoadingDialog(state.message ?? "", () => {}));
                    break;
                  case EventStatus.failure:
                    Navigator.pop(context);
                    ToastUtil.showToast(state.message ?? "");
                    break;
                  case EventStatus.loadingSuccess:
                    Navigator.pop(context);
                    ToastUtil.showToast(state.message ?? "");
                    Navigator.pop(context);
                    break;
                  case EventStatus.popPage:
                    if (!StringUtil.isEmpty(state.message)) {
                      ToastUtil.showToast(state.message!);
                    }
                    print("aaaa Chatpage EventStatus.popPage");
                    Navigator.pop(context);
                    break;
                  case EventStatus.nothing:
                    break;
                  case EventStatus.update:
                    if (null != state.refreshMessage) {
                      bool isUpdated = false;
                      for (int i = 0; i < state.msgList.list.length; i++) {
                        Message msg = state.msgList.list[i];
                        if (msg.code == state.refreshMessage!.code) {
                          isUpdated = true;
                          if (null != stateSetterMap[msg.code]) {
                            stateSetterMap[msg.code]!(() {});
                          }
                          //item布局变大后，需要把list滑到最底部,否则显示不全
                          if ((state.canScrollList ?? false) && i == state.msgList.list.length - 1) {
                            _scroll2lastedMessage(million: 100);
                          }
                          break;
                        }
                      }
                      if (!isUpdated) {
                        for (int i = 0; i < state.historyMsgList.list.length; i++) {
                          Message msg = state.historyMsgList.list[i];
                          if (msg.code == state.refreshMessage!.code) {
                            if (null != stateSetterMap[msg.code]) {
                              stateSetterMap[msg.code]!(() {});
                            }
                            break;
                          }
                        }
                      }
                    }
                    break;
                  default:
                    break;
                }
              },
              child: Column(
                children: <Widget>[
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        print("chatpage  chatlist GestureDetector onTap");
                        if (selectableTextFosusNoded) {
                          selectableTextFosusNoded = false;
                          FocusScope.of(context).requestFocus(FocusNode());
                        }
                      },
                      onPanDown: (DragDownDetails e) {
                        //打印手指按下的位置
                        print("chatpage chatlist GestureDetector  onPanDown");
                        if (showMore) {
                          showMore = false;
                          bottomLayoutState!(() {});
                        }
                        if (_focusNode.hasFocus) {
                          _focusNode.unfocus();
                        }
                      },
                      onPanUpdate: (DragUpdateDetails e) {
                        print("chatpage chatlist GestureDetector  onPanUpdate");
                      },
                      child: Stack(children: [
                        BlocBuilder<ChatBloc, ChatState>(buildWhen: (previous, current) {
                          return (previous.msgList != current.msgList) || (previous.historyMsgList != current.historyMsgList);
                        }, builder: (context, state) {
                          return chatList(context, state);
                        }),
                        BlocBuilder<ChatBloc, ChatState>(buildWhen: (previous, current) {
                          return (previous.isMultiCalling != current.isMultiCalling) ||
                              (previous.isAcceptCalling != current.isAcceptCalling) ||
                              (previous.multiMeetingCode != current.multiMeetingCode) ||
                              (previous.isMultiMeetingVideo != current.isMultiMeetingVideo);
                        }, builder: (context, state) {
                          print("aaaa isMultiCalling:${state.isMultiCalling}");
                          print("aaaa isAcceptCalling:${state.isAcceptCalling}");

                          return Visibility(
                              visible: state.isMultiCalling && !state.isAcceptCalling,
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: Container(
                                    margin: EdgeInsets.only(top: 8, left: 8, right: 8),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        border: Border.all(
                                          color: Colors.white,
                                          width: 0,
                                        ),
                                        borderRadius: BorderRadius.all(Radius.circular(4))),
                                    height: 46,
                                    child: InkWell(
                                      onTap: () {
                                        ChatBloc bloc = BlocProvider.of<ChatBloc>(context);
                                        if (null != bloc.meetingInfo) {
                                          FlutterManager.instance.backToMultiCalling(bloc.meetingInfo!);
                                        }
                                      },
                                      child: Row(
                                        children: [
                                          Container(
                                            width: 28,
                                            height: 28,
                                            margin: EdgeInsets.only(left: 8, right: 8),
                                            child: ImageHelper.assetImage("ic_multi_call.png"),
                                          ),
                                          Expanded(
                                            child: Text(
                                              !StringUtil.isEmpty(state.multiMeetingCode)
                                                  ? "${state.multiMeetingCode}邀请你的${state.isMultiMeetingVideo ? "视频" : "语音"}通话正在进行中"
                                                  : "你发起的${state.isMultiMeetingVideo ? "视频" : "语音"}通话正在进行中",
                                              style: TextStyle(fontSize: 14, color: ColorUtil.COLOR_FF636D8A),
                                            ),
                                          ),
                                          Container(
                                            width: 7,
                                            height: 13,
                                            margin: EdgeInsets.only(right: 16),
                                            child: ImageHelper.assetImage("ic_arrow_right.png"),
                                          )
                                        ],
                                      ),
                                    )),
                              ));
                        }),
                        BlocBuilder<ChatBloc, ChatState>(buildWhen: (previous, current) {
                          return ((previous.isMultiCalling != current.isMultiCalling) || (previous.isAcceptCalling != current.isAcceptCalling)) ||
                              (previous.pttSpeaker != current.pttSpeaker);
                        }, builder: (context, state) {
                          print("aaaa build ptt layout speak : ${state.pttSpeaker}");
                          return Visibility(
                              visible: state.pttSpeaker != null,
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: Container(
                                    margin: EdgeInsets.only(top: (state.isMultiCalling && !state.isAcceptCalling) ? 60 : 8, left: 8, right: 8),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        border: Border.all(
                                          color: Colors.white,
                                          width: 0,
                                        ),
                                        borderRadius: BorderRadius.all(Radius.circular(4))),
                                    height: 46,
                                    child: InkWell(
                                      onTap: () {
                                        String chat_title = "";
                                        if (widget.sessionEntity.sessionType == SessionType.GROUP) {
                                          String groupName = state.group?.groupName ?? "";
                                          if (groupName.length > 9) {
                                            groupName = groupName.substring(0, 8) + "...";
                                          }
                                          chat_title = groupName;
                                          if ((state.groupMemberCount ?? 0) > 0) {
                                            chat_title += "(${state.groupMemberCount})";
                                          }
                                        } else {
                                          chat_title = state.contact?.name ?? "";
                                        }

                                        Navigator.of(context).push(
                                          CupertinoPageRoute(
                                            builder: (context) => PttPage(
                                              widget.sessionEntity,
                                              chat_title,
                                            ),
                                          ),
                                        );
                                      },
                                      child: Row(
                                        children: [
                                          Container(
                                            width: 22,
                                            height: 22,
                                            margin: EdgeInsets.only(left: 17, right: 8),
                                            child: ImageHelper.assetImage("ic_ptt_wave.png"),
                                          ),
                                          Expanded(
                                            child: Text(
                                              (state.pttSpeaker?.name ?? "") + "正在讲话",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                fontSize: 14,
                                                color: ColorUtil.COLOR_FF636D8A,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            width: 7,
                                            height: 13,
                                            margin: EdgeInsets.only(right: 16),
                                            child: ImageHelper.assetImage("ic_arrow_right.png"),
                                          )
                                        ],
                                      ),
                                    )),
                              ));
                        })
                      ]),
                    ),
                  ),
                  Container(
                    child: StatefulBuilder(builder: (context, setState) {
                      bottomLayoutState = setState;
                      return Column(
                        children: [
                          Divider(
                            height: 0.5,
                            color: ColorUtil.dividerColor,
                          ),
                          sendLayout(),
                          Visibility(visible: showMore, child: moreLayout()),
                        ],
                      );
                    }),
                  ),
                  Container(
                    height: MediaQuery.of(context).padding.bottom,
                    width: MediaQuery.of(context).size.width,
                    color: ColorUtil.COLOR_FFF6F7F8,
                  )
                ],
              ),
            ),
          ),
        ));
  }

  showVideoCallDialog(bool isMulti, Contact? contact, ChatState chatState) {
    showModalBottomSheet(
        barrierColor: ColorUtil.COLOR_33000000,
        backgroundColor: Colors.transparent,
        context: context,
        builder: (BuildContext buildContext) {
          return Container(
            child: Container(
                height: Platform.isAndroid ? 140 : 140 + MediaQuery.of(context).padding.bottom,
                child: Column(
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pop(buildContext);

                        if (DataManager.instance.isDisconnected) {
                          ToastUtil.showToast("网络连接已断开");
                          return;
                        }

                        if (isMulti) {
                          //判断是否有悬浮窗权限
                          FlutterManager.instance.hasFloatWindowPermission()!.then((value) {
                            if (!value) {
                              FlutterManager.instance.requestFloatWindowPermission();
                              return;
                            }
                          });

                          GetGroupMemberParam getGroupMemberParam = GetGroupMemberParam();
                          getGroupMemberParam.groupCode = widget.sessionEntity.code;
                          getGroupMemberParam.count = 10000;
                          SxtGroupPlugin.getGroupMember(getGroupMemberParam).then((value) {
                            List<GroupMember> groupMemberList = value.data!;
                            List<String> code = [];

                            groupMemberList.forEach((element) {
                              code.add(DomainUtil.toCode(element.code!));
                            });
                            //TODO 删除一行
                            code.remove(ContactModuleManager.instance.getContactModuleOption()!.userCode);
                            code.remove(ContactModuleManager.instance.getContactModuleOption()!.userCode);
                            Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
                              return ContactListSelectPage(
                                contactCodeList: code,
                                title: "选择联系人",
                                limitCount: 8,
                              );
                            })).then((value) {
                              if (value == null) return;

                              FlutterManager.instance.startMultiVideoCall(chatState.group!, value);
                            }).onError((error, stackTrace) {
                              ToastUtil.showToast("发起多方会议失败");
                            });
                          }).onError((error, stackTrace) {
                            ToastUtil.showToast("发起多方会议失败");
                          });
                        } else {
                          FlutterManager.instance.startVideoCall(contact!);
                        }
                      },
                      child: Container(
                        height: 44,
                        child: Align(
                          alignment: Alignment.center,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 23,
                                height: 23,
                                margin: EdgeInsets.only(right: 6),
                                child: ImageHelper.assetImage("ic_video_call.png"),
                              ),
                              Container(
                                padding: EdgeInsets.only(bottom: 2),
                                child: Text('视频通话', style: TextStyle(color: Colors.black, fontSize: 16)),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      height: 1,
                      color: CustomColors.cl_F5F5F5,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.pop(buildContext);

                        if (DataManager.instance.isDisconnected) {
                          ToastUtil.showToast("网络连接已断开");
                          return;
                        }

                        if (isMulti) {
                          GetGroupMemberParam getGroupMemberParam = GetGroupMemberParam();
                          getGroupMemberParam.groupCode = widget.sessionEntity.code;
                          getGroupMemberParam.count = 10000;
                          SxtGroupPlugin.getGroupMember(getGroupMemberParam).then((value) {
                            List<GroupMember> groupMemberList = value.data!;
                            List<String> code = [];

                            groupMemberList.forEach((element) {
                              code.add(DomainUtil.toCode(element.code!));
                            });
                            //TODO 删除一行
                            code.remove(ContactModuleManager.instance.getContactModuleOption()!.userCode);
                            code.remove(ContactModuleManager.instance.getContactModuleOption()!.userCode);
                            Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
                              return ContactListSelectPage(
                                contactCodeList: code,
                                title: "选择联系人",
                                limitCount: 8,
                              );
                            })).then((value) {
                              if (value == null) return;
                              FlutterManager.instance.startMultiVoiceCall(chatState.group!, value);
                            }).onError((error, stackTrace) {
                              ToastUtil.showToast("发起多方会议失败");
                            });
                          }).onError((error, stackTrace) {
                            ToastUtil.showToast("发起多方会议失败");
                          });
                        } else {
                          FlutterManager.instance.startVoiceCall(contact!);
                        }
                      },
                      child: Container(
                        height: 44,
                        child: Align(
                          alignment: Alignment.center,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 23,
                                height: 23,
                                margin: EdgeInsets.only(right: 6),
                                child: ImageHelper.assetImage("ic_voice_call.png"),
                              ),
                              Container(
                                padding: EdgeInsets.only(bottom: 2),
                                child: Text('语音通话', style: TextStyle(color: Colors.black, fontSize: 16)),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      height: 4,
                      color: CustomColors.cl_F5F5F5,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        height: 46,
                        child: Align(
                          alignment: Alignment.center,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [Text('取消', style: TextStyle(color: Colors.black, fontSize: 16))],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      height: Platform.isAndroid ? 0 : MediaQuery.of(context).padding.bottom,
                      width: MediaQuery.of(context).size.width,
                      color: Colors.white,
                    )
                  ],
                ),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10)))),
          );
        });
  }

  Future<void> commitPicAndVideos(AssetResult value) async {
    if (value.assets == null || value.assets!.isEmpty) return;
    for (AssetEntry element in value.assets!) {
      String? filename;
      String? path;
      filename = element.title;
      path = element.path;
      int? length = element.size;

      final param = SendMessageParam()
        ..userCode = widget.sessionEntity.code!
        ..sessionType = widget.sessionEntity.sessionType;
      if (element.type == AssetType.image) {
        param.msgType = MsgType.PICTURE;
        param.attachment = PicAttachment(
          filename: filename,
          path: path,
          size: length,
        ).toJson();
      } else {
        param.msgType = MsgType.VIDEO_FILE;
        param.attachment = VideoAttachment(
          filename: filename,
          path: path,
          duration: element.duration * 1000,
          size: length,
        ).toJson();
      }
      await SxtMessagePlugin.sendMessage(param);
    }
  }

  bool getPreviousPageMsgList(ChatState chatState, BuildContext context) {
    if (isRefresh) return false;
    isRefresh = true;
    if (chatState.msgList.list.length >= 1) {
      print("aaaa getNextPageMsgList");
      chatBloc.add(LoadPreviousPageMessageEvent(chatState.historyMsgList.list.isEmpty ? chatState.msgList.list[0] : chatState.historyMsgList.list.last));
    }
    return true;
  }

  bool getNextPageMsgList(ChatState chatState, BuildContext context) {
    if (isRefresh) return false;
    isRefresh = true;
    print("aaaa getNextPageMsgList");
    Message lastMsg = chatState.msgList.list.isEmpty ? chatState.historyMsgList.list.last : chatState.msgList.list.last;
    chatBloc.add(LoadNextPageMessageEvent(lastMsg.code!, lastMsg.createTime!));
    return true;
  }

  void setListVisible(ChatState state) {
    if (!visible && state.msgList.list.isNotEmpty) {
      WidgetsBinding.instance?.endOfFrame.then((timeStamp) {
        setState(() {
          visible = true;
        });
      });
    }
  }

  Widget msgLoadingWidget() {
    return Container(
      height: 50,
      width: MediaQuery.of(context).size.width,
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 10,
            ),
            CupertinoActivityIndicator(
              radius: 12,
            ),
          ],
        ),
      ),
    );
  }

  bool isRefresh = false;
  Key centerKey = ValueKey('second-sliver-list');
  bool visible = false;

  Widget chatList(BuildContext context, ChatState state) {
    //是不是查看历史消息
    if (state.isLoadHistoryMessageOperate || state.isLoadNextPageMessageOperate) {
      isRefresh = false;
    }

    //要是来新消息自动往上滚动
    if (!state.isLoadHistoryMessageOperate &&
        _scrollController.hasClients &&
        (_scrollController.offset - _scrollController.position.maxScrollExtent).abs() < 150 &&
        state.msgList.list.isNotEmpty) {
      WidgetsBinding.instance?.endOfFrame.then((timeStamp) {
        if (state.isLoadNextPageMessageOperate) {
          setListVisible(state);
        } else {
          _scroll2lastedMessage(million: 50, hasMessage: state.msgList.list.isNotEmpty).then((value) {
            setListVisible(state);
          });
        }
      });
    }
    print("aaaa build chatList ");
    return IgnorePointer(
      ignoring: !visible,
      child: NotificationListener(
        onNotification: (ScrollNotification scrollInfo) {
          //查看历史消息监听
          if ((scrollInfo.metrics.pixels - scrollInfo.metrics.minScrollExtent) < 30 && state.hasPreviousPageMessage && !isRefresh) {
            getPreviousPageMsgList(state, context);
          }

          if ((scrollInfo.metrics.pixels >= scrollInfo.metrics.maxScrollExtent) && state.hasNextPageMessage && !isRefresh) {
            getNextPageMsgList(state, context);
          }
          return true;
        },
        child: Opacity(
          opacity: visible ? 1 : 0,
          child: CustomScrollView(
            controller: _scrollController,
            center: centerKey,
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            physics: AlwaysScrollableScrollPhysics(),
            slivers: [
              SliverList(
                delegate: SliverChildBuilderDelegate(
                  (BuildContext context, int index) {
                    if (index == state.historyMsgList.list.length) {
                      return msgLoadingWidget();
                    }
                    return StatefulBuilder(builder: (context, setState) {
                      int realIndex = index;
                      Message currentMessage = state.historyMsgList.list[realIndex];
                      stateSetterMap[currentMessage.code!] = setState;
                      bool showTime = false;
                      if (realIndex != 0) {
                        Message previousMessage = state.historyMsgList.list[realIndex - 1];
                        if ((currentMessage.createTime! - previousMessage.createTime!).abs() < 60 * 5 * 1000) {
                          showTime = false;
                        } else {
                          showTime = true;
                        }
                      } else {
                        if (!state.hasPreviousPageMessage) {
                          showTime = true;
                        }
                      }

                      double? progress = state.fileProgressMap[currentMessage.code];
                      return ChatMessageWidget(ValueKey<int>(DateTime.now().millisecond), currentMessage, state.currentAccount?.code ?? "", showTime,
                          widget.sessionEntity.sessionType == SessionType.GROUP, progress, chatBloc);
                    });
                  },
                  childCount: state.historyMsgList.list.length + (state.hasPreviousPageMessage ? 1 : 0),
                ),
              ),
              SliverList(
                key: centerKey,
                delegate: SliverChildBuilderDelegate(
                  (BuildContext context, int index) {
                    if ((index == state.msgList.list.length)) {
                      return msgLoadingWidget();
                    }
                    return StatefulBuilder(builder: (context, setState) {
                      int realIndex = index;
                      Message currentMessage = state.msgList.list[realIndex];
                      stateSetterMap[currentMessage.code!] = setState;
                      bool showTime = false;
                      if (realIndex != 0) {
                        Message previousMessage = state.msgList.list[realIndex - 1];
                        if ((currentMessage.createTime! - previousMessage.createTime!).abs() < 60 * 5 * 1000) {
                          showTime = false;
                        } else {
                          showTime = true;
                        }
                      } else {
                        if (!state.hasPreviousPageMessage) {
                          showTime = true;
                        }
                      }

                      double? progress = state.fileProgressMap[currentMessage.code];
                      return ChatMessageWidget(ValueKey<int>(DateTime.now().millisecond), currentMessage, state.currentAccount?.code ?? "", showTime,
                          widget.sessionEntity.sessionType == SessionType.GROUP, progress, chatBloc);
                    });
                  },
                  childCount: state.msgList.list.length + (state.hasNextPageMessage ? 1 : 0),
                  // childCount: state.msgList.list.length,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget sendLayout() {
    print("aaaa build sendLayout ");
    return Container(
        constraints: BoxConstraints(minHeight: 54),
        color: ColorUtil.COLOR_FFF6F7F8,
        padding: EdgeInsets.fromLTRB(5, 10, 9, 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            InkWell(
                child: Image.asset(_isSpeaking ? 'images/icon_keyboard.png' : 'images/ic_chat_audio_record.png',
                    fit: BoxFit.fill, height: 34, width: 34, package: PACKAGE_NAME),
                onTap: () {
                  _isSpeaking = !_isSpeaking;
                  if (showMore) {
                    showMore = false;
                  }
                  bottomLayoutState!(() {});
                  if (!_isSpeaking) {
                    _focusNode.requestFocus();
                  }
                }),
            Expanded(
              child: _isSpeaking
                  ? Listener(
                      onPointerSignal: (_) {},
                      onPointerDown: (event) {
                        _scroll2lastedMessage(million: 50);
                        print("chat_page _onPointerDown${event.position.dy}");
                        _touchDy = event.position.dy;
                        stateChangeController = new StreamController();
                        _isPressed = true;
                        bottomLayoutState!(() {});
                        showDialog<AudioAttachment>(
                            useSafeArea: false,
                            barrierDismissible: false,
                            context: context,
                            builder: (context) {
                              return Dialog(
                                backgroundColor: Colors.transparent,
                                insetPadding: EdgeInsets.zero,
                                child: Container(
                                  width: double.infinity,
                                  child: SoundRecordDialog(stateChangeController),
                                ),
                              );
                            }).then((value) {
                          //重置录音状态
                          recordState.resetState();
                          if (value != null) {
                            SxtMessagePlugin.sendMessage(SendMessageParam()
                              ..userCode = widget.sessionEntity.code!
                              ..sessionType = widget.sessionEntity.sessionType
                              ..attachment = value.toJson()
                              ..msgType = MsgType.VOICE_FILE);
                          }
                        });
                      },
                      child: Container(
                        margin: EdgeInsets.only(left: 4, right: 8),
                        alignment: Alignment.center,
                        constraints: BoxConstraints(minHeight: 34),
                        decoration: BoxDecoration(
                          border: Border.all(width: 1.0, color: ColorUtil.COLOR_FFEEEEEE),
                          borderRadius: const BorderRadius.all(const Radius.circular(5.0)),
                          color: _isPressed ? ColorUtil.backGroundColor : Colors.white,
                        ),
                        child: Text(
                          _isPressed ? "松开 结束" : "按住 说话",
                          style: TextStyle(fontSize: 16, color: ColorUtil.colorFF181818, fontWeight: FontWeight.w500),
                        ),
                      ),
                    )
                  : Container(
                      margin: EdgeInsets.only(left: 4, right: 8),
                      alignment: Alignment.center,
                      constraints: BoxConstraints(minHeight: Platform.isAndroid ? 34 : 38),
                      decoration: BoxDecoration(
                        border: Border.all(width: 1.0, color: ColorUtil.COLOR_FFEEEEEE),
                        borderRadius: const BorderRadius.all(const Radius.circular(5.0)),
                        color: Colors.white,
                      ),
                      child: TextField(
                        keyboardType: TextInputType.multiline,
                        maxLines: 4,
                        minLines: 1,
                        controller: editingController,
                        focusNode: _focusNode,
                        onChanged: (text) {
                          _inputText = text;
                          bottomLayoutState!(() {});
                        },
                        style: TextStyle(fontSize: 16, color: Colors.black),
                        decoration:
                            InputDecoration(isCollapsed: true, contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 6), border: InputBorder.none),
                      ),
                    ),
            ),
            Visibility(
              visible: (_inputText?.isEmpty ?? true) || !_focusNode.hasFocus,
              child: InkWell(
                  //加号
                  child: Container(
                      padding: EdgeInsets.only(bottom: 5),
                      child: Image.asset('images/ic_chat_more.png', width: 24, height: 24, fit: BoxFit.fill, package: PACKAGE_NAME)),
                  onTap: () {
                    if (_isSpeaking) {
                      _isSpeaking = !_isSpeaking;
                    }
                    print("aaaa chatpage onAddClick--showmore before:${showMore}");

                    if (showMore) {
                      showMore = false;
                      _focusNode.requestFocus();
                    } else {
                      _focusNode.unfocus();
                      showMore = true;
                    }
                    bottomLayoutState!(() {});
                    print("aaaa chatpage onAddClick --showmore:${showMore}");
                    WidgetsBinding.instance?.addPostFrameCallback((timeStamp) {
                      _scroll2lastedMessage(million: 150);
                    });
                  }),
            ),
            Visibility(
              visible: (_inputText?.isNotEmpty ?? false) && _focusNode.hasFocus,
              child: SizedBox(
                height: 33,
                child: ElevatedButton(
                  onPressed: () {
                    SxtMessagePlugin.sendMessage(SendMessageParam()
                      ..userCode = widget.sessionEntity.code!
                      ..sessionType = widget.sessionEntity.sessionType
                      ..attachment = TextAttachment(text: _inputText).toJson()
                      ..msgType = MsgType.TEXT);
                    editingController.clear();
                    _inputText = "";
                    bottomLayoutState!(() {});
                  },
                  style: ButtonStyle(
                      elevation: MaterialStateProperty.all(0),
                      padding: MaterialStateProperty.all(EdgeInsets.symmetric(horizontal: 15.0, vertical: 6.0)),
                      backgroundColor: MaterialStateProperty.resolveWith((states) {
                        return ColorUtil.COLOR_FF0F77FE;
                      })),
                  child: Text("发送"),
                ),
              ),
            ),
          ],
        ));
  }

  Widget moreLayout() {
    print("aaaa build moreLayout ");
    double screenWidth = MediaQuery.of(context).size.width;
    double spaceValue = (screenWidth - 48 - 56 * 4) / 3.0;

    return Container(
      color: ColorUtil.COLOR_FFF6F7F8,
      child: Column(
        children: [
          Divider(
            height: 0.5,
            color: ColorUtil.dividerColor,
          ),
          Container(
            // height: moreActionDrawable.length > 4 ? 191 : 144,
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            // color: ColorUtil.COLOR_FFF6F7F8,
            child: Wrap(
              spacing: spaceValue,
              runSpacing: 12,
              children: moreActionDrawable.keys.map((element) {
                return BlocBuilder<ChatBloc, ChatState>(buildWhen: (previous, current) {
                  return previous.contact != current.contact;
                }, builder: (context, state) {
                  return Container(
                    width: 56,
                    child: TextButton(
                      style: ButtonStyle(padding: MaterialStateProperty.all(EdgeInsets.zero)),
                      onPressed: () async {
                        switch (element) {
                          case PHOTO:
                            Permission.storage.request().then((value) {
                              if (value != PermissionStatus.granted) {
                                ToastUtil.showToast("需要相册权限，请先授权");
                              } else {
                                final max = 9;
                                KDAssetPicker.pickerImagesAndVideos(
                                  context,
                                  maxAssets: max,
                                ).then(
                                  (AssetResult value) async {
                                    await commitPicAndVideos(value);
                                  },
                                );
                              }
                            });
                            break;
                          case TAKE_PHOTO:
                            Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
                              return TakePicturePage(
                                widget.sessionEntity,
                              );
                            })).then((value) {});
                            break;
                          case VIDEO_CALL:
                            SxtManager.instance.isCalling().then((value) {
                              if (value) {
                                ToastUtil.showToast("正在音视频通话中...");
                              } else {
                                if (widget.sessionEntity.sessionType == SessionType.GROUP) {
                                  showVideoCallDialog(true, null, state);
                                } else {
                                  showVideoCallDialog(false, state.contact, state);
                                }
                              }
                            });
                            break;
                          case LOCATION:
                            var permissions = [Permission.location];
                            permissions.request().then((value) {
                              sendMyLocation(context);
                            });
                            break;
                          case FILE:
                            sendFiles();
                            break;
                          case PTT:
                            String chat_title = "";
                            if (widget.sessionEntity.sessionType == SessionType.GROUP) {
                              String groupName = state.group?.groupName ?? "";
                              if (groupName.length > 9) {
                                groupName = groupName.substring(0, 8) + "...";
                              }
                              chat_title = groupName;
                              if ((state.groupMemberCount ?? 0) > 0) {
                                chat_title += "(${state.groupMemberCount})";
                              }
                            } else {
                              chat_title = state.contact?.name ?? "";
                            }
                            Navigator.of(context).push(
                              CupertinoPageRoute(
                                builder: (context) => PttPage(
                                  widget.sessionEntity,
                                  chat_title,
                                ),
                              ),
                            );
                            break;
                          case POKE:
                            sendPoke();
                            break;
                        }
                      },
                      child: Column(
                        children: [
                          Image.asset(
                            moreActionDrawable[element]!,
                            width: double.infinity,
                            height: 56,
                            package: PACKAGE_NAME,
                          ),
                          SizedBox(
                            height: 7,
                          ),
                          Text(
                            element,
                            style: TextStyle(fontSize: 12, color: ColorUtil.COLOR_FF6D6D6E),
                          )
                        ],
                      ),
                    ),
                  );
                });
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  void sendMyLocation(BuildContext context) async {
    KdFlutterMapManager.getInstance().initLocationOptions(AMapLocationOption(locationInterval: 5000));
    var result = await KdFlutterMapManager.getInstance().getMyLocation(context);
    if (result != null) {
      print("获取到我的位置:$result");
      String mapImage = result["image"] as String;
      PoiBean poiBean = PoiBean.fromJson(jsonDecode(result["poi"]));

      LocationAttachment locationAttachment = LocationAttachment()
        ..name = poiBean.name
        ..address = poiBean.address
        ..latitude = double.tryParse(poiBean.wgs84_la ?? "0.0")
        ..longitude = double.tryParse(poiBean.wgs84_lo ?? "0.0")
        ..csysType = 1
        ..csysLat = double.tryParse(poiBean.la ?? "0.0")
        ..csysLon = double.tryParse(poiBean.lo ?? "0.0")
        ..path = mapImage;
      SendMessageParam param = SendMessageParam()
        ..userCode = widget.sessionEntity.code!
        ..sessionType = widget.sessionEntity.sessionType
        ..attachment = locationAttachment.toJson()
        ..msgType = MsgType.LOCATION;
      SxtMessagePlugin.sendMessage(param);
    }
  }

  void sendMessageFiles() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    if (result != null) {
      PlatformFile file = result.files.first;
      FileAttachment attachment = FileAttachment();
      attachment.path = file.path;
      attachment.size = file.size;
      attachment.filename = file.name;
      SendMessageParam param = SendMessageParam()
        ..userCode = widget.sessionEntity.code!
        ..sessionType = widget.sessionEntity.sessionType
        ..attachment = attachment.toJson()
        ..msgType = MsgType.OTHERS;
      SxtMessagePlugin.sendMessage(param);
    }
  }

  void sendFiles() async {
    if (Platform.isAndroid) {
      FlutterManager.instance.gotoFilePickPage();
    } else {
      showModalBottomSheet(
          barrierColor: ColorUtil.COLOR_33000000,
          backgroundColor: Colors.transparent,
          context: context,
          builder: (BuildContext buildContext) {
            return Container(
              child: Container(
                  height: 140 + MediaQuery.of(context).padding.bottom,
                  child: Column(
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.pop(buildContext);
                          sendMessageFiles();
                        },
                        child: Container(
                          height: 44,
                          child: Align(
                            alignment: Alignment.center,
                            child: Container(
                              padding: EdgeInsets.only(bottom: 2),
                              child: Text('本地文件', style: TextStyle(color: Colors.black, fontSize: 16)),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        height: 1,
                        color: CustomColors.cl_F5F5F5,
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.pop(buildContext);
                          Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
                            return SelectFilePage(title: "选择文件", sessionEntity: widget.sessionEntity);
                          }));
                        },
                        child: Container(
                          height: 44,
                          child: Align(
                              alignment: Alignment.center,
                              child: Container(
                                padding: EdgeInsets.only(bottom: 2),
                                child: Text('消息文件', style: TextStyle(color: Colors.black, fontSize: 16)),
                              )),
                        ),
                      ),
                      Container(
                        height: 4,
                        color: CustomColors.cl_F5F5F5,
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Container(
                          height: 46,
                          child: Align(
                            alignment: Alignment.center,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [Text('取消', style: TextStyle(color: Colors.black, fontSize: 16))],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        height: MediaQuery.of(context).padding.bottom,
                        width: MediaQuery.of(context).size.width,
                        color: Colors.white,
                      )
                    ],
                  ),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10)))),
            );
          });
    }
  }

  void sendPoke() async {
    PromptAttachment promptTAttachment = new PromptAttachment();
    promptTAttachment.content = "prompt";
    promptTAttachment.msgCatg = PromptType.POKE;
    SendMessageParam param = SendMessageParam()
      ..userCode = widget.sessionEntity.code!
      ..sessionType = widget.sessionEntity.sessionType
      ..attachment = promptTAttachment.toJson()
      ..msgType = MsgType.PROMPT;
    SxtMessagePlugin.sendMessage(param);
  }
}
