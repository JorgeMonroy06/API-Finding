import 'package:flutter/cupertino.dart';
import 'package:sxt_flutter_plugin/group/model/set_group_watch_param.dart';

@immutable
abstract class GuardianMonitorEvent {}

class GuardianMonitorInitEvent extends GuardianMonitorEvent {}

class GuardianMonitorSettingEvent extends GuardianMonitorEvent {
  final SetGroupWatchParam param;

  GuardianMonitorSettingEvent(this.param);
}
