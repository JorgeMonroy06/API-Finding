import 'dart:async';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_imagepicker_plugin/flutter_imagepicker_plugin.dart';
import 'package:flutter_sxt_ui_plugin/manager/flutter_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/video_calling_listener.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/message.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/pic_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/send_message_param.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/model/video_attachment.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';
import 'package:video_player/video_player.dart';

class TakePicturePage extends StatefulWidget {
  final SessionEntity sessionEntity;

  TakePicturePage(this.sessionEntity);

  @override
  _TakePicturePageState createState() => _TakePicturePageState();
}

class _TakePicturePageState extends State<TakePicturePage>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  ///标记是否在拍照/录像页面
  bool _isTakingPhoto = true;

  ///标记是否在录像
  bool _isFirstRecord = true;

  ///摄像头是否是背面
  bool _isBackCamera = true;
  List<CameraDescription>? cameras;
  CameraController? controller;
  CameraDescription? cameraDescription;
  XFile? imageFile;
  XFile? videoFile;
  VideoPlayerController? videoController;
  VoidCallback? videoPlayerListener;

  late AnimationController _indicatorController;
  late AnimationController _takeVideoSizeBoxController;
  late AnimationController _takePhotoSizeBoxController;

  late Animation _indicatorAnimation;
  late Animation _takeVideoAnimation;
  late Animation _takePhotoAnimation;
  double _takePhotoSize = 60.0;
  final double _takePhotoMaxSize = 60.0;
  final double _takePhotoMinSize = 30.0;

  final double _takePhotoAnimateMaxSize = 118.0;
  final double _takePhotoAnimateMinSize = 78.0;

  double _maxBoxSize = 118.0;
  double _minBoxSize = 78.0;

  double _indicatorValue = 0.0;
  DateTime? _touchTime;
  DateTime? _moveTime;
  DateTime? _upTime;
  bool isAnimating = false;

  VideoCallingListener? videoCallingListener;

  ///返回拍照
  void _backToTakePicture() {
    if (videoFile != null) {
      File(videoFile!.path).delete();
    }
    setState(() {
      _isTakingPhoto = true;
      _isFirstRecord = true;
      imageFile = null;
      videoFile = null;
      videoController?.pause();
    });
  }

  @override
  void initState() {
    super.initState();
    requestPermission().then((value) {
      if (value) {
        WidgetsBinding.instance?.addObserver(this);
        SystemChrome.setPreferredOrientations(
            [DeviceOrientation.portraitDown, DeviceOrientation.portraitUp]);

        _initAnimate();
        _camera();
      } else {
        ToastUtil.showToast("需要相机和麦克风权限，请先授权");
        Navigator.of(context).pop();
      }
    });
    videoCallingListener = VideoCallingListener(
        onStart: () {
          _releaseData();
        },
        onStop: () {});

    FlutterManager.instance.addVideoCallingListener(videoCallingListener);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.inactive) {
      _releaseData();
    }
    FlutterManager.instance.removeVideoCallingListener(videoCallingListener);
  }

  @override
  void dispose() {
    WidgetsBinding.instance?.removeObserver(this);
    super.dispose();
    controller?.dispose();
    _indicatorController.dispose();
    _takePhotoSizeBoxController.dispose();
    _takeVideoSizeBoxController.dispose();
    videoController?.pause();
    videoController?.dispose();
    SystemChrome.setPreferredOrientations([]);
  }

  Future<bool> requestPermission() async {
    if (Platform.isIOS) {
      var permissions = [Permission.microphone, Permission.camera];
      Map<Permission, PermissionStatus> map = await permissions.request();
      return map[Permission.microphone]!.isGranted &&
          map[Permission.camera]!.isGranted;
    }
    return true;
  }

  _releaseData() {
    if (_isTakingPhoto) {
      _takeVideoSizeBoxController.stop();
      _indicatorController.stop();
    }
    FlutterManager.instance.removeVideoCallingListener(videoCallingListener);
    Navigator.pop(context, false);
  }

  void _initAnimate() {
    _indicatorController = AnimationController(
      duration: const Duration(seconds: 10),
      vsync: this,
    );
    _takePhotoSizeBoxController = AnimationController(
      duration: const Duration(milliseconds: 200),
      reverseDuration: const Duration(milliseconds: 100),
      vsync: this,
    );
    _takeVideoSizeBoxController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _indicatorAnimation =
        new Tween(begin: 0.0, end: 1.0).animate(_indicatorController)
          ..addListener(() {
            setState(() => {_indicatorValue = _indicatorAnimation.value});
          })
          ..addStatusListener((status) {
            printLog("indicator status:$status");
            if (status == AnimationStatus.completed) {
              printLog(
                  "_indicatorAnimation:${status} and _isTakingPhoto:$_isTakingPhoto");

              if (_isTakingPhoto) {
                onStopVideoRecordPressed();
              }
            }
          });

    _takePhotoAnimation =
        new Tween(begin: _takePhotoMaxSize, end: _takePhotoMinSize)
            .animate(_takePhotoSizeBoxController)
          ..addListener(() {
            setState(() {
              _takePhotoSize = _takePhotoAnimation.value;
            });
          })
          ..addStatusListener((status) {
            if (status == AnimationStatus.completed) {
              _takePhotoSizeBoxController.reverse();
            }
          });
    _takeVideoAnimation = new Tween(
            begin: _takePhotoAnimateMinSize, end: _takePhotoAnimateMaxSize)
        .animate(_takeVideoSizeBoxController)
      ..addListener(() {
        setState(() {
          _minBoxSize = _takeVideoAnimation.value;
        });
      });
  }

  Future<void> _camera() async {
    WidgetsFlutterBinding.ensureInitialized();
    cameras = await availableCameras();
    if (cameras != null) {
      cameraDescription = cameras!.first;
      controller = CameraController(cameraDescription!, ResolutionPreset.medium,
          enableAudio: true, imageFormatGroup: ImageFormatGroup.yuv420);
    }
    controller?.initialize().then((_) {
      if (mounted) {
        setState(() {});
      }
    });
  }

  Future<void> _startVideoPlayer() async {
    if (videoFile == null) {
      return;
    }
    imageFile = null;
    videoController = VideoPlayerController.file(File(videoFile!.path))
      ..initialize().then((_) async {
        setState(() {});
        printLog("videoController is null: ${videoController == null}");
        await videoController?.setLooping(true);
        await videoController?.play();
      });
  }

  void onStopVideoRecordPressed() async {
    _indicatorController.stop();
    _indicatorController.reset();
    _takeVideoSizeBoxController.reset();
    isAnimating = false;
    _isTakingPhoto = false;
    setState(() {});
    XFile? file = await stopVideoRecording();
    printLog("onStopVideoRecordPressed()--state_cameraController7");
    if (file != null) {
      videoFile = file;
      printLog(
          "onStopVideoRecordPressed()--videoFile:${file.path} and time:${videoController?.value.duration.inMilliseconds}");
      _startVideoPlayer();
    } else {
      ToastUtil.showToast("录制异常，请重新录制");
      _backToTakePicture();
    }
  }

  Future<XFile?> stopVideoRecording() async {
    final CameraController? cameraController = controller;

    if (cameraController == null || !cameraController.value.isRecordingVideo) {
      return null;
    }
    try {
      XFile file = await cameraController.stopVideoRecording();
      return file;
    } on CameraException catch (e) {
      printLog(e.toString());
      return null;
    }
  }

  Future<void> startVideoRecording() async {
    _isFirstRecord = false;
    isAnimating = true;
    _indicatorController.forward();
    _takeVideoSizeBoxController.forward();
    final CameraController? cameraController = controller;
    if (cameraController == null || !cameraController.value.isInitialized) {
      // showInSnackBar('Error: select a camera first.');
      return;
    }
    if (cameraController.value.isRecordingVideo) {
      // A recording is already started, do nothing.
      return;
    }
    try {
      await cameraController.startVideoRecording();
    } on CameraException catch (e) {
      print(e.toString());
      return;
    }
  }

  Future<XFile?> takePicture() async {
    final CameraController? cameraController = controller;
    if (cameraController == null || !cameraController.value.isInitialized) {
      return null;
    }
    if (cameraController.value.isTakingPicture) {
      return null;
    }
    try {
      XFile file = await cameraController.takePicture();
      return file;
    } on CameraException catch (e) {
      print(e.toString());
      return null;
    }
  }

  ///切换摄像头
  void onNewCameraSelected(CameraDescription cameraDescription) async {
    print("onNewCameraSelected");
    // if (controller != null) {
    //   await controller!.dispose();
    // }
    final CameraController cameraController = CameraController(
        cameraDescription, ResolutionPreset.medium,
        enableAudio: true, imageFormatGroup: ImageFormatGroup.yuv420);
    controller = cameraController;

    cameraController.addListener(() {
      if (mounted)
        setState(() {
          print("state_cameraController");
        });
      if (cameraController.value.hasError) {
        print('Camera error ${cameraController.value.errorDescription}');
      }
    });

    try {
      await cameraController.initialize();
    } on CameraException catch (e) {
      print(e.toString());
    }
  }

  ///摄像头切换
  void changeCameraBack() {
    if (controller != null &&
        controller!.value.isInitialized &&
        !controller!.value.isRecordingVideo) {
      _isBackCamera = !_isBackCamera;
      onNewCameraSelected(_isBackCamera ? cameras!.first : cameras!.last);
    }
  }

  /// 拍照
  void onTakePictureButtonPressed() {
    _takePhotoSizeBoxController.forward();
    takePicture().then((XFile? file) {
      if (mounted) {
        _takePhotoSizeBoxController.reset();
        setState(() {
          imageFile = file;
          _isTakingPhoto = false;
          print("state_cameraController2");
        });
        if (file != null) {
          // showInSnackBar('Picture saved to ${file.path}');
        }
      }
    });
  }

  /// 发送
  void _sendMessage() async {
    bool isImageFile;
    VideoAttachment? videoAttachment;
    PicAttachment? picAttachment;
    if (imageFile != null) {
      isImageFile = true;
      picAttachment = new PicAttachment();
      int size = await imageFile!.length();
      picAttachment.size = size;
      picAttachment.path = imageFile!.path;
      picAttachment.filename = imageFile!.name;
    } else {
      isImageFile = false;
      videoAttachment = new VideoAttachment();
      videoAttachment.filename = (videoFile?.name);
      videoAttachment.path = (videoFile?.path);
      int size = await videoFile!.length();
      videoAttachment.size = size;
      videoAttachment.duration =
          videoController?.value.duration.inMilliseconds ?? -1;
      printLog(
          "time----------------:${videoController?.value.duration.inMilliseconds ?? -1}");
    }

    SendMessageParam sendMessageParam = new SendMessageParam()
      ..userCode = widget.sessionEntity.code
      ..sessionType = widget.sessionEntity.sessionType
      ..msgType = isImageFile ? MsgType.PICTURE : MsgType.VIDEO_FILE
      ..attachment = (isImageFile
          ? (picAttachment!.toJson())
          : (videoAttachment!.toJson()));
    SxtMessagePlugin.sendMessage(sendMessageParam);
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 55,
        backgroundColor: ColorUtil.colorFF010101,
        brightness: Brightness.dark,
        leading: Container(
          alignment: Alignment.center,
          padding: _isTakingPhoto
              ? EdgeInsets.only(left: 16)
              : EdgeInsets.only(left: 0),
          child: _isTakingPhoto
              ? Text(
                  "",
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                )
              : InkWell(
                  onTap: () {
                    _backToTakePicture();
                  },
                  child: Container(
                    alignment: Alignment.centerLeft,
                    padding: EdgeInsets.fromLTRB(15, 5, 10, 5),
                    child: Image.asset('images/ic_back.png',
                        fit: BoxFit.contain, package: PACKAGE_NAME),
                  ),
                ),
        ),
      ),
      body: Container(
        height: double.infinity,
        color: ColorUtil.colorFF181818,
        child: Stack(
          alignment: Alignment.topLeft,
          children: [
            _isTakingPhoto
                ? _cameraView()
                : Container(
                    child: _afterTake(),
                  ),
            Positioned(
                bottom: 175,
                left: 0,
                right: 0,
                child: Visibility(
                    visible: _isTakingPhoto,
                    child: Container(
                      alignment: Alignment.center,
                      child: Text(
                        "轻触拍照，按住摄像",
                        style: TextStyle(fontSize: 14, color: Colors.white),
                      ),
                    ))),
            Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  height: 55,
                  color: ColorUtil.colorFF010101,
                  alignment: Alignment.topRight,
                  padding: EdgeInsets.only(top: 12, right: 10),
                  child: Visibility(
                      visible: !_isTakingPhoto,
                      child: SizedBox(
                        height: 33,
                        width: 70,
                        child: ElevatedButton(
                          onPressed: () {
                            _sendMessage();
                          },
                          child: Text(
                            "发送",
                            style: TextStyle(fontSize: 16, color: Colors.white),
                          ),
                        ),
                      )),
                )),
            Positioned(
                bottom: 60,
                left: 0,
                right: 0,
                child: Visibility(
                  visible: _isTakingPhoto,
                  child: Container(
                    height: _takePhotoAnimateMaxSize,
                    color: Colors.transparent,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          height: _minBoxSize,
                          width: _minBoxSize,
                          decoration: BoxDecoration(
                              borderRadius:
                                  BorderRadius.circular(_minBoxSize / 2),
                              border: Border.all(
                                color: Color(0X48FFFFFF),
                                width: _minBoxSize / 2,
                              )),
                        ),
                        Listener(
                          onPointerDown: (ev) {
                            _touchTime = DateTime.now();
                            printLog("touch${ev.toString()}");
                          },
                          onPointerMove: (ev) {
                            _moveTime = DateTime.now();

                            ///持续一秒
                            if ((_moveTime!.millisecondsSinceEpoch -
                                        _touchTime!.millisecondsSinceEpoch) >
                                    500 &&
                                !isAnimating &&
                                _isTakingPhoto &&
                                _isFirstRecord) {
                              startVideoRecording();
                            }
                          },
                          onPointerUp: (ev) {
                            _upTime = DateTime.now();
                            int duration = (_upTime!.millisecondsSinceEpoch -
                                _touchTime!.millisecondsSinceEpoch);

                            ///持续一秒
                            if (duration > 500 && _isTakingPhoto) {
                              onStopVideoRecordPressed();
                            } else if (_isTakingPhoto) {
                              onTakePictureButtonPressed();
                            }
                            printLog("up${ev.toStringFull()}");
                          },
                          child: Container(
                            width: _takePhotoSize,
                            height: _takePhotoSize,
                            decoration: BoxDecoration(
                                borderRadius:
                                    BorderRadius.circular(_takePhotoSize / 2),
                                border: Border.all(
                                    color: Colors.white,
                                    width: _takePhotoSize / 2)),
                          ),
                        ),
                        Visibility(
                            visible: isAnimating,
                            child: SizedBox(
                              height: _maxBoxSize - 5,
                              width: _maxBoxSize - 5,
                              child: CircularProgressIndicator(
                                value: _indicatorValue,
                                valueColor: AlwaysStoppedAnimation(
                                    ColorUtil.color3D7DFF),
                                backgroundColor: Colors.transparent,
                                strokeWidth: 5,
                              ),
                            )),
                        Positioned(
                            left: 47,
                            child: InkWell(
                                onTap: () {
                                  Navigator.pop(context, false);
                                },
                                child: Padding(
                                  padding: EdgeInsets.all(10),
                                  child: Image.asset('images/ic_arrow_down.png',
                                      package: PACKAGE_NAME,
                                      width: 24,
                                      height: 24),
                                ))),
                        Positioned(
                            right: 45,
                            child: InkWell(
                              onTap: () {
                                changeCameraBack();
                              },
                              child: Padding(
                                padding: EdgeInsets.all(10),
                                child: Image.asset(
                                    'images/ic_change_camera.png',
                                    package: PACKAGE_NAME,
                                    width: 26,
                                    height: 26),
                              ),
                            )),
                      ],
                    ),
                  ),
                )),
          ],
        ),
      ),
    );
  }

  Widget _cameraView() {
    if (controller == null || !controller!.value.isInitialized) {
      return Container();
    } else {
      return CameraPreview(controller!);
    }
  }

  ///拍照或者录像后的页面布局
  Widget _afterTake() {
    bool video = false;
    bool image = false;
    // final VideoPlayerController? localVideoController = videoController;
    if (videoFile != null) {
      video = true;
    } else if (imageFile != null) {
      image = true;
    }
    return Container(
      color: ColorUtil.colorFF010101,
      child: _isTakingPhoto
          ? Container()
          : video
              ? VideoPlayer(videoController!)
              : image
                  ? ImagePreviewWidget(
                      url: imageFile!.path,
                      isLocal: true,
                    )
                  : Container(),
    );
  }
}
