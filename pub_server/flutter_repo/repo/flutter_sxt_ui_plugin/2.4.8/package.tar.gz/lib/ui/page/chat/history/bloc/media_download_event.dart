import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';

@immutable
abstract class MediaDownloadEvent {}

class MediaDownloadInitEvent extends MediaDownloadEvent {}

class MediaDownloadProgressEvent extends MediaDownloadEvent {
  final Message message;
  final int? progress;

  MediaDownloadProgressEvent(this.message, this.progress);
}
