part of 'select_file_bloc.dart';

@immutable
abstract class SelectFileEvent {
  const SelectFileEvent();
}

class Initial extends SelectFileEvent {
  const Initial();
}

class SelectFileSearchEvent extends SelectFileEvent {
  final String keyword;
  const SelectFileSearchEvent(this.keyword);
}

class SelectFileCheckChanged extends SelectFileEvent {
  final SelectFileModel selectFileModel;
  const SelectFileCheckChanged(this.selectFileModel);
}

class SelectSendFile extends SelectFileEvent {
  final List<SelectFileModel> list;
  const SelectSendFile(this.list);
}
