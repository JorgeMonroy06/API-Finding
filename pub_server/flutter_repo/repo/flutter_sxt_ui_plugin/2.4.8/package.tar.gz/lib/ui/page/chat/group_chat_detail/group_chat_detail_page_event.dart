part of 'group_chat_detail_page_bloc.dart';

@immutable
abstract class GroupChatDetailPageEvent {
  const GroupChatDetailPageEvent();
}

class Initial extends GroupChatDetailPageEvent {
  final String groupCode;

  const Initial(this.groupCode);
}

class Update extends GroupChatDetailPageEvent {
  final String groupCode;

  const Update(this.groupCode);
}

class PopPage extends GroupChatDetailPageEvent {
  final String message;

  const PopPage(this.message);
}

class Loading extends GroupChatDetailPageEvent {
  final String message;

  const Loading(this.message);
}

class LoadingFailed extends GroupChatDetailPageEvent {
  final String? failedMessage;

  const LoadingFailed({this.failedMessage});
}

class LoadingSuccess extends GroupChatDetailPageEvent {
  const LoadingSuccess();
}
