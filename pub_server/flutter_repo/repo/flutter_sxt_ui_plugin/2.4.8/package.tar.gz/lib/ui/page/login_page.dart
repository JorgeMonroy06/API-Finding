import 'dart:io';
import 'dart:ui';

import 'package:contact_sdk_flutter/http/http_manager.dart';
import 'package:contact_sdk_flutter/manager/contact_manager.dart';
import 'package:contact_sdk_flutter/model/contact_sdk_options.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/manager/contact_module_manager.dart';
import 'package:contact_ui_flutter/manager/contact_module_option.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/bean/server_config.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/manager/flutter_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/log/logger.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/message_free/message_free_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/message_free/message_free_event.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/strong_reminder/strong_reminder_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/conversation/ontop/ontop_conversation_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/main_home.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/list_dialog.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/loading_widget.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/prefrence_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sxt_flutter_plugin/account/model/sxt_account.dart';
import 'package:sxt_flutter_plugin/account/model/sxt_login_param.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_result_code.dart';
import 'package:sxt_flutter_plugin/model/job.dart';

class LoginPage extends StatefulWidget {
  final bool needAutoLogin;

  LoginPage({this.needAutoLogin = false});

  @override
  LoginPageState createState() => LoginPageState();
}

class LoginPageState extends State<LoginPage> {
  static const methodChannel = MethodChannel('sxt_flutter_method_channel');
  Image checkBoxImage = Image(
    image: ImageHelper.getAssetImage("checkBox_icon.png"),
    width: 22,
    height: 22,
    fit: BoxFit.contain,
  );
  TextEditingController accountTF = TextEditingController();
  TextEditingController passwordTF = TextEditingController();
  bool loginBtnEnable = false;
  bool isRememberSecrect = false;
  bool isHidenClearPassword = true;
  bool isHidenClearAccount = true;
  bool sxtInit = true;
  int clickIndex = 0;

  @override
  void initState() {
    SxtLogger.instance.info("LoginPage initState");
    requestPermission().then((value) {
      if (value) {
        //先初始化
        //再初始化账号
        initAccount().then((value) {
          setState(() {});

          if (widget.needAutoLogin) {
            //自动登录
            Future.delayed(Duration(milliseconds: 500), () {
              if (!StringUtil.isEmpty(accountTF.text) && !StringUtil.isEmpty(passwordTF.text)) {
                loginEvent(context);
              }
            });
          }
        });
      } else {
        setState(() => sxtInit = false);
      }
    });

    if (Platform.isAndroid) {
      FlutterManager.instance.requestFloatWindowPermission();
      FlutterManager.instance.requestBlessPermission();
    }

    super.initState();
  }

  Future<void> initAccount() async {
    isRememberSecrect = await PreferenceUtil.isRememberSecret();

    if (isRememberSecrect) {
      String? account = await PreferenceUtil.getAccount();
      String? pwd = await PreferenceUtil.getPwd();
      accountTF.text = account!;
      passwordTF.text = pwd!;
    }
    checkBoxImage = Image(
      image: ImageHelper.getAssetImage(isRememberSecrect ? 'checkbox_selected.png' : 'checkBox_icon.png'),
      width: 22,
      height: 22,
      fit: BoxFit.contain,
    );
    refreshLoginBtn();
  }

  Future<bool> requestPermission() async {
    if (Platform.isAndroid) {
      var permissions = [Permission.storage, Permission.camera, Permission.phone, Permission.microphone, Permission.location];
      await permissions.request();
    }
    return true;
  }

  void textFieldAccountChanged(String content) {
    isHidenClearAccount = !(content.length > 0);
    refreshLoginBtn();
    setState(() {});
  }

  void textFieldPasswordChanged(String content) {
    isHidenClearPassword = !(content.length > 0);
    refreshLoginBtn();
    setState(() {});
  }

  void refreshLoginBtn() {
    if (accountTF.text.isNotEmpty && passwordTF.text.isNotEmpty) {
      loginBtnEnable = true;
    } else {
      loginBtnEnable = false;
    }
  }

  void rememberSecrect() {
    if (isRememberSecrect) {
      checkBoxImage = Image(
        image: ImageHelper.getAssetImage('checkBox_icon.png'),
        width: 22,
        height: 22,
        fit: BoxFit.contain,
      );
    } else {
      checkBoxImage = Image(
        image: ImageHelper.getAssetImage('checkbox_selected.png'),
        width: 22,
        height: 22,
        fit: BoxFit.contain,
      );
    }
    isRememberSecrect = !isRememberSecrect;
    if (!isRememberSecrect) {
      PreferenceUtil.setRememberSecret(false);
    }

    setState(() {});
    print("记住密码");
  }

  void loginEvent(context, {isForce = false}) {
    SxtLogger.instance.info("LoginPage loginEvent start");
    if (!loginBtnEnable) return print("开始登陆");

    //Navigator.of(context).pop();
    // Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
    //   return ChatPage();
    // }));
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return LoadingWidget("登录中…");
        });
    callLogin(isForce).then((value) {
      ContactModuleOption contactModuleOption = ContactModuleOption();
      contactModuleOption.userCode = DomainUtil.toCode(value.data?.code);
      ContactModuleManager.instance.init(contactModuleOption);
      Navigator.pop(context);
      onSuccessLogin();
    }).catchError((e) {
      Navigator.pop(context);
      if (e is PlatformException) {
        handleException(e, context);
      }
    });
  }

  Future<Job<SxtAccount>> callLogin(isForce) {
    if (isForce) {
      print('强制登录');
      return SxtAccountPlugin.forceLogin(SxtLoginParam()
        ..userCode = accountTF.text
        ..password = passwordTF.text
        ..sxtServerIp = Constant.SXT_IP
        ..sxtServerPort = Constant.SXT_PORT
        ..sxtClientId = Constant.SXT_CLIENT_ID
        ..sxtClientSecret = Constant.SXT_CLIENT_SECRET
        ..sxtUseSSL = Constant.SXT_USE_SSL);
    } else {
      return SxtAccountPlugin.login(SxtLoginParam()
        ..userCode = accountTF.text
        ..password = passwordTF.text
        ..sxtServerIp = Constant.SXT_IP
        ..sxtServerPort = Constant.SXT_PORT
        ..sxtClientId = Constant.SXT_CLIENT_ID
        ..sxtClientSecret = Constant.SXT_CLIENT_SECRET
        ..sxtUseSSL = Constant.SXT_USE_SSL);
    }
  }

  void clearPassword() {
    //清除密码
    passwordTF.clear();
    isHidenClearPassword = true;
    refreshLoginBtn();
    setState(() {});
  }

  void clearAccount() {
    //清除账号
    accountTF.clear();
    print('clear');
    isHidenClearAccount = true;
    refreshLoginBtn();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).requestFocus(FocusNode());
      },
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          toolbarHeight: 0,
        ),
        body: !sxtInit
            ? const Center(child: Text('视信通初始化失败'))
            : Container(
                margin: const EdgeInsets.only(top: 80),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Stack(
                      children: [
                        Container(
                          height: 106,
                        ),
                        Positioned(
                          child: Image(image: ImageHelper.getAssetImage('login_icon.png'), width: 158, height: 45),
                          top: 0,
                          left: 40,
                        ),
                        const Positioned(
                          child: Text("登录", style: TextStyle(fontSize: 30, color: Color(0xFF333333), fontWeight: FontWeight.bold)),
                          top: 27,
                          left: 40,
                        ),
                        Positioned(
                          child: InkWell(
                              onTap: () {
                                if (clickIndex > 7) {
                                  switchIp();
                                } else {
                                  clickIndex++;
                                }
                              },
                              child: Image(image: ImageHelper.getAssetImage('defaultHeader.png'), width: 46, height: 46)),
                          top: 12,
                          right: 35,
                        ),
                      ],
                    ),
                    // SizedBox(height: 50,),
                    Row(
                      children: [
                        Container(
                          color: Colors.white,
                          width: 40,
                          height: 200,
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            LContainer("账号", "请输入您的账号", accountTF, clearAccount, textFieldAccountChanged),
                            const SizedBox(
                              height: 34,
                            ),
                            LContainer("密码", "请输入密码", passwordTF, clearPassword, textFieldPasswordChanged),
                            const SizedBox(
                              height: 23,
                            ),
                            Row(
                              children: [
                                SizedBox(
                                  // color: Colors.green,
                                  width: 22,
                                  height: 22,
                                  child: TextButton(
                                    onPressed: rememberSecrect,
                                    child: checkBoxImage,
                                    style: ButtonStyle(
                                      minimumSize: MaterialStateProperty.all(Size(22, 22)),
                                      // backgroundColor: MaterialStateProperty.all(Colors.white),
                                      padding: MaterialStateProperty.all(EdgeInsets.zero),
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 5,
                                ),
                                Text("记住密码")
                              ],
                            )
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 63,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      alignment: Alignment.center,
                      child: Container(
                        width: MediaQuery.of(context).size.width - 76,
                        height: 48,
                        decoration:
                            BoxDecoration(color: loginBtnEnable ? Color(0xFF2E6AFD) : Color(0xFFAFBACC), borderRadius: BorderRadius.all(Radius.circular(10))),
                        child: TextButton(
                          onPressed: () {
                            loginEvent(context);
                          },
                          child: const Text(
                            "登 录",
                            style: TextStyle(fontSize: 18, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        alignment: Alignment.bottomCenter,
                        child: Image(
                            image: ImageHelper.getAssetImage('loginBottom_icon.png'), fit: BoxFit.fitWidth, width: double.infinity, height: double.infinity),
                      ),
                    )
                  ],
                ),
              ),
      ),
    );
  }

  void handleException(PlatformException e, context) {
    if (e.code == SxtResultCode.ACCOUNT_LOGINED) {
      showCupertinoDialog(
          context: context,
          builder: (context) {
            return CupertinoAlertDialog(
              content: Container(
                padding: const EdgeInsets.fromLTRB(0, 20, 0, 16),
                child: const Text(
                  '已登录，是否强制登录？',
                  style: TextStyle(color: ColorUtil.color333333, fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
              actions: <Widget>[
                CupertinoDialogAction(
                  child: Text(
                    '取消',
                    style: TextStyle(fontSize: 16, color: ColorUtil.colorFF666666),
                  ),
                  onPressed: () {
                    Navigator.of(context).pop(false);
                  },
                ),
                CupertinoDialogAction(
                  child: Text('确认', style: TextStyle(fontSize: 16, color: ColorUtil.COLOR_FF1677FF)),
                  onPressed: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              ],
            );
          }).then((value) {
        if (value) {
          loginEvent(context, isForce: true);
        }
      });
    } else if (e.code == SxtResultCode.ACCOUNT_ALREADY_ONLINE) {
      onSuccessLogin();
    } else if (e.code == SxtResultCode.ILLEGAL_LOGIN_STATE) {
      ToastUtil.showToast("登录失败：${e.message}");
    } else if (e.code == SxtResultCode.ACCOUNT_HAD_CHANGE) {
      SxtAccountPlugin.logoutAndClear().then((value) {});
      ToastUtil.showToast("登录失败，账号信息发生变化，请重新登录!");
    } else {
      ToastUtil.showToast("登录失败：${e.message}");
    }
  }

  void onSuccessLogin() {
    if (isRememberSecrect) {
      PreferenceUtil.setRememberSecret(true);
    }
    PreferenceUtil.setAccount(accountTF.text);
    PreferenceUtil.setPwd(passwordTF.text);
    _initGlobalBloc();
    // ignore: unnecessary_null_comparison
    Navigator.of(context).pushAndRemoveUntil(
        new CupertinoPageRoute(builder: (context) => MainPage(), settings: RouteSettings(name: '/MainPage', arguments: Map())), (route) => route == null);
  }

  void _initGlobalBloc() {
    context.read<MessageFreeBloc>().add(MessageFreeInitEvent());
    context.read<OnTopConversationBloc>().add(OnTopConversationInitEvent());
    context.read<StrongReminderBloc>().add(StrongReminderInitEvent());
  }

  void switchIp() {
    clickIndex = 0;
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => ListDialog(
              ["昆仑", "177环境", "新区test环境", "园区test环境"],
            )).then((value) {
      ServerConfig serverConfig = ServerConfig();
      switch (value) {
        case 0:
          serverConfig.sxtIp = "47.100.250.39";
          serverConfig.sxtPort = "39900";
          serverConfig.sxtClientId = "";
          serverConfig.sxtClientSecret = "";
          serverConfig.sxtUseSsl = false;
          serverConfig.contactClientId = "xingchen";
          serverConfig.contactClientSecret = "J85905";
          serverConfig.contactBaseUrl = "http://bestkunlun.com";
          break;
        case 1:
          serverConfig.sxtIp = "172.16.249.177";
          serverConfig.sxtPort = "9900";
          serverConfig.sxtClientId = "";
          serverConfig.sxtClientSecret = "";
          serverConfig.sxtUseSsl = false;
          serverConfig.contactClientId = "xingchen";
          serverConfig.contactClientSecret = "5eSLvh";
          serverConfig.contactBaseUrl = "http://dolphin-dev.kedacom.com";
          break;
        case 2:
          serverConfig.sxtIp = "10.65.5.214";
          serverConfig.sxtPort = "59443";
          serverConfig.sxtClientId = "";
          serverConfig.sxtClientSecret = "";
          serverConfig.sxtUseSsl = true;
          serverConfig.contactClientId = "xingchen";
          serverConfig.contactClientSecret = "y479XI";
          serverConfig.contactBaseUrl = "http://dispatch.testdolphin.com";
          break;
        case 3:
          serverConfig.sxtIp = "dispatch.testdolphin.com";
          serverConfig.sxtPort = "59443";
          serverConfig.sxtClientId = "";
          serverConfig.sxtClientSecret = "";
          serverConfig.sxtUseSsl = true;
          serverConfig.contactClientId = "xingchen";
          serverConfig.contactClientSecret = "y479XI";
          serverConfig.contactBaseUrl = "http://dispatch.testdolphin.com";
          break;
      }

      Constant.SXT_IP = serverConfig.sxtIp;
      Constant.SXT_PORT = serverConfig.sxtPort;
      Constant.SXT_CLIENT_ID = serverConfig.sxtClientId;
      Constant.SXT_CLIENT_SECRET = serverConfig.sxtClientSecret;
      Constant.SXT_USE_SSL = serverConfig.sxtUseSsl;
      Constant.CONTACT_CLIENT_ID = serverConfig.contactClientId;
      Constant.CONTACT_CLIENT_SECRET = serverConfig.contactClientSecret;
      Constant.CONTACT_BASE_URL = serverConfig.contactBaseUrl;

      HttpManager.instance.release();

      ContactSDKOptions contactSDKOptions = ContactSDKOptions();
      contactSDKOptions.clientSecret = Constant.CONTACT_CLIENT_SECRET;
      contactSDKOptions.clientId = Constant.CONTACT_CLIENT_ID;
      contactSDKOptions.baseUrl = Constant.CONTACT_BASE_URL;
      ContactManager.instance.init(contactSDKOptions);
    });
  }
}

class LContainer extends StatefulWidget {
  TextEditingController tfvc;
  String title;
  String hintText;
  bool hasFocus = false;
  Function clearFunction;
  Function changeFunction;
  StateSetter? stateSetter;

  LContainer(this.title, this.hintText, this.tfvc, this.clearFunction, this.changeFunction);

  @override
  LContainerState createState() => new LContainerState(this.title, this.hintText, this.tfvc, this.clearFunction, this.changeFunction);
}

class LContainerState extends State<LContainer> {
  FocusNode _focusNode = new FocusNode();

  TextEditingController tfvc;
  String title;
  String hintText;
  bool hasFocus = false;
  Function clearFunction;
  Function changeFunction;
  StateSetter? stateSetter;

  LContainerState(this.title, this.hintText, this.tfvc, this.clearFunction, this.changeFunction);

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(_focusNodeListener); // 初始化一个listener
  }

  @override
  void dispose() {
    _focusNode.removeListener(_focusNodeListener); // 页面消失时必须取消这个listener！！
    super.dispose();
  }

  Future<Null> _focusNodeListener() async {
    // 用async的方式实现这个listener
    if (_focusNode.hasFocus) {
      print("aaaa title :$title _focusNode.hasFocus : ${_focusNode.hasFocus}");
    } else {
      print("aaaa title :$title _focusNode.hasFocus : ${_focusNode.hasFocus}");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: TextStyle(fontSize: 16, color: Color(0xFF333333), fontWeight: FontWeight.w500)),
        Container(
            width: MediaQuery.of(context).size.width - 80,
            height: 40,
            child: Focus(
              onFocusChange: (hasFocus) {
                print("aaaa title :${title} hasFocus : ${hasFocus}");
                this.hasFocus = hasFocus;
                stateSetter!(() {});
              },
              child: TextField(
                focusNode: _focusNode,
                // keyboardType: TextInputType.number,
                // cursorHeight: 30,
                obscureText: hintText.contains("密码"),
                controller: tfvc,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.fromLTRB(0, 5, 0, 5),
                  hintText: hintText,
                  hintStyle: TextStyle(color: Color(0xFFB4BBC2), fontSize: 14, fontWeight: FontWeight.w400),
                  suffixIcon: GestureDetector(
                    child: Container(
                        padding: EdgeInsets.only(top: 4, bottom: 8, left: 22),
                        child: StatefulBuilder(
                          builder: (context, setState) {
                            stateSetter = setState;
                            print("aaaa title :$title _focusNode.hasFocus : ${_focusNode.hasFocus}");
                            print("aaaa title :$title hasFocus : $hasFocus");
                            print("aaaa title :$title  tfvc.text.isNotEmpty : ${tfvc.text.isNotEmpty}");

                            return Visibility(
                              visible: hasFocus && tfvc.text.isNotEmpty, //这里控制 true  false 布尔值
                              child: ImageHelper.assetImage('clear.png'),
                            );
                          },
                        )),
                    onTap: () => clearFunction(),
                  ),
                  enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFFC6D2DE))),
                  focusedBorder: new UnderlineInputBorder(
                    // 焦点集中的时候颜色
                    borderSide: BorderSide(color: Color(0xFFC6D2DE)),
                  ),
                ),
                onChanged: (value) => changeFunction(value),
                autofocus: false,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
              ),
            )),
      ],
    );
  }
}
