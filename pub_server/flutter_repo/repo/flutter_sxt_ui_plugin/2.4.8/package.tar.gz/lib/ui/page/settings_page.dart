import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_sxt_ui_plugin/manager/flutter_manager.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: BackgroundImageAppbar(
          title: "设置",
          leadingWidget: Container(
            padding: EdgeInsets.only(left: 12, right: 16, top: 8, bottom: 8),
            child: InkWell(
              child: ImageHelper.assetImage(
                "ic_back.png",
              ),
              onTap: () {
                Navigator.pop(context);
              },
            ),
          ),
        ),
        body: Container(
          child: Column(
            children: [
              SizedBox(
                height: 10,
              ),
              Platform.isAndroid
                  ? InkWell(
                      onTap: () {
                        FlutterManager.instance.gotoPermissionGuidePage();
                      },
                      child: Container(
                        padding: EdgeInsets.only(left: 18),
                        height: 54,
                        color: Colors.white,
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                "权限设置",
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Color(0xff333333),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                right: 7,
                              ),
                              child: Image.asset(
                                'images/icon_arrow_go.png',
                                width: 24,
                                height: 24,
                                package: PACKAGE_NAME,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  : Container(),
            ],
          ),
        ));
  }
}
