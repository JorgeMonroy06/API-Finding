import 'package:flutter/cupertino.dart';

class SwitchItem extends StatelessWidget {
  const SwitchItem({
    Key? key,
    required this.title,
    required this.value,
    this.content,
    this.onChanged,
  }) : super(key: key);

  final String title;
  final bool value;
  final String? content;
  final ValueChanged<bool>? onChanged;

  @override
  Widget build(BuildContext context) => Container(
        height: content == null ? 56 : 76,
        color: CupertinoColors.white,
        child: Row(
          children: [
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Color(0xFF131D27),
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  if (content != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      content!,
                      style: const TextStyle(
                        color: Color(0xFF999999),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(width: 14),
            CupertinoSwitch(
              activeColor: CupertinoColors.activeBlue,
              value: value,
              onChanged: onChanged,
            ),
            const SizedBox(width: 12),
          ],
        ),
      );
}
