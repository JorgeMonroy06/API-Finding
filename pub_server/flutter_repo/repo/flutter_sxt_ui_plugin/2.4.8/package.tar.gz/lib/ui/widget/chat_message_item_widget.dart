import 'dart:io';

import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_swipe_action_cell/flutter_swipe_action_cell.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/image_text_widget.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/ios_invite_group_widget.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/net_image.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/date_time_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/group_image_stream_controller.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/ios_message_stream_controller.dart';
import 'package:flutter_sxt_ui_plugin/utils/message_stream_controller.dart';
import 'package:flutter_sxt_ui_plugin/utils/sxt_status_listener.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/conversation.dart';
import 'package:sxt_flutter_plugin/message/model/send_state.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';
import 'package:sxt_flutter_plugin/message/model/set_conv_unread_count_param.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';

typedef ItemOperationListener = Function(
    Conversation coversation, int opreation);
typedef ItemClickListener = Function(
  Conversation coversation,
  int index,
);

class ChatMessageItemWidget extends StatefulWidget {
  final Conversation item;
  final int index;
  final ItemOperationListener operationListener;
  final ItemClickListener? itemClickListener;

  // final Key key;
  // final SlidableController? slidAbleController;
  final SwipeActionController? slidAbleController;

  ChatMessageItemWidget({
    required this.item,
    required this.index,
    required this.operationListener,
    this.itemClickListener,
    this.slidAbleController,
  });

  @override
  _ChatMessageItemWidgetState createState() => _ChatMessageItemWidgetState();
}

class _ChatMessageItemWidgetState extends State<ChatMessageItemWidget> {
  //点击事件
  String? url;
  String? filePath;

  String titleContent = "";

  Contact? senderContact;

  String scrollRead = ""; //标为已读

  String scrollTop = "";
  Contact? currentLoginUser;

  Group? _groupInfo;
  bool _isTop = false;

  @override
  void initState() {
    super.initState();
    _refresh();
    MessageStreamController.getInstance()
        .streamController
        .stream
        .listen((event) {
      Future.delayed(Duration(milliseconds: 300), _refresh);
    });
    GroupImageStreamController.getInstance()
        .streamController
        .stream
        .listen((event) {
      Future.delayed(Duration(milliseconds: 200), _refreshGroupImage(event));
    });
  }

  _itemClick() {
    if (widget.itemClickListener != null) {
      widget.itemClickListener!(widget.item, widget.index);
    }
  }

  _operation(int operation) async {
    switch (operation) {
      case 1: //标为已读
        bool read;
        if (scrollRead == "标为已读") {
          read = true;
        } else {
          read = false;
        }
        await _setMessageRead(widget.item, read);
        widget.operationListener(
          widget.item,
          operation,
        );
        break;
      case 2:
        if (scrollTop == "置顶") {
          if (widget.item.convCode == null) {
            ToastUtil.showToast("会话列表id为空，无法置顶");
          }
          await StatusChangeLister.setTopMessage(widget.item.convCode!);
        } else {
          await StatusChangeLister.removeTopMessage(widget.item.convCode!);
        }
        widget.operationListener(
          widget.item,
          operation,
        );
        break;
      case 3:
        setState(() {
          widget.operationListener(
            widget.item,
            operation,
          );
        });
        // showCupertinoDialog(
        //     context: context,
        //     builder: (context) {
        //       return CupertinoAlertDialog(
        //         content: Container(
        //           padding: EdgeInsets.fromLTRB(0, 20, 0, 16),
        //           child: Text(
        //             '删除后，将清空该聊天的消息记录',
        //             style: TextStyle(color: ColorUtil.color333333, fontWeight: FontWeight.w600, fontSize: 15),
        //           ),
        //         ),
        //         actions: <Widget>[
        //           CupertinoDialogAction(
        //             child: Text(
        //               '取消',
        //               style: TextStyle(fontSize: 16, color: ColorUtil.colorFF666666),
        //             ),
        //             onPressed: () {
        //               Navigator.of(context).pop(false);
        //             },
        //           ),
        //           CupertinoDialogAction(
        //             child: Text('删除', style: TextStyle(fontSize: 16, color: ColorUtil.colorFFD74A49)),
        //             onPressed: () {
        //               Navigator.of(context).pop(true);
        //             },
        //           ),
        //         ],
        //       );
        //     }).then((value) {
        //   if (value) {
        //     widget.operationListener(
        //       widget.item,
        //       operation,
        //     );
        //   }
        // });
        break;
    }
  }

  _setMessageRead(Conversation bean, bool alreadyRead) async {
    SetConvUnreadCountParam param =
        new SetConvUnreadCountParam(sessionEnitity: bean.talker);
    if (alreadyRead) {
      param.count = 0;
    } else {
      param.count = 1;
    }
    SxtMessagePlugin.setConvUnreadCount(param);
  }

  _refresh() async {
    currentLoginUser = await StatusChangeLister.getCurrentLoginUser();
    filePath = null;
    url = null;
    initData(widget.item);
    _setScrollData();
  }

  _setScrollData() async {
    StatusChangeLister.isTopMessage(widget.item.convCode ?? "").then((value) {
      if (mounted) {
        setState(() {
          scrollTop = value ? "取消置顶" : "置顶";
          scrollRead = ((widget.item.unReadCount ?? 0) > 0) ? "标为已读" : "标为未读";
        });
      }
    });
  }

  initData(Conversation bean) {
    int sessionType = bean.talker!.sessionType!;
    StatusChangeLister.isTopMessage(bean.convCode!).then((value) {
      if (mounted)
        setState(() {
          _isTop = value;
        });
    });
    if (sessionType == SessionType.GROUP) {
      if (Platform.isIOS) {
        if (null != bean.memberList && bean.memberList!.isNotEmpty) {
          IosMessageStreamController.getInstance().streamController.add(0);
        }
      }
      SxtGroupPlugin.getGroupInfo(bean.talker!.code!).then((value) {
        _groupInfo = value.data;
        if (mounted) {
          setState(() {
            titleContent = value.data?.groupName ?? "";
          });
        }
        if (value.data!.avatarThumbState != SendState.SUCCESS) {
          SxtGroupPlugin.downloadGroupThumbAvatar(bean.talker!.code!);
        } else {
          //缩略图
          if (mounted)
            setState(() {
              filePath = value.data?.avatarThumbPath;
            });
        }
      });
    } else if (sessionType == SessionType.USER) {
      String talkerCode = DomainUtil.toCode(bean.talker!.code);
      DataManager.instance.getContact(talkerCode).then((value) {
        if (value == null) return;
        if (mounted) {
          setState(() {
            Contact talkerContact = value;
            titleContent = talkerContact.name ?? "";
            url = StringUtil.getAvatarUrl(talkerContact);
          });
        }
      });
    }
    if (bean.sender != null) {
      String senderCode = DomainUtil.toCode(bean.sender!.code);
      if (!StringUtil.isEmpty(senderCode)) {
        DataManager.instance.getContact(senderCode).then((value) {
          if (value == null) return;
          if (mounted) {
            setState(() {
              senderContact = value;
            });
          }
        });
      }
    }
  }

  _refreshGroupImage(Group group) {
    int sessionType = widget.item.talker!.sessionType!;
    if (sessionType == SessionType.GROUP &&
        group.groupCode == _groupInfo?.groupCode) {
      if (mounted) {
        setState(() {
          filePath = group.avatarThumbPath;
        });
      }
    }
  }

  ///未读数
  String _getUnReadCount() {
    if (widget.item.unReadCount != null) {
      int count = widget.item.unReadCount!;
      if (count > 0 && count < 100) {
        return "$count";
      } else if (count >= 100) {
        return "99+";
      } else {
        return "";
      }
    }
    return "";
  }

  @override
  Widget build(BuildContext context) {
    return SwipeActionCell(
      controller: widget.slidAbleController,
      index: widget.index,
      key: ValueKey(widget.index),
      fullSwipeFactor: 0.185 * 3,

      ///animation default value below...
      normalAnimationDuration: 500,
      deleteAnimationDuration: 400,
      performsFirstActionWithFullSwipe: false,
      trailingActions: [
        SwipeAction(
            nestedAction: SwipeNestedAction(title: "移除该聊天"),
            title: "移除",
            color: ColorUtil.colorFFEE4A37,
            style: TextStyle(
                fontSize: 14, color: Colors.white, fontWeight: FontWeight.w500),
            onTap: (handler) {
              // await handler(true);
              _operation(3);
              widget.slidAbleController?.closeAllOpenCell();
            }),
        SwipeAction(
            title: "$scrollTop",
            color: ColorUtil.colorFF0F77FE,
            style: TextStyle(
                fontSize: 14, color: Colors.white, fontWeight: FontWeight.w500),
            onTap: (handler) {
              _operation(2);
              widget.slidAbleController?.closeAllOpenCell();
            }),
        SwipeAction(
            color: ColorUtil.colorFFA2A3A7,
            title: "$scrollRead",
            style: TextStyle(
                fontSize: 14, color: Colors.white, fontWeight: FontWeight.w500),
            onTap: (handler) async {
              // await handler(true);
              _operation(1);
              widget.slidAbleController?.closeAllOpenCell();
              // list.removeAt(index);
              // setState(() {});
            }),
      ],
      child: InkWell(
        onTap: () {
          _itemClick();
        },
        onLongPress: () {
          widget.slidAbleController
              ?.openCellAt(index: widget.index, trailing: true);
        },
        child: Stack(
          alignment: Alignment.center,
          children: [
            Container(
                height: 68,
                alignment: Alignment.topLeft,
                padding: Platform.isAndroid
                    ? EdgeInsets.fromLTRB(15, 4, 15, 9)
                    : EdgeInsets.fromLTRB(15, 4, 15, 5),
                color: _isTop ? ColorUtil.colorF7F7F7 : Colors.white,
                child: Row(
                  children: [
                    _imageWidget(),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.only(top: 8, bottom: 3),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    "$titleContent",
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        fontSize: 16,
                                        color: ColorUtil.color333333,
                                        fontWeight: FontWeight.w500),
                                  ),
                                ),
                                Text(
                                  DateTimeUtil.formatMessageTime(
                                      widget.item.receiverTime ?? 0),
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontSize: 13, color: Color(0xFFBCBCBE)),
                                )
                              ],
                            ),
                            _contentWidget(widget.item)
                          ],
                        ),
                      ),
                    )
                  ],
                )),
            Positioned.fill(
              left: 75,
              top: 67,
              child: Container(
                child: Divider(
                  height: 1,
                  color: ColorUtil.dividerColor,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  ///左边头像
  Widget _imageWidget() {
    //SessionType,确定类型，如果是群消息用的群头像，下载群组头像接口；
    return Container(
      width: 55,
      margin: EdgeInsets.only(right: 5),
      child: Stack(
        children: [
          Positioned(
              top: 6,
              child: Container(
                width: 48,
                height: 48,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: NetFileImage(
                    widget.item.talker?.sessionType == SessionType.GROUP
                        ? 'images/icon_group_placeholder.png'
                        : 'images/icon_person_placeholder.png',
                    url: url,
                    filePath: filePath,
                    height: 48,
                    width: 48,
                    fit: BoxFit.fill,
                  ),
                ),
              )),
          Positioned(
              top: 0,
              right: 0,
              child: _getUnReadCount().isEmpty
                  ? Container()
                  : Container(
                      alignment: Alignment.center,
                      padding: EdgeInsets.symmetric(horizontal: 4),
                      height: 16,
                      constraints: BoxConstraints(minWidth: 16),
                      decoration: BoxDecoration(
                          color: ColorUtil.colorFF85152,
                          borderRadius: BorderRadius.all(Radius.circular(8))),
                      child: Text(
                        _getUnReadCount(),
                        style: TextStyle(fontSize: 12, color: Colors.white),
                      ),
                    )),
        ],
      ),
    );
  }

  /// 消息内容
  /// 消息分类: fas
  Widget _contentWidget(Conversation conversation) {
    bool isGroup = conversation.talker?.sessionType == SessionType.GROUP;
    if (conversation.content != null &&
        conversation.content!.startsWith("\n")) {
      conversation.content = conversation.content!.replaceRange(0, 1, "");
    }
    //1是否是群消息
    Widget child;
    if (isGroup) {
      if (Platform.isIOS) {
        if (null != conversation.memberList &&
            conversation.memberList!.isNotEmpty) {
          return InviteGroupForIos(conversation);
        }
      }
      String content;
      if (senderContact == null) {
        content = "${conversation.content ?? ""}";
      } else {
        if (senderContact!.name == null) {
          content = "${conversation.content ?? ""}";
        } else {
          content = "${senderContact!.name}:${conversation.content ?? ""}";
        }
      }
      child = RichText(
          overflow: TextOverflow.ellipsis,
          maxLines: 1,
          text: TextSpan(
              text: conversation.isMention ?? false ? '[有人@我] ' : "",
              style: TextStyle(fontSize: 13, color: ColorUtil.colorFF85152),
              children: <TextSpan>[
                TextSpan(
                    text: content,
                    style: TextStyle(
                      fontSize: 13,
                      color: ColorUtil.color999999,
                    )),
              ]));
    } else {
      bool senderIsLoginUser = DomainUtil.toCode(conversation.sender?.code) ==
          currentLoginUser?.code;
      if (senderIsLoginUser && conversation.lastMsgSendStatus != null) {
        switch (conversation.lastMsgSendStatus) {
          case SendState.FAILURE:
            child = ImageTextWidget(
              Text('消息发送失败',
                  style: TextStyle(fontSize: 13, color: ColorUtil.color999999)),
              Image.asset(
                'images/ic_chat_send_failed.png',
                package: PACKAGE_NAME,
                width: 13,
                height: 13,
              ),
              alignment: Alignment.centerLeft,
              drawablePadding: 4,
            );
            break;
          case SendState.SENDING:
            child = ImageTextWidget(
              Text('${conversation.content ?? ""}',
                  style: TextStyle(fontSize: 13, color: ColorUtil.color999999)),
              Image.asset('images/icon_message_sending.png',
                  package: PACKAGE_NAME, width: 13, height: 13),
              alignment: Alignment.centerLeft,
              drawablePadding: 4,
            );
            break;
          default:
            child = Text(
              conversation.content ?? "",
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 13, color: ColorUtil.color999999),
            );
            break;
        }
      } else {
        child = Text(
          conversation.content ?? "",
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(fontSize: 13, color: ColorUtil.color999999),
        );
      }
    }
    //2 是否是我本人发送的
    return Container(
      child: child,
    );
  }
}
