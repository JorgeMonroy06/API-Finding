import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:meta/meta.dart';
import 'dart:io';
import 'package:sxt_flutter_plugin/account/model/sxt_account.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/file_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/file_model.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/send_message_param.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';
import 'package:sxt_flutter_plugin/model/job.dart';
part 'select_file_event.dart';
part 'select_file_state.dart';

class SelectFileBloc extends Bloc<SelectFileEvent, SelectFileState> {
  List<String>? fileCodeList;
  List<String>? selectFileCodeList;
  final SessionEntity sessionEntity;
  SelectFileBloc(this.fileCodeList, this.selectFileCodeList, this.sessionEntity)
      : super(SelectFileState());

  @override
  Stream<SelectFileState> mapEventToState(
    SelectFileEvent event,
  ) async* {
    if (event is Initial) {
      yield* initial(event);
    } else if (event is SelectFileCheckChanged) {
      yield* recombinationSelectFileList(event);
    } else if (event is SelectFileSearchEvent) {
      yield* searchFile(event);
    } else if (event is SelectSendFile) {
      yield* sendFileMsg(event);
    }
  }

  void inital() {
    add(Initial());
  }

  Stream<SelectFileState> sendFileMsg(SelectSendFile event) async* {
    for (SelectFileModel fileModel in event.list) {
      String path = fileModel.fileModel!.path ?? "";
      File file = File(path);
      var filename = path.split("/").last;
      if (file.existsSync()) {
        FileAttachment attachment = FileAttachment();
        attachment.path = file.path;
        attachment.size = fileModel.fileModel!.size ?? 0;
        attachment.filename = filename;
        SendMessageParam param = SendMessageParam()
          ..userCode = sessionEntity.code
          ..sessionType = sessionEntity.sessionType
          ..attachment = attachment.toJson()
          ..msgType = MsgType.OTHERS;
        SxtMessagePlugin.sendMessage(param);
      }
    }
    yield state.clone();
  }

  Stream<SelectFileState> initial(Initial event) async* {
    yield state.init()
      ..fileModelList = await getFileModelList("") as List<SelectFileModel>;
  }

  Stream<SelectFileState> searchFile(SelectFileSearchEvent event) async* {
    yield state.init()
      ..fileModelList =
          await getFileModelList(event.keyword) as List<SelectFileModel>;
  }

  Future getFileModelList(String keyWord) async {
    Job<List<FileModel>> job = await SxtMessagePlugin.getFileDesc("");
    List<SelectFileModel> list = [];
    for (FileModel model in job.data!) {
      SelectFileModel fileModel =
          SelectFileModel(isChecked: false, fileModel: model);
      SxtAccount currentAccount = await SxtAccountPlugin.getCurrentUser();
      String code = DomainUtil.toCode(currentAccount.code);
      if (fileModel.fileModel!.sender!.sessionType == SessionType.USER) {
        String senderCode =
            DomainUtil.toCode(fileModel.fileModel!.sender!.code);
        if (code == senderCode) {
          //显示发给talker
          //获取联系人信息
          final contact = await DataManager.instance
              .getContact(fileModel.fileModel!.talker!.code!);
          fileModel.detailStr = "发给${contact!.name}";
        } else {
          //显示来自sender
          final contact = await DataManager.instance
              .getContact(fileModel.fileModel!.sender!.code!);
          fileModel.detailStr = "来自${contact!.name}";
        }
      } else {
        //显示来自talker
        Job<Group> job = await SxtGroupPlugin.getGroupInfo(
            fileModel.fileModel!.talker!.code!);
        fileModel.detailStr = job.data!.groupName;
      }
      list.add(fileModel);
    }
    Future future = Future(() {
      return list;
    });
    return future;
  }

  Stream<SelectFileState> recombinationSelectFileList(
      SelectFileCheckChanged event) async* {
    // Job<List<FileModel>> job = await SxtMessagePlugin.getFileDesc("");
    // yield state.init()..fileModelList = job.data!..hasMoreMessage = job.data?.length == 20;
    List<SelectFileModel> selectFileList = [];
    for (SelectFileModel model in state.fileModelList!) {
      if (event.selectFileModel.fileModel!.code == model.fileModel!.code) {
        model.isChecked = event.selectFileModel.isChecked;
      }
      if (model.isChecked ?? false) {
        selectFileList.add(model);
      }
    }
    yield state.clone()..selectfileModelList = selectFileList;
  }
}
