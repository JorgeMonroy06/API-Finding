import 'dart:io';

import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/ui/contact_child/contact_child_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_imagepicker_plugin/flutter_imagepicker_plugin.dart';
import 'package:flutter_sxt_ui_plugin/manager/app_manager.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/favourite/favourite_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/settings_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/net_image.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/sxt_status_listener.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_manager.dart';
import 'package:sxt_flutter_plugin/message/model/file_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/send_message_param.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';

import 'login_page.dart';

///我的
class MinePage extends StatefulWidget {
  @override
  _MinePageState createState() => _MinePageState();
}

class _MinePageState extends State<MinePage> {
  Contact? contact;
  String? version;

  @override
  void initState() {
    super.initState();
    _getUserInfo();
  }

  _getUserInfo() async {
    contact = await StatusChangeLister.getCurrentLoginUser();
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    version = "V " + packageInfo.version;
    setState(() {});
  }

  ///退出登录
  void _loginOut() {
    showCupertinoDialog(
        context: context,
        builder: (context) {
          return CupertinoAlertDialog(
            content: Container(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 16),
              child: Text(
                '确认退出？',
                style: TextStyle(color: ColorUtil.color333333, fontWeight: FontWeight.w600, fontSize: 15),
              ),
            ),
            actions: <Widget>[
              CupertinoDialogAction(
                child: Text(
                  '取消',
                  style: TextStyle(fontSize: 16, color: ColorUtil.colorFF666666),
                ),
                onPressed: () {
                  Navigator.of(context).pop(false);
                },
              ),
              CupertinoDialogAction(
                child: Text('确定', style: TextStyle(fontSize: 16, color: ColorUtil.colorFFD74A49)),
                onPressed: () {
                  Navigator.of(context).pop(true);
                },
              ),
            ],
          );
        }).then((value) {
      if (value) {
        StatusChangeLister.setCurrentLoginUser(null);

        SxtAccountPlugin.logout().then((value) {}).onError((error, stackTrace) {
          print(error);
        });

        StatusChangeLister.getJobId().forEach((element) {
          SxtManager.instance.cancelJob(element);
        });
        StatusChangeLister.removeAllJobId();
        _clearMessageToast();
        Navigator.of(context).pushAndRemoveUntil(
            new CupertinoPageRoute(
              builder: (context) => LoginPage(),
            ),
            (route) => false);
        // FlutterLocalNotificationsPlugin().cancelAll();
        AppManager.instance.clear();
      }
    });
  }

  _clearMessageToast() async {
    // FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    //     new FlutterLocalNotificationsPlugin();
    // await flutterLocalNotificationsPlugin.cancelAll();
  }

  @override
  Widget build(BuildContext context) {
    final avator = StringUtil.getAvatarUrl(contact ?? Contact());
    return Scaffold(
      appBar: BackgroundImageAppbar(
        title: "个人中心",
      ),
      backgroundColor: ColorUtil.backGroundColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 82,
              padding: EdgeInsets.all(14),
              margin: EdgeInsets.only(bottom: 10),
              color: Colors.white,
              child: Row(
                children: [
                  GestureDetector(
                    onDoubleTap: () {
                      SxtMessagePlugin.getLogListDesc().then((value) {
                        for (String path in value.data!) {
                          File file = File(path);
                          var filename = path.split("/").last;
                          if (file.existsSync()) {
                            FileAttachment attachment = FileAttachment();
                            attachment.path = file.path;
                            attachment.size = file.lengthSync();
                            attachment.filename = filename;
                            SendMessageParam param = SendMessageParam()
                              ..userCode = "KD017893@320500"
                              ..sessionType = 2
                              ..attachment = attachment.toJson()
                              ..msgType = MsgType.OTHERS;
                            SxtMessagePlugin.sendMessage(param);
                          }
                        }
                        // setState(() {});
                      }, onError: (e, stackTrace) {
                        if (e is PlatformException) {
                          print("获取日志失败  errorCode：${e.code} ,message: ${e.message} , detail: ${e.details.toString()}");
                        }
                        print(stackTrace);
                      });
                    },
                    onTap: () {
                      if (avator.isNotEmpty) {
                        KDAssetPicker.playImage(context, avator);
                        setState(() {});
                      }
                    },
                    child: Container(
                        child: NetFileImage('images/icon_person_placeholder.png', filePath: null, url: avator, height: 54, width: 54, fit: BoxFit.fill),
                        padding: const EdgeInsets.all(0),
                        decoration: new BoxDecoration(
                          //背景
                          borderRadius: BorderRadius.all(Radius.circular(0)),
                        )),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 14),
                    child: Text(contact?.name ?? "", style: TextStyle(fontSize: 18, color: ColorUtil.color333333, fontWeight: FontWeight.w600)),
                  )
                ],
              ),
            ),
            _itemWidget(1, "手机", contact?.telNo ?? ""),
            _divider(),
            _itemWidget(2, "座机", contact?.fixedNo ?? ""),
            _divider(),
            _itemWidget(3, "邮箱", contact?.email ?? ""),
            _divider(),
            InkWell(
              onTap: () {
                Org org = Org();
                org.code = contact?.pcode;
                org.name = contact?.deptId_name;

                Navigator.push(context, new CupertinoPageRoute(builder: (context) {
                  return ContactChildPage(org);
                }));
              },
              child: _itemWidget(
                4,
                "部门",
                contact?.deptId_name ?? "",
                secondContent: contact?.deptId_name ?? "",
              ),
            ),
            SizedBox(
              height: 10,
            ),
            GestureDetector(
              onTap: () {
                Navigator.of(context).push(
                  new CupertinoPageRoute(
                    settings: RouteSettings(name: "/fav_home_page", arguments: {}),
                    builder: (context) => FavouritePage(),
                  ),
                );
              },
              child: Container(
                color: Colors.white,
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 15,
                        vertical: 15,
                      ),
                      child: Image.asset(
                        ImageHelper.wrapAssets("icon_collect.png"),
                        package: PACKAGE_NAME,
                        width: 24,
                        height: 24,
                      ),
                    ),
                    Expanded(
                      child: Text(
                        "收藏",
                        style: TextStyle(
                          fontSize: 16,
                          color: Color(0xff333333),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                        right: 7,
                      ),
                      child: Image.asset(
                        'images/icon_arrow_go.png',
                        width: 24,
                        height: 24,
                        package: PACKAGE_NAME,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            _divider(),
            Container(
              color: Colors.white,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 15,
                      vertical: 15,
                    ),
                    child: Image.asset(
                      ImageHelper.wrapAssets("icon_version_info.png"),
                      package: PACKAGE_NAME,
                      width: 24,
                      height: 24,
                    ),
                  ),
                  Expanded(
                    child: Text(
                      "版本信息",
                      style: TextStyle(
                        color: Color(0xff333333),
                        fontSize: 16,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                      right: 15,
                    ),
                    child: Text(
                      "${version ?? ""}",
                      style: TextStyle(
                        color: Color(0xff999999),
                        fontSize: 14,
                      ),
                    ),
                  )
                ],
              ),
            ),
            _divider(),
            Visibility(
              visible: Platform.isAndroid,
              child: GestureDetector(
                onTap: () {
                  Navigator.of(context).push(
                    new CupertinoPageRoute(
                      builder: (context) => SettingsPage(),
                    ),
                  );
                },
                child: Container(
                  color: Colors.white,
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 15,
                          vertical: 15,
                        ),
                        child: Image.asset(
                          ImageHelper.wrapAssets("icon_setting.png"),
                          package: PACKAGE_NAME,
                          width: 24,
                          height: 24,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          "设置",
                          style: TextStyle(
                            fontSize: 16,
                            color: Color(0xff333333),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                          right: 7,
                        ),
                        child: Image.asset(
                          'images/icon_arrow_go.png',
                          width: 24,
                          height: 24,
                          package: PACKAGE_NAME,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(14, 20, 14, 0),
              height: 40,
              width: double.infinity,
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.all(Radius.circular(4))),
              child: TextButton(
                onPressed: () {
                  _loginOut();
                },
                style: ButtonStyle(overlayColor: MaterialStateProperty.all(ColorUtil.backGroundColor)),
                child: Text(
                  "退出登录",
                  style: TextStyle(fontSize: 16, color: Color(0xFFF85152)),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
          ],
        ),
      ),
    );
  }

  Widget _itemWidget(int index, String leftHint, String rightContent, {String? secondContent}) {
    double heights = 56.0;
    switch (index) {
      case 1:
      case 2:
      case 3:
        return Container(
          height: heights,
          padding: EdgeInsets.symmetric(horizontal: 14),
          alignment: Alignment.center,
          color: Colors.white,
          child: Row(
            children: [
              Text(
                leftHint,
                style: TextStyle(fontSize: 16, color: ColorUtil.color333333, fontWeight: FontWeight.w600),
              ),
              Container(
                margin: EdgeInsets.only(left: 22),
                child: Text(
                  rightContent,
                  style: TextStyle(fontSize: 16, color: ColorUtil.color677DB1),
                ),
              )
            ],
          ),
        );
      case 4:
        heights = 81.0;
        return Container(
          height: heights,
          padding: EdgeInsets.fromLTRB(14, 18, 0, 0),
          color: Colors.white,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                leftHint,
                style: TextStyle(fontSize: 16, color: ColorUtil.color333333, fontWeight: FontWeight.w600),
              ),
              Expanded(
                child: Container(
                    margin: EdgeInsets.only(left: 22),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text(
                          rightContent,
                          style: TextStyle(fontSize: 16, color: ColorUtil.color333333, fontWeight: FontWeight.w600),
                        ),
                        Container(
                            margin: EdgeInsets.only(top: 5),
                            child: Text(
                              secondContent ?? "",
                              style: TextStyle(fontSize: 13, color: ColorUtil.color999999),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            )),
                      ],
                    )),
              ),
              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.only(bottom: 18, right: 7),
                child: Image.asset(
                  'images/icon_arrow_go.png',
                  width: 24,
                  height: 24,
                  package: PACKAGE_NAME,
                ),
              )
            ],
          ),
        );
      default:
        return Container();
    }
  }

  Widget _divider() {
    return Container(
      margin: EdgeInsets.only(left: 14),
      color: Colors.white,
      child: Divider(
        color: ColorUtil.dividerColor,
        height: 1,
      ),
    );
  }
}
