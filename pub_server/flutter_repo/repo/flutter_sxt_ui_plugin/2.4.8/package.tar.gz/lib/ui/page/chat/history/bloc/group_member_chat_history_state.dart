part of 'group_member_chat_history_bloc.dart';

class GroupMemberChatHistoryState {
  String? keyword;
  List<MapEntry<GroupMember, Contact>>? memberList;

  GroupMemberChatHistoryState([
    this.keyword,
    this.memberList,
  ]);
}
