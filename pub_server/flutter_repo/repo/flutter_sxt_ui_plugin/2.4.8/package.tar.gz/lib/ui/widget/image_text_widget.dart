import 'package:flutter/material.dart';

class ImageTextWidget extends StatefulWidget {
  final Text content;
  final Image image;
  final Color? color;
  final double drawablePadding;
  final Decoration? decoration;
  final Direction direction;
  final double? height;
  final double? width;
  final AlignmentGeometry? alignment;
  final GestureTapCallback? onTap;

  ImageTextWidget(this.content, this.image,
      {this.color,
      this.drawablePadding = 5.0,
      this.decoration,
      this.direction = Direction.left,
      this.height,
      this.width,
      this.alignment,
      this.onTap});

  @override
  _ImageTextWidgetState createState() => _ImageTextWidgetState();
}

class _ImageTextWidgetState extends State<ImageTextWidget> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: widget.onTap,
      child: Container(
        color: widget.color,
        alignment: widget.alignment,
        height: widget.height,
        width: widget.width,
        decoration: widget.decoration,
        child: _getChild(),
      ),
    );
  }

  Widget _getChild() {
    switch (widget.direction) {
      case Direction.left:
        return Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            widget.image,
            Container(
              margin: EdgeInsets.only(left: widget.drawablePadding),
              child: widget.content,
            )
          ],
        );
      case Direction.top:
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            widget.image,
            Container(
              margin: EdgeInsets.only(top: widget.drawablePadding),
              child: widget.content,
            ),
          ],
        );
      case Direction.right:
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              margin: EdgeInsets.only(right: widget.drawablePadding),
              child: widget.content,
            ),
            widget.image,
          ],
        );
      case Direction.bottom:
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              margin: EdgeInsets.only(bottom: widget.drawablePadding),
              child: widget.content,
            ),
            widget.image,
          ],
        );
    }
  }
}

enum Direction { left, top, right, bottom }
