part of 'contact_bloc.dart';

class ContactState {
  final Contact? contact;

  ContactState([this.contact]);
}
