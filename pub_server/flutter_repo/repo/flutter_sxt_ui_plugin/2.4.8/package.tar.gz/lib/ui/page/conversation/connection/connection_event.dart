part of 'connection_bloc.dart';

@immutable
abstract class ConnectionEvent {}

class ConnectionInitialEvent extends ConnectionEvent {}
