import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:dartx/dartx.dart';
import 'package:flutter_easyrefresh/easy_refresh.dart';
import 'package:meta/meta.dart';
import 'package:rxdart/rxdart.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';
import 'package:sxt_flutter_plugin/message/model/query_msg_param.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';

part 'chat_history_event.dart';
part 'chat_history_state.dart';

class ChatHistoryBloc extends Bloc<ChatHistoryEvent, ChatHistoryState> {
  ChatHistoryBloc(this.sessionEntity) : super(ChatHistoryState());

  final SessionEntity sessionEntity;

  final refreshController = EasyRefreshController();

  final _sreamController = StreamController<String>();
  StreamSubscription? _streamSubscription;

  Message? lastMsg;

  @override
  Future<void> close() {
    _sreamController.close();
    _streamSubscription?.cancel();
    refreshController.dispose();
    return super.close();
  }

  @override
  Stream<ChatHistoryState> mapEventToState(ChatHistoryEvent event) async* {
    if (event is ChatHistoryInitEvent) {
      _listenKeywordChange();
    } else if (event is ChatHistoryKeywordEvent) {
      _sreamController.add(event.keyword);
    } else if (event is ChatHistoryResultEvent) {
      yield ChatHistoryState(state.keyword, state.messages, state.noMore);
    }
  }

  void _listenKeywordChange() {
    _streamSubscription = _sreamController.stream
        .debounceTime(300.milliseconds)
        .switchMap(_loadMessageList)
        .listen((msgList) => add(ChatHistoryResultEvent()));
  }

  Stream<List<Message>> _loadMessageList(String keyword) async* {
    if (keyword != state.keyword) lastMsg = null;
    state.keyword = keyword;
    if (keyword.isEmpty) {
      yield [];
      return;
    }

    final params = QueryMsgParam();
    params.msgCount = 50;
    params.keyword = keyword;
    params.userCode = sessionEntity.code;
    params.sessionType = sessionEntity.sessionType;
    params.msgCode = lastMsg?.code ?? 0;
    params.msgTime = lastMsg?.createTime ?? 0;

    final job = await SxtMessagePlugin.getMsgsByKey(params);
    if (lastMsg == null) {
      state.messages = job.data!;
    } else {
      state.messages.addAll(job.data!);
      refreshController.finishLoad();
    }
    if (job.data!.isNotEmpty) lastMsg = job.data!.last;
    state.noMore = job.data!.length < params.msgCount!;
    yield job.data!;
  }
}
