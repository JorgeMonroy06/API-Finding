part of 'chat_record_list_bloc.dart';

class ChatRecordListState {
  final List<GroupMessage>? groupMessageList;

  const ChatRecordListState({
    @required this.groupMessageList,
  });

  ChatRecordListState.initial() : this(groupMessageList: null);

  ChatRecordListState copyWith({List<GroupMessage>? groupMessageList}) {
    return ChatRecordListState(
        groupMessageList: groupMessageList ?? this.groupMessageList);
  }
}
