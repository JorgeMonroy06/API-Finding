part of 'date_chat_history_bloc.dart';

@immutable
abstract class DateChatHistoryEvent {}

class DateChatHistoryInitEvent extends DateChatHistoryEvent {}
