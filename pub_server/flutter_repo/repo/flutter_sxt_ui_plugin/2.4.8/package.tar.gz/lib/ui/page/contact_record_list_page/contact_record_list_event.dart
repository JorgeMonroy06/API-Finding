part of 'contact_record_list_bloc.dart';

@immutable
abstract class ContactRecordListEvent {
  const ContactRecordListEvent();
}

class Search extends ContactRecordListEvent {
  final String keyword;
  final SessionEntity sessionEntity;

  const Search(this.keyword, this.sessionEntity);
}
