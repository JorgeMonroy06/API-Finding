import 'dart:async';
import 'dart:convert';

import 'package:connectivity/connectivity.dart';
import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/ui/contact_select/contact_select_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_swipe_action_cell/flutter_swipe_action_cell.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/manager/app_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/my_navigator.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/global_search_page/global_search_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/login_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/chat_message_item_widget.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/empty_widget.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/image_text_widget.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/loading_dialog.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/search_widget.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/group_image_stream_controller.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/message_stream_controller.dart';
import 'package:flutter_sxt_ui_plugin/utils/prefrence_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/sxt_status_listener.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/account/listener/connection_state_listener.dart';
import 'package:sxt_flutter_plugin/account/model/socket_connect_state.dart';
import 'package:sxt_flutter_plugin/account/model/sxt_login_param.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';
import 'package:sxt_flutter_plugin/group/listener/group_avatar_state_update_listener.dart';
import 'package:sxt_flutter_plugin/group/model/group_avatar_event.dart';
import 'package:sxt_flutter_plugin/group/model/group_create_param.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_manager.dart';
import 'package:sxt_flutter_plugin/message/listener/conversation_update_listener.dart';
import 'package:sxt_flutter_plugin/message/model/conversation.dart';
import 'package:sxt_flutter_plugin/message/model/send_state.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';
import 'package:sxt_flutter_plugin/message/model/set_conv_unread_count_param.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';
import 'package:sxt_flutter_plugin/model/modification_event.dart';
import 'package:sxt_flutter_plugin/model/modification_event_type.dart';

typedef NewMessageUpdate = Future Function(int count);

///消息列表
class MessagePage extends StatefulWidget {
  final NewMessageUpdate _messageUpdate;

  MessagePage(this._messageUpdate);

  @override
  _MessagePageState createState() => _MessagePageState();
}

class _MessagePageState extends State<MessagePage> with WidgetsBindingObserver {
  List<Conversation> dataSource = List.empty(growable: true);
  late StreamController<List<Conversation>> dataSourceStreamController;

  String _title = "消息";

  ///视信通连接状态
  bool _sxtConnecting = true;
  StateSetter? _sxtConnectState;

  ///当前登录用户
  Contact? _currentLoginUser;

  // late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

  // final SlidableController slidAbleController = SlidableController();
  final SwipeActionController slidAbleController = SwipeActionController();
  final Connectivity _connectivity = Connectivity();
  late StreamSubscription<ConnectivityResult> _connectivitySubscription;
  bool _noNetWork = false;

  @override
  void dispose() {
    _connectivitySubscription.cancel();
    WidgetsBinding.instance!.removeObserver(this);
    dataSourceStreamController.close();
    super.dispose();
  }

  @override
  void initState() {
    dataSourceStreamController = StreamController();
    _connectStatusEventListener();
    _groupChangListener();
    _getMessageList();
    _getUnReadMessageCount();
    _registerMessageUpdateListener();
    super.initState();
    WidgetsBinding.instance!.addObserver(this);
    initConnectivity();
    _connectivitySubscription =
        _connectivity.onConnectivityChanged.listen(_updateConnectionStatus);
    // flutterLocalNotificationsPlugin = new FlutterLocalNotificationsPlugin();
    // AndroidInitializationSettings android = new AndroidInitializationSettings(AppManager.instance.uiOptions.androidNotifyBarRes);
    // IOSInitializationSettings iOS = new IOSInitializationSettings();
    // MacOSInitializationSettings macOS = new MacOSInitializationSettings();
    // var initSettings = new InitializationSettings(android: android, iOS: iOS, macOS: macOS);
    // flutterLocalNotificationsPlugin.initialize(initSettings, onSelectNotification: (payload) async {
    //   if (payload == null) return;
    //   await Navigator.of(context).push(CupertinoPageRoute<void>(
    //       settings: RouteSettings(name: '/ChatPage'),
    //       builder: (context) {
    //         return ChatPage(sessionEntity: SessionEntity.fromJson(json.decode(payload)));
    //       }));
    // });
  }

  ///网络状态变化监听初始化
  Future<void> initConnectivity() async {
    printLog("wifi:initConnectivity");
    ConnectivityResult result = ConnectivityResult.none;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      result = await _connectivity.checkConnectivity();
    } on PlatformException catch (e) {
      printLog(e.toString());
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) {
      return Future.value(null);
    }

    return _updateConnectionStatus(result);
  }

  ///网络状态变更回调
  Future<void> _updateConnectionStatus(ConnectivityResult result) async {
    printLog("wifi:${result.toString()}}");
    switch (result) {
      case ConnectivityResult.wifi:
      case ConnectivityResult.mobile:
        _noNetWork = false;
        if (_sxtConnecting) {
          return;
        }
        _sxtConnecting = true;
        _sxtConnectState!(() {});

        break;
      case ConnectivityResult.none:
        _noNetWork = true;
        if (!_sxtConnecting) {
          return;
        }
        _sxtConnecting = false;
        _sxtConnectState!(() {});
        break;
      default:
        break;
    }
  }

  _getLoginUser() async {
    _currentLoginUser = await StatusChangeLister.getCurrentLoginUser();
  }

  ///点击搜索跳转
  void _jumpToSearch() {
    Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
      return GlobalSearchPage();
    }));
  }

  ///item点击事件
  void _itemClick(Conversation item, int index) {
    int unReadCount = item.unReadCount ?? 0;
    if (unReadCount > 0) {
      _setMessageRead(item, true);
    }
    // flutterLocalNotificationsPlugin.cancel(item.convCode!.hashCode);
    Navigator.of(context).push(CupertinoPageRoute(
        settings: RouteSettings(name: '/ChatPage'),
        builder: (_) {
          return ChatPage(sessionEntity: item.talker!);
        }));
  }

  ///item点击事件
  void _createGroupChat() async {
    var data =
        await Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
      return ContactSelectPage(title: "选择联系人");
    }));
    if (data != null) {
      List<Contact> list = data;
      showDialog(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => LoadingDialog("创建群组中...", () => {}));

      List<String> userCodes = [];
      list.forEach((element) {
        userCodes.add(element.code! + "@" + element.originCode!);
      });

      GroupCreateParam param = GroupCreateParam();
      param.userCodes = userCodes;
      SxtGroupPlugin.createGroup(param).then((value) {
        Future.delayed((Duration(milliseconds: 500)), () {
          Navigator.popUntil(
            context,
            (route) {
              if (!route.willHandlePopInternally &&
                  route is ModalRoute &&
                  route.settings.name == '/MainPage') {
                return true;
              }
              return false;
            },
          );
          Navigator.push(
              context,
              new CupertinoPageRoute(
                  settings: RouteSettings(name: '/ChatPage'),
                  builder: (context) {
                    SessionEntity sessionEntity = new SessionEntity(
                        code: value.data?.groupCode,
                        sessionType: SessionType.GROUP);
                    return ChatPage(sessionEntity: sessionEntity);
                  }));
        });
      }).onError((e, stackTrace) {
        Navigator.pop(context);
        if (e is PlatformException) {
          ToastUtil.showToast(e.message ?? "创建群组失败");
        } else {
          ToastUtil.showToast("创建群组失败");
        }
      });
    }
  }

  ///设置消息已读未读
  _setMessageRead(Conversation bean, bool alreadyRead) async {
    SetConvUnreadCountParam param =
        new SetConvUnreadCountParam(sessionEnitity: bean.talker);
    if (alreadyRead) {
      param.count = 0;
    } else {
      param.count = 1;
    }
    SxtMessagePlugin.setConvUnreadCount(param);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    printLog("didChangeAppLifecycleState:$state");
    if (state == AppLifecycleState.resumed) {
      MyNavigator.getInstance().appIsHome = false;
    } else if (state == AppLifecycleState.inactive) {
      MyNavigator.getInstance().appIsHome = true;
    }
    super.didChangeAppLifecycleState(state);
  }

  ///通知栏发送消息
  showNotification(Conversation? bean) async {
    // if ((MyNavigator.getInstance().getCurrentRoute().settings.name ?? "").contains('/ChatPage') && !_appIsHome) {
    //   return;
    // }
    // if ((MyNavigator.getInstance().getCurrentRoute().settings.name ?? "").contains('/MainPage') &&
    //     MyNavigator.getInstance().mainPageCurrentIndex == 0 &&
    //     !_appIsHome) {
    //   return;
    // }
    // if (!(bean?.isNewUnreadIncoming ?? true)) {
    //   return;
    // }
    // if (bean == null) {
    //   return;
    // }
    // var android = new AndroidNotificationDetails('channel id', 'channel NAME', 'CHANNEL DESCRIPTION',
    //     // sound: RawResourceAndroidNotificationSound('call_wait'),
    //     priority: Priority.high,
    //     importance: Importance.max);
    // var iOS = new IOSNotificationDetails();
    // var macOS = new MacOSNotificationDetails();
    // var platform = new NotificationDetails(android: android, iOS: iOS, macOS: macOS);
    // await flutterLocalNotificationsPlugin.cancel(bean.convCode!.hashCode);
    // String body;
    // if (bean.unReadCount! > 1) {
    //   body = '[${bean.unReadCount}条] ${bean.content}';
    // } else {
    //   body = '${bean.content}';
    // }
    // String title;
    // if (bean.talker!.sessionType == SessionType.GROUP) {
    //   title = bean.talker!.name!;
    // } else {
    //   Contact? contact = await DataManager.instance.getContact(bean.talker!.code!);
    //   title = contact?.name ?? "视信通";
    // }
    // await flutterLocalNotificationsPlugin.show(bean.convCode!.hashCode, title, body, platform, payload: '${jsonEncode(bean.talker)}');
  }

  ///会话列表监听
  _registerMessageUpdateListener() async {
    printLog("注册消息更新相关监听");
    SxtMessagePlugin.setConversationUpdateListener(ConversationUpdateListener(
        onChanged: (ModificationEvent<Conversation> event) {
      printLog("setConversationUpdateListener--${event.type}");
      _getUnReadMessageCount();
      _getMessageList();
      switch (event.type) {
        case ModificationEventType.DATA_UPDATE:
          // _updateSingItem(event.data);
          // showNotification(event.data);
          break;
        case ModificationEventType.DATA_DELETE:
          // _deleteSingItem(event.data);
          break;
        case ModificationEventType.DATA_ADD:
          // showNotification(event.data);
          // if (event.data != null) {
          //   dataSource.insert(0, event.data!);
          //   reSortList(dataSource);
          // }
          break;
        default:
          break;
      }
    })).then((value) => {StatusChangeLister.setJobId(value.jobId!)});
  }

  ///群头像变更监听
  _groupChangListener() async {
    SxtGroupPlugin.setGroupAvatarStateUpdateListener(
        GroupAvatarStateUpdateListener(onChanged: (GroupAvatarEvent event) {
      if (event.group!.avatarThumbState == SendState.SUCCESS) {
        if (mounted) {
          GroupImageStreamController.getInstance()
              .streamController
              .add(event.group);
        }
      }
    })).then((value) => {StatusChangeLister.setJobId(value.jobId!)});
  }

  ///帐号连接状态更新事件监听
  _connectStatusEventListener() {
    printLog("setOnlineStateListener()--listener");
    SxtAccountPlugin.setOnlineStateListener(
        ConnectionStateListener(onKicked: () {
      printLog("setOnlineStateListener()--onKicked");

      _loginOut();

      _sxtConnecting = false;
      _sxtConnectState!(() {});
    }, onlineStateChanged: (state) {
      printLog("setOnlineStateListener()--state:${state.state}");

      // ignore: unrelated_type_equality_checks
      if (state.state == SocketConnectState.DISCONNECTED) {
        _sxtConnecting = false;
        _sxtConnectState!(() {});
        // ignore: unrelated_type_equality_checks
      } else if (state.state == SocketConnectState.CONNECTED) {
        _sxtConnecting = true;
        _sxtConnectState!(() {});
      }
    })).then((value) {
      StatusChangeLister.setJobId(value.jobId!);
    });
  }

  ///更新单条数据
  _updateSingItem(Conversation? item) {
    if (item != null) {
      int index =
          dataSource.indexWhere((element) => element.convCode == item.convCode);
      printLog(
          "update_single item index:$index and isNewUnreadIncoming:${item.isNewUnreadIncoming}");
      if (index != -1) {
        if (index == 0 || !item.isNewUnreadIncoming!) {
          dataSource[index] = item;
          reSortList(dataSource);
        } else {
          dataSource.removeAt(index);
          dataSource.insert(0, item);
          reSortList(dataSource);
        }
      }
    }
  }

  ///删除单条数据
  _deleteSingItem(Conversation? item) {
    if (item != null) {
      dataSource.removeWhere((element) {
        return element.convCode == item.convCode;
      });
      reSortList(dataSource);
      return;
    }
  }

  ///获取消息列表(会话列表)
  _getMessageList() async {
    await _getLoginUser();

    SxtMessagePlugin.getConversationList().then((value) {
      if (value.data == null) {
      } else {
        dataSource.clear();
        dataSource.addAll(value.data ?? List.empty(growable: true));
        reSortList(dataSource);
      }
    }).onError((error, stackTrace) {
      print(error);
    });
  }

  ///获取消息未读数量
  _getUnReadMessageCount() async {
    SxtMessagePlugin.getAllConvUnreadCount().then((value) {
      int count = value.data ?? 0;
      printLog("获取消息未读数:$count");
      widget._messageUpdate(count);
      if (mounted)
        setState(() {
          if (count > 0) {
            _title = "消息($count)";
          } else {
            _title = "消息";
          }
        });
    });
  }

  ///左滑动作
  _operation(Conversation bean, int operation) {
    switch (operation) {
      case 1:
        //标记已读未读
        break;
      case 2:
        //置顶/取消置顶
        reSortList(dataSource);
        break;
      case 3:
        //移除
        SxtMessagePlugin.delConversation(bean);
        break;
    }
  }

//重新排序，查找置顶页面
  reSortList(List<Conversation> source) async {
    Map<String, List<String>>? topListMap =
        await StatusChangeLister.getTopMessageList();
    if (topListMap == null ||
        _currentLoginUser == null ||
        topListMap[_currentLoginUser!.code!] == null ||
        topListMap[_currentLoginUser!.code!]!.isEmpty) {
      printLog("reSortList_top list_is null");
      dataSourceStreamController.add(dataSource);
    } else {
      if (dataSource.isNotEmpty) {
        List<Conversation> newList = List.from(dataSource, growable: true);

        topListMap[_currentLoginUser!.code!]!.forEach((element) {
          int index = newList.indexWhere((it) {
            return element == it.convCode;
          });
          if (index != -1) {
            newList.insert(0, newList.removeAt(index));
          }
        });
        printLog(jsonEncode(newList).toString());
        dataSourceStreamController.add(newList);
      }
    }
    MessageStreamController.getInstance().streamController.add(0);
  }

  ///重新登录
  _reLogin() async {
    if (_noNetWork) {
      ToastUtil.showToast("无网络，请检查网络设置");
      return;
    }
    SxtAccountPlugin.login(SxtLoginParam()
      ..userCode = await PreferenceUtil.getAccount()
      ..password = await PreferenceUtil.getPwd()
      ..sxtServerIp = Constant.SXT_IP
      ..sxtServerPort = Constant.SXT_PORT
      ..sxtClientId = Constant.SXT_CLIENT_ID
      ..sxtClientSecret = Constant.SXT_CLIENT_SECRET
      ..sxtUseSSL = Constant.SXT_USE_SSL);
    // .then((value) => {setState(() {})});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            width: double.infinity,
            child: BackgroundImageAppbar(
              title: _title,
              trailingWidget: InkWell(
                  onTap: () {
                    _createGroupChat();
                  },
                  child: Container(
                    alignment: Alignment.center,
                    padding: EdgeInsets.only(right: 8),
                    child: Image.asset('images/icon_add_chat.png',
                        height: 32,
                        width: 32,
                        fit: BoxFit.fill,
                        package: PACKAGE_NAME),
                  )),
            ),
          ),
          _connectWidget(),
          Expanded(
            child: Container(
              color: Colors.white,
              child: StreamBuilder<List<Conversation>>(
                initialData: List.empty(growable: true),
                stream: dataSourceStreamController.stream,
                builder: (context, snapshot) {
                  return !(snapshot.hasData && snapshot.data!.isNotEmpty)
                      ? Column(
                          children: [
                            SearchBar(
                                hint: "搜索",
                                callbackAction: () {
                                  _jumpToSearch();
                                }),
                            Expanded(
                                child: EmptyWidget(
                              "当前没有消息",
                              height: double.infinity,
                              width: double.infinity,
                              padding: EdgeInsets.only(top: 100),
                            ))
                          ],
                        )
                      : ListView.builder(
                          padding: EdgeInsets.only(top: 0),
                          itemCount: snapshot.data!.length + 1,
                          itemBuilder: (context, index) {
                            if (index == 0) {
                              return SearchBar(
                                  hint: "搜索",
                                  callbackAction: () {
                                    _jumpToSearch();
                                  });
                            } else {
                              int realIndex = index - 1;
                              return ChatMessageItemWidget(
                                // key: GlobalObjectKey(index),
                                item: snapshot.data![realIndex],
                                itemClickListener: (item, realIndex) =>
                                    {_itemClick(item, realIndex)},
                                index: realIndex,
                                slidAbleController: slidAbleController,
                                operationListener: (bean, operation) =>
                                    _operation(bean, operation),
                              );
                            }
                          });
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _connectWidget() {
    printLog(
        "setOnlineStateListener()--build and _sxtConnectState:$_sxtConnecting");
    return StatefulBuilder(
      builder: (context, setState) {
        _sxtConnectState = setState;
        return _sxtConnecting
            ? Container(
                height: 0,
              )
            : ImageTextWidget(
                Text(
                  "视信通登录失败，重新登录",
                  style: TextStyle(color: ColorUtil.colorFF85152, fontSize: 12),
                ),
                Image.asset('images/ic_chat_send_failed.png',
                    height: 13,
                    width: 13,
                    fit: BoxFit.fill,
                    package: PACKAGE_NAME),
                onTap: () {
                  _reLogin();
                },
                alignment: Alignment.center,
                height: 38,
                width: double.infinity,
                drawablePadding: 6,
                color: ColorUtil.colorFFFFEDED,
              );
      },
    );
    // if (_sxtConnecting) {
    //   return Container(
    //     height: 0,
    //   );
    // } else {
    //   return ImageTextWidget(
    //     Text(
    //       "视信通登录失败，重新登录",
    //       style: TextStyle(color: ColorUtil.colorFF85152, fontSize: 12),
    //     ),
    //     Image.asset('images/ic_chat_send_failed.png', height: 13, width: 13, fit: BoxFit.fill, package: PACKAGE_NAME),
    //     onTap: () {
    //       _reLogin();
    //     },
    //     height: 38,
    //     width: double.infinity,
    //     drawablePadding: 6,
    //     color: ColorUtil.colorFFFFEDED,
    //   );
    // }
  }

  ///退出登录
  void _loginOut() {
    showCupertinoDialog(
        context: context,
        builder: (context) {
          return CupertinoAlertDialog(
            content: Container(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 16),
              child: Text(
                '您已被踢下线，请重新登录',
                style: TextStyle(
                    color: ColorUtil.color333333,
                    fontWeight: FontWeight.w600,
                    fontSize: 15),
              ),
            ),
            actions: <Widget>[
              CupertinoDialogAction(
                child: Text('确定',
                    style: TextStyle(
                        fontSize: 16, color: ColorUtil.colorFFD74A49)),
                onPressed: () {
                  Navigator.of(context).pop(true);
                },
              ),
            ],
          );
        }).then((value) {
      if (value) {
        StatusChangeLister.setCurrentLoginUser(null);

        SxtAccountPlugin.logout().then((value) {}).onError((error, stackTrace) {
          print(error);
        });
        StatusChangeLister.getJobId().forEach((element) {
          SxtManager.instance.cancelJob(element);
        });
        StatusChangeLister.removeAllJobId();
        Navigator.of(context).pushAndRemoveUntil(
            new CupertinoPageRoute(
              builder: (context) => LoginPage(),
            ),
            (route) => true);

        AppManager.instance.clear();
      }
    });
  }
}

printLog(String msg) {
  print("Message---$msg");
}
