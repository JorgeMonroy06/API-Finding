part of 'group_bloc.dart';

class GroupState {}
