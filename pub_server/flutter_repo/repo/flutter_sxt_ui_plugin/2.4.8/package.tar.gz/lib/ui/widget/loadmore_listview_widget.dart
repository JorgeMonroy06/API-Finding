/// @author newtab on 2021/5/10
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

typedef LoadMore = Future<void> Function();

///加载更多控件
class LoadMoreListViewWidget extends StatefulWidget {
  final IndexedWidgetBuilder? itemBuilder;
  final int itemCount;
  final bool canLoadMore;
  final bool reverse;
  final bool shrinkWrap;
  final LoadMore? loadMore;
  final ScrollPhysics? scrollPhysics;
  final ScrollController? scrollController;

  LoadMoreListViewWidget({
    this.itemBuilder,
    this.itemCount = 0,
    this.canLoadMore = false,
    this.loadMore,
    this.reverse = false,
    this.shrinkWrap = false,
    this.scrollPhysics,
    this.scrollController,
  });

  @override
  _LoadMoreListViewWidgetState createState() => _LoadMoreListViewWidgetState();
}

class _LoadMoreListViewWidgetState extends State<LoadMoreListViewWidget> {
  late ScrollController _scrollController;
  bool isLoadingMore = false;

  @override
  void initState() {
    if (widget.scrollController == null) {
      _scrollController = ScrollController();
    } else {
      _scrollController = widget.scrollController!;
    }
    _scrollController.addListener(() {
      if (isLoadingMore || !widget.canLoadMore) return;

      if (_scrollController.position.atEdge &&
          _scrollController.position.pixels >
              _scrollController.position.minScrollExtent) {
        isLoadingMore = true;
        if (widget.loadMore != null) {
          widget.loadMore!().then((_) {
            isLoadingMore = false;
          });
        }
      }
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      reverse: widget.reverse,
      shrinkWrap: widget.shrinkWrap,
      physics: widget.scrollPhysics,
      controller: _scrollController,
      itemBuilder: (context, index) {
        if (index == widget.itemCount) {
          return Container(
            width: MediaQuery.of(context).size.width,
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    height: 10,
                  ),
                  CupertinoActivityIndicator(
                    radius: 12,
                  ),
                ],
              ),
            ),
          );
        } else {
          return widget.itemBuilder!(context, index);
        }
      },
      itemCount: widget.itemCount +
          (widget.itemCount != 0 ? (widget.canLoadMore ? 1 : 0) : 0),
    );
  }
}
