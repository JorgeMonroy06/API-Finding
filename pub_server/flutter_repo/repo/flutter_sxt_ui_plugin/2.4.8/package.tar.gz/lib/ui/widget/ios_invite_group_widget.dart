import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/ios_message_stream_controller.dart';
import 'package:sprintf/sprintf.dart';
import 'package:sxt_flutter_plugin/message/model/conversation.dart';
import 'package:sxt_flutter_plugin/model/user.dart';

class InviteGroupForIos extends StatefulWidget {
  final Conversation conversation;

  InviteGroupForIos(this.conversation);

  @override
  _InviteGroupForIosState createState() => _InviteGroupForIosState();
}

class _InviteGroupForIosState extends State<InviteGroupForIos> {
  String? content;

  @override
  void initState() {
    super.initState();
    _getData();
    IosMessageStreamController.getInstance()
        .streamController
        .stream
        .listen((event) {
      Future.delayed(Duration(milliseconds: 200), _getData);
    });
  }

  _getData() async {
    // Contact? loginUser =  await StatusChangeLister.getCurrentLoginUser();
    List<String> codeList = [];
    Map<String, String> nameList = {};
    List<User> memberList =
        List.from(widget.conversation.memberList!, growable: true);
    String? firstCode = DomainUtil.toCode(memberList.first.userCode);
    // memberList.removeWhere((element){return DomainUtil.toCode(element.userCode) == (loginUser?.code??"");});
    memberList.forEach((element) {
      String code = DomainUtil.toCode(element.userCode);
      if (DataManager.instance.isCacheContact(code)) {
        nameList[code] =
            (DataManager.instance.getContactFromCache(code)?.name) ?? "";
      } else {
        codeList.add(DomainUtil.toCode(element.userCode));
      }
    });

    if (memberList.length == nameList.length) {
      List<String> realNameList = [];
      nameList.forEach((key, value) {
        realNameList.add(value);
      });
      content = sprintf(widget.conversation.content!, realNameList);
      if (mounted) {
        setState(() {});
      }
    } else {
      DataManager.instance.getContactList(codeList).then((value) {
        value.forEach((element) {
          nameList[element.code!] = element.name!;
        });
        List<String> realNameList = [];
        if (widget.conversation.content!.startsWith("%s")) {
          String firstName = nameList[firstCode]!;
          nameList.remove(firstCode);
          realNameList.add(firstName);
        }
        nameList.forEach((key, value) {
          realNameList.add(value);
        });
        content = sprintf(widget.conversation.content!, realNameList);
        if (mounted) {
          setState(() {});
        }
      });
      // ContactManager.instance
      //     .getContactsByCodes(codeList, DataFilterBuilder())
      //     .where((event) => (null != event && event.isNotEmpty))
      //     .take(1)
      //     .first
      //     .then((value) {
      //   value.forEach((element) {
      //     nameList[element.code!] = element.name!;
      //     DataManager.instance.addContactCache(element.code!, element);
      //   });
      //
      //   List<String> realNameList = [];
      //   if (widget.conversation.content!.startsWith("%s")) {
      //     String firstName = nameList[codeList[0]]!;
      //     nameList.remove(codeList[0]);
      //     realNameList.add(firstName);
      //   }
      //   nameList.forEach((key, value) {
      //     realNameList.add(value);
      //   });
      //   content = sprintf(widget.conversation.content!, realNameList);
      //   if (mounted) {
      //     setState(() {});
      //   }
      // });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text(
        content ?? "",
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontSize: 13, color: ColorUtil.color999999),
      ),
    );
  }
}
