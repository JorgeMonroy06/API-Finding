part of 'forward_msg_bloc.dart';

class ForwardMsgState {
  final List<ContactListItem>? contactListItem;
  final List<ContactListItem>? searchedContactListItem;
  final List<Contact>? selectContactList;
  final bool? isMultiSelectState;

  const ForwardMsgState({
    @required this.contactListItem,
    @required this.searchedContactListItem,
    @required this.isMultiSelectState,
    @required this.selectContactList,
  });

  ForwardMsgState.initial()
      : this(
            contactListItem: null,
            searchedContactListItem: null,
            isMultiSelectState: false,
            selectContactList: []);

  ForwardMsgState copyWith(
      {List<ContactListItem>? contactListItem,
      List<ContactListItem>? searchedContactListItem,
      List<Contact>? selectContactList,
      bool? isMultiSelectState}) {
    return ForwardMsgState(
      contactListItem: contactListItem ?? this.contactListItem,
      searchedContactListItem:
          searchedContactListItem ?? this.searchedContactListItem,
      selectContactList: selectContactList ?? this.selectContactList,
      isMultiSelectState: isMultiSelectState ?? this.isMultiSelectState,
    );
  }
}
