import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/widgets.dart';

/// @author newtab on 2021/9/8

class PTTAudioRippleWidget extends StatefulWidget {
  const PTTAudioRippleWidget({Key? key}) : super(key: key);

  @override
  PTTAudioRippleWidgetState createState() => PTTAudioRippleWidgetState();
}

class PTTAudioRippleWidgetState extends State<PTTAudioRippleWidget> {
  bool isOtherSpeaking = false;
  bool playing = false;
  bool isMeSpeaking = false;
  List<int> list = [];
  Timer? timer;

  void _startPlay() {
    if (playing) return;
    playing = true;
    _startTimer();
  }

  void _stopPlay() {
    if (!playing) return;
    playing = false;
    timer?.cancel();
    list.clear();
    setState(() {});
  }

  void _startTimer() {
    timer = Timer.periodic(Duration(milliseconds: 300), (time) {
      int count = (MediaQuery.of(context).size.width - 20) ~/ 18;

      list.clear();
      list = List.generate(
          count, (index) => math.max(math.Random().nextInt(10), 3));
      setState(() {});
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  void play({bool isMeSpeaking = false, bool? isOtherSpeaking}) {
    this.isMeSpeaking = isMeSpeaking;
    if (isOtherSpeaking != null) {
      this.isOtherSpeaking = isOtherSpeaking;
    }
    _startPlay();
  }

  void stop({bool isMeSpeaking = false, bool? isOtherSpeaking}) {
    this.isMeSpeaking = isMeSpeaking;
    if (isOtherSpeaking != null) {
      this.isOtherSpeaking = isOtherSpeaking;
    }
    if (!this.isMeSpeaking && !this.isOtherSpeaking) {
      _stopPlay();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: Container(
            padding: EdgeInsets.only(
              right: 10,
              left: 10,
              top: 30,
            ),
            width: MediaQuery.of(context).size.width,
            child: Stack(
              children: [
                Positioned.fill(
                  child: CustomPaint(
                    painter: PaintTop(),
                  ),
                ),
                Positioned.fill(
                  child: CustomPaint(
                    painter: BluePainter(list),
                  ),
                ),
              ],
            ),
          ),
        ),
        SizedBox(
          height: 10,
        ),
        Expanded(
          child: Container(
            padding: EdgeInsets.only(
              right: 10,
              left: 10,
              bottom: 20,
            ),
            width: MediaQuery.of(context).size.width,
            child: Stack(
              children: [
                Positioned.fill(
                  child: CustomPaint(
                    painter: PaintBottom(),
                  ),
                ),
                Positioned.fill(
                  child: CustomPaint(
                    painter: BlueBottomPainter(list),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class PaintTop extends CustomPainter {
  final Paint bgPaint = Paint()
    ..color = Color(0xffe3e3e3)
    ..style = PaintingStyle.fill;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    double width = size.width;
    double height = size.height;

    double blockWidth = width / 18 - 3;

    double blockHeight = 5;

    double top = height;

    //当前多少行
    while (top > 0) {
      double left = 0;
      bgPaint.color = Color(0xffe3e3e3).withOpacity(top / height);
      while (left < width) {
        Rect rect = Rect.fromLTWH(left, top, blockWidth, blockHeight);
        canvas.drawRect(rect, bgPaint);
        left = left + blockWidth + 3;
      }
      top = top - 6;
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}

class PaintBottom extends CustomPainter {
  final Paint bgPaint = Paint()
    ..color = Color(0xffe3e3e3)
    ..style = PaintingStyle.fill;

  @override
  void paint(Canvas canvas, Size size) {
    drawBg(canvas, size);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }

  void drawBg(Canvas canvas, Size size) {
    double width = size.width;
    double height = size.height;

    double blockWidth = width / 18 - 3;

    double blockHeight = 5;

    double top = 0;

    while (top < height) {
      double left = 0;

      bgPaint.color = Color(0xffe3e3e3).withOpacity((height - top) / height);

      while (left < width) {
        Rect rect = Rect.fromLTWH(left, top, blockWidth, blockHeight);
        canvas.drawRect(rect, bgPaint);
        left = left + blockWidth + 3;
      }
      top = top + 6;
    }
  }
}

class BluePainter extends CustomPainter {
  List<int> counts;

  BluePainter(this.counts);

  final Paint bgPaint = Paint()
    ..color = Color(0xff5A8EDD)
    ..style = PaintingStyle.fill;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    double width = size.width;
    double height = size.height;

    double blockWidth = width / 18 - 3;

    double blockHeight = 5;

    double top = height;

    //当前多少行
    int rowIndex = 0;
    while (top > 0) {
      double left = 0;
      bgPaint.color = Color(0xff5A8EDD).withOpacity(top / height);

      int columnIndex = 0;
      while (left < width) {
        if (counts.length > columnIndex) {
          int count = counts[columnIndex];
          if (count > rowIndex) {
            Rect rect = Rect.fromLTWH(left, top, blockWidth, blockHeight);
            canvas.drawRect(rect, bgPaint);
          }
        }
        columnIndex = columnIndex + 1;
        left = left + blockWidth + 3;
      }
      top = top - 6;
      rowIndex = rowIndex + 1;
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}

class BlueBottomPainter extends CustomPainter {
  final Paint bgPaint = Paint()
    ..color = Color(0xff5A8EDD)
    ..style = PaintingStyle.fill;

  final List<int> counts;

  BlueBottomPainter(this.counts);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    double width = size.width;
    double height = size.height;

    double blockWidth = width / 18 - 3;

    double blockHeight = 5;

    double top = 0;

    //当前多少行
    int rowIndex = 0;
    while (top < height) {
      double left = 0;
      bgPaint.color = Color(0xff5A8EDD).withOpacity((height - top) / height);

      int columnIndex = 0;
      while (left < width) {
        if (counts.length > columnIndex) {
          int count = counts[columnIndex];
          if (count > rowIndex) {
            Rect rect = Rect.fromLTWH(left, top, blockWidth, blockHeight);
            canvas.drawRect(rect, bgPaint);
          }
        }
        columnIndex = columnIndex + 1;
        left = left + blockWidth + 3;
      }
      top = top + 6;
      rowIndex = rowIndex + 1;
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}
