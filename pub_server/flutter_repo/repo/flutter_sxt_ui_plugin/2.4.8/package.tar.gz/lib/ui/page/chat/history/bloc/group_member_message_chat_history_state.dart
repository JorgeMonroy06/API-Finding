part of 'group_member_message_chat_history_bloc.dart';

class GroupMemberMessageChatHistoryState {
  final List<Message>? messages;

  GroupMemberMessageChatHistoryState([this.messages]);
}
