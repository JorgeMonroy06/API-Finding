import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:contact_sdk_flutter/model/contact.dart';
import 'package:dartx/dartx.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:meta/meta.dart';
import 'package:rxdart/rxdart.dart';
import 'package:sxt_flutter_plugin/group/model/get_group_member_param.dart';
import 'package:sxt_flutter_plugin/group/model/group_member.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

part 'group_member_chat_history_event.dart';
part 'group_member_chat_history_state.dart';

class GroupMemberChatHistoryBloc
    extends Bloc<GroupMemberChatHistoryEvent, GroupMemberChatHistoryState> {
  GroupMemberChatHistoryBloc(this.sessionEntity, [this.groupLeaderCode])
      : super(GroupMemberChatHistoryState());

  final SessionEntity sessionEntity;
  final String? groupLeaderCode;

  final _sreamController = StreamController<String>();
  StreamSubscription? _streamSubscription;

  List<MapEntry<GroupMember, Contact>>? _memberList;

  @override
  Future<void> close() {
    _sreamController.close();
    _streamSubscription?.cancel();
    return super.close();
  }

  @override
  Stream<GroupMemberChatHistoryState> mapEventToState(
      GroupMemberChatHistoryEvent event) async* {
    if (event is GroupMemberChatHistoryInitEvent) {
      _listenKeywordChange();
      yield* _getGroupMemberChatHistoryState();
    } else if (event is GroupMemberChatHistoryLoadEvent) {
      yield* _getGroupMemberChatHistoryState();
    } else if (event is GroupMemberChatHistoryKeywordEvent) {
      _sreamController.add(event.keyword);
    } else if (event is GroupMemberChatHistoryResultEvent) {
      yield GroupMemberChatHistoryState(state.keyword, state.memberList);
    } else if (event is GroupMemberChatHistorySearchEvent) {
      if (event.isSearch) {
        yield GroupMemberChatHistoryState('', _memberList);
      } else {
        yield GroupMemberChatHistoryState(null, _memberList);
      }
    }
  }

  void _listenKeywordChange() {
    _streamSubscription = _sreamController.stream
        .debounceTime(300.milliseconds)
        .listen((keyword) {
      final list = keyword.isEmpty
          ? _memberList
          : _memberList!
              .where((entry) => entry.value.name!.contains(keyword))
              .toList(growable: false);
      state.keyword = keyword;
      state.memberList = list;
      add(GroupMemberChatHistoryResultEvent());
    });
  }

  Stream<GroupMemberChatHistoryState> _getGroupMemberChatHistoryState() async* {
    yield* _loadMemberList().map(
        (e) => GroupMemberChatHistoryState(state.keyword, state.memberList));
  }

  Stream<List<GroupMember>> _loadMemberList() async* {
    final params = GetGroupMemberParam();
    params.count = 999;
    params.offset = 0;
    params.groupCode = sessionEntity.code;

    final job = await SxtGroupPlugin.getGroupMember(params);
    final list = job.data!.where((e) => e.state == 0).toList();
    final index = list.indexWhere((e) => e.code == groupLeaderCode);
    if (index != -1) {
      final memeber = list.removeAt(index);
      list.insert(0, memeber);
    }

    _memberList = {
      for (var e in list) e: (await DataManager.instance.getContact(e.code!))!
    }.entries.toList(growable: false);
    state.memberList = _memberList;
    yield list;
  }
}
