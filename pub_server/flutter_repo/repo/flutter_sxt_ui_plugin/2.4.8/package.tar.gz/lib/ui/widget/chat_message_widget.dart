import 'dart:async';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/ui/contact_detail/contact_detail_page.dart';
import 'package:contact_ui_flutter/widget/image_loader.dart';
import 'package:extended_image/extended_image.dart';
import 'package:extended_text/extended_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_imagepicker_plugin/flutter_imagepicker_plugin.dart';
import 'package:flutter_sxt_ui_plugin/manager/app_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/audio_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/flutter_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/log/logger.dart';
import 'package:flutter_sxt_ui_plugin/ui/dialog/hint_dialog.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/bubble/bubble.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/images_animation.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/msg_pop_menu.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/my_extended_text_selection_controls.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/my_material_text_selection_controls.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/popmenu/popup_menu.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/date_time_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/fav_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/file_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/forward_msg_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:kd_flutter_map/amap_location_option.dart';
import 'package:kd_flutter_map/bean/poi_bean.dart';
import 'package:kd_flutter_map/flutter_map_manager.dart';
import 'package:kd_flutter_map/widget/gcoord.dart';
import 'package:sprintf/sprintf.dart';
import 'package:sxt_flutter_plugin/message/model/attachment.dart';
import 'package:sxt_flutter_plugin/message/model/audio_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/file_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/location_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/pic_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/prompt_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/prompt_type.dart';
import 'package:sxt_flutter_plugin/message/model/send_state.dart';
import 'package:sxt_flutter_plugin/message/model/share_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/text_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/video_attachment.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';

const styleOther = BubbleStyle(
  nip: BubbleNip.leftTop,
  nipOffset: 18,
  nipHeight: 7.5,
  nipWidth: 6,
  color: Colors.white,
  radius: Radius.circular(4.0),
  alignment: Alignment.centerLeft,
  borderWidth: 0,
  padding: BubbleEdges.fromLTRB(10, 10, 10, 10),
  shadowColor: Colors.transparent,
);

const styleMeWhite = BubbleStyle(
  nip: BubbleNip.rightTop,
  nipOffset: 18,
  nipHeight: 10,
  nipWidth: 6,
  color: Colors.white,
  radius: Radius.circular(4.0),
  alignment: Alignment.centerLeft,
  borderWidth: 0,
  padding: BubbleEdges.fromLTRB(10, 10, 10, 10),
  shadowColor: Colors.transparent,
);

const styleMe = BubbleStyle(
  nip: BubbleNip.rightTop,
  nipOffset: 18,
  nipHeight: 10,
  nipWidth: 6,
  color: ColorUtil.COLOR_FFCDE8FC,
  radius: Radius.circular(4.0),
  alignment: Alignment.centerLeft,
  borderWidth: 0,
  padding: BubbleEdges.fromLTRB(10, 10, 10, 10),
  shadowColor: Colors.transparent,
);

bool selectableTextFosusNoded = false;

class ChatMessageWidget extends StatefulWidget {
  final Message<Attachment> msg;
  final String selfCode;
  final bool isShowTime;
  final bool isGroupChat;
  final double? progress;
  final ChatBloc? chatBloc;

  ChatMessageWidget(Key key, this.msg, this.selfCode, this.isShowTime, this.isGroupChat, this.progress, this.chatBloc) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ChatMessageState(msg, selfCode, isShowTime, isGroupChat, progress, chatBloc);
  }
}

class ChatMessageState extends State<ChatMessageWidget> {
  final Message<Attachment> msg;
  final String selfCode;
  final bool isShowTime;
  final bool isGroupChat;
  final double? progress;
  final ChatBloc? chatBloc;

  late BuildContext widgetBuildContext;
  Contact? contact;
  StateSetter? nameStateSetter;
  StateSetter? avatarStateSetter;
  StateSetter? readMarkStateSetter;
  BuildContext? itemBuildContext;
  StreamSubscription? receiveMsgStreamSubscription;

  ChatMessageState(this.msg, this.selfCode, this.isShowTime, this.isGroupChat, this.progress, this.chatBloc) {}

  @override
  Widget build(BuildContext context) {
    print("aaaa  build ChatMessageState msg code : ${msg.code}");

    this.widgetBuildContext = context;
    FileUtil.clearImageCache();
    if (DataManager.instance.isCacheContact(msg.sender!.code!)) {
      contact = DataManager.instance.getContactFromCache(msg.sender!.code!);
    } else {
      //获取联系人信息
      DataManager.instance.getContact(msg.sender!.code!).then((value) {
        contact = value;
        if (nameStateSetter != null) {
          nameStateSetter!(() {});
        }
        if (avatarStateSetter != null) {
          avatarStateSetter!(() {});
        }
      });
    }

    //是否是提示类型的消息
    bool isPrompt = msg.msgType == MsgType.PROMPT &&
        (msg.attachment as PromptAttachment).msgCatg != PromptType.VOICE &&
        (msg.attachment as PromptAttachment).msgCatg != PromptType.VIDEO &&
        (msg.attachment as PromptAttachment).msgCatg != PromptType.POKE;

    bool isSend = msg.sender?.code == selfCode;

    //是否是上传或下载中
    bool isSendingOrDownloading = false;
    if (!isPrompt) {
      switch (msg.msgType) {
        case MsgType.TEXT:
          isSendingOrDownloading = msg.sendState == SendState.SENDING;
          break;
        case MsgType.VOICE_FILE:
          isSendingOrDownloading = isSend && (msg.attachment as AudioAttachment).fileState == SendState.SENDING;
          break;
        case MsgType.PICTURE:
          isSendingOrDownloading = (msg.attachment as PicAttachment).fileState == SendState.SENDING;
          break;
        case MsgType.VIDEO_FILE:
          isSendingOrDownloading = (msg.attachment as VideoAttachment).fileState == SendState.SENDING;
          break;
        case MsgType.OTHERS:
          isSendingOrDownloading = (msg.attachment as FileAttachment).fileState == SendState.SENDING;
          break;
      }
    }

    return isPrompt
        ? _buildPromptMessageWidget(msg, isSend)
        : Column(
            children: [
              SizedBox(
                height: 15,
              ),
              isShowTime
                  ? Column(
                      children: [
                        Text(
                          DateTimeUtil.formatMessageTime(msg.createTime!),
                          style: TextStyle(fontSize: 12, color: ColorUtil.COLOR_FF9A9C9C),
                        ),
                        SizedBox(
                          height: 14,
                        ),
                      ],
                    )
                  : Container(),
              Row(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.start,
                textDirection: isSend ? TextDirection.rtl : TextDirection.ltr,
                children: [
                  SizedBox(
                    width: 12,
                  ),
                  InkWell(onTap: () {
                    if (contact == null || !AppManager.instance.uiOptions.enableChatPageClickMember) return;
                    Navigator.push(context, CupertinoPageRoute(builder: (context) {
                      return ContactDetailPage(contact!);
                    }));
                  }, child: StatefulBuilder(
                    builder: (context, setState) {
                      avatarStateSetter = setState;
                      return ImageLoader(
                        url: contact == null ? null : StringUtil.getAvatarUrl(contact!),
                        defaultAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                        errorAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                        borderRadius: 4,
                        width: 40,
                        height: 40,
                        package: PACKAGE_NAME,
                      );
                    },
                  )),
                  SizedBox(
                    width: 4,
                  ),
                  Column(
                    crossAxisAlignment: isSend ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Visibility(
                        visible: isGroupChat,
                        child: StatefulBuilder(
                          builder: (context, setState) {
                            nameStateSetter = setState;
                            return Container(
                              margin: EdgeInsets.only(bottom: 3),
                              padding: EdgeInsets.only(left: 6),
                              child: Text(
                                contact?.name ?? "",
                                style: TextStyle(fontSize: 12, color: ColorUtil.COLOR_FF9A9C9C),
                              ),
                            );
                          },
                        ),
                      ),
                      Row(
                        textDirection: isSend ? TextDirection.rtl : TextDirection.ltr,
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          buildMsgContent(isSend),
                          SizedBox(
                            width: 5,
                          ),
                          Center(
                            child: Visibility(
                                visible: msg.sendState == SendState.FAILURE,
                                child: InkWell(
                                  onTap: () {
                                    showCupertinoDialog(
                                        context: context,
                                        builder: (context) {
                                          return CupertinoAlertDialog(
                                            content: Container(
                                              padding: EdgeInsets.fromLTRB(0, 20, 0, 16),
                                              child: Text(
                                                '是否重发该消息？',
                                                style: TextStyle(color: ColorUtil.color333333, fontWeight: FontWeight.bold, fontSize: 16),
                                              ),
                                            ),
                                            actions: <Widget>[
                                              CupertinoDialogAction(
                                                child: Text(
                                                  '取消',
                                                  style: TextStyle(fontSize: 16, color: ColorUtil.colorFF666666),
                                                ),
                                                onPressed: () {
                                                  Navigator.pop(context);
                                                },
                                              ),
                                              CupertinoDialogAction(
                                                child: Text('重发', style: TextStyle(fontSize: 16, color: ColorUtil.COLOR_FF1677FF)),
                                                onPressed: () {
                                                  Navigator.pop(context);
                                                  SxtMessagePlugin.resendMessage(msg).then((value) {});
                                                },
                                              ),
                                            ],
                                          );
                                        });
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    child: Image.asset("images/ic_chat_send_failed.png", width: 18, height: 18, package: PACKAGE_NAME),
                                  ),
                                )),
                          ),
                          Visibility(
                              visible: isSendingOrDownloading,
                              child: Container(
                                  width: 20,
                                  height: 20,
                                  alignment: Alignment.centerLeft,
                                  child: isSend
                                      ? ((progress == null || progress == 0)
                                          ? CircularProgressIndicator(strokeWidth: 3, valueColor: new AlwaysStoppedAnimation<Color>(ColorUtil.color3D7DFF))
                                          : CircularProgressIndicator(
                                              strokeWidth: 3,
                                              value: progress! / 100,
                                              backgroundColor: Colors.grey[200],
                                              valueColor: new AlwaysStoppedAnimation<Color>(ColorUtil.color3D7DFF),
                                            ))
                                      : CircularProgressIndicator(
                                          strokeWidth: 3,
                                          value: progress == null ? 0 : (progress! / 100),
                                          backgroundColor: Colors.grey[200],
                                          valueColor: new AlwaysStoppedAnimation<Color>(ColorUtil.color3D7DFF),
                                        ))),
                        ],
                      )
                    ],
                  ),
                ],
              ),
              SizedBox(
                height: 15,
              ),
            ],
          );
  }

  Widget buildMsgContent(bool isSelf) {
    switch (msg.msgType) {
      case MsgType.TEXT:
        {
          return _buildTextChatMessageWidget(msg, isSelf);
        }
      case MsgType.PICTURE:
        {
          return _buildPictureChatMessageWidget(msg, isSelf);
        }
      case MsgType.VIDEO_FILE:
        {
          return _buildVideoChatMessageWidget(msg, isSelf);
        }
      case MsgType.SHARE:
        {
          return _buildShareChatMessageWidget(msg, isSelf);
        }
      case MsgType.VOICE_FILE:
        {
          return _buildVoiceFileChatMessageWidget(msg, isSelf);
        }
      case MsgType.PROMPT:
        {
          return _buildPromptChatMessageWidget(msg, isSelf);
        }
      case MsgType.OTHERS:
        {
          return _buildOthersChatMessageWidget(msg, isSelf);
        }
      case MsgType.LOCATION:
        {
          return _buildLocationChatMessageWidget(msg, isSelf);
        }
      default:
        {
          return _buildNotSupportChatMessageWidget(msg, isSelf);
        }
    }
  }

  Widget _buildNotSupportChatMessageWidget(Message<Attachment> msg, bool isSelf) {
    return Bubble(
        style: isSelf ? styleMe : styleOther,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 204),
          color: isSelf ? ColorUtil.COLOR_FFCDE8FC : Colors.white,
          child: GestureDetector(
            onTap: () {},
            child: const Text(
              "暂不支持的消息类型",
              style: TextStyle(fontSize: 16, color: ColorUtil.COLOR_FF9A9C9C),
            ),
          ),
        ));
  }

  Widget _buildPromptMessageWidget(Message<Attachment> msg, bool isSelf) {
    late StateSetter setter;
    PromptAttachment attachment = msg.attachment as PromptAttachment;

    String content = "";
    switch (attachment.msgCatg) {
      case PromptType.MULTI:
        content = attachment.content ?? "";
        if (content.contains("发起")) {
          if (null != msg.sender && selfCode != msg.sender!.code) {
            DataManager.instance.getContact(msg.sender!.code!).then((value) {
              String senderName = value!.name!;
              content = senderName + attachment.content!;
              setter(() {});
            });
          } else if (isSelf) {
            content = "你" + attachment.content!;
          }
        } else if (content.contains("结束") && (attachment.during ?? 0) > 0) {
          content = content + ", 通话时长 ${DateTimeUtil.getDuration(DateTimeUtil.formatLongTime(attachment.during ?? 0))}";
        }
        break;
      case PromptType.GROUP:
        if (Platform.isAndroid) {
          if (null != attachment.memberList && attachment.memberList!.isNotEmpty) {
            content = attachment.content ?? "";
          } else {
            content = attachment.content ?? "";
            if (null != msg.sender && selfCode != msg.sender!.code) {
              if (!StringUtil.isEmpty(DomainUtil.toCode(msg.sender!.code!))) {
                DataManager.instance.getContact(DomainUtil.toCode(msg.sender!.code!)).then((value) {
                  String senderName = value!.name!;
                  content = senderName + attachment.content!;
                  setter(() {});
                });
              }
            }
          }
        } else if (Platform.isIOS) {
          if (null == attachment.memberList || attachment.memberList!.isEmpty) {
            content = attachment.content ?? "";
          } else {
            List<String> codeList = [];
            Map<String, String> nameList = {};
            attachment.memberList?.forEach((element) {
              String code = DomainUtil.toCode(element.userCode);
              if (DataManager.instance.isCacheContact(code)) {
                nameList[code] = (DataManager.instance.getContactFromCache(code)?.name) ?? "";
              } else {
                codeList.add(DomainUtil.toCode(element.userCode));
              }
            });

            if (attachment.memberList!.length == nameList.length) {
              List<String> realNameList = [];
              nameList.forEach((key, value) {
                realNameList.add(value);
              });
              content = sprintf(attachment.content!, realNameList);
            } else {
              ContactManager.instance
                  .getContactsByCodes(codeList, DataFilterBuilder())
                  .where((event) => (null != event && event.isNotEmpty))
                  .take(1)
                  .first
                  .then((value) {
                for (var element in value) {
                  nameList[element.code!] = element.name!;
                  DataManager.instance.addContactCache(element.code!, element);
                }

                final List<String> realNameList = [];
                if (attachment.content!.startsWith("%s")) {
                  final String firstName = nameList[codeList[0]]!;
                  nameList.remove(codeList[0]);
                  realNameList.add(firstName);
                }
                nameList.forEach((key, value) {
                  realNameList.add(value);
                });
                content = sprintf(attachment.content!, realNameList);

                setState(() {});
              });
            }
          }
        }
        break;
      case PromptType.REVOKE:
        if (isSelf) {
          content = "你撤回了一条消息";
        } else {
          if (msg.sender != null) {
            String? senderName = msg.sender?.name;
            if (StringUtil.isEmpty(senderName)) {
              if (null != msg.sender && selfCode != msg.sender!.code) {
                DataManager.instance.getContact(msg.sender!.code!).then((value) {
                  String senderName = value!.name!;
                  content = "\"" + senderName + "\"" + " 撤回了一条消息";
                  setter(() {});
                });
              }
            } else {
              content = "\"" + (senderName ?? "") + "\"" + " 撤回了一条消息";
            }
          } else {
            content = "对方撤回了一条消息";
          }
        }
        break;
      default:
        content = attachment.content ?? "";
        break;
    }
    return StatefulBuilder(builder: (BuildContext context, StateSetter stateSetter) {
      setter = stateSetter;
      return Container(
        margin: const EdgeInsets.only(left: 30, right: 30),
        child: Column(
          children: [
            const SizedBox(
              height: 12,
            ),
            isShowTime
                ? Text(
                    DateTimeUtil.formatMessageTime(msg.createTime!),
                    style: const TextStyle(fontSize: 12, color: ColorUtil.COLOR_FF9A9C9C),
                  )
                : Container(),
            isShowTime
                ? const SizedBox(
                    height: 14,
                  )
                : Container(),
            Container(
              padding: EdgeInsets.only(left: 16, right: 16, top: 4, bottom: 5.5),
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.all(const Radius.circular(4.0)),
                color: (attachment.msgCatg == PromptType.REVOKE) ? Colors.transparent : ColorUtil.COLOR_FFE2E5E8,
              ),
              // child: Text(
              //   content,
              //   style: TextStyle(fontSize: 12, color: ColorUtil.COLOR_FF59637C),
              // ),
              child: ExtendedText(
                content,
                joinZeroWidthSpace: true,
                selectionControls: MyTextSelectionControls(),
                style: TextStyle(fontSize: 12, color: (attachment.msgCatg == PromptType.REVOKE) ? ColorUtil.color999999 : ColorUtil.COLOR_FF59637C),
                selectionEnabled: false,
              ),
            ),
            const SizedBox(
              height: 12,
            ),
          ],
        ),
      );
    });
  }

  Widget _buildTextChatMessageWidget(Message<Attachment> msg, bool isSelf) {
    bool canRevoke = false;
    final bool isSend = msg.sender?.code == selfCode;
    if (DateTime.now().millisecondsSinceEpoch < (msg.createTime! + 120000) && isSend) {
      canRevoke = true;
    }

    return Builder(builder: (BuildContext buildContext) {
      itemBuildContext = buildContext;

      return Bubble(
          tapFunction: () {
            print(".............");
            print("hide self");
          },
          style: isSelf ? styleMe : styleOther,
          child: Container(
            constraints: const BoxConstraints(maxWidth: 204),
            child: SelectableText(
              '${(msg.attachment as TextAttachment).text}',
              selectionControls: MyMaterialTextSelectionControls(
                textLength: (msg.attachment as TextAttachment).text?.length ?? 0,
                buildContext: buildContext,
                onDeleteMsg: () {
                  _showDeleteMsgDialog();
                },
                onFavMsg: () {
                  _favMsg();
                },
                onForwardMsg: () {
                  _forwardMsg();
                },
                onRevokeMsg: canRevoke ? _showRevokeMsgDialog : null,
              ),
              onSelectionChanged: (TextSelection selection, SelectionChangedCause? cause) {
                if (selection.extentOffset - selection.baseOffset > 0) {
                  selectableTextFosusNoded = true;
                } else {
                  selectableTextFosusNoded = false;
                }
              },
              style: const TextStyle(fontSize: 16, color: Colors.black),
            ),
          ));
    });
  }

  Widget _buildPictureChatMessageWidget(Message<Attachment> msg, bool isSelf) {
    final PicAttachment attachment = msg.attachment as PicAttachment;
    bool isDownload = false;
    if (attachment.thumbFileState == SendState.SUCCESS) {
      if (!StringUtil.isEmpty(attachment.thumbPath)) {
        final File file = File(attachment.thumbPath!);
        if (file.existsSync()) {
          isDownload = true;
        }
      }
    }

    if (!isDownload && !DataManager.instance.isDownloading(msg.code!)) {
      SxtMessagePlugin.downloadMsgAttachmentThumb(msg);
      DataManager.instance.addDownloading(msg.code!);
    }

    String? imagePath = attachment.thumbPath ?? "";
    if (isDownload && !StringUtil.isEmpty(attachment.path)) {
      final File file = File(attachment.path!);
      if (file.existsSync()) {
        imagePath = attachment.path!;
      }
    }

    print("aaaa msg code :${msg.code} , isDownload : $isDownload");

    return Builder(
      builder: (BuildContext buildContext) {
        itemBuildContext = buildContext;
        return Container(
            constraints: const BoxConstraints(maxWidth: 100, maxHeight: 143),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(4)),
            child: Stack(
              children: <Widget>[
                LayoutBuilder(
                  builder: (context, constrain) {
                    return isDownload
                        ? ExtendedImage.file(
                            File(
                              imagePath!,
                            ),
                            fit: BoxFit.cover,
                            width: constrain.maxWidth,
                            height: constrain.maxHeight,
                            shape: BoxShape.rectangle,
                            borderRadius: const BorderRadius.all(Radius.circular(4.0)),
                          )
                        : Image.asset(
                            ImageHelper.wrapAssets("ic_image_holder.png"),
                            package: PACKAGE_NAME,
                            fit: BoxFit.fill,
                            width: constrain.maxWidth,
                            height: constrain.maxHeight,
                          );
                  },
                ),
                Positioned.fill(
                  child: Material(
                    color: Colors.transparent,
                    borderRadius: const BorderRadius.all(Radius.circular(4)),
                    child: InkWell(
                      borderRadius: const BorderRadius.all(Radius.circular(4)),
                      onLongPress: () {
                        _showMsgLongClickPop(buildContext);
                      },
                      onTap: () {
                        bool isImageDownload = false;
                        if (attachment.fileState == SendState.SUCCESS) {
                          if (!StringUtil.isEmpty(attachment.path)) {
                            final File file = File(attachment.path!);
                            if (file.existsSync()) {
                              isImageDownload = true;
                            }
                          }
                        }
                        if (!isImageDownload) {
                          SxtMessagePlugin.downloadMsgAttachment(msg);
                        } else {
                          KDAssetPicker.playImage(context, attachment.path!, isLocal: true);
                          // FileUtil.openFile(attachment.path!);
                        }
                      },
                    ),
                  ),
                ),
              ],
            ));
      },
    );
  }

  Widget _buildVideoChatMessageWidget(Message<Attachment> msg, bool isSelf) {
    final VideoAttachment attachment = msg.attachment as VideoAttachment;
    bool isDownload = false;
    if (attachment.thumbFileState == SendState.SUCCESS) {
      if (!StringUtil.isEmpty(attachment.thumbPath)) {
        final File file = File(attachment.thumbPath!);
        if (file.existsSync()) {
          isDownload = true;
        }
      }
    }

    if (!isDownload && !DataManager.instance.isDownloading(msg.code!)) {
      SxtMessagePlugin.downloadMsgAttachmentThumb(msg);
      DataManager.instance.addDownloading(msg.code!);
    }

    return Builder(builder: (BuildContext buildContext) {
      itemBuildContext = buildContext;
      return Container(
          constraints: const BoxConstraints(maxWidth: 100, maxHeight: 143),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(4)),
          child: Stack(
            children: <Widget>[
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    child: isDownload
                        ? LayoutBuilder(
                            builder: (context, constrain) {
                              return ExtendedImage.file(
                                File(
                                  attachment.thumbPath!,
                                ),
                                fit: BoxFit.cover,
                                width: constrain.maxWidth,
                                height: constrain.maxHeight,
                                shape: BoxShape.rectangle,
                                borderRadius: const BorderRadius.all(Radius.circular(4.0)),
                              );
                            },
                          )
                        : ImageHelper.assetImage("ic_image_holder.png"),
                  ),
                  isDownload
                      ? Container(
                          width: 30,
                          height: 30,
                          alignment: Alignment.center,
                          child: ImageHelper.assetImage("ic_video.png"),
                        )
                      : Container(),
                  isDownload
                      ? Container(
                          alignment: Alignment.bottomCenter,
                          margin: const EdgeInsets.only(bottom: 8),
                          child: Text(
                            DateTimeUtil.getDuration(DateTimeUtil.formatLongTime(attachment.duration ?? 0)),
                            style: const TextStyle(fontSize: 12, color: Colors.white),
                          ),
                        )
                      : Container()
                ],
              ),
              Positioned.fill(
                child: Material(
                  color: Colors.transparent,
                  borderRadius: const BorderRadius.all(Radius.circular(4)),
                  child: InkWell(
                    borderRadius: const BorderRadius.all(Radius.circular(4)),
                    onLongPress: () {
                      _showMsgLongClickPop(buildContext);
                    },
                    onTap: () {
                      bool isImageDownload = false;
                      if (attachment.fileState == SendState.SUCCESS) {
                        if (!StringUtil.isEmpty(attachment.path)) {
                          final File file = File(attachment.path!);
                          if (file.existsSync()) {
                            isImageDownload = true;
                          }
                        }
                      }
                      if (!isImageDownload) {
                        SxtMessagePlugin.downloadMsgAttachment(msg);
                      } else {
                        //视频直接app内预览
                        KDAssetPicker.playVideo(context, attachment.path!, true);
                        // FileUtil.openFile(attachment.path!);
                      }
                    },
                  ),
                ),
              ),
            ],
          ));
    });
  }

  Widget _buildOthersChatMessageWidget(Message<Attachment> msg, bool isSelf) {
    final FileAttachment attachment = msg.attachment as FileAttachment;

    bool isDownload = false;
    if (attachment.fileState == SendState.SUCCESS) {
      if (!StringUtil.isEmpty(attachment.path)) {
        final File file = File(attachment.path!);
        if (file.existsSync()) {
          isDownload = true;
        }
      }
    }

    var defaultImg = Container(child: ImageHelper.assetImage("ic_file_default.png"));

    final String fileName = attachment.filename ?? "";
    defaultImg = Container(child: Image.asset(FileUtil.getIconByFileType(fileName), package: PACKAGE_NAME));

    String fileSize = "";
    if ((attachment.size ?? 0) > 0) {
      fileSize = FileUtil.getFileSize(attachment.size!);
    }
    return Builder(builder: (BuildContext buildContext) {
      itemBuildContext = buildContext;
      return Bubble(
        tapFunction: () {
          if (!isDownload) {
            SxtMessagePlugin.downloadMsgAttachment(msg);
          } else {
            FileUtil.openFile(attachment.path!);
          }
        },
        longPressFunction: () {
          _showMsgLongClickPop(buildContext);
        },
        style: isSelf ? styleMeWhite : styleOther,
        child: Container(
          padding: const EdgeInsets.only(top: 6, bottom: 6),
          constraints: const BoxConstraints(maxWidth: 190),
          child: Row(
            textDirection: isSelf ? TextDirection.rtl : TextDirection.ltr,
            children: [
              Container(
                margin: const EdgeInsets.only(top: 4, left: 4, right: 4),
                alignment: Alignment.centerLeft,
                width: 36,
                height: 36,
                child: defaultImg,
              ),
              Expanded(
                  child: Column(
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.only(left: 12, bottom: 1, right: 12),
                      child: Text(fileName,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.black,
                          )),
                    ),
                  ),
                  StringUtil.isEmpty(fileSize)
                      ? Container()
                      : Align(
                          alignment: Alignment.centerLeft,
                          child: Container(
                            margin: const EdgeInsets.only(left: 12, top: 1, right: 12),
                            child: Text(fileSize,
                                textAlign: TextAlign.left,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 13,
                                  color: ColorUtil.color999999,
                                )),
                          ))
                ],
              ))
            ],
          ),
        ),
      );
    });
  }

  Widget _buildVoiceFileChatMessageWidget(Message<Attachment> msg, bool isSelf) {
    StateSetter? stateSetter;

    AudioAttachment attachment = msg.attachment as AudioAttachment;
    double maxWidth = 60;
    if (attachment.duration! >= 60000) {
      maxWidth = 170;
    } else {
      maxWidth = 60 + (110 / 60 * (attachment.duration! / 1000));
    }
    bool isPlaying = false;
    bool isDownload = false;
    if (attachment.fileState == SendState.SUCCESS) {
      if (!StringUtil.isEmpty(attachment.path)) {
        File file = File(attachment.path!);
        if (file.existsSync()) {
          isDownload = true;
        }
      }
    }
    if (!isDownload && attachment.fileState != SendState.SENDING && !DataManager.instance.isDownloading(msg.code!)) {
      SxtMessagePlugin.downloadMsgAttachment(msg);
      DataManager.instance.addDownloading(msg.code!);
    }

    SmartTransBean? smartTransBean = chatBloc?.state.smartTransList[msg.code];

    return Column(
      crossAxisAlignment: isSelf ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Builder(builder: (BuildContext buildContext) {
              itemBuildContext = buildContext;
              return Bubble(
                  longPressFunction: () {
                    _showMsgLongClickPop(buildContext);
                  },
                  style: isSelf ? styleMe : styleOther,
                  child: Container(
                    constraints: BoxConstraints(minWidth: maxWidth),
                    child: GestureDetector(
                      onTap: () {
                        bool isDownload2 = false;
                        if (attachment.fileState == SendState.SUCCESS) {
                          if (!StringUtil.isEmpty(attachment.path)) {
                            File file = File(attachment.path!);
                            if (file.existsSync()) {
                              isDownload2 = true;
                            }
                          }
                        }
                        if (!isDownload2) {
                          SxtLogger.instance.info("ChatMessageWidget downloadMsgAttachment msg code ${msg.code.toString()}");
                          SxtMessagePlugin.downloadMsgAttachment(msg);
                        } else {
                          if (AudioManager.instance.isPlaying(attachment.path!)) {
                            SxtLogger.instance.info("ChatMessageWidget stop play audio msg code ${msg.code.toString()}");
                            AudioManager.instance.stop();
                            isPlaying = false;
                            if (null != stateSetter && mounted) {
                              stateSetter!(() {});
                            }
                          } else {
                            SxtLogger.instance.info("ChatMessageWidget start play audio msg code ${msg.code.toString()}");
                            AudioManager.instance.play(
                                attachment.path!,
                                PlayListener(onCompleted: () {
                                  SxtLogger.instance.info("PlayListener onCompleted " + attachment.path!);
                                  isPlaying = false;
                                  AudioManager.instance.stop();
                                  if (null != stateSetter && mounted) {
                                    stateSetter!(() {});
                                  }
                                }, onLoading: () {
                                  SxtLogger.instance.info("PlayListener onLoading " + attachment.path!);
                                  isPlaying = true;
                                  if (null != stateSetter && mounted) {
                                    stateSetter!(() {});
                                  }
                                }, onIdled: () {
                                  SxtLogger.instance.info("PlayListener onIdled " + attachment.path!);
                                  isPlaying = false;
                                  if (null != stateSetter && mounted) {
                                    stateSetter!(() {});
                                  }
                                }));
                            if (!(msg.isRead ?? false)) {
                              SxtMessagePlugin.setReadMark(msg).then((value) {
                                msg.isRead = true;
                                if (null != readMarkStateSetter) {
                                  readMarkStateSetter!(() {});
                                }
                              });
                            }
                          }
                        }
                      },
                      child: Row(
                        textDirection: isSelf ? TextDirection.rtl : TextDirection.ltr,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          StatefulBuilder(builder: (context, setState) {
                            stateSetter = setState;
                            return Container(
                              width: 20,
                              height: 20,
                              margin: EdgeInsets.only(right: 4),
                              child: isPlaying
                                  ? ImagesAnimation(entry: ImagesAnimationEntry(1, 3, isSelf ? "images/ic_play_voice_right_" : "images/ic_play_voice_"))
                                  : ImageHelper.assetImage(isSelf ? "ic_play_voice_right_3.png" : "ic_play_voice_3.png"),
                            );
                          }),
                          Text(
                            DateTimeUtil.fromeLongTime(attachment.duration!),
                            style: TextStyle(fontSize: 16, color: Colors.black),
                          )
                        ],
                      ),
                    ),
                  ));
            }),
            Container(
              margin: EdgeInsets.only(left: 6),
              child: StatefulBuilder(builder: (context, setState) {
                readMarkStateSetter = setState;
                return Visibility(
                    visible: !isSelf && (msg.msgType == MsgType.VOICE_FILE) && (!msg.isRead!),
                    child: Container(width: 10, height: 10, alignment: Alignment.centerLeft, child: ImageHelper.assetImage("ic_red_point.png")));
              }),
            )
          ],
        ),
        Builder(builder: (BuildContext voiceTextContext) {
          return Visibility(
            visible: (smartTransBean?.state ?? 2) != 2,
            child: Container(
              margin: EdgeInsets.only(top: 6, right: isSelf ? 11 : 0, left: isSelf ? 0 : 5),
              width: maxWidth + 20,
              child: Material(
                color: Colors.white,
                borderRadius: const BorderRadius.all(Radius.circular(4)),
                child: InkWell(
                    highlightColor: ColorUtil.COLOR_E5E5E5,
                    borderRadius: const BorderRadius.all(Radius.circular(4)),
                    onLongPress: () {
                      _showHideTransLongClickPop(widgetBuildContext, voiceTextContext);
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        smartTransBean?.text ?? "",
                        style: const TextStyle(fontSize: 16, color: ColorUtil.color333333),
                      ),
                    )),
              ),
            ),
          );
        })
      ],
    );
  }

  Widget _buildPromptChatMessageWidget(Message<Attachment> msg, bool isSelf) {
    PromptAttachment promptAttachment = msg.attachment as PromptAttachment;
    if (promptAttachment.msgCatg == PromptType.VIDEO || promptAttachment.msgCatg == PromptType.VOICE) {
      return Builder(builder: (BuildContext buildContext) {
        itemBuildContext = buildContext;
        return Bubble(
            longPressFunction: () {
              _showMsgLongClickPop(buildContext);
            },
            style: isSelf ? styleMe : styleOther,
            child: Container(
              constraints: BoxConstraints(maxWidth: 204),
              child: GestureDetector(
                onTap: () {
                  if (isSelf) {
                    DataManager.instance.getContact(msg.talker!.code!).then((value) {
                      if (promptAttachment.msgCatg == PromptType.VIDEO) {
                        FlutterManager.instance.startVideoCall(value!);
                      } else if (promptAttachment.msgCatg == PromptType.VOICE) {
                        FlutterManager.instance.startVoiceCall(value!);
                      }
                    });
                  } else {
                    if (promptAttachment.msgCatg == PromptType.VIDEO) {
                      FlutterManager.instance.startVideoCall(contact!);
                    } else if (promptAttachment.msgCatg == PromptType.VOICE) {
                      FlutterManager.instance.startVoiceCall(contact!);
                    }
                  }
                },
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Visibility(
                        visible: !isSelf,
                        child: Container(
                          width: 22,
                          height: 22,
                          margin: EdgeInsets.only(right: 4),
                          child: ImageHelper.assetImage(promptAttachment.msgCatg == PromptType.VIDEO ? "ic_video_call_empty.png" : "ic_chattype_phone.png"),
                        )),
                    Text(
                      promptAttachment.during == 0
                          ? promptAttachment.content ?? ""
                          : "通话时长：${DateTimeUtil.getDuration(DateTimeUtil.formatLongTime(promptAttachment.during ?? 0))}",
                      style: TextStyle(fontSize: 16, color: Colors.black, height: 1.2),
                    ),
                    Visibility(
                        visible: isSelf,
                        child: Container(
                          width: 22,
                          height: 22,
                          margin: EdgeInsets.only(left: 4),
                          child: ImageHelper.assetImage(promptAttachment.msgCatg == PromptType.VIDEO ? "ic_video_call_empty.png" : "ic_chattype_phone.png"),
                        ))
                  ],
                ),
              ),
            ));
      });
    } else if (promptAttachment.msgCatg == PromptType.POKE) {
      return Builder(builder: (BuildContext buildContext) {
        itemBuildContext = buildContext;
        return Bubble(
            longPressFunction: () {
              _showMsgLongClickPop(buildContext);
            },
            style: isSelf ? styleMe : styleOther,
            child: Container(
              constraints: BoxConstraints(maxWidth: 204),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Visibility(
                      visible: !isSelf,
                      child: Container(
                        width: 22,
                        height: 22,
                        margin: EdgeInsets.only(right: 4),
                        child: ImageHelper.assetImage("ic_msg_poke.png"),
                      )),
                  Text(
                    isSelf ? "你戳了他一下" : "他戳了你一下",
                    style: TextStyle(fontSize: 16, color: Colors.black, height: 1.2),
                  ),
                  Visibility(
                      visible: isSelf,
                      child: Container(
                        width: 22,
                        height: 22,
                        margin: EdgeInsets.only(left: 4),
                        child: ImageHelper.assetImage("ic_msg_poke.png"),
                      ))
                ],
              ),
            ));
      });
    }
    return _buildNotSupportChatMessageWidget(msg, isSelf);
  }

  Widget _buildShareChatMessageWidget(Message<Attachment> msg, bool isSelf) {
    ShareAttachment shareAttachment = msg.attachment as ShareAttachment;
    return Builder(builder: (BuildContext buildContext) {
      itemBuildContext = buildContext;
      return Bubble(
          longPressFunction: () {
            _showMsgLongClickPop(buildContext);
          },
          style: isSelf ? styleMe : styleOther,
          child: Container(
            constraints: BoxConstraints(maxWidth: 204),
            child: GestureDetector(
              onTap: () {},
              child: Row(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ImageLoader(
                    url: shareAttachment.imgUrl ?? "",
                    defaultAssetImg: ImageHelper.wrapAssets("ic_device.png"),
                    errorAssetImg: ImageHelper.wrapAssets("ic_device.png"),
                    borderRadius: 4,
                    width: 36,
                    height: 36,
                    package: PACKAGE_NAME,
                  ),
                  Expanded(
                      child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Container(
                          margin: EdgeInsets.only(left: 8, bottom: 4, right: 8),
                          child: Text(shareAttachment.title ?? "",
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.black,
                              )),
                        ),
                      ),
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Container(
                            margin: EdgeInsets.only(left: 8, right: 8),
                            child: Text(shareAttachment.desc ?? "",
                                textAlign: TextAlign.left,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 13,
                                  color: ColorUtil.color999999,
                                )),
                          ))
                    ],
                  ))
                ],
              ),
            ),
          ));
    });
  }

  Widget _buildLocationChatMessageWidget(Message<Attachment> msg, bool isSelf) {
    LocationAttachment attachment = msg.attachment as LocationAttachment;
    bool isDownload = false;
    if (attachment.fileState == SendState.SUCCESS || isSelf) {
      if (!StringUtil.isEmpty(attachment.path)) {
        File file = File(attachment.path!);
        if (file.existsSync()) {
          isDownload = true;
        }
      }
    }

    if (!isDownload && !DataManager.instance.isDownloading(msg.code!)) {
      SxtMessagePlugin.downloadMsgAttachment(msg);
      DataManager.instance.addDownloading(msg.code!);
    }
    double itemHeight = 159;
    double itemWidth = 212;
    var defaultImg = Container(width: itemWidth, height: itemHeight, child: ImageHelper.assetImage("ic_image_holder.png"));
    return Builder(builder: (BuildContext buildContext) {
      itemBuildContext = buildContext;
      return Container(
          constraints: BoxConstraints(maxWidth: itemWidth, maxHeight: itemHeight),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(4)),
          child: Stack(
            children: <Widget>[
              Container(
                child: Column(
                  children: [
                    Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        decoration:
                            BoxDecoration(color: Colors.white, borderRadius: BorderRadius.only(topLeft: Radius.circular(4), topRight: Radius.circular(4))),
                        // height: 55,
                        width: itemWidth,
                        padding: EdgeInsets.only(left: 12, right: 12, top: 4, bottom: 4),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              attachment.name ?? "",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: ColorUtil.color333333,
                                fontSize: 16,
                              ),
                            ),
                            SizedBox(
                              height: 3,
                            ),
                            Text(
                              attachment.address ?? "",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: ColorUtil.color999999, fontSize: 12),
                            )
                          ],
                        ),
                      ),
                    ),
                    Expanded(
                      child: Stack(
                        children: [
                          !isDownload
                              ? defaultImg
                              : ImageLoader(
                                  url: attachment.path ?? "",
                                  defaultAssetImg: ImageHelper.wrapAssets("ic_image_holder.png"),
                                  errorAssetImg: ImageHelper.wrapAssets("ic_image_holder.png"),
                                  borderRadius: 4,
                                  isLocal: true,
                                ),
                          Visibility(
                              visible: attachment.fileState == SendState.SENDING && !isSelf,
                              child: Center(
                                child: CircularProgressIndicator(value: (progress == null || progress == 0) ? 0 : progress! / 100),
                              ))
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Positioned.fill(
                child: Material(
                  color: Colors.transparent,
                  borderRadius: const BorderRadius.all(Radius.circular(4)),
                  child: InkWell(
                    borderRadius: const BorderRadius.all(Radius.circular(4)),
                    onLongPress: () {
                      _showMsgLongClickPop(buildContext);
                    },
                    onTap: () {
                      GcoordResult gcoordResult = CoordTransform.transformWGS84toGCJ02(attachment.longitude ?? 0.0, attachment.latitude ?? 0.0);

                      KdFlutterMapManager.getInstance().initLocationOptions(AMapLocationOption(locationInterval: 5000));
                      KdFlutterMapManager.getInstance().showMyLocation(
                        context,
                        PoiBean(
                          name: attachment.name,
                          address: attachment.address,
                          la: gcoordResult.lat.toString(),
                          lo: gcoordResult.lon.toString(),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ));
    });
  }

  _showDeleteMsgDialog() {
    showDialog(
        context: AppManager.instance.globalKey!.currentContext!,
        builder: (context) {
          return HintDialog(
            content: '是否删除该条消息?',
            onPositiveClicked: () {
              SxtMessagePlugin.deleteMessage(msg).then((value) {
                chatBloc?.add(DeleteMsg(msg));
              });
            },
          );
        });
  }

  _showRevokeMsgDialog() {
    showModalBottomSheet(
        barrierColor: ColorUtil.COLOR_33000000,
        backgroundColor: Colors.transparent,
        context: AppManager.instance.globalKey!.currentContext!,
        builder: (BuildContext buildContext) {
          return Container(
              height: Platform.isAndroid ? 140 : 140 + MediaQuery.of(buildContext).padding.bottom,
              child: Column(
                children: [
                  SizedBox(
                    height: 44,
                    child: Align(
                      alignment: Alignment.center,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            padding: EdgeInsets.only(bottom: 2),
                            child: Text('是否撤回该条消息？', style: TextStyle(color: CustomColors.cl_666666, fontSize: 12)),
                          )
                        ],
                      ),
                    ),
                  ),
                  Container(
                    height: 1,
                    color: CustomColors.cl_F5F5F5,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.pop(AppManager.instance.globalKey!.currentContext!);

                      if (DateTime.now().millisecondsSinceEpoch > (msg.createTime! + 120000)) {
                        return;
                      }

                      SxtMessagePlugin.revokeMessage(msg).then((value) {
                        chatBloc?.add(DeleteMsg(msg));
                      });
                    },
                    child: SizedBox(
                      height: 44,
                      child: Align(
                        alignment: Alignment.center,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: EdgeInsets.only(bottom: 2),
                              child: Text('确定', style: TextStyle(color: ColorUtil.COLOR_FFFF4B34, fontSize: 16)),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 4,
                    color: CustomColors.cl_F5F5F5,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.pop(AppManager.instance.globalKey!.currentContext!);
                    },
                    child: SizedBox(
                      height: 46,
                      child: Align(
                        alignment: Alignment.center,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [Text('取消', style: TextStyle(color: CustomColors.cl_333333, fontSize: 16))],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: Platform.isAndroid ? 0 : MediaQuery.of(buildContext).padding.bottom,
                    width: MediaQuery.of(buildContext).size.width,
                    color: Colors.white,
                  )
                ],
              ),
              decoration:
                  const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10))));
        });
  }

  _showMsgLongClickPop(BuildContext buildContext) {
    List<MenuItem> itemList = [];
    bool isSend = msg.sender?.code == selfCode;

    if (msg.msgType != MsgType.PROMPT) {
      if (DateTime.now().millisecondsSinceEpoch < (msg.createTime! + 120000) && isSend) {
        itemList.add(PopupMenu.getMenuItem("撤销", "ic_msg_revoke.png"));
      }
      itemList.add(PopupMenu.getMenuItem("收藏", "ic_msg_fav.png"));
      if (msg.msgType != MsgType.VOICE_FILE) {
        itemList.add(PopupMenu.getMenuItem("转发", "ic_msg_forward.png"));
      }

      final SmartTransBean? smartTransBean = chatBloc?.state.smartTransList[msg.code];
      if (msg.msgType == MsgType.VOICE_FILE && AppManager.instance.uiOptions.enableTransVoiceToText && (smartTransBean?.state ?? 2) == 2) {
        itemList.add(PopupMenu.getMenuItem("转文字", "ic_voice_to_text.png"));
      }
    }
    itemList.add(PopupMenu.getMenuItem("删除", "ic_delete_msg.png"));

    final PopupMenu menu = PopupMenu(
        items: itemList,
        onClickMenu: (MenuItemProvider item) {
          switch (item.menuTitle) {
            case "删除":
              _showDeleteMsgDialog();
              break;
            case "撤销":
              _showRevokeMsgDialog();
              break;
            case "收藏":
              _favMsg();
              break;
            case "转发":
              _forwardMsg();
              break;
            case "转文字":
              chatBloc?.add(TransVoiceToText(msg));
              break;
          }
        },
        onDismiss: () {},
        maxColumn: itemList.length,
        highlightColor: const Color(0x55000000),
        context: buildContext,
        backgroundColor: ColorUtil.COLOR_FF4C4C4C,
        stateChanged: (PopupMenu popMenu, bool isShow) {
          // print("PopupMenu stateChanged isShow: ${isShow}");
          //
          // if (isShow) {
          //   receiveMsgStreamSubscription?.cancel();
          //   receiveMsgStreamSubscription = SxtEventBusManager.instance.eventBus?.on<ReceiveMsgEvent>().listen((event) {
          //     popMenu.dismiss();
          //   });
          // } else {
          //   receiveMsgStreamSubscription?.cancel();
          // }
        },
        lineColor: Colors.transparent);

    RenderBox renderBox = itemBuildContext?.findRenderObject() as RenderBox;
    var offset = renderBox.localToGlobal(Offset.zero);
    Rect rect = Rect.fromLTWH(offset.dx, offset.dy, renderBox.size.width, renderBox.size.height);
    menu.show(rect: rect);
  }

  _favMsg() {
    FavMsgHelper.favMsg(msg);
  }

  void _forwardMsg() {
    ForwardMsgHelper.forwardMsg(AppManager.instance.globalKey!.currentContext!, msg.attachment!);
  }

  _showHideTransLongClickPop(BuildContext buildContext, BuildContext voiceTextContext) {
    PopupMenu menu = PopupMenu(
        items: [
          MenuItem(
              title: '隐藏',
              image: Image.asset(
                ImageHelper.wrapAssets("ic_trans_hide.png"),
                package: PACKAGE_NAME,
                fit: BoxFit.fill,
                width: 16,
                height: 16,
              ),
              textAlign: TextAlign.center,
              textStyle: TextStyle(fontSize: 12, color: Colors.white)),
          PopupMenu.getMenuItem("转发", "ic_msg_forward.png")
        ],
        onClickMenu: (MenuItemProvider item) {
          switch (item.menuTitle) {
            case "隐藏":
              chatBloc?.add(HideTrans(msg));
              break;
            case "转发":
              final SmartTransBean? smartTransBean = chatBloc?.state.smartTransList[msg.code];
              final TextAttachment attachment = TextAttachment(text: smartTransBean?.text ?? "");
              ForwardMsgHelper.forwardMsg(buildContext, attachment);
              break;
          }
        },
        onDismiss: () {},
        maxColumn: 2,
        highlightColor: Color(0x55000000),
        context: buildContext,
        backgroundColor: ColorUtil.COLOR_FF4C4C4C,
        stateChanged: (PopupMenu popMenu, bool isShow) {
          // if (isShow) {
          //   receiveMsgStreamSubscription?.cancel();
          //   receiveMsgStreamSubscription = SxtEventBusManager.instance.eventBus?.on<ReceiveMsgEvent>().listen((event) {
          //     popMenu.dismiss();
          //   });
          // } else {
          //   receiveMsgStreamSubscription?.cancel();
          // }
        },
        lineColor: Colors.transparent);

    RenderBox renderBox = voiceTextContext.findRenderObject() as RenderBox;
    var offset = renderBox.localToGlobal(Offset.zero);
    Rect rect = Rect.fromLTWH(offset.dx, offset.dy, renderBox.size.width, renderBox.size.height);
    menu.show(rect: rect);
  }

  @override
  void dispose() {
    if (msg.attachment != null) {
      if (msg.attachment is ShareAttachment) {
        ShareAttachment attachment = msg.attachment as ShareAttachment;
        if (attachment.imgUrl != null) {
          CachedNetworkImage.evictFromCache(attachment.imgUrl!);
        }
      }
    }
    FileUtil.clearImageCache();
    super.dispose();
  }
}
