import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:flutter/services.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/manager/log/logger.dart';
import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/group/listener/group_avatar_state_update_listener.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_manager.dart';
import 'package:sxt_flutter_plugin/message/model/send_state.dart';
import 'package:sxt_flutter_plugin/model/job.dart';

part 'group_list_event.dart';

part 'group_list_state.dart';

class GroupListBloc extends Bloc<GroupListEvent, GroupListState> {
  final String? initKeyword;
  Job? groupAvatarStateJob;
  bool isLoading = true;

  GroupListBloc(this.initKeyword) : super(GroupListState.initial());

  void inital() {
    if (StringUtil.isEmpty(initKeyword)) {
      add(Initial());
    } else {
      add(SearchGroup(initKeyword!));
    }

    SxtGroupPlugin.setGroupAvatarStateUpdateListener(
        GroupAvatarStateUpdateListener(onChanged: (data) {
      SxtLogger.instance.info("群组信息变更:" + data.toString());
      if (data.group!.avatarThumbState == SendState.SUCCESS) {
        add(UpdateGroup(data.group!));
      }
    })).then((value) {
      groupAvatarStateJob = value;
      SxtLogger.instance.info('注册下载群组头像状态变更事件监听成功' + value.toString());
    }).onError((e, stackTrace) {
      if (e is PlatformException) {
        SxtLogger.instance.info(
            "注册下载群组头像状态变更事件监听失败  errorCode：${e.code} ,message: ${e.message} , detail: ${e.details.toString()}");
      }
      print(stackTrace);
    });
  }

  @override
  Future<void> close() {
    if (null != groupAvatarStateJob) {
      SxtManager.instance.cancelJob(groupAvatarStateJob!.jobId!).then((value) {
        print("解绑头像监听成功");
      });
    }
    return super.close();
  }

  @override
  Stream<GroupListState> mapEventToState(GroupListEvent event) async* {
    if (event is Initial) {
      yield* _mapInitialEventState(event);
    } else if (event is SearchGroup) {
      yield* _mapSearchGroupEventState(event);
    } else if (event is UpdateGroup) {
      yield* _mapUpdateGroupEventState(event);
    }
  }

  Stream<GroupListState> _mapInitialEventState(Initial event) async* {
    try {
      Job<List<Group>> job = await SxtGroupPlugin.getSelfGroupList();
      isLoading = false;
      yield state.copyWith(groupList: job.data);
    } catch (e) {
      isLoading = false;
      print(e);
    }
  }

  Stream<GroupListState> _mapUpdateGroupEventState(UpdateGroup event) async* {
    for (int i = 0; i < state.groupList!.length; i++) {
      if (event.group.groupCode == state.groupList![i].groupCode) {
        state.groupList![i] = event.group;
        yield state.copyWith(status: EventStatus.update);
        break;
      }
    }
  }

  Stream<GroupListState> _mapSearchGroupEventState(SearchGroup event) async* {
    if (StringUtil.isEmpty(event.keyword)) {
      add(Initial());
      return;
    }

    try {
      Job<List<Group>> job = await SxtGroupPlugin.searchGroup(event.keyword);
      isLoading = false;
      yield state.copyWith(groupList: job.data);
    } catch (e) {
      isLoading = false;
      print(e);
    }
  }
}
