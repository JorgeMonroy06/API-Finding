import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/strong_reminder/strong_reminder_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/switch_item.dart';
import 'package:intl/intl.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

class StrongReminderItem extends StatelessWidget {
  StrongReminderItem(this.sessionEntity, {Key? key}) : super(key: key);

  final SessionEntity sessionEntity;

  final _dateFormat = DateFormat.Hm();

  @override
  Widget build(BuildContext context) =>
      BlocBuilder<StrongReminderBloc, StrongReminderState>(
        builder: (context, state) {
          final bloc = context.read<StrongReminderBloc>();
          final milliseconds = bloc.state.strongReminder[sessionEntity.code];
          final now = DateTime.now();
          DateTime date = now.add(const Duration(hours: 4));
          if (milliseconds != null) {
            final lastDate = DateTime.fromMillisecondsSinceEpoch(milliseconds);
            if (lastDate.isAfter(now)) {
              date = lastDate;
            } else {
              bloc.add(StrongReminderSwitchEvent(sessionEntity, false));
            }
          }
          final value = bloc.isStrongReminder(sessionEntity);
          return SwitchItem(
            title: '强提醒',
            content: value ? '将提醒 ${_dateFormat.format(date)} 前的第一条消息' : null,
            value: value,
            onChanged: (value) =>
                bloc.add(StrongReminderSwitchEvent(sessionEntity, value, date)),
          );
        },
      );
}
