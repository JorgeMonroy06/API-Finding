import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/action_button.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';

class SearchAppBar extends StatefulWidget {
  const SearchAppBar({
    Key? key,
    this.autofocus = false,
    this.onChanged,
    this.onPressed,
  }) : super(key: key);

  final bool autofocus;
  final ValueChanged<String>? onChanged;
  final VoidCallback? onPressed;

  @override
  State<SearchAppBar> createState() => _SearchAppBarState();
}

class _SearchAppBarState extends State<SearchAppBar> {
  final _editingController = TextEditingController();

  @override
  void dispose() {
    _editingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnnotatedRegion(
        value: SystemUiOverlayStyle.dark,
        child: Container(
          color: Colors.grey[100],
          padding: const EdgeInsets.only(left: 10, top: 8, bottom: 8),
          child: SafeArea(
            bottom: false,
            child: SizedBox(
              height: 34,
              width: double.infinity,
              child: Row(
                children: [
                  Expanded(
                    child: Material(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(6),
                      child: Row(
                        children: [
                          const SizedBox(width: 10),
                          Image.asset(
                            'images/ic_search_grey.png',
                            package: PACKAGE_NAME,
                          ),
                          Expanded(
                            child: TextField(
                              controller: _editingController,
                              autofocus: widget.autofocus,
                              onChanged: (text) {
                                widget.onChanged?.call(text);
                                setState(() {});
                              },
                              style: TextStyle(
                                color: Colors.grey[850],
                                fontSize: 14,
                              ),
                              decoration: const InputDecoration(
                                contentPadding:
                                    EdgeInsets.symmetric(horizontal: 4),
                                border: OutlineInputBorder(
                                  borderSide: BorderSide.none,
                                ),
                                hintText: '搜索',
                                hintStyle: TextStyle(color: Colors.grey),
                              ),
                            ),
                          ),
                          if (_editingController.text.isNotEmpty)
                            InkResponse(
                              onTap: () {
                                widget.onChanged?.call('');
                                _editingController.text = '';
                                setState(() {});
                              },
                              child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: Image.asset(
                                  'images/ic_clear.png',
                                  package: PACKAGE_NAME,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                  ActionButton(
                    width: 60,
                    height: double.infinity,
                    text: '取消',
                    onPressed: widget.onPressed,
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}
