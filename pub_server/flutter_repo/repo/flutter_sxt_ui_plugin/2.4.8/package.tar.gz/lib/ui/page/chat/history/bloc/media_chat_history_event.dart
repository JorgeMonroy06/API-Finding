part of 'media_chat_history_bloc.dart';

@immutable
abstract class MediaChatHistoryEvent {}

class MediaChatHistoryInitEvent extends MediaChatHistoryEvent {}

class MediaChatHistoryLoadEvent extends MediaChatHistoryEvent {}

class MediaChatHistorySearchEvent extends MediaChatHistoryEvent {
  final bool isSearch;

  MediaChatHistorySearchEvent(this.isSearch);
}

class MediaChatHistoryKeywordEvent extends MediaChatHistoryEvent {
  final String keyword;

  MediaChatHistoryKeywordEvent(this.keyword);
}

class MediaChatHistoryResultEvent extends MediaChatHistoryEvent {}
