part of 'group_member_chat_history_bloc.dart';

@immutable
abstract class GroupMemberChatHistoryEvent {}

class GroupMemberChatHistoryInitEvent extends GroupMemberChatHistoryEvent {}

class GroupMemberChatHistoryLoadEvent extends GroupMemberChatHistoryEvent {}

class GroupMemberChatHistorySearchEvent extends GroupMemberChatHistoryEvent {
  final bool isSearch;

  GroupMemberChatHistorySearchEvent(this.isSearch);
}

class GroupMemberChatHistoryKeywordEvent extends GroupMemberChatHistoryEvent {
  final String keyword;

  GroupMemberChatHistoryKeywordEvent(this.keyword);
}

class GroupMemberChatHistoryResultEvent extends GroupMemberChatHistoryEvent {}
