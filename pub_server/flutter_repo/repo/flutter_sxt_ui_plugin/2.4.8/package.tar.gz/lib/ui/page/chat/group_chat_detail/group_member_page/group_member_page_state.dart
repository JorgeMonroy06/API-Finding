part of 'group_member_page_bloc.dart';

class GroupMemberPageState {
  final EventStatus? status;
  final String? failedMessage;
  final List<Contact>? groupMemberList;
  final List<IndexedGroupMember>? indexedGroupMemberList;

  const GroupMemberPageState({
    @required this.status,
    @required this.failedMessage,
    @required this.groupMemberList,
    @required this.indexedGroupMemberList,
  });

  GroupMemberPageState.initial()
      : this(
            status: EventStatus.nothing,
            failedMessage: null,
            groupMemberList: null,
            indexedGroupMemberList: null);

  GroupMemberPageState copyWith(
      {EventStatus? status,
      String? failedMessage,
      List<Contact>? groupMemberList,
      List<IndexedGroupMember>? indexedGroupMemberList}) {
    return GroupMemberPageState(
      status: status ?? EventStatus.nothing,
      failedMessage: failedMessage ?? this.failedMessage,
      groupMemberList: groupMemberList ?? this.groupMemberList,
      indexedGroupMemberList:
          indexedGroupMemberList ?? this.indexedGroupMemberList,
    );
  }
}
