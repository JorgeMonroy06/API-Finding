part of 'group_list_bloc.dart';

class GroupListState {
  final List<Group>? groupList;
  final EventStatus? status;

  const GroupListState({
    @required this.groupList,
    @required this.status,
  });

  GroupListState.initial() : this(groupList: null, status: EventStatus.nothing);

  GroupListState copyWith({List<Group>? groupList, EventStatus? status}) {
    return GroupListState(
        groupList: groupList ?? this.groupList,
        status: status ?? EventStatus.nothing);
  }
}
