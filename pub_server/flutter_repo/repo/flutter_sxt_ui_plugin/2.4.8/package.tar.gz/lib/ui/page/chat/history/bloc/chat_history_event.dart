part of 'chat_history_bloc.dart';

@immutable
abstract class ChatHistoryEvent {}

class ChatHistoryInitEvent extends ChatHistoryEvent {}

class ChatHistoryKeywordEvent extends ChatHistoryEvent {
  final String keyword;

  ChatHistoryKeywordEvent(this.keyword);
}

class ChatHistoryResultEvent extends ChatHistoryEvent {}
