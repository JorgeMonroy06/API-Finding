import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:dartx/dartx.dart';
import 'package:flutter_easyrefresh/easy_refresh.dart';
import 'package:intl/intl.dart';
import 'package:meta/meta.dart';
import 'package:rxdart/rxdart.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';
import 'package:sxt_flutter_plugin/message/model/query_msg_param.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';
import 'package:sxt_flutter_plugin/model/job.dart';

part 'media_chat_history_event.dart';
part 'media_chat_history_state.dart';

class MediaChatHistoryBloc
    extends Bloc<MediaChatHistoryEvent, MediaChatHistoryState> {
  MediaChatHistoryBloc(this.sessionEntity, this.type)
      : super(MediaChatHistoryState());
  final SessionEntity sessionEntity;
  final MediaType type;

  final refreshController = EasyRefreshController();
  final msgList = <Message>[];

  final _sreamController = StreamController<String>();
  StreamSubscription? _streamSubscription;

  final _dateFormat = DateFormat('yyyy年M月');

  @override
  Future<void> close() {
    _sreamController.close();
    _streamSubscription?.cancel();
    refreshController.dispose();
    return super.close();
  }

  @override
  Stream<MediaChatHistoryState> mapEventToState(
      MediaChatHistoryEvent event) async* {
    if (event is MediaChatHistoryInitEvent) {
      _listenKeywordChange();
      yield* _getMediaChatHistoryState();
    } else if (event is MediaChatHistoryLoadEvent) {
      yield* _getMediaChatHistoryState();
    } else if (event is MediaChatHistorySearchEvent) {
      if (event.isSearch) {
        yield MediaChatHistoryState('', state.msgList, state.noMore);
      } else {
        yield* _getMediaChatHistoryState();
      }
    } else if (event is MediaChatHistoryKeywordEvent) {
      _sreamController.add(event.keyword);
    } else if (event is MediaChatHistoryResultEvent) {
      yield MediaChatHistoryState(state.keyword, state.msgList, state.noMore);
    }
  }

  void _listenKeywordChange() {
    _streamSubscription = _sreamController.stream
        .debounceTime(300.milliseconds)
        .switchMap(_loadMessageList)
        .listen((msgList) => add(MediaChatHistoryResultEvent()));
  }

  Stream<MediaChatHistoryState> _getMediaChatHistoryState() async* {
    yield* _loadMessageList().map((e) =>
        MediaChatHistoryState(state.keyword, state.msgList, state.noMore));
  }

  Stream<List<Message>> _loadMessageList([String? keyword]) async* {
    if (keyword != state.keyword) msgList.clear();
    state.keyword = keyword;

    final params = QueryMsgParam();
    params.msgCount = type == MediaType.file ? 50 : 100;
    params.keyword = keyword ?? '';
    params.userCode = sessionEntity.code;
    params.sessionType = sessionEntity.sessionType;
    if (msgList.isEmpty) {
      params.msgCode = 0;
      params.msgTime = 0;
    } else {
      final lastMsg = msgList.last;
      params.msgCode = lastMsg.code ?? 0;
      params.msgTime = lastMsg.createTime ?? 0;
    }

    Job<List<Message>> job;
    if (type == MediaType.file) {
      job = await SxtMessagePlugin.getFileMsgsByKey(params);
    } else {
      job = await SxtMessagePlugin.getMediaMsgs(params);
    }
    msgList.addAll(job.data!);
    state.msgList = msgList.groupBy((e) =>
        _dateFormat.format(DateTime.fromMillisecondsSinceEpoch(e.createTime!)));
    state.noMore = job.data!.length < params.msgCount!;
    yield job.data!;
  }
}

enum MediaType {
  file,
  media,
}
