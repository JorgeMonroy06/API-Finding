part of 'connection_bloc.dart';

class ConnectionState {
  final ConnectionStatus status;

  ConnectionState([this.status = ConnectionStatus.connected]);
}

enum ConnectionStatus {
  kicked,
  signout,
  connected,
  disconnected,
}
