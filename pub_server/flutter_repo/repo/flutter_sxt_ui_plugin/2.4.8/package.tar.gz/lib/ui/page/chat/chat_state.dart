part of 'chat_bloc.dart';

class ChatState {
  late MessageListBean msgList;
  late MessageListBean historyMsgList;
  late int unReadCount;
  late Contact? contact;
  late Group? group;
  late int? groupMemberCount;
  late SxtAccount? currentAccount;
  late EventStatus status;
  late String? message;
  late Message? refreshMessage;
  late bool? canScrollList;
  late Map<int, double> fileProgressMap;
  late bool hasPreviousPageMessage; //是否还有上一页聊天记录
  late bool hasNextPageMessage; //是否还有下一页聊天记录
  late bool isLoadHistoryMessageOperate;
  late bool isLoadNextPageMessageOperate;
  late bool isMultiCalling;
  late bool isAcceptCalling;
  late String multiMeetingCode;
  late bool isMultiMeetingVideo;
  late Map<int, SmartTransBean> smartTransList;
  late SessionEntity? pttSpeaker;

  ChatState init() {
    return ChatState()
      ..msgList = MessageListBean([])
      ..historyMsgList = MessageListBean([])
      ..unReadCount = 0
      ..unReadCount = 0
      ..contact = null
      ..hasPreviousPageMessage = true
      ..hasNextPageMessage = true
      ..group = null
      ..groupMemberCount = 0
      ..status = EventStatus.nothing
      ..currentAccount = null
      ..message = null
      ..refreshMessage = null
      ..canScrollList = false
      ..isLoadHistoryMessageOperate = false
      ..isLoadNextPageMessageOperate = false
      ..fileProgressMap = {}
      ..isMultiCalling = false
      ..isAcceptCalling = false
      ..multiMeetingCode = ""
      ..isMultiMeetingVideo = false
      ..pttSpeaker = null
      ..smartTransList = {};
  }

  ChatState clone() {
    return ChatState()
      ..msgList = this.msgList
      ..historyMsgList = this.historyMsgList
      ..unReadCount = this.unReadCount
      ..contact = this.contact
      ..group = this.group
      ..hasPreviousPageMessage = this.hasPreviousPageMessage
      ..hasNextPageMessage = this.hasNextPageMessage
      ..groupMemberCount = this.groupMemberCount
      ..status = EventStatus.nothing
      ..currentAccount = this.currentAccount
      ..message = null
      ..isLoadHistoryMessageOperate = false
      ..isLoadNextPageMessageOperate = false
      ..refreshMessage = null
      ..canScrollList = false
      ..fileProgressMap = this.fileProgressMap
      ..isMultiCalling = this.isMultiCalling
      ..isAcceptCalling = this.isAcceptCalling
      ..multiMeetingCode = this.multiMeetingCode
      ..isMultiMeetingVideo = this.isMultiMeetingVideo
      ..smartTransList = this.smartTransList
      ..pttSpeaker = this.pttSpeaker;
  }
}

class SmartTransBean {
  int? state; //0 转换中 ， 1 转换成功  ， 2 隐藏
  String? text;
}
