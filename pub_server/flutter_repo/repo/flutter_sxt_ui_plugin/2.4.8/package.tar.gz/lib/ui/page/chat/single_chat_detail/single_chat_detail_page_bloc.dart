import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_sdk_flutter/manager/contact_manager.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:meta/meta.dart';

part 'single_chat_detail_page_event.dart';

part 'single_chat_detail_page_state.dart';

class SingleChatDetailPageBloc
    extends Bloc<SingleChatDetailPageEvent, SingleChatDetailPageState> {
  SingleChatDetailPageBloc(String userCode)
      : super(SingleChatDetailPageState.initial()) {
    add(Initial(userCode));
  }

  @override
  Stream<SingleChatDetailPageState> mapEventToState(
      SingleChatDetailPageEvent event) async* {
    if (event is Initial) {
      yield* _mapInitialEventState(event);
    } else if (event is Loading) {
      yield* _mapLoadingEventState(event);
    } else if (event is LoadingSuccess) {
      yield* _mapLoadingSuccessEventState(event);
    }
  }

  Stream<SingleChatDetailPageState> _mapInitialEventState(
      Initial event) async* {
    List<Contact> contactList = await ContactManager.instance
        .getContactsByCodes(
            [DomainUtil.toCode(event.userCode)], DataFilterBuilder())
        .take(1)
        .first;
    if (null != contactList && contactList.length > 0) {
      yield state.copyWith(contact: contactList[0]);
    }
  }

  Stream<SingleChatDetailPageState> _mapLoadingEventState(
      Loading event) async* {
    yield state.copyWith(status: EventStatus.loading);
  }

  Stream<SingleChatDetailPageState> _mapLoadingSuccessEventState(
      LoadingSuccess event) async* {
    yield state.copyWith(status: EventStatus.loadingSuccess);
  }
}
