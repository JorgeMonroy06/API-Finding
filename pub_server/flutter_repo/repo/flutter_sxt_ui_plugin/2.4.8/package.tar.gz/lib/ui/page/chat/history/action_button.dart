import 'package:flutter/cupertino.dart';

class ActionButton extends StatelessWidget {
  const ActionButton({
    Key? key,
    this.width,
    this.height,
    required this.text,
    this.onPressed,
  }) : super(key: key);

  final double? width;
  final double? height;
  final String text;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) => SizedBox(
        width: width,
        height: height,
        child: CupertinoButton(
          onPressed: onPressed,
          padding: EdgeInsets.zero,
          child: Text(
            text,
            style: const TextStyle(
              color: Color(0xFF677DB1),
              fontSize: 16,
            ),
          ),
        ),
      );
}
