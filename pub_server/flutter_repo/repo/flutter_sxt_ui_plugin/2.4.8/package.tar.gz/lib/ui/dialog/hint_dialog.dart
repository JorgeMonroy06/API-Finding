import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';

class HintDialog extends StatefulWidget {
  final String content;
  final String posHintText;
  final String nagHintText;
  final Color posTextColor;
  final Function? onPositiveClicked;
  final Function? onNegativeClicked;

  HintDialog({
    required this.content,
    this.posHintText = '确定',
    this.nagHintText = '取消',
    this.posTextColor = ColorUtil.COLOR_FF1677FF,
    this.onPositiveClicked,
    this.onNegativeClicked,
  });

  @override
  _HintDialogState createState() => _HintDialogState();
}

class _HintDialogState extends State<HintDialog> {
  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 23),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.all(Radius.circular(10)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    child: Text(
                      widget.content,
                      style: const TextStyle(fontSize: 16, color: ColorUtil.color333333, fontWeight: FontWeight.bold),
                    ),
                    margin: const EdgeInsets.fromLTRB(12, 40, 12, 40),
                  ),
                  Container(
                    color: ColorUtil.dividerColor,
                    height: 1,
                  ),
                  SizedBox(
                    height: 46,
                    child: Row(
                      children: [
                        Expanded(
                            flex: 1,
                            child: Material(
                              color: Colors.white,
                              borderRadius: const BorderRadius.only(bottomLeft: Radius.circular(10)),
                              child: InkWell(
                                borderRadius: const BorderRadius.only(bottomLeft: Radius.circular(10)),
                                onTap: () {
                                  Navigator.maybePop(context, true);
                                  if (null != widget.onNegativeClicked) {
                                    widget.onNegativeClicked!();
                                  }
                                },
                                child: Align(
                                    alignment: Alignment.center,
                                    child: Text(widget.nagHintText, style: const TextStyle(fontSize: 16, color: ColorUtil.colorFF666666))),
                              ),
                            )),
                        Container(
                          color: ColorUtil.dividerColor,
                          width: 1,
                        ),
                        Expanded(
                            flex: 1,
                            child: Material(
                              color: Colors.white,
                              borderRadius: const BorderRadius.only(bottomRight: Radius.circular(10)),
                              child: InkWell(
                                borderRadius: const BorderRadius.only(bottomRight: Radius.circular(10)),
                                onTap: () {
                                  Navigator.maybePop(context, true);

                                  if (null != widget.onPositiveClicked) {
                                    widget.onPositiveClicked!();
                                  }
                                },
                                child: Align(
                                    alignment: Alignment.center, child: Text(widget.posHintText, style: TextStyle(fontSize: 16, color: widget.posTextColor))),
                              ),
                            ))
                      ],
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
