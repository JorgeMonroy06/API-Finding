import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/message_free/message_free_event.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/message_free/message_free_state.dart';
import 'package:flutter_sxt_ui_plugin/utils/prefrence_util.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

class MessageFreeBloc extends Bloc<MessageFreeEvent, MessageFreeState> {
  MessageFreeBloc() : super(MessageFreeState([]));

  @override
  Stream<MessageFreeState> mapEventToState(MessageFreeEvent event) async* {
    if (event is MessageFreeInitEvent) {
      yield* _getMessageFreeState();
    } else if (event is MessageFreeSwitchEvent) {
      yield _switchMessageFreeState(event);
    }
  }

  bool isMessageFree(SessionEntity sessionEntity) {
    return state.messageFreeList.contains(sessionEntity.code);
  }

  Stream<MessageFreeState> _getMessageFreeState() async* {
    final messageFreeList = await PreferenceUtil.getMessageFreeList();
    yield MessageFreeState(messageFreeList);
  }

  MessageFreeState _switchMessageFreeState(MessageFreeSwitchEvent event) {
    _handleMessageFreeList(event);
    _saveMessageFreeList();
    return MessageFreeState(state.messageFreeList);
  }

  void _handleMessageFreeList(MessageFreeSwitchEvent event) {
    if (event.isMessageFree) {
      state.messageFreeList.add(event.sessionEntity.code!);
    } else {
      state.messageFreeList.remove(event.sessionEntity.code);
    }
  }

  void _saveMessageFreeList() {
    final messageFreeList = state.messageFreeList;
    PreferenceUtil.setMessageFreeList(messageFreeList);
  }
}
