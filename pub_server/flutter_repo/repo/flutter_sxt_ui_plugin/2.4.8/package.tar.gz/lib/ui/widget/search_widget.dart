import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';

class SearchBar extends StatefulWidget {
  final String? hint;
  final GestureTapCallback? callbackAction;

  const SearchBar({this.hint, this.callbackAction});

  @override
  _SearchBarState createState() => _SearchBarState();
}

class _SearchBarState extends State<SearchBar> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: CustomColors.cl_F5F5F5,
      child: Padding(
          padding: EdgeInsets.all(10),
          child: InkWell(
            onTap: widget.callbackAction,
            child: Container(
              height: 34,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(6))),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('images/icon_search_mark.png',
                      fit: BoxFit.fill,
                      width: 14,
                      height: 14,
                      package: PACKAGE_NAME),
                  Container(
                    margin: EdgeInsets.only(left: 4),
                    child: Text(
                      widget.hint ?? "",
                      style: TextStyle(
                          fontSize: 14, color: ColorUtil.hintColorAAAAAA),
                    ),
                  )
                ],
              ),
            ),
          )),
    );
  }
}
