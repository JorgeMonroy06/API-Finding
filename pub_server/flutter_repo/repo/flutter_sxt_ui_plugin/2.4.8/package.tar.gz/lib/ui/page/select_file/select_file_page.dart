import 'dart:async';
import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/image_helper.dart';
import 'package:contact_ui_flutter/manager/LazyLoadState.dart';
import 'package:contact_ui_flutter/widget/background_appbar2.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/select_file_widget.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'select_file_bloc.dart';

class SelectFilePage extends StatefulWidget {
  String? title;
  List<String>? fileCodeList;
  List<String>? selectFileCodeList;
  int? limitCount;
  late SelectFileBloc selectFileBloc;
  final SessionEntity sessionEntity;
  SelectFilePage(
      {this.title,
      this.fileCodeList,
      this.selectFileCodeList,
      this.limitCount,
      required this.sessionEntity});

  @override
  State<StatefulWidget> createState() => SelectFilePageState();
}

class SelectFilePageState extends State<SelectFilePage>
    with LazyLoadState<SelectFilePage> {
  late SelectFileBloc selectFileBloc;
  // late EasyRefreshController refreshController;
  TextEditingController textController = TextEditingController();
  FocusNode? focus;
  bool isStartSearch = false;
  @override
  void prepareData() {
    super.prepareData();
    // refreshController = EasyRefreshController();
    selectFileBloc = SelectFileBloc(
        widget.fileCodeList, widget.selectFileCodeList, widget.sessionEntity);
  }

  @override
  void initState() {
    super.initState();
    focus = FocusNode();
  }

  @override
  void onLazyLoad() {
    selectFileBloc.inital();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
        value: selectFileBloc,
        child: Scaffold(
          resizeToAvoidBottomInset: true,
          backgroundColor: Colors.white,
          appBar: BackgroundImageAppbar(
            titleWidget: Text(
              widget.title ?? "",
              // (state.currentOrg == null ? widget.title : state.currentOrg!.name) ?? "",
              style: TextStyle(
                  fontSize: 18,
                  color: Colors.white,
                  fontWeight: FontWeight.bold),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            leadingWidget: Row(
              children: [
                BlocBuilder<SelectFileBloc, SelectFileState>(
                    builder: (context, state) {
                  return Container(
                    margin: EdgeInsets.only(left: 16),
                    child: InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          "取消",
                          style: TextStyle(fontSize: 16, color: Colors.white),
                        )),
                  );
                }),
              ],
            ),
            trailingWidget: Row(
              children: [
                BlocBuilder<SelectFileBloc, SelectFileState>(
                    builder: (context, state) {
                  bool hasData = state.fileModelList != null &&
                      state.fileModelList!.length > 0;
                  return hasData
                      ? Container(
                          margin: EdgeInsets.only(left: 16),
                          child: InkWell(
                              onTap: () {
                                SelectFileBloc bloc =
                                    BlocProvider.of<SelectFileBloc>(context);
                                bloc.add(SelectSendFile(
                                    state.selectfileModelList ?? []));
                                Navigator.pop(context);
                              },
                              child: Text(
                                "确定${state.selectfileModelList!.length > 0 ? "(${state.selectfileModelList!.length})" : ""}",
                                style: TextStyle(
                                    fontSize: 16, color: Colors.white),
                              )),
                        )
                      : Container();
                }),
              ],
            ),
          ),
          body: Container(
              child: Column(
            children: [
              SearchBarButton(),
              SearchBar(),
              Expanded(child: BlocBuilder<SelectFileBloc, SelectFileState>(
                  builder: (context, state) {
                // if (state.isLoadFinish ?? true) {
                //   if (state.hasMoreData ?? true) {
                //     refreshController.finishLoad(success: true, noMore: false);
                //   } else {
                //     refreshController.finishLoad(success: true, noMore: true);
                //   }
                // } else {
                //   refreshController.finishLoad(success: false, noMore: false);
                // }
                // if (state.isRefreshFinish ?? true) {
                //   refreshController.finishRefresh(success: true);
                // } else {
                //   refreshController.finishRefresh(success: false);
                // }
                bool hasData = state.fileModelList != null &&
                    state.fileModelList!.length > 0;
                return hasData
                    ? GestureDetector(
                        onPanDown: (_) {
                          focus!.unfocus();
                        },
                        child: ListView.separated(
                          itemBuilder: (context, index) {
                            return SelectFileWidget(
                              isSelectable: false,
                              file: state.fileModelList![index],
                              onItemClick: () {},
                              onSelected: (selectFileItem) {
                                SelectFileBloc bloc =
                                    BlocProvider.of<SelectFileBloc>(context);
                                bloc.add(
                                    SelectFileCheckChanged(selectFileItem));
                              },
                            );
                          },
                          separatorBuilder: (BuildContext context, int index) {
                            return Container(
                              height: 0.5,
                              margin: EdgeInsets.only(left: 55),
                              color: ColorUtil.COLOR_FFE0E0E0,
                            );
                          },
                          itemCount: state.fileModelList?.length ?? 0,
                        ),
                      )
                    : Container(
                        margin: EdgeInsets.only(top: 120),
                        child: Stack(
                          children: [
                            Center(
                              child: Column(
                                children: [
                                  ImageHelper.assetImage("bg_empty_holder.png"),
                                  Text.rich(TextSpan(children: [
                                    TextSpan(
                                        text: "暂无相关数据",
                                        style: TextStyle(
                                            color: CustomColors.cl_999999)),
                                  ]))
                                ],
                              ),
                            )
                          ],
                        ),
                      );
                // : EasyRefresh(
                //     controller: refreshController,
                //     child: ListView.separated(
                //       itemBuilder: (context, index) {
                //         // bool isWord = state.indexedFileMemberList != null && !StringUtil.isEmpty(state.indexedFileMemberList![index].word!);
                //         return SelectFileWidget(
                //           isSelectable: false,
                //           file: state.fileModelList![index],
                //           onItemClick: () {},
                //           onSelected: (selectContactListItem) {
                //             SelectFileBloc bloc = BlocProvider.of<SelectFileBloc>(context);
                //             bloc.add(SelectFileCheckChanged("", selectContactListItem.isChecked!));
                //           },
                //         );
                //       },
                //       separatorBuilder: (BuildContext context, int index) {
                //         return Container(
                //           height: 0.5,
                //           margin: EdgeInsets.only(left: 55),
                //           color: ColorUtil.COLOR_FFE0E0E0,
                //         );
                //       },
                //       itemCount: state.fileModelList?.length ?? 0,
                //     ),
                //     onLoad: () async {
                //       selectFileBloc.add(SelectFileLoadMoreData());
                //     },
                //     onRefresh: () async {
                //       selectFileBloc.add(Initial());
                //     },
                //     enableControlFinishLoad: true,
                //     enableControlFinishRefresh: true,
                //     bottomBouncing: true,
                //     topBouncing: true,
                //     footer: ClassicalFooter(
                //         showInfo: false,
                //         // 正在加载时的文字
                //         loadingText: "加载中...",
                //         noMoreText: "没有更多数据了"),
                //   );
              }))
            ],
          )),
        ));
  }

  Widget SearchBar() {
    return Visibility(
      visible: isStartSearch,
      child: Container(
        padding: EdgeInsets.all(10),
        color: CustomColors.cl_F5F5F5,
        child: Container(
          height: 32,
          padding: EdgeInsets.only(right: 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(4)),
            color: Colors.white,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: EdgeInsets.only(left: 8, right: 8),
                child: ImageHelper.assetImage("ic_search_grey.png"),
              ),
              Expanded(
                child: TextField(
                  autofocus: true,
                  controller: textController,
                  focusNode: focus,
                  textAlign: TextAlign.left,
                  textInputAction: TextInputAction.search,
                  onEditingComplete: () {
                    if (textController.text.length > 0) {
                      selectFileBloc
                          .add(SelectFileSearchEvent(textController.text));
                      focus!.unfocus();
                    } else {
                      ToastUtil.showToast("请输入搜索的内容");
                    }
                  },
                  onChanged: (value) {
                    if (value != null && value.length == 0) {
                      selectFileBloc.inital();
                    }
                  },
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.zero,
                    hintText: "搜索",
                    hintStyle:
                        TextStyle(fontSize: 14, color: CustomColors.cl_AAAAAA),
                    border: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.transparent,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.transparent,
                      ),
                    ),
                    disabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.transparent,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.transparent,
                      ),
                    ),
                  ),
                  maxLines: 1,
                ),
              ),
              StatefulBuilder(
                builder: (BuildContext context, StateSetter stateSetter) {
                  // clearButtonStateSetter = stateSetter;
                  return textController.text.length == 0
                      ? Container()
                      : InkWell(
                          onTap: () {
                            textController.text = "";
                            // clearButtonStateSetter!(() {});
                            //
                            // widget.onSearch!("");
                          },
                          child: Container(
                            child: ImageHelper.assetImage("ic_clear.png"),
                          ));
                },
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget SearchBarButton() {
    return Visibility(
        visible: !isStartSearch,
        child: Container(
          color: CustomColors.cl_F5F5F5,
          child: Padding(
            padding: EdgeInsets.all(10),
            child: InkWell(
              onTap: () {
                isStartSearch = true;
                setState(() {});
              },
              child: Container(
                height: 34,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(6))),
                child: Align(
                  alignment: Alignment.center,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 14,
                        width: 14,
                        margin: EdgeInsets.only(right: 4),
                        child: ImageHelper.assetImage("ic_search_grey.png"),
                      ),
                      Text(
                        '搜索',
                        style: TextStyle(
                            fontSize: 14, color: CustomColors.cl_AAAAAA),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
        ));
  }
}
