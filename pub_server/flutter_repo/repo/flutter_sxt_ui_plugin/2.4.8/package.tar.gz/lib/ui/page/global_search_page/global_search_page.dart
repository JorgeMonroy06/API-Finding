import 'dart:async';

import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/ui/contact_child/contact_child_page.dart';
import 'package:contact_ui_flutter/ui/contact_search/contact_search_page.dart';
import 'package:contact_ui_flutter/widget/image_loader.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/contact_record_list_page/contact_record_list_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/global_search_page/global_search_page_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/group_list_page/group_list_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/record_list_page/chat_record_list_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/record_list_widget.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/search_appbar.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/group_message.dart';
import 'package:sxt_flutter_plugin/message/model/send_state.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';

class GlobalSearchPage extends StatefulWidget {
  @override
  _GlobalSearchState createState() => _GlobalSearchState();
}

class _GlobalSearchState extends State<GlobalSearchPage> {
  Timer? cancelTask;
  var lastKeyword = "";
  FocusNode? focus;

  @override
  void initState() {
    super.initState();
    focus = FocusNode();
  }

  @override
  void dispose() {
    super.dispose();
    if (cancelTask != null && cancelTask!.isActive) {
      cancelTask?.cancel();
    }
  }

  @override
  Widget build(BuildContext context) {
    // FocusScope.of(context).requestFocus(focus);
    return BlocProvider(
        create: (_) => GlobalSearchPageBloc(),
        child: BlocBuilder<GlobalSearchPageBloc, GlobalSearchPageState>(builder: (context, state) {
          return Scaffold(
            backgroundColor: ((state.groupList?.length ?? 0) == 0 &&
                    (state.contactList?.length ?? 0) == 0 &&
                    (state.orgList?.length ?? 0) == 0 &&
                    (state.groupMessageList?.length ?? 0) == 0 &&
                    !StringUtil.isEmpty(lastKeyword))
                ? Colors.white
                : CustomColors.cl_F5F5F5,
            appBar: SearchAppbar(
                onSearch: (keyWord) {
                  if (null != cancelTask && cancelTask!.isActive) {
                    print('GlobalSearchPage search cancel');
                    cancelTask?.cancel();
                  }
                  print('GlobalSearchPage onChanged $keyWord');
                  print('GlobalSearchPage lastKeyword $lastKeyword');
                  if (keyWord == lastKeyword) {
                    print('GlobalSearchPage same words');
                    return;
                  }
                  print('GlobalSearchPage search start');
                  cancelTask = Timer(Duration(milliseconds: 1500), () {
                    print('GlobalSearchPage search end');
                    lastKeyword = keyWord;
                    GlobalSearchPageBloc bloc = BlocProvider.of<GlobalSearchPageBloc>(context);
                    bloc.add(Search(keyWord));
                  });
                },
                focus: focus),
            body: ((state.groupList?.length ?? 0) == 0 &&
                    (state.contactList?.length ?? 0) == 0 &&
                    (state.orgList?.length ?? 0) == 0 &&
                    (state.groupMessageList?.length ?? 0) == 0 &&
                    !StringUtil.isEmpty(lastKeyword))
                ? Container(
                    margin: EdgeInsets.only(top: 135),
                    child: Stack(
                      children: [
                        Center(
                          child: Column(
                            children: [
                              ImageHelper.assetImage("bg_empty_holder.png"),
                              Text.rich(TextSpan(children: [
                                TextSpan(text: "没有找到“", style: TextStyle(color: CustomColors.cl_999999)),
                                TextSpan(text: lastKeyword, style: TextStyle(color: CustomColors.cl_0F77FE)),
                                TextSpan(text: "”相关的结果", style: TextStyle(color: CustomColors.cl_999999))
                              ]))
                            ],
                          ),
                        )
                      ],
                    ),
                  )
                : Container(
                    child: ListView(
                    keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                    children: [
                      ((state.contactList?.length ?? 0) == 0)
                          ? Container()
                          : Container(
                              color: Colors.white,
                              child: Column(
                                children: [
                                  Align(
                                    child: Container(
                                      margin: EdgeInsets.only(left: 16),
                                      alignment: Alignment.centerLeft,
                                      padding: EdgeInsets.only(top: 10, bottom: 10),
                                      child: Text(
                                        '联系人',
                                        style: TextStyle(fontSize: 12, color: CustomColors.cl_999999),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.only(left: 16),
                                    height: 1,
                                    color: CustomColors.cl_EEEEEE,
                                  ),
                                  ContactList(
                                    contact: state.contactList![0],
                                    onItemClick: () {
                                      Navigator.push(
                                          context,
                                          new CupertinoPageRoute(
                                              settings: RouteSettings(name: '/ChatPage'),
                                              builder: (context) {
                                                SessionEntity sessionEntity = new SessionEntity(
                                                    code: "${state.contactList![0].code}@${state.contactList![0].originCode}", sessionType: SessionType.USER);
                                                return ChatPage(sessionEntity: sessionEntity);
                                              }));
                                    },
                                  ),
                                  (state.contactList?.length ?? 0) > 1
                                      ? Container(
                                          margin: EdgeInsets.only(left: 16),
                                          height: 1,
                                          color: CustomColors.cl_EEEEEE,
                                        )
                                      : Container(),
                                  (state.contactList?.length ?? 0) > 1
                                      ? ContactList(
                                          contact: state.contactList![1],
                                          onItemClick: () {
                                            Navigator.push(
                                                context,
                                                new CupertinoPageRoute(
                                                    settings: RouteSettings(name: '/ChatPage'),
                                                    builder: (context) {
                                                      SessionEntity sessionEntity = new SessionEntity(
                                                          code: "${state.contactList![1].code}@${state.contactList![1].originCode}",
                                                          sessionType: SessionType.USER);
                                                      return ChatPage(sessionEntity: sessionEntity);
                                                    }));
                                          },
                                        )
                                      : Container(),
                                  (state.contactList?.length ?? 0) > 2
                                      ? Container(
                                          margin: EdgeInsets.only(left: 16),
                                          height: 1,
                                          color: CustomColors.cl_EEEEEE,
                                        )
                                      : Container(),
                                  (state.contactList?.length ?? 0) > 2
                                      ? ContactList(
                                          contact: state.contactList![2],
                                          onItemClick: () {
                                            Navigator.push(
                                                context,
                                                new CupertinoPageRoute(
                                                    settings: RouteSettings(name: '/ChatPage'),
                                                    builder: (context) {
                                                      SessionEntity sessionEntity = new SessionEntity(
                                                          code: "${state.contactList![2].code}@${state.contactList![2].originCode}",
                                                          sessionType: SessionType.USER);
                                                      return ChatPage(sessionEntity: sessionEntity);
                                                    }));
                                          },
                                        )
                                      : Container(),
                                  (state.contactList?.length ?? 0) > 3
                                      ? Container(
                                          margin: EdgeInsets.only(left: 16),
                                          height: 1,
                                          color: CustomColors.cl_EEEEEE,
                                        )
                                      : Container(),
                                  (state.contactList?.length ?? 0) > 3
                                      ? Container(
                                          height: 38,
                                          child: InkWell(
                                            onTap: () {
                                              Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
                                                return ContactSearchPage(
                                                  keyword: lastKeyword,
                                                  searchContact: true,
                                                  searchOrg: false,
                                                );
                                              }));
                                            },
                                            child: Row(
                                              children: [
                                                Container(
                                                  width: 15,
                                                  height: 16,
                                                  margin: EdgeInsets.only(right: 6, left: 16),
                                                  child: ImageHelper.assetImage("ic_search_blue.png"),
                                                ),
                                                Expanded(
                                                    child: Text(
                                                  '更多联系人',
                                                  style: TextStyle(fontSize: 12, color: CustomColors.cl_677DB1),
                                                )),
                                                Container(
                                                  width: 7,
                                                  height: 13,
                                                  margin: EdgeInsets.only(right: 18),
                                                  child: ImageHelper.assetImage("ic_arrow_right.png"),
                                                ),
                                              ],
                                            ),
                                          ),
                                        )
                                      : Container()
                                ],
                              ),
                            ),
                      (state.contactList?.length ?? 0) > 0
                          ? Container(
                              height: 10,
                              color: CustomColors.cl_F5F5F5,
                            )
                          : Container(),
                      ((state.orgList?.length ?? 0) == 0)
                          ? Container()
                          : Container(
                              color: Colors.white,
                              child: Column(
                                children: [
                                  Align(
                                    child: Container(
                                      margin: EdgeInsets.only(left: 16),
                                      alignment: Alignment.centerLeft,
                                      padding: EdgeInsets.only(top: 10, bottom: 10),
                                      child: Text(
                                        '组织架构',
                                        style: TextStyle(fontSize: 12, color: CustomColors.cl_999999),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.only(left: 16),
                                    height: 1,
                                    color: CustomColors.cl_EEEEEE,
                                  ),
                                  OrgList(
                                    org: state.orgList![0],
                                    onItemClick: () {
                                      Navigator.push(context, new CupertinoPageRoute(builder: (context) {
                                        return ContactChildPage(state.orgList![0]);
                                      }));
                                    },
                                  ),
                                  (state.orgList?.length ?? 0) > 1
                                      ? Container(
                                          margin: EdgeInsets.only(left: 16),
                                          height: 1,
                                          color: CustomColors.cl_EEEEEE,
                                        )
                                      : Container(),
                                  (state.orgList?.length ?? 0) > 1
                                      ? OrgList(
                                          org: state.orgList![1],
                                          onItemClick: () {
                                            Navigator.push(context, new CupertinoPageRoute(builder: (context) {
                                              return ContactChildPage(state.orgList![1]);
                                            }));
                                          },
                                        )
                                      : Container(),
                                  (state.orgList?.length ?? 0) > 2
                                      ? Container(
                                          margin: EdgeInsets.only(left: 16),
                                          height: 1,
                                          color: CustomColors.cl_EEEEEE,
                                        )
                                      : Container(),
                                  (state.orgList?.length ?? 0) > 2
                                      ? OrgList(
                                          org: state.orgList![2],
                                          onItemClick: () {
                                            Navigator.push(context, new CupertinoPageRoute(builder: (context) {
                                              return ContactChildPage(state.orgList![2]);
                                            }));
                                          },
                                        )
                                      : Container(),
                                  (state.orgList?.length ?? 0) > 3
                                      ? Container(
                                          margin: EdgeInsets.only(left: 16),
                                          height: 1,
                                          color: CustomColors.cl_EEEEEE,
                                        )
                                      : Container(),
                                  (state.orgList?.length ?? 0) > 3
                                      ? Container(
                                          height: 38,
                                          child: InkWell(
                                            onTap: () {
                                              Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
                                                return ContactSearchPage(
                                                  keyword: lastKeyword,
                                                  searchOrg: true,
                                                  searchContact: false,
                                                );
                                              }));
                                            },
                                            child: Row(
                                              children: [
                                                Container(
                                                  width: 15,
                                                  height: 16,
                                                  margin: EdgeInsets.only(right: 6, left: 16),
                                                  child: ImageHelper.assetImage("ic_search_blue.png"),
                                                ),
                                                Expanded(
                                                    child: Text(
                                                  '更多部门',
                                                  style: TextStyle(fontSize: 12, color: CustomColors.cl_677DB1),
                                                )),
                                                Container(
                                                  width: 7,
                                                  height: 13,
                                                  margin: EdgeInsets.only(right: 18),
                                                  child: ImageHelper.assetImage("ic_arrow_right.png"),
                                                ),
                                              ],
                                            ),
                                          ),
                                        )
                                      : Container()
                                ],
                              ),
                            ),
                      (state.orgList?.length ?? 0) > 0
                          ? Container(
                              height: 10,
                              color: CustomColors.cl_F5F5F5,
                            )
                          : Container(),
                      ((state.groupList?.length ?? 0) == 0)
                          ? Container()
                          : Container(
                              color: Colors.white,
                              child: Column(
                                children: [
                                  Align(
                                    child: Container(
                                      margin: EdgeInsets.only(left: 16),
                                      alignment: Alignment.centerLeft,
                                      padding: EdgeInsets.only(top: 10, bottom: 10),
                                      child: Text(
                                        '群组',
                                        style: TextStyle(fontSize: 12, color: CustomColors.cl_999999),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.only(left: 16),
                                    height: 1,
                                    color: CustomColors.cl_EEEEEE,
                                  ),
                                  GroupList(
                                    group: state.groupList![0],
                                    onItemClick: () {
                                      Navigator.push(
                                          context,
                                          new CupertinoPageRoute(
                                              settings: RouteSettings(name: '/ChatPage'),
                                              builder: (context) {
                                                SessionEntity sessionEntity =
                                                    new SessionEntity(code: state.groupList![0].groupCode, sessionType: SessionType.GROUP);
                                                return ChatPage(sessionEntity: sessionEntity);
                                              }));
                                    },
                                  ),
                                  (state.groupList?.length ?? 0) > 1
                                      ? Container(
                                          margin: EdgeInsets.only(left: 16),
                                          height: 1,
                                          color: CustomColors.cl_EEEEEE,
                                        )
                                      : Container(),
                                  (state.groupList?.length ?? 0) > 1
                                      ? GroupList(
                                          group: state.groupList![1],
                                          onItemClick: () {
                                            Navigator.push(
                                                context,
                                                new CupertinoPageRoute(
                                                    settings: RouteSettings(name: '/ChatPage'),
                                                    builder: (context) {
                                                      SessionEntity sessionEntity =
                                                          new SessionEntity(code: state.groupList![1].groupCode, sessionType: SessionType.GROUP);
                                                      return ChatPage(sessionEntity: sessionEntity);
                                                    }));
                                          },
                                        )
                                      : Container(),
                                  (state.groupList?.length ?? 0) > 2
                                      ? Container(
                                          margin: EdgeInsets.only(left: 16),
                                          height: 1,
                                          color: CustomColors.cl_EEEEEE,
                                        )
                                      : Container(),
                                  (state.groupList?.length ?? 0) > 2
                                      ? GroupList(
                                          group: state.groupList![2],
                                          onItemClick: () {
                                            Navigator.push(
                                                context,
                                                new CupertinoPageRoute(
                                                    settings: RouteSettings(name: '/ChatPage'),
                                                    builder: (context) {
                                                      SessionEntity sessionEntity =
                                                          new SessionEntity(code: state.groupList![2].groupCode, sessionType: SessionType.GROUP);
                                                      return ChatPage(sessionEntity: sessionEntity);
                                                    }));
                                          },
                                        )
                                      : Container(),
                                  (state.groupList?.length ?? 0) > 3
                                      ? Container(
                                          margin: EdgeInsets.only(left: 16),
                                          height: 1,
                                          color: CustomColors.cl_EEEEEE,
                                        )
                                      : Container(),
                                  (state.groupList?.length ?? 0) > 3
                                      ? Container(
                                          height: 38,
                                          child: InkWell(
                                            onTap: () {
                                              Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
                                                return GroupListPage(initKeyword: lastKeyword);
                                              }));
                                            },
                                            child: Row(
                                              children: [
                                                Container(
                                                  width: 15,
                                                  height: 16,
                                                  margin: EdgeInsets.only(right: 6, left: 16),
                                                  child: ImageHelper.assetImage("ic_search_blue.png"),
                                                ),
                                                Expanded(
                                                    child: Text(
                                                  '更多群组',
                                                  style: TextStyle(fontSize: 12, color: CustomColors.cl_677DB1),
                                                )),
                                                Container(
                                                  width: 7,
                                                  height: 13,
                                                  margin: EdgeInsets.only(right: 18),
                                                  child: ImageHelper.assetImage("ic_arrow_right.png"),
                                                ),
                                              ],
                                            ),
                                          ),
                                        )
                                      : Container()
                                ],
                              ),
                            ),
                      (state.groupList?.length ?? 0) > 0
                          ? Container(
                              height: 10,
                              color: CustomColors.cl_F5F5F5,
                            )
                          : Container(),
                      ((state.groupMessageList?.length ?? 0) == 0)
                          ? Container()
                          : Container(
                              color: Colors.white,
                              child: Column(
                                children: [
                                  Align(
                                    child: Container(
                                      margin: EdgeInsets.only(left: 16),
                                      alignment: Alignment.centerLeft,
                                      padding: EdgeInsets.only(top: 10, bottom: 10),
                                      child: Text(
                                        '聊天记录',
                                        style: TextStyle(fontSize: 12, color: CustomColors.cl_999999),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.only(left: 16),
                                    height: 1,
                                    color: CustomColors.cl_EEEEEE,
                                  ),
                                  RecordList(
                                    groupMessage: state.groupMessageList![0],
                                    onItemClick: (String name) {
                                      if ((state.groupMessageList![0].count ?? 0) == 1) {
                                        //跳转到聊天界面
                                        GroupMessage groupMessage = state.groupMessageList![0];
                                        SessionEntity sessionEntity = SessionEntity(code: groupMessage.talkerCode, sessionType: groupMessage.talkerType);
                                        Navigator.push(
                                            context,
                                            CupertinoPageRoute(
                                                builder: (context) {
                                                  return ChatPage(
                                                      normalBack: true,
                                                      sessionEntity: sessionEntity,
                                                      isFromRecord: true,
                                                      msgId: groupMessage.msgId,
                                                      msgTime: groupMessage.msgTime);
                                                },
                                                settings: RouteSettings(name: '/ChatPage')));
                                      } else {
                                        Navigator.push(context, CupertinoPageRoute(builder: (context) {
                                          return ContactRecordListPage(
                                              lastKeyword,
                                              SessionEntity(
                                                  code: state.groupMessageList![0].talkerCode, sessionType: state.groupMessageList![0].talkerType, name: name));
                                        }));
                                      }
                                    },
                                    keyword: lastKeyword,
                                  ),
                                  (state.groupMessageList?.length ?? 0) > 1
                                      ? Container(
                                          margin: EdgeInsets.only(left: 16),
                                          height: 1,
                                          color: CustomColors.cl_EEEEEE,
                                        )
                                      : Container(),
                                  (state.groupMessageList?.length ?? 0) > 1
                                      ? RecordList(
                                          groupMessage: state.groupMessageList![1],
                                          onItemClick: (String name) {
                                            if ((state.groupMessageList![1].count ?? 0) == 1) {
                                              //跳转到聊天界面
                                              GroupMessage groupMessage = state.groupMessageList![1];
                                              SessionEntity sessionEntity = SessionEntity(code: groupMessage.talkerCode, sessionType: groupMessage.talkerType);
                                              Navigator.push(
                                                  context,
                                                  CupertinoPageRoute(
                                                      builder: (context) {
                                                        return ChatPage(
                                                            sessionEntity: sessionEntity,
                                                            isFromRecord: true,
                                                            normalBack: true,
                                                            msgId: groupMessage.msgId,
                                                            msgTime: groupMessage.msgTime);
                                                      },
                                                      settings: RouteSettings(name: '/ChatPage')));
                                            } else {
                                              Navigator.push(context, new CupertinoPageRoute(builder: (context) {
                                                return ContactRecordListPage(
                                                    lastKeyword,
                                                    SessionEntity(
                                                        code: state.groupMessageList![1].talkerCode,
                                                        sessionType: state.groupMessageList![1].talkerType,
                                                        name: name));
                                              }));
                                            }
                                          },
                                          keyword: lastKeyword,
                                        )
                                      : Container(),
                                  (state.groupMessageList?.length ?? 0) > 2
                                      ? Container(
                                          margin: EdgeInsets.only(left: 16),
                                          height: 1,
                                          color: CustomColors.cl_EEEEEE,
                                        )
                                      : Container(),
                                  (state.groupMessageList?.length ?? 0) > 2
                                      ? RecordList(
                                          groupMessage: state.groupMessageList![2],
                                          onItemClick: (String name) {
                                            if ((state.groupMessageList![2].count ?? 0) == 1) {
                                              GroupMessage groupMessage = state.groupMessageList![2];
                                              SessionEntity sessionEntity = SessionEntity(code: groupMessage.talkerCode, sessionType: groupMessage.talkerType);
                                              Navigator.push(
                                                  context,
                                                  CupertinoPageRoute(
                                                      builder: (context) {
                                                        return ChatPage(
                                                            sessionEntity: sessionEntity,
                                                            isFromRecord: true,
                                                            normalBack: true,
                                                            msgId: groupMessage.msgId,
                                                            msgTime: groupMessage.msgTime);
                                                      },
                                                      settings: RouteSettings(name: '/ChatPage')));
                                            } else {
                                              Navigator.push(context, new CupertinoPageRoute(builder: (context) {
                                                return ContactRecordListPage(
                                                    lastKeyword,
                                                    SessionEntity(
                                                        code: state.groupMessageList![2].talkerCode,
                                                        sessionType: state.groupMessageList![2].talkerType,
                                                        name: name));
                                              }));
                                            }
                                          },
                                          keyword: lastKeyword,
                                        )
                                      : Container(),
                                  (state.groupList?.length ?? 0) > 3
                                      ? Container(
                                          margin: EdgeInsets.only(left: 16),
                                          height: 1,
                                          color: CustomColors.cl_EEEEEE,
                                        )
                                      : Container(),
                                  (state.groupMessageList?.length ?? 0) > 3
                                      ? Container(
                                          height: 38,
                                          child: InkWell(
                                            onTap: () {
                                              Navigator.push(context, new CupertinoPageRoute(builder: (context) {
                                                return ChatRecordListPage(lastKeyword);
                                              }));
                                            },
                                            child: Row(
                                              children: [
                                                Container(
                                                  width: 15,
                                                  height: 16,
                                                  margin: EdgeInsets.only(right: 6, left: 16),
                                                  child: ImageHelper.assetImage("ic_search_blue.png"),
                                                ),
                                                Expanded(
                                                    child: Text(
                                                  '更多聊天记录',
                                                  style: TextStyle(fontSize: 12, color: CustomColors.cl_677DB1),
                                                )),
                                                Container(
                                                  width: 7,
                                                  height: 13,
                                                  margin: EdgeInsets.only(right: 18),
                                                  child: ImageHelper.assetImage("ic_arrow_right.png"),
                                                ),
                                              ],
                                            ),
                                          ),
                                        )
                                      : Container()
                                ],
                              ),
                            ),
                    ],
                  )),
          );
        }));
  }
}

class GroupList extends StatelessWidget {
  Group? group;
  Function? onItemClick;

  GroupList({this.group, this.onItemClick});

  @override
  Widget build(BuildContext context) {
    if (StringUtil.isEmpty(group!.avatarThumbPath) && (group!.avatarThumbState != SendState.SENDING)) {
      SxtGroupPlugin.downloadGroupThumbAvatar(group!.groupCode!);
    }
    return InkWell(
      splashColor: ThemeData.light().splashColor,
      highlightColor: ThemeData.light().highlightColor,
      onTap: () {
        onItemClick!();
      },
      child: Container(
        height: 56,
        padding: EdgeInsets.only(left: 16),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Row(
            children: [
              ImageLoader(
                isLocal: true,
                url: group!.avatarThumbPath,
                defaultAssetImg: ImageHelper.wrapAssets("ic_group.png"),
                errorAssetImg: ImageHelper.wrapAssets("ic_group.png"),
                borderRadius: 4,
                width: 36,
                height: 36,
                cacheWidth: 36,
                cacheHeight: 36,
                package: PACKAGE_NAME,
              ),
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(left: 10),
                  child: Text(
                    group?.groupName ?? "",
                    style: TextStyle(fontSize: 14, color: ColorUtil.color333333),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class ContactList extends StatelessWidget {
  Contact? contact;
  Function? onItemClick;

  ContactList({this.contact, this.onItemClick});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: ThemeData.light().splashColor,
      highlightColor: ThemeData.light().highlightColor,
      onTap: () {
        onItemClick!();
      },
      child: Container(
        height: 56,
        padding: EdgeInsets.only(left: 16),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Row(
            children: [
              ImageLoader(
                url: StringUtil.getAvatarUrl(contact!),
                defaultAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                errorAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                borderRadius: 4,
                width: 36,
                height: 36,
                cacheWidth: 36,
                cacheHeight: 36,
                package: PACKAGE_NAME,
              ),
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(left: 10),
                  child: Text(
                    contact?.name ?? "",
                    style: TextStyle(fontSize: 14, color: ColorUtil.color333333),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class OrgList extends StatelessWidget {
  Org? org;
  Function? onItemClick;

  OrgList({this.org, this.onItemClick});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: ThemeData.light().splashColor,
      highlightColor: ThemeData.light().highlightColor,
      onTap: () {
        onItemClick!();
      },
      child: Container(
        height: 56,
        padding: EdgeInsets.only(left: 16),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Row(
            children: [
              ImageLoader(
                isLocal: true,
                url: null,
                defaultAssetImg: ImageHelper.wrapAssets("ic_group.png"),
                errorAssetImg: ImageHelper.wrapAssets("ic_group.png"),
                borderRadius: 4,
                width: 36,
                height: 36,
                cacheWidth: 36,
                cacheHeight: 36,
                package: PACKAGE_NAME,
              ),
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(left: 10),
                  child: Text(
                    org?.name ?? "",
                    style: TextStyle(fontSize: 14, color: CustomColors.cl_333333),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
