import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';

class NetFileImage extends StatefulWidget {
  NetFileImage(
    this.placeholder, {
    this.url,
    this.filePath,
    this.errorHolder,
    this.width,
    this.height,
    this.fit,
  });

  final String placeholder;
  final String? url;
  final String? filePath;
  final String? errorHolder;
  final double? width;
  final double? height;
  final BoxFit? fit;

  @override
  State<StatefulWidget> createState() {
    return _NetImageFileState();
  }
}

class _NetImageFileState extends State<NetFileImage> {
  @override
  Widget build(BuildContext context) {
    if (widget.filePath != null) {
      return Image.file(File(widget.filePath!), errorBuilder:
          (BuildContext context, Object exception, StackTrace? stackTrace) {
        return Image.asset(widget.errorHolder ?? widget.placeholder,
            height: widget.height,
            width: widget.width,
            fit: widget.fit,
            package: PACKAGE_NAME);
      });
    }
    return Image.network(widget.url ?? "",
        loadingBuilder: (context, child, loadingProgress) {
      if (loadingProgress == null) return child;
      return Image.asset(widget.placeholder,
          height: widget.height,
          width: widget.width,
          fit: widget.fit,
          package: PACKAGE_NAME);
    }, errorBuilder:
            (BuildContext context, Object exception, StackTrace? stackTrace) {
      return Image.asset(widget.errorHolder ?? widget.placeholder,
          height: widget.height,
          width: widget.width,
          fit: widget.fit,
          package: PACKAGE_NAME);
    });
  }
}
