import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/bloc/group_member_message_chat_history_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/empty.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/record_msg_list.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

class GroupMemberMessageChatHistoryPage extends StatelessWidget {
  const GroupMemberMessageChatHistoryPage(
    this.sessionEntity,
    this.memberCode, {
    Key? key,
  }) : super(key: key);

  final SessionEntity sessionEntity;
  final String memberCode;

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: BackgroundImageAppbar(
          title: '按群成员查找',
          leadingWidget: _buildBackButton(context),
        ),
        body: BlocProvider(
          create: (context) =>
              GroupMemberMessageChatHistoryBloc(sessionEntity, memberCode)
                ..add(GroupMemberMessageChatHistoryInitEvent()),
          child: BlocBuilder<GroupMemberMessageChatHistoryBloc,
              GroupMemberMessageChatHistoryState>(
            builder: (context, state) => state.messages == null
                ? const Center(
                    child: CupertinoActivityIndicator(radius: 12),
                  )
                : state.messages!.isEmpty
                    ? const Empty()
                    : ListView.separated(
                        itemCount: state.messages!.length,
                        cacheExtent: 60,
                        itemBuilder: (context, index) => RecordMsgItem(
                          message: state.messages![index],
                          onItemClick: () =>
                              _jumpChatPage(context, state, index),
                        ),
                        separatorBuilder: (context, index) => _buildDivider(),
                      ),
          ),
        ),
      );

  Widget _buildDivider() => const Divider(
        indent: 16,
        height: 1,
        thickness: 1,
        color: Color(0xFFEEEEEE),
      );

  void _jumpChatPage(BuildContext context,
          GroupMemberMessageChatHistoryState state, int index) =>
      Navigator.of(context).push(
        CupertinoPageRoute(
          settings: const RouteSettings(name: '/ChatPage'),
          builder: (context) => ChatPage(
            sessionEntity: sessionEntity,
            isFromRecord: true,
            msgId: state.messages![index].code,
            msgTime: state.messages![index].createTime,
            normalBack: true,
          ),
        ),
      );

  Widget _buildBackButton(BuildContext context) => IconButton(
        onPressed: Navigator.of(context).pop,
        icon: ImageIcon(
          AssetImage(
            ImageHelper.wrapAssets("ic_back.png"),
            package: PACKAGE_NAME,
          ),
          color: Colors.white,
        ),
      );
}
