import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/guardian_monitor/guardian_monitor_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/guardian_monitor/guardian_monitor_event.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/group_chat_detail/guardian_monitor/guardian_monitor_state.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/switch_item.dart';
import 'package:sxt_flutter_plugin/group/model/set_group_watch_param.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

class GuardianMonitorItem extends StatelessWidget {
  const GuardianMonitorItem(this.sessionEntity, {Key? key}) : super(key: key);

  final SessionEntity sessionEntity;

  @override
  Widget build(BuildContext context) =>
      BlocBuilder<GuardianMonitorBloc, GuardianMonitorState>(
        builder: (context, state) => SwitchItem(
          title: '守护监听',
          value: BlocProvider.of<GuardianMonitorBloc>(context)
              .isListening(sessionEntity),
          onChanged: (value) =>
              BlocProvider.of<GuardianMonitorBloc>(context).add(
            GuardianMonitorSettingEvent(
              SetGroupWatchParam(
                sessionEntity: sessionEntity,
                isWatch: value,
              ),
            ),
          ),
        ),
      );
}
