import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_easyrefresh/easy_refresh.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/action_button.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/bloc/chat_history_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/bloc/media_chat_history_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/date_chat_history_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/group_member_chat_history_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/media_chat_history_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/search_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/history/search_empty.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/record_msg_list.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';

class ChatHistoryPage extends StatelessWidget {
  const ChatHistoryPage(this.sessionEntity, {Key? key, this.groupLeaderCode})
      : super(key: key);

  final SessionEntity sessionEntity;
  final String? groupLeaderCode;

  @override
  Widget build(BuildContext context) => BlocProvider(
        create: (context) =>
            ChatHistoryBloc(sessionEntity)..add(ChatHistoryInitEvent()),
        child: Material(
          color: const Color(0xFFF5F5F5),
          child: Column(
            children: [
              Builder(
                builder: (context) => SearchAppBar(
                  onChanged: (keyword) => context
                      .read<ChatHistoryBloc>()
                      .add(ChatHistoryKeywordEvent(keyword)),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
              BlocBuilder<ChatHistoryBloc, ChatHistoryState>(
                builder: (context, state) => state.keyword.isEmpty
                    ? _Shortcuts(
                        sessionEntity,
                        groupLeaderCode: groupLeaderCode,
                      )
                    : state.messages.isEmpty
                        ? Expanded(
                            child: SearchEmpty(keyword: state.keyword),
                          )
                        : _buildList(context, state),
              ),
            ],
          ),
        ),
      );

  Widget _buildList(BuildContext context, ChatHistoryState state) => Expanded(
        child: Container(
          color: Colors.white,
          child: EasyRefresh(
            controller: context.read<ChatHistoryBloc>().refreshController,
            enableControlFinishLoad: true,
            onLoad: state.noMore
                ? null
                : () async => context
                    .read<ChatHistoryBloc>()
                    .add(ChatHistoryKeywordEvent(state.keyword)),
            child: ListView.separated(
              itemCount: state.messages.length,
              cacheExtent: 60,
              itemBuilder: (context, index) => RecordMsgItem(
                keyword: state.keyword,
                message: state.messages[index],
                onItemClick: () => _jumpChatPage(context, state, index),
              ),
              separatorBuilder: (context, index) => _buildDivider(),
            ),
          ),
        ),
      );

  Widget _buildDivider() => const Divider(
        indent: 16,
        height: 1,
        thickness: 1,
        color: Color(0xFFEEEEEE),
      );

  void _jumpChatPage(BuildContext context, ChatHistoryState state, int index) =>
      Navigator.of(context).push(
        CupertinoPageRoute(
          settings: const RouteSettings(name: '/ChatPage'),
          builder: (context) => ChatPage(
            sessionEntity: sessionEntity,
            isFromRecord: true,
            msgId: state.messages[index].code,
            msgTime: state.messages[index].createTime,
            normalBack: true,
          ),
        ),
      );
}

class _Shortcuts extends StatelessWidget {
  const _Shortcuts(this.sessionEntity, {Key? key, this.groupLeaderCode})
      : super(key: key);

  final SessionEntity sessionEntity;
  final String? groupLeaderCode;

  final _padding = 20.0;

  final _divider = const SizedBox(
    height: 16,
    child: VerticalDivider(
      width: 1,
      thickness: 1,
      color: Color(0xFFE0E0E0),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final width = (MediaQuery.of(context).size.width - _padding * 2 - 2) / 3;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: _padding),
      child: Column(
        children: [
          const SizedBox(height: 25),
          const Text(
            '快速搜索聊天内容',
            style: TextStyle(color: Color(0xFFAAAAAA)),
          ),
          const SizedBox(height: 20),
          Wrap(
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              if (sessionEntity.sessionType == SessionType.GROUP) ...[
                ActionButton(
                  width: width,
                  height: 46,
                  text: '群成员',
                  onPressed: () => Navigator.of(context).push(
                    CupertinoPageRoute(
                      builder: (context) => GroupMemberChatHistoryPage(
                        sessionEntity,
                        groupLeaderCode: groupLeaderCode,
                      ),
                    ),
                  ),
                ),
                _divider,
              ],
              ActionButton(
                width: width,
                height: 46,
                text: '日期',
                onPressed: () => Navigator.of(context).push(
                  CupertinoPageRoute(
                    builder: (context) => DateChatHistoryPage(sessionEntity),
                  ),
                ),
              ),
              _divider,
              ActionButton(
                width: width,
                height: 46,
                text: '图片及视频',
                onPressed: () => Navigator.of(context).push(
                  CupertinoPageRoute(
                    builder: (context) =>
                        MediaChatHistoryPage(sessionEntity, MediaType.media),
                  ),
                ),
              ),
              if (sessionEntity.sessionType != SessionType.GROUP) _divider,
              ActionButton(
                width: width,
                height: 46,
                text: '文件',
                onPressed: () => Navigator.of(context).push(
                  CupertinoPageRoute(
                    builder: (context) =>
                        MediaChatHistoryPage(sessionEntity, MediaType.file),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
