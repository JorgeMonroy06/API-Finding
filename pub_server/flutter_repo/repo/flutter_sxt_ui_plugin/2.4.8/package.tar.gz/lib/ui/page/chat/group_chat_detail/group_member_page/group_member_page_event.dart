part of 'group_member_page_bloc.dart';

@immutable
abstract class GroupMemberPageEvent {
  const GroupMemberPageEvent();
}

class Initial extends GroupMemberPageEvent {
  const Initial();
}

class Update extends GroupMemberPageEvent {
  final String groupCode;

  const Update(this.groupCode);
}

class DeleteUser extends GroupMemberPageEvent {
  final String code;

  const DeleteUser(this.code);
}

class PopPage extends GroupMemberPageEvent {
  final String message;

  const PopPage(this.message);
}
