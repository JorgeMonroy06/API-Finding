part of 'forward_msg_bloc.dart';

@immutable
abstract class ForwardMsgEvent {
  const ForwardMsgEvent();
}

class Init extends ForwardMsgEvent {
  const Init();
}

class Search extends ForwardMsgEvent {
  final String keyword;

  const Search(this.keyword);
}

class MultiSelectChange extends ForwardMsgEvent {
  const MultiSelectChange();
}

class CheckChanged extends ForwardMsgEvent {
  final Contact contact;
  final bool isCheck;

  const CheckChanged(this.contact, this.isCheck);
}
