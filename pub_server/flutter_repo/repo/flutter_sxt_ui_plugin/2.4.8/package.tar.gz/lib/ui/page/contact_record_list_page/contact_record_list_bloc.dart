import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';
import 'package:sxt_flutter_plugin/message/model/query_msg_param.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';
import 'package:sxt_flutter_plugin/model/job.dart';

part 'contact_record_list_event.dart';

part 'contact_record_list_state.dart';

class ContactRecordListBloc
    extends Bloc<ContactRecordListEvent, ContactRecordListState> {
  ContactRecordListBloc() : super(ContactRecordListState.initial());

  @override
  Stream<ContactRecordListState> mapEventToState(
      ContactRecordListEvent event) async* {
    if (event is Search) {
      yield* _mapSearchEventState(event);
    }
  }

  void inital(String keyword, SessionEntity sessionEntity) {
    add(Search(keyword, sessionEntity));
  }

  Stream<ContactRecordListState> _mapSearchEventState(Search event) async* {
    if (StringUtil.isEmpty(event.keyword)) {
      yield state.copyWith(messageList: [], isLoading: false);
      return;
    }

    yield state.copyWith(isLoading: true);

    int lastMsgTime = 0;
    int code = 0;
    if (null != state.messageList && state.messageList!.length > 0) {
      lastMsgTime =
          state.messageList![state.messageList!.length - 1].createTime!;
      code = state.messageList![state.messageList!.length - 1].code!;
    }
    try {
      QueryMsgParam queryMsgParam = QueryMsgParam();
      queryMsgParam.sessionType = event.sessionEntity.sessionType;
      queryMsgParam.userCode = event.sessionEntity.code;
      queryMsgParam.keyword = event.keyword;
      queryMsgParam.msgCode = code;
      queryMsgParam.msgTime = lastMsgTime;
      queryMsgParam.msgCount = 20;

      Job<List<Message>> job =
          await SxtMessagePlugin.getMsgsByKey(queryMsgParam);
      yield state.copyWith(messageList: job.data, isLoading: false);
    } catch (e) {
      print(e);
    }
  }
}
