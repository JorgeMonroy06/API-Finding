import 'package:flutter/material.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';

import '../../utils/color_sxt.dart';

class EmptyWidget extends StatelessWidget {
  final String content;
  final EdgeInsetsGeometry? margin;
  final double? height;
  final double? width;
  final EdgeInsetsGeometry? padding;

  EmptyWidget(
    this.content, {
    this.margin,
    this.height,
    this.width,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      height: this.height,
      width: this.width,
      margin: margin,
      padding: padding,
      child: Column(
        children: [
          Image.asset(
            'images/icon_empty_bg.png',
            package: PACKAGE_NAME,
            width: 194,
            fit: BoxFit.cover,
          ),
          Text(
            content,
            style: TextStyle(fontSize: 14, color: ColorUtil.color999999),
          )
        ],
      ),
    );
  }
}
