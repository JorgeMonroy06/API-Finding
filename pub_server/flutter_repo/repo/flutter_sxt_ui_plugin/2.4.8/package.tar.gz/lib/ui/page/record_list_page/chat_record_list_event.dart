part of 'chat_record_list_bloc.dart';

@immutable
abstract class ChatRecordListEvent {
  const ChatRecordListEvent();
}

class Search extends ChatRecordListEvent {
  final String keyword;

  const Search(this.keyword);
}
