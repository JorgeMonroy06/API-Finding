part of 'chat_bloc.dart';

@immutable
abstract class ChatEvent {}

class LoadCurrentPageMessageEvent extends ChatEvent {
  LoadCurrentPageMessageEvent();
}

class LoadNextPageMessageEvent extends ChatEvent {
  final int msgId;
  final int msgTime;

  LoadNextPageMessageEvent(this.msgId, this.msgTime);
}

class LoadPreviousPageMessageEvent extends ChatEvent {
  final Message firstMsg;

  LoadPreviousPageMessageEvent(this.firstMsg);
}

class InitEvent extends ChatEvent {
  InitEvent();
}

class PopEvent extends ChatEvent {
  final String message;

  PopEvent(this.message);
}

class UpdateUnreadCount extends ChatEvent {
  final int unreadCount;

  UpdateUnreadCount(this.unreadCount);
}

class UpdateMessageEvent extends ChatEvent {
  final Message message;
  bool canScrollList;

  UpdateMessageEvent(this.message, {this.canScrollList = false});
}

class OpenFileEvent extends ChatEvent {
  final Message message;

  OpenFileEvent(this.message);
}

class DeleteMsg extends ChatEvent {
  final Message message;

  DeleteMsg(this.message);
}

class UpdateProgressEvent extends ChatEvent {
  final Message message;
  final double progress;

  UpdateProgressEvent(this.message, this.progress);
}

class UpdateMsgListEvent extends ChatEvent {
  final ModificationEvent<Message> event;

  UpdateMsgListEvent(this.event);
}

class MultiMeetingUpdate extends ChatEvent {
  MultiMeetingUpdate();
}

class TransVoiceToText extends ChatEvent {
  final Message message;

  TransVoiceToText(this.message);
}

class HideTrans extends ChatEvent {
  final Message message;

  HideTrans(this.message);
}

class SpeakStartEvent extends ChatEvent {
  SessionEntity sessionEntity;

  SpeakStartEvent(this.sessionEntity);
}

class SpeakEndEvent extends ChatEvent {
  SpeakEndEvent();
}
