import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:connectivity/connectivity.dart';
import 'package:flutter_sxt_ui_plugin/utils/sxt_status_listener.dart';
import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/account/listener/connection_state_listener.dart';
import 'package:sxt_flutter_plugin/account/model/socket_connect_state.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';

part 'connection_event.dart';
part 'connection_state.dart';

class ConnectionBloc extends Bloc<ConnectionEvent, ConnectionState> {
  ConnectionBloc() : super(ConnectionState());

  final _connectivity = Connectivity();
  final _streamController = StreamController<ConnectionState>();

  @override
  Future<void> close() {
    _streamController.close();
    return super.close();
  }

  @override
  Stream<ConnectionState> mapEventToState(ConnectionEvent event) async* {
    if (event is ConnectionInitialEvent) {
      _listenConnectionState();
      yield* _streamController.stream;
    }
  }

  void _listenConnectionState() {
    SxtAccountPlugin.setOnlineStateListener(ConnectionStateListener(
      onKicked: () =>
          _streamController.add(ConnectionState(ConnectionStatus.kicked)),
      onlineStateChanged: (socketConnectState) async {
        if (socketConnectState.state == SocketConnectState.DISCONNECTED) {
          final status = await _getConnectionStatus();
          _streamController.add(ConnectionState(status));
        } else {
          _streamController.add(ConnectionState());
        }
      },
    )).then((job) => StatusChangeLister.setJobId(job.jobId!));
  }

  Future<ConnectionStatus> _getConnectionStatus() async {
    final connectivityResult = await _connectivity.checkConnectivity();
    if (connectivityResult == ConnectivityResult.none) {
      return ConnectionStatus.disconnected;
    } else {
      return ConnectionStatus.signout;
    }
  }
}
