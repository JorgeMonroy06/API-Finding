part of 'ontop_conversation_bloc.dart';

@immutable
abstract class OnTopConversationEvent {}

class OnTopConversationInitEvent extends OnTopConversationEvent {}

class OnTopConversationSwitchEvent extends OnTopConversationEvent {
  final SessionEntity sessionEntity;
  final bool isOnTop;

  OnTopConversationSwitchEvent(this.sessionEntity, this.isOnTop);
}
