import 'package:sxt_flutter_plugin/message/model/message.dart';

class MediaDownloadState {
  final Message message;
  final int? progress;

  MediaDownloadState(this.message, [this.progress]);
}
