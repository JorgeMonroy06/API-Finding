part of 'rename_group_page_bloc.dart';

class RenameGroupPageState {
  final EventStatus? status;
  final String? failedMessage;

  const RenameGroupPageState({
    @required this.status,
    @required this.failedMessage,
  });

  RenameGroupPageState.initial()
      : this(status: EventStatus.nothing, failedMessage: null);

  RenameGroupPageState copyWith({EventStatus? status, String? failedMessage}) {
    return RenameGroupPageState(
      status: status ?? EventStatus.nothing,
      failedMessage: failedMessage ?? this.failedMessage,
    );
  }
}
