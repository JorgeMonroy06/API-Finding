import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/message_free/message_free_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/message_free/message_free_event.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/message_free/message_free_state.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/switch_item.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

class MessageFreeItem extends StatelessWidget {
  const MessageFreeItem(this.sessionEntity, {Key? key}) : super(key: key);

  final SessionEntity sessionEntity;

  @override
  Widget build(BuildContext context) =>
      BlocBuilder<MessageFreeBloc, MessageFreeState>(
        builder: (context, state) => SwitchItem(
          title: '消息免打扰',
          value: BlocProvider.of<MessageFreeBloc>(context)
              .isMessageFree(sessionEntity),
          onChanged: (value) => BlocProvider.of<MessageFreeBloc>(context)
              .add(MessageFreeSwitchEvent(sessionEntity, value)),
        ),
      );
}
