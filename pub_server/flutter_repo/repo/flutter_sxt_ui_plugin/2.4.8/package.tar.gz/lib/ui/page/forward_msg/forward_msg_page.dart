import 'dart:async';

import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/Colors.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/manager/LazyLoadState.dart';
import 'package:contact_ui_flutter/ui/contact_list.dart';
import 'package:contact_ui_flutter/ui/contact_select/contact_select_page.dart';
import 'package:contact_ui_flutter/widget/image_loader.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/forward_msg/forward_msg_bloc.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/background_appbar.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/forward_msg_dialog.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/loading_dialog.dart';
import 'package:flutter_sxt_ui_plugin/utils/color_sxt.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/group/model/group_create_param.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/attachment.dart';
import 'package:sxt_flutter_plugin/message/model/file_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/location_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/pic_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/send_message_param.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';
import 'package:sxt_flutter_plugin/message/model/text_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/video_attachment.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';

class ForwardMsgPage extends StatefulWidget {
  final Attachment attachment;

  ForwardMsgPage(this.attachment);

  @override
  _ForwardMsgPageState createState() => _ForwardMsgPageState();
}

class _ForwardMsgPageState extends State<ForwardMsgPage> with LazyLoadState<ForwardMsgPage> {
  late ForwardMsgBloc forwardMsgBloc;
  TextEditingController textController = TextEditingController();
  Timer? cancelTask;
  var lastKeyword = "";
  StateSetter? clearButtonStateSetter;
  StateSetter? searchBarStateSetter;

  @override
  void prepareData() {
    super.prepareData();
    forwardMsgBloc = ForwardMsgBloc();
  }

  @override
  void onLazyLoad() {
    forwardMsgBloc.inital();
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    if (cancelTask != null && cancelTask!.isActive) {
      cancelTask?.cancel();
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
        value: forwardMsgBloc,
        child: Scaffold(
            appBar: BackgroundImageAppbar(
              title: "转发",
              leadingWidget: IconButton(
                icon: ImageIcon(
                  AssetImage(ImageHelper.wrapAssets("ic_back.png"), package: PACKAGE_NAME),
                  color: Colors.white,
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
              trailingWidget: BlocBuilder<ForwardMsgBloc, ForwardMsgState>(buildWhen: (previous, current) {
                return (previous.isMultiSelectState != current.isMultiSelectState);
              }, builder: (context, state) {
                return Container(
                  margin: EdgeInsets.only(right: 16),
                  child: InkWell(
                      onTap: () {
                        forwardMsgBloc.add(MultiSelectChange());
                      },
                      child: Text(
                        (state.isMultiSelectState ?? false) ? '完成' : '多选',
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      )),
                );
              }),
            ),
            body: Container(
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  _searchBar(),
                  _createNewConversationButton(),
                  Container(
                    height: 30,
                    width: MediaQuery.of(context).size.width,
                    padding: EdgeInsets.only(left: 16),
                    color: ColorUtil.COLOR_FFF5F5F5,
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text('联系人', style: TextStyle(color: CustomColors.cl_666666, fontSize: 12)),
                    ),
                  ),
                  BlocBuilder<ForwardMsgBloc, ForwardMsgState>(buildWhen: (previous, current) {
                    return (previous.contactListItem != current.contactListItem) ||
                        (previous.isMultiSelectState != current.isMultiSelectState) ||
                        (previous.searchedContactListItem != current.searchedContactListItem);
                  }, builder: (context, state) {
                    return Expanded(
                        child: !StringUtil.isEmpty(lastKeyword) && (state.searchedContactListItem == null || state.searchedContactListItem!.isEmpty)
                            ? Center(
                                child: Column(
                                  children: [
                                    SizedBox(height: 48),
                                    ImageHelper.assetImage("bg_empty_holder.png"),
                                    Text.rich(TextSpan(children: [
                                      TextSpan(text: "暂无联系人"),
                                    ]))
                                  ],
                                ),
                              )
                            : (state.contactListItem == null
                                ? Center(
                                    child: CupertinoActivityIndicator(),
                                  )
                                : contactList(StringUtil.isEmpty(lastKeyword) ? state.contactListItem! : state.searchedContactListItem!,
                                    state.isMultiSelectState ?? false)));
                  }),
                  selectListWidget(),
                  BlocBuilder<ForwardMsgBloc, ForwardMsgState>(builder: (context, state) {
                    return Container(
                      height: MediaQuery.of(context).padding.bottom,
                      width: MediaQuery.of(context).size.width,
                      color: state.selectContactList?.length == 0 ? Colors.white : CustomColors.cl_F6F7F8,
                    );
                  })
                ],
              ),
            )));
  }

  Widget _searchBar() {
    return StatefulBuilder(builder: (BuildContext context, StateSetter stateSetter) {
      bool isEditing = !StringUtil.isEmpty(textController.text);
      searchBarStateSetter = stateSetter;
      return Container(
          color: CustomColors.cl_F5F5F5,
          child: Padding(
              padding: EdgeInsets.all(10),
              child: Container(
                  height: 34,
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.all(Radius.circular(6))),
                  child: Container(
                    child: Stack(
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: Visibility(
                              visible: !isEditing,
                              child: Container(
                                margin: EdgeInsets.all(8),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      width: 14,
                                      height: 14,
                                      margin: EdgeInsets.only(top: 2),
                                      child: ImageHelper.assetImage("icon_search_mark.png"),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(left: 4),
                                      child: Text(
                                        "搜索",
                                        style: TextStyle(fontSize: 14, color: CustomColors.cl_AAAAAA),
                                      ),
                                    )
                                  ],
                                ),
                              )),
                        ),
                        Align(
                          alignment: Alignment.center,
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              SizedBox(
                                width: 8,
                              ),
                              Visibility(
                                  visible: false,
                                  child: Container(
                                    width: 14,
                                    height: 14,
                                    margin: EdgeInsets.all(8),
                                    child: ImageHelper.assetImage("icon_search_mark.png"),
                                  )),
                              Expanded(child: BlocBuilder<ForwardMsgBloc, ForwardMsgState>(builder: (context, state) {
                                return TextField(
                                  controller: textController,
                                  maxLines: 1,
                                  onChanged: (v) {
                                    searchBarStateSetter!(() {});

                                    if (null != cancelTask && cancelTask!.isActive) {
                                      print('ForwardMsgPage search cancel');
                                      cancelTask?.cancel();
                                    }
                                    print('ForwardMsgPage onChanged $v');
                                    print('ForwardMsgPage lastKeyword $lastKeyword');
                                    if (v == lastKeyword) {
                                      print('ForwardMsgPage same words');
                                      return;
                                    }
                                    print('ForwardMsgPage search start');
                                    cancelTask = Timer(Duration(milliseconds: 1500), () {
                                      print('ForwardMsgPage search end');
                                      lastKeyword = v;
                                      forwardMsgBloc.add(Search(v));
                                    });
                                  },
                                  textAlign: TextAlign.left,
                                  style: TextStyle(fontSize: 14, color: CustomColors.cl_333333),
                                  decoration: InputDecoration.collapsed(
                                      hintText: "", hintStyle: TextStyle(fontSize: 14, color: CustomColors.cl_AAAAAA), border: InputBorder.none),
                                );
                              })),
                              textController.text.length == 0
                                  ? Container()
                                  : InkWell(
                                      onTap: () {
                                        textController.text = "";
                                        searchBarStateSetter!(() {});

                                        lastKeyword = "";
                                        forwardMsgBloc.add(Search(""));
                                      },
                                      child: Container(
                                        width: 23,
                                        height: 23,
                                        margin: EdgeInsets.all(4),
                                        child: ImageHelper.assetImage("ic_clear.png"),
                                      ))
                            ],
                          ),
                        )
                      ],
                    ),
                  ))));
    });
  }

  Widget contactList(List<ContactListItem> contactItemList, bool isCheckable) {
    return ListView.separated(
      itemBuilder: (context, index) {
        return ContactList(
          isSelectable: isCheckable,
          isCheckable: true,
          contactListItem: contactItemList[index],
          onItemClick: () {
            _showForwardDialog([contactItemList[index].contact!], null);
          },
          onSelected: (selectContactListItem) {
            if (selectContactListItem.isChecked && (forwardMsgBloc.state.selectContactList?.length ?? 0) >= 9) {
              ToastUtil.showToast("最多选择9个联系人");
              return false;
            }

            forwardMsgBloc.add(CheckChanged(contactItemList[index].contact!, selectContactListItem.isChecked));
            return true;
          },
        );
      },
      separatorBuilder: (BuildContext context, int index) {
        return Container(
          height: 0.5,
          margin: EdgeInsets.only(left: 60),
          color: CustomColors.cl_E0E0E0,
        );
      },
      itemCount: contactItemList.length,
    );
  }

  _showForwardDialog(List<Contact>? contactList, Group? group) {
    showDialog(
      context: context,
      builder: (buildContext) {
        return ForwardMsgDialog(contactList, group?.groupName, widget.attachment, () async {
          bool isSuccess = true;
          if (contactList != null) {
            contactList.forEach((element) async {
              isSuccess = await _sendMessage("${element.code}@${element.originCode}", SessionType.USER);
            });
          } else {
            isSuccess = await _sendMessage(group!.groupCode!, SessionType.GROUP);
          }
          ToastUtil.showToast(isSuccess ? "转发成功" : "转发失败");

          Future.delayed(Duration(milliseconds: 500), () {
            Navigator.of(context).pop();
          });
        });
      },
    );
  }

  Future<bool> _sendMessage(String code, int sessionType) async {
    SendMessageParam param = SendMessageParam();
    param.isForward = true;
    param.userCode = code;
    param.sessionType = sessionType;

    if (widget.attachment is TextAttachment) {
      param.attachment = (widget.attachment as TextAttachment).toJson();
      param.msgType = MsgType.TEXT;
    } else if (widget.attachment is PicAttachment) {
      param.attachment = (widget.attachment as PicAttachment).toJson();
      param.msgType = MsgType.PICTURE;
    } else if (widget.attachment is FileAttachment) {
      param.attachment = (widget.attachment as FileAttachment).toJson();
      param.msgType = MsgType.OTHERS;
    } else if (widget.attachment is LocationAttachment) {
      param.attachment = (widget.attachment as LocationAttachment).toJson();
      param.msgType = MsgType.LOCATION;
    } else if (widget.attachment is VideoAttachment) {
      param.attachment = (widget.attachment as VideoAttachment).toJson();
      param.msgType = MsgType.VIDEO_FILE;
    }

    try {
      await SxtMessagePlugin.sendMessage(param);
      return true;
    } catch (e) {
      return false;
    }
  }

  Widget selectListWidget() {
    return BlocBuilder<ForwardMsgBloc, ForwardMsgState>(buildWhen: (previous, current) {
      return previous.selectContactList != current.selectContactList;
    }, builder: (context, state) {
      int count = state.selectContactList?.length ?? 0;
      return count == 0
          ? Container()
          : Container(
              child: Column(children: [
              Container(
                height: 0.5,
                color: CustomColors.cl_E0E0E0,
              ),
              SafeArea(
                child: Container(
                  color: CustomColors.cl_F6F7F8,
                  height: 64,
                  child: Row(
                    children: [
                      Expanded(
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: state.selectContactList?.length ?? 0,
                          itemBuilder: (context, index) {
                            Contact contact = state.selectContactList![index];
                            return GestureDetector(
                              onTap: () {
                                forwardMsgBloc.add(CheckChanged(contact, false));
                              },
                              child: Container(
                                padding: EdgeInsets.only(left: 4, right: 4),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    ImageLoader(
                                      url: StringUtil.getAvatarUrl(contact),
                                      defaultAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                                      errorAssetImg: ImageHelper.wrapAssets("icon_person_placeholder.png"),
                                      package: PACKAGE_NAME,
                                      borderRadius: 4,
                                      width: 30,
                                      height: 30,
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: 4),
                                      padding: EdgeInsets.only(left: 2, right: 2),
                                      width: 30,
                                      child: Center(
                                        child: Text(
                                          contact.name ?? "",
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(fontSize: 12, color: CustomColors.cl_666666),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          _showForwardDialog(state.selectContactList!, null);
                        },
                        child: Container(
                          padding: EdgeInsets.only(right: 8, left: 8, bottom: 3),
                          constraints: BoxConstraints(minWidth: 70, maxHeight: 34),
                          decoration: BoxDecoration(
                            color: CustomColors.cl_0F77FE,
                            borderRadius: BorderRadius.all(Radius.circular(4)),
                          ),
                          margin: EdgeInsets.only(right: 10, left: 10),
                          child: Center(
                              child: Text(
                            '确定(${state.selectContactList?.length})',
                            style: TextStyle(fontSize: 16, color: Colors.white),
                          )),
                        ),
                      )
                    ],
                  ),
                ),
              )
            ]));
    });
  }

  Widget _createNewConversationButton() {
    return Container(
      color: Colors.white,
      height: 56,
      padding: EdgeInsets.only(left: 16, right: 10),
      child: InkWell(
        onTap: () {
          Navigator.of(context).push(CupertinoPageRoute(builder: (context) {
            return ContactSelectPage(title: "选择联系人");
          })).then((value) {
            if (null == value) return;

            List<Contact> list = value;
            if (list.isEmpty) return;

            if (list.length == 1) {
              _showForwardDialog(list, null);
            } else {
              if (null == value) return;

              List<Contact> list = value;
              if (list.isEmpty) return;

              if (list.length == 1) {
                _showForwardDialog(list, null);
              } else {
                showDialog(context: context, barrierDismissible: false, builder: (ctx) => LoadingDialog("创建群组中...", () => {}));

                List<String> userCodes = list.map((e) => (e.code! + "@" + e.originCode!)).toList();

                GroupCreateParam param = GroupCreateParam();
                param.userCodes = userCodes;
                SxtGroupPlugin.createGroup(param).then((value) {
                  Navigator.pop(context);
                  _showForwardDialog(null, value.data);
                }).onError((e, stackTrace) {
                  Navigator.pop(context);
                  if (e is PlatformException) {
                    ToastUtil.showToast(e.message ?? "创建群组失败");
                  } else {
                    ToastUtil.showToast("创建群组失败");
                  }
                });
              }
            }
          });
        },
        child: Align(
          alignment: Alignment.centerLeft,
          child: Row(
            children: [
              Expanded(
                child: Container(
                  child: Text(
                    "创建新聊天",
                    style: TextStyle(fontSize: 16, color: CustomColors.cl_333333),
                  ),
                ),
              ),
              ImageHelper.assetImage("ic_arrow_right.png"),
            ],
          ),
        ),
      ),
    );
  }
}
