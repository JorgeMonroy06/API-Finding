import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:meta/meta.dart';
import 'package:sxt_flutter_plugin/message/model/group_message.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';
import 'package:sxt_flutter_plugin/model/job.dart';

part 'chat_record_list_event.dart';

part 'chat_record_list_state.dart';

class ChatRecordListBloc
    extends Bloc<ChatRecordListEvent, ChatRecordListState> {
  ChatRecordListBloc() : super(ChatRecordListState.initial());

  @override
  Stream<ChatRecordListState> mapEventToState(
      ChatRecordListEvent event) async* {
    if (event is Search) {
      yield* _mapSearchEventState(event);
    }
  }

  void inital(String keyword) {
    add(Search(keyword));
  }

  Stream<ChatRecordListState> _mapSearchEventState(Search event) async* {
    if (StringUtil.isEmpty(event.keyword)) {
      yield state.copyWith(groupMessageList: []);
      return;
    }

    try {
      Job<List<GroupMessage>> job =
          await SxtMessagePlugin.searchMessage(event.keyword);
      yield state.copyWith(groupMessageList: job.data);
    } catch (e) {
      print(e);
    }
  }
}
