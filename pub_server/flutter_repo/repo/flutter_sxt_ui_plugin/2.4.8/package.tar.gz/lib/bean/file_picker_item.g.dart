// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'file_picker_item.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FilePickerItem _$FilePickerItemFromJson(Map<String, dynamic> json) {
  return FilePickerItem(
    name: json['name'] as String?,
    path: json['path'] as String?,
    size: json['size'] as int?,
    dateTime: json['dateTime'] as int?,
  );
}

Map<String, dynamic> _$FilePickerItemToJson(FilePickerItem instance) => <String, dynamic>{
      'name': instance.name,
      'path': instance.path,
      'size': instance.size,
      'dateTime': instance.dateTime,
    };
