// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ct_server_config.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CtServerConfig _$CtServerConfigFromJson(Map<String, dynamic> json) {
  return CtServerConfig(
    token: json['token'] as String?,
  )
    ..rootUrl = json['rootUrl'] as String?
    ..appName = json['appName'] as String?
    ..version = json['version'] as String?;
}

Map<String, dynamic> _$CtServerConfigToJson(CtServerConfig instance) =>
    <String, dynamic>{
      'token': instance.token,
      'rootUrl': instance.rootUrl,
      'appName': instance.appName,
      'version': instance.version,
    };
