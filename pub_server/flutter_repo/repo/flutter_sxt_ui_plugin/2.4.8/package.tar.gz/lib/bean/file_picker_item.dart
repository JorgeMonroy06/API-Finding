import 'package:json_annotation/json_annotation.dart';

part 'file_picker_item.g.dart';

@JsonSerializable()
class FilePickerItem {
  String? name;
  String? path;
  int? size;
  int? dateTime;

  factory FilePickerItem.fromJson(Map<String, dynamic> json) => _$FilePickerItemFromJson(json);

  Map<String, dynamic> toJson() => _$FilePickerItemToJson(this);

  FilePickerItem({this.name, this.path, this.size, this.dateTime});
}
