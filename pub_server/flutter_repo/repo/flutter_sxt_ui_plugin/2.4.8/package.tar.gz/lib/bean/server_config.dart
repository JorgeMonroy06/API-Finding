class ServerConfig {
  String? sxtIp; //视信通IP地址

  String? sxtPort; //视信通端口

  String? sxtClientId; //视信通免密登录ClientId

  String? sxtClientSecret; //视信通免密登录ClientSecret

  bool sxtUseSsl = false; //视信通是否加密

  String? contactClientId; //通讯录微服务ClientId

  String? contactClientSecret; //通讯录微服务ClientSecret

  String? contactBaseUrl; //通讯录为服务器地址
}
