import 'package:sxt_flutter_plugin/message/model/attachment.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';

class MessageListBean {
  List<Message<Attachment>> list = [];

  MessageListBean(this.list);
}
