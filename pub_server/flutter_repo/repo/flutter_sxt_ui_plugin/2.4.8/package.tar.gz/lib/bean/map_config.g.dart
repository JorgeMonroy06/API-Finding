// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'map_config.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

MapConfig _$MapConfigFromJson(Map<String, dynamic> json) {
  return MapConfig(
    androidKey: json['androidKey'] as String?,
    iosKey: json['iosKey'] as String?,
    isOffline: json['isOffline'] as bool?,
    showDownloadMapButton: json['showDownloadMapButton'] as bool?,
    ctServerConfig: json['ctServerConfig'] == null
        ? null
        : CtServerConfig.fromJson(
            json['ctServerConfig'] as Map<String, dynamic>),
    latLng: json['latLng'] == null
        ? null
        : LatLng.fromJson(json['latLng'] as Map<String, dynamic>),
    cacheMapPath: json['cacheMapPath'] as String?,
  );
}

Map<String, dynamic> _$MapConfigToJson(MapConfig instance) => <String, dynamic>{
      'androidKey': instance.androidKey,
      'iosKey': instance.iosKey,
      'isOffline': instance.isOffline,
      'showDownloadMapButton': instance.showDownloadMapButton,
      'ctServerConfig': instance.ctServerConfig,
      'latLng': instance.latLng,
      'cacheMapPath': instance.cacheMapPath,
    };
