import 'package:flutter_sxt_ui_plugin/bean/ct_server_config.dart';
import 'package:json_annotation/json_annotation.dart';
import 'package:kd_flutter_map/kd_flutter_map.dart';

part 'map_config.g.dart';

@JsonSerializable()
class MapConfig {
  String? androidKey;
  String? iosKey;
  bool? isOffline;
  bool fromMobile = true;
  bool? showDownloadMapButton;
  CtServerConfig? ctServerConfig;
  LatLng? latLng;
  String? cacheMapPath;

  factory MapConfig.fromJson(Map<String, dynamic> json) =>
      _$MapConfigFromJson(json);

  Map<String, dynamic> toJson() => _$MapConfigToJson(this);

  MapConfig({
    this.androidKey,
    this.iosKey,
    this.isOffline,
    this.fromMobile = true,
    this.showDownloadMapButton,
    this.ctServerConfig,
    this.latLng,
    this.cacheMapPath,
  });
}
