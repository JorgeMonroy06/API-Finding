class UIOptions {
  String androidNotifyBarRes =
      "@mipmap/ic_notification"; //android通知栏图标资源名称，例:"@mipmap/icon_notify_mark"
  bool enableUpdateGroupMember = true; //是否支持添加或删除群成员
  bool enableDeleteGroup = true; //是否支持删除群组
  bool enableUpdateGroupName = true; //是否支持修改群名称
  bool enableChatPageClickMember = true; //是否支持聊天界面点击群成员头像
  bool enableMultiGroupCalling = true; //是否支持多方组会
  bool enableSendLocation = true; //是否支持发送位置
  bool enablePTT = true; //是否支持PTT对讲
  bool enableTransVoiceToText = false; //是否支持语音转文字
  String transVoiceToTextAppKey = ""; //语音转文字AppKey
  String transVoiceToTextAppSecret = ""; //语音转文字AppSecret
}
