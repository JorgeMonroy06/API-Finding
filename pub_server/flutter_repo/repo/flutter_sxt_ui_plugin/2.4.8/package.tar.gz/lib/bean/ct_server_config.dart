import 'package:json_annotation/json_annotation.dart';

part 'ct_server_config.g.dart';

@JsonSerializable()
class CtServerConfig {
  String? token;
  String? rootUrl;
  String? appName;
  String? version;

  factory CtServerConfig.fromJson(Map<String, dynamic> json) =>
      _$CtServerConfigFromJson(json);

  Map<String, dynamic> toJson() => _$CtServerConfigToJson(this);

  CtServerConfig({this.token});
}
