import 'dart:convert';

import 'package:contact_sdk_flutter/manager/contact_manager.dart';
import 'package:contact_sdk_flutter/model/contact_sdk_options.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_imagepicker_plugin/flutter_imagepicker_plugin.dart';
import 'package:flutter_sxt_ui_plugin/bean/map_config.dart';
import 'package:flutter_sxt_ui_plugin/bean/server_config.dart';
import 'package:flutter_sxt_ui_plugin/bean/ui_options.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/manager/app_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:kd_flutter_map/flutter_map_manager.dart';
import 'package:sxt_flutter_plugin/account/listener/connection_state_listener.dart';
import 'package:sxt_flutter_plugin/account/model/socket_connect_state.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';

import 'ui/widget/map_appbar.dart';

class FlutterSxtUIPlugin {
  static void init() {
    WidgetsFlutterBinding.ensureInitialized();
    SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(statusBarColor: Colors.transparent));

    AppManager.instance.init();
    KDAssetPicker.initSXTApp(
      maxVideoLength: 300 * 1024 * 1024,
      maxPicLength: 300 * 1024 * 1024,
    );
    SxtAccountPlugin.init().then((value) {
      SxtAccountPlugin.setOnlineStateListener(
          ConnectionStateListener(onKicked: () {
        DataManager.instance.isDisconnected = true;
      }, onlineStateChanged: (state) {
        if (state.state == SocketConnectState.DISCONNECTED) {
          DataManager.instance.isDisconnected = true;
        } else if (state.state == SocketConnectState.CONNECTED) {
          DataManager.instance.isDisconnected = false;
        }
      })).then((value) {});
    }).onError((error, stackTrace) {
      print(error);
    });
  }

  static void setServerConfig(ServerConfig serverConfig) {
    Constant.SXT_IP = serverConfig.sxtIp;
    Constant.SXT_PORT = serverConfig.sxtPort;
    Constant.SXT_CLIENT_ID = serverConfig.sxtClientId;
    Constant.SXT_CLIENT_SECRET = serverConfig.sxtClientSecret;
    Constant.SXT_USE_SSL = serverConfig.sxtUseSsl;
    Constant.CONTACT_CLIENT_ID = serverConfig.contactClientId;
    Constant.CONTACT_CLIENT_SECRET = serverConfig.contactClientSecret;
    Constant.CONTACT_BASE_URL = serverConfig.contactBaseUrl;

    ContactSDKOptions contactSDKOptions = ContactSDKOptions();
    contactSDKOptions.clientSecret = Constant.CONTACT_CLIENT_SECRET;
    contactSDKOptions.clientId = Constant.CONTACT_CLIENT_ID;
    contactSDKOptions.baseUrl = Constant.CONTACT_BASE_URL;
    ContactManager.instance.init(contactSDKOptions);
  }

  static void setUIConfig(UIOptions uiOptions) {
    AppManager.instance.uiOptions = uiOptions;
  }

  static void setMapConfig(MapConfig mapConfig) {
    KdFlutterMapManager.setApiKey(
      mapConfig.androidKey ?? "",
      mapConfig.iosKey ?? "",
      mapConfig.isOffline ?? false,
      jsonEncode(mapConfig.ctServerConfig),
      showDownloadMapButton: mapConfig.showDownloadMapButton ?? false,
      defLatLng: mapConfig.latLng,
      fromMobile: mapConfig.fromMobile,
      cacheMapPath: mapConfig.cacheMapPath,
    );

    KdFlutterMapManager.initAppBar((title,
        {action, actionEnable, actionStr, backAction, key}) {
      return MapAppbar(key, title, backAction, action, actionStr, actionEnable);
    });
  }
}
