class Constant {
  static String? SXT_IP;

  static String? SXT_PORT;

  static String? SXT_CLIENT_ID;

  static String? SXT_CLIENT_SECRET;

  static bool? SXT_USE_SSL;

  static String? CONTACT_CLIENT_ID;

  static String? CONTACT_CLIENT_SECRET;

  static String? CONTACT_BASE_URL;
}

enum EventStatus { nothing, loading, loadingSuccess, failure, popPage, update }
