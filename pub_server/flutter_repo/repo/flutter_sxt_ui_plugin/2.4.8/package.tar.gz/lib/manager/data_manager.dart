import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';

class DataManager {
  factory DataManager() => _getInstance();

  static DataManager get instance => _getInstance();
  static DataManager? _instance;

  Map<String, Contact> _contactMapCache = {};
  Set<int> _downloadMsgCache = Set();
  Contact? currentUser;
  bool isDisconnected = false;
  String lastActiveRoomCode = "";

  DataManager._internal();

  static DataManager _getInstance() {
    if (_instance == null) {
      _instance = DataManager._internal();
    }
    return _instance!;
  }

  void init() {}

  void addContactCache(String userCode, Contact contact) {
    userCode = DomainUtil.toCode(userCode);
    _contactMapCache[userCode] = contact;
  }

  Contact? getContactFromCache(String userCode) {
    userCode = DomainUtil.toCode(userCode);
    return _contactMapCache[userCode];
  }

  Future<Contact?> getContact(String userCode) async {
    userCode = DomainUtil.toCode(userCode);
    if (!isCacheContact(userCode)) {
      List<Contact> contactList = await ContactManager.instance
          .getContactsByCodes([userCode], DataFilterBuilder())
          .where((event) => (event != null && event.isNotEmpty))
          .take(1)
          .first;
      Contact firstContact = contactList[0];

      addContactCache(userCode, firstContact);
      return firstContact;
    } else {
      return _contactMapCache[userCode];
    }
  }

  Future<List<Contact>> getContactList(List<String> list) async {
    List<String> userCodeList = [];
    list.forEach((element) {
      userCodeList.add(DomainUtil.toCode(element));
    });
    List<Contact> contactList = [];
    userCodeList.forEach((element) {
      if (isCacheContact(element)) {
        contactList.add(_contactMapCache[element]!);
      }
    });
    contactList.forEach((element) {
      for (int i = 0; i < userCodeList.length; i++) {
        if (element.code == userCodeList[i]) {
          userCodeList.removeAt(i);
          break;
        }
      }
    });
    if (userCodeList.length > 0) {
      List<Contact> newContactList = await ContactManager.instance
          .getContactsByCodes(userCodeList, DataFilterBuilder())
          .take(2)
          .last;

      if (null != newContactList && newContactList.isNotEmpty) {
        newContactList.forEach((element) {
          addContactCache(element.code!, element);
        });
        contactList.addAll(newContactList);
      }
    }

    return contactList;
  }

  bool isCacheContact(String userCode) {
    userCode = DomainUtil.toCode(userCode);
    return _contactMapCache.containsKey(userCode);
  }

  void removeCache(String userCode) {
    userCode = DomainUtil.toCode(userCode);
    _contactMapCache.remove(userCode);
  }

  void addDownloading(int msgCode) {
    _downloadMsgCache.add(msgCode);
  }

  bool isDownloading(int msgCode) {
    return _downloadMsgCache.contains(msgCode);
  }

  void clearDownloading() {
    _downloadMsgCache.clear();
  }

  void setLastActiveRoomCode(String roomCode) {
    lastActiveRoomCode = roomCode;
  }

  void clear() {
    clearDownloading();
    _contactMapCache.clear();
    currentUser = null;
    isDisconnected = false;
    lastActiveRoomCode = "";
  }
}
