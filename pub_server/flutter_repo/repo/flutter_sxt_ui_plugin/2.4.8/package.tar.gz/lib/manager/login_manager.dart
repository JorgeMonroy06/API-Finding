import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_sxt_ui_plugin/constant.dart';
import 'package:flutter_sxt_ui_plugin/manager/app_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/log/logger.dart';
import 'package:flutter_sxt_ui_plugin/utils/prefrence_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/account/model/sxt_account.dart';
import 'package:sxt_flutter_plugin/account/model/sxt_login_param.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_result_code.dart';
import 'package:sxt_flutter_plugin/model/job.dart';

class LoginManager {
  void login() async {
    SxtLogger.instance.info("LoginManager login start");
    callLogin(false).then((value) {
      if (value != null) {
        SxtLogger.instance.info("LoginManager login success");
      }
    }).onError((e, stackTrace) {
      SxtLogger.instance.info("LoginManager login failed");
      if (e is PlatformException) {
        handleException(e, AppManager.instance.globalKey);
      }
    });
  }

  Future<Job<SxtAccount>?> callLogin(isForce) async {
    String? account = await PreferenceUtil.getAccount();
    String? pwd = await PreferenceUtil.getPwd();
    if (StringUtil.isEmpty(account) || StringUtil.isEmpty(pwd)) {
      return null;
    }

    if (isForce) {
      print('强制登录');
      return SxtAccountPlugin.forceLogin(SxtLoginParam()
        ..userCode = account
        ..password = pwd
        ..sxtServerIp = Constant.SXT_IP
        ..sxtServerPort = Constant.SXT_PORT
        ..sxtClientId = Constant.SXT_CLIENT_ID
        ..sxtClientSecret = Constant.SXT_CLIENT_SECRET
        ..sxtUseSSL = Constant.SXT_USE_SSL);
    } else {
      return SxtAccountPlugin.login(SxtLoginParam()
        ..userCode = account
        ..password = pwd
        ..sxtServerIp = Constant.SXT_IP
        ..sxtServerPort = Constant.SXT_PORT
        ..sxtClientId = Constant.SXT_CLIENT_ID
        ..sxtClientSecret = Constant.SXT_CLIENT_SECRET
        ..sxtUseSSL = Constant.SXT_USE_SSL);
    }
  }

  void handleException(PlatformException e, context) {
    SxtLogger.instance
        .info("LoginManager error code :${e.code} , message :${e.message}");
    if (e.code == SxtResultCode.ACCOUNT_LOGINED) {
      SxtLogger.instance.info("LoginManager AlertDialog showDialog");
      showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text('提示'),
              actions: <Widget>[
                TextButton(
                  child: Text('取消'),
                  onPressed: () {
                    SxtLogger.instance
                        .info("LoginManager AlertDialog cancel click");
                    Navigator.of(context).pop(false);
                  },
                ),
                TextButton(
                  child: Text('确认'),
                  onPressed: () {
                    SxtLogger.instance
                        .info("LoginManager AlertDialog sure click");
                    Navigator.of(context).pop(true);
                  },
                ),
              ],
              content: Text('已登录，是否强制登录？'),
            );
          }).then((value) {
        if (value) {
          callLogin(true).then((value) {}).onError((e, stackTrace) {
            if (e is PlatformException) {
              handleException(e, AppManager.instance.globalKey);
            }
          });
        }
      });
    } else if (e.code == SxtResultCode.ILLEGAL_LOGIN_STATE) {
      ToastUtil.showToast("登录失败：${e.message}");
    } else if (e.code == SxtResultCode.ACCOUNT_HAD_CHANGE) {
      SxtAccountPlugin.logoutAndClear().then((value) {});
      ToastUtil.showToast("登录失败，账号信息发生变化，请重新登录!");
    } else {
      ToastUtil.showToast("登录失败：${e.message}");
    }
  }
}
