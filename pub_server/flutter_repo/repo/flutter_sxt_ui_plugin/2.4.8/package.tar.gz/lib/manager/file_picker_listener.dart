import 'package:flutter_sxt_ui_plugin/bean/file_picker_item.dart';

class FilePickerListener {
  Function(List<FilePickerItem> list) onPicked;

  FilePickerListener({required this.onPicked});
}
