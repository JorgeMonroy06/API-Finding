class UpdateMainPageIndexEvent {}
