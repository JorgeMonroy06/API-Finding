class MultiMeetingListener {
  Function() onStart;
  Function() onStop;
  Function() onChanged;

  MultiMeetingListener(
      {required this.onStart, required this.onStop, required this.onChanged});
}
