class ReceiveMsgEvent {}
