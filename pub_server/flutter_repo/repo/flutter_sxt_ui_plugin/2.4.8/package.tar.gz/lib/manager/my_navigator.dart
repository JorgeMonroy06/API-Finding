import 'package:flutter/material.dart';

///导航栈的变化监听
class MyNavigator extends NavigatorObserver {
  MyNavigator._internal();

  static MyNavigator _instance = MyNavigator._internal();

  static List<Route> _routes = List.empty(growable: true);

  factory MyNavigator.getInstance() => _instance;

  int mainPageCurrentIndex = -1;
  bool appIsHome = false;

  @override
  void didPop(Route route, Route? previousRoute) {
    super.didPop(route, previousRoute);
    if (_routes.contains(route)) _routes.remove(route);
  }

  @override
  void didPush(Route route, Route? previousRoute) {
    super.didPush(route, previousRoute);
    if (!_routes.contains(route)) _routes.add(route);
  }

  Route getCurrentRoute() {
    return _routes.last;
  }

  Route? getRoute(int index) {
    if (index >= 0 && index < _routes.length) {
      return _routes[index];
    }
    return null;
  }
}
