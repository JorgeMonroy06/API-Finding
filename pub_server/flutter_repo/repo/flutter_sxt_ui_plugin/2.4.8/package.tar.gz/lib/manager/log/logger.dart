import 'dart:io';

import 'package:flutter_sxt_ui_plugin/manager/log/my_file_output.dart';
import 'package:flutter_sxt_ui_plugin/manager/log/myprinter.dart';
import 'package:logger/logger.dart';
import 'package:path_provider/path_provider.dart';

class SxtLogger {
  factory SxtLogger() => _getInstance();

  static SxtLogger get instance => _getInstance();
  static SxtLogger? _instance;

  Logger? _logger;
  String? _today;

  SxtLogger._internal();

  static SxtLogger _getInstance() {
    if (_instance == null) {
      _instance = SxtLogger._internal();
    }
    return _instance!;
  }

  void init() async {
    Directory? appDocDir = Platform.isAndroid
        ? await getExternalStorageDirectory()
        : await getLibraryDirectory();
    String appDocPath = appDocDir!.path;
    DateTime dateTime = DateTime.now();
    _today =
        "${dateTime.year.toString()}_${dateTime.month.toString().padLeft(2, '0')}_${dateTime.day.toString().padLeft(2, '0')}";
    String saveLogPath = appDocPath + "/logs/sxt_ui/" + _today! + ".log";
    print("sxt log savelog path：" + saveLogPath);
    if (!await File(saveLogPath).exists()) {
      await File(saveLogPath).create(recursive: true);
    }
    List<LogOutput> list = [];
    list.add(MyFileOutput(file: File(saveLogPath)));
    list.add(ConsoleOutput());
    var outPut = MultiOutput(list);
    _logger = Logger(
      filter:
          ProductionFilter(), // Use the default LogFilter (-> only log in debug mode)
      printer: MyPrinter(printTime: true),
      // printer: PrettyPrinter(
      //     methodCount: 2,
      //     // number of method calls to be displayed
      //     errorMethodCount: 8,
      //     // number of method calls if stacktrace is provided
      //     lineLength: 120,
      //     // width of the output
      //     colors: true,
      //     // Colorful log messages
      //     printEmojis: true,
      //     // Print an emoji for each log message
      //     printTime: false // Should each log print contain a timestamp
      //     ), // Use the PrettyPrinter to format and print log
      output:
          outPut, // Use the default LogOutput (-> send everything to console)
    );
  }

  void info(String msg) {
    DateTime dateTime = DateTime.now();
    String today =
        "${dateTime.year.toString()}_${dateTime.month.toString().padLeft(2, '0')}_${dateTime.day.toString().padLeft(2, '0')}";
    if (_today != today) {
      init();
    }
    _logger?.i(msg);
  }

  void error(String msg, dynamic error) {
    DateTime dateTime = DateTime.now();
    String today =
        "${dateTime.year.toString()}_${dateTime.month.toString().padLeft(2, '0')}_${dateTime.day.toString().padLeft(2, '0')}";
    if (_today != today) {
      init();
    }
    _logger?.e(msg, error);
  }
}
