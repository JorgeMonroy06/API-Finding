import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:device_information/device_information.dart';
import 'package:dio/dio.dart';
import 'package:flutter_sxt_ui_plugin/manager/app_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/log/logger.dart';
import 'package:sxt_flutter_plugin/message/model/audio_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';
import 'package:sxt_flutter_plugin/message/sxt_message_plugin.dart';
import 'package:sxt_flutter_plugin/model/job.dart';

class TransVoiceToTextHelper {
  runSxtMethod(Function(Message message) successCallback,
      Function(String text) failedCallback, Message message) async {
    AudioAttachment attachment = message.attachment as AudioAttachment;
    if (!File(attachment.path!).existsSync()) {
      failedCallback('文件不存在');
      return;
    }

    try {
      Job<Message> job = await SxtMessagePlugin.speechToTextByMsgId(message);
      Message newMsg = job.data!;

      successCallback(newMsg);
      SxtLogger.instance.info(
          "TransVoiceToTextHelper trans success text: ${(newMsg.attachment as AudioAttachment).content}");
    } catch (error) {
      SxtLogger.instance.info("TransVoiceToTextHelper trans failed");
      failedCallback(error.toString());
    }
  }

  run(Function(String text) successCallback,
      Function(String text) failedCallback, String path) async {
    if (!File(path).existsSync()) {
      failedCallback('文件不存在');
      return;
    }

    try {
      String token = await requestToken();
      String text = await requestData(token, path);
      successCallback(text);
      SxtLogger.instance
          .info("TransVoiceToTextHelper trans success text: $text");
    } catch (error) {
      SxtLogger.instance.info("TransVoiceToTextHelper trans failed");
      failedCallback(error.toString());
    }
  }

  requestToken() async {
    String appKey = AppManager.instance.uiOptions.transVoiceToTextAppKey;
    String appSecret = AppManager.instance.uiOptions.transVoiceToTextAppSecret;

    SxtLogger.instance.info("TransVoiceToTextHelper requestToken start");

    HttpClient httpClient = HttpClient();

    //http://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=EDBjFkdbjwCm403STKHZyl1N&client_secret=NlxnidSB3nSHIsGrZK0UPDwzcmhLOdD0
    var uri = Uri.http('openapi.baidu.com', '/oauth/2.0/token', {
      'grant_type': 'client_credentials',
      'client_id': appKey,
      'client_secret': appSecret
    });
    var request = await httpClient.getUrl(uri);
    var response = await request.close();
    if (response.statusCode == HttpStatus.ok) {
      var json = await response.transform(utf8.decoder).join();
      var data = jsonDecode(json);
      String token = data['access_token'];

      SxtLogger.instance
          .info("TransVoiceToTextHelper requestToken success token : $token");
      return token;
    } else {
      SxtLogger.instance.info("TransVoiceToTextHelper requestToken failed ");
      throw Exception('TransVoiceToTextHelper requestToken error');
    }
  }

  requestData(String token, String path) async {
    SxtLogger.instance.info("TransVoiceToTextHelper requestData start");
    String imei = await DeviceInformation.deviceIMEINumber;
    BaseOptions options = BaseOptions(
      connectTimeout: 30 * 1000,
      receiveTimeout: 30 * 1000,
    );
    Dio dio = Dio(options);
    Uint8List file = File(path).readAsBytesSync();
    Response? response = await dio.put(
      'http://vop.baidu.com/server_api',
      queryParameters: {'cuid': imei, 'dev_pid': '1537', 'token': token},
      options: Options(headers: {
        HttpHeaders.contentTypeHeader: 'audio/m4a;rate=16000',
      }),
      data: Stream.fromIterable(file.map((e) => [e])),
    );
    String result = response.data['result'][0];
    return result;
  }
}
