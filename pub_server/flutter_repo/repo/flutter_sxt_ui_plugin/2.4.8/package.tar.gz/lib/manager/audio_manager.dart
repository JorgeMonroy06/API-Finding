import 'dart:async';

import 'package:flutter_sxt_ui_plugin/manager/log/logger.dart';
import 'package:just_audio/just_audio.dart';

class AudioManager {
  factory AudioManager() => _getInstance();

  static AudioManager get instance => _getInstance();
  static AudioManager? _instance;

  AudioManager._internal();

  AudioPlayer? _player;
  PlayListener? listener;
  StreamSubscription? subscription;
  String? playPath;

  static AudioManager _getInstance() {
    if (_instance == null) {
      _instance = AudioManager._internal();
    }
    return _instance!;
  }

  void init() {
    _player = AudioPlayer();
    subscription = _player?.playerStateStream.listen((event) {
      switch (event.processingState) {
        case ProcessingState.idle:
          SxtLogger.instance.info("AudioManager ProcessingState.idle");
          listener?.onIdled!();
          break;
        case ProcessingState.loading:
          SxtLogger.instance.info("AudioManager ProcessingState.loading");
          listener?.onLoading!();
          break;
        case ProcessingState.buffering:
          SxtLogger.instance.info("AudioManager ProcessingState.buffering");
          break;
        case ProcessingState.ready:
          SxtLogger.instance.info("AudioManager ProcessingState.ready");
          break;
        case ProcessingState.completed:
          SxtLogger.instance.info("AudioManager ProcessingState.completed");
          listener?.onCompleted!();
          break;
        default:
          break;
      }
    });
    _player?.playbackEventStream.listen((event) {
      // switch (event.processingState) {
      //   case ProcessingState.idle:
      //     print("AudioManager ProcessingState.idle");
      //     break;
      //   case ProcessingState.loading:
      //     print("AudioManager ProcessingState.loading");
      //     listeners.forEach((key, value) {
      //       value.onLoading!();
      //     });
      //     break;
      //   case ProcessingState.buffering:
      //     print("AudioManager ProcessingState.buffering");
      //     break;
      //   case ProcessingState.ready:
      //     print("AudioManager ProcessingState.ready");
      //     break;
      //   case ProcessingState.completed:
      //     print("AudioManager ProcessingState.completed");
      //     listeners.forEach((key, value) {
      //       value.onCompleted!();
      //     });
      //     break;
      //   default:
      //     break;
      // }
    }, onError: (Object e, StackTrace stackTrace) {
      SxtLogger.instance.info('A stream error occurred: $e');
    });
  }

  void destroy() {
    SxtLogger.instance.info("AudioManager destroy");
    subscription?.cancel();
    _player?.dispose();
    listener = null;
    _instance = null;
  }

  bool isPlaying(String filePath) {
    return filePath == playPath && ((_player?.playing) ?? false);
  }

  void play(String filePath, PlayListener playListener) {
    stop();
    SxtLogger.instance.info("AudioManager play");
    listener = playListener;
    _player?.setFilePath(filePath);
    _player?.play();
    playPath = filePath;
  }

  void stop() {
    SxtLogger.instance.info("AudioManager stop");
    _player?.stop();
    if (null != listener) {
      listener?.onIdled!();
    }
  }
}

class PlayListener {
  Function? onLoading;

  Function? onCompleted;

  Function? onIdled;

  PlayListener({this.onLoading, this.onCompleted, this.onIdled});
}
