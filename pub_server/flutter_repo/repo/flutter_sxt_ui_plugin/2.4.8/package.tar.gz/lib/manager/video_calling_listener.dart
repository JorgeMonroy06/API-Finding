class VideoCallingListener {
  Function() onStart;
  Function() onStop;

  VideoCallingListener({required this.onStart, required this.onStop});
}
