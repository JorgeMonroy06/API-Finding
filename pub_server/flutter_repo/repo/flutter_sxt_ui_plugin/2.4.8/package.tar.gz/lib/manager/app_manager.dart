import 'package:contact_sdk_flutter/model/contact.dart';
import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:contact_ui_flutter/manager/contact_module_manager.dart';
import 'package:contact_ui_flutter/manager/contact_module_option.dart';
import 'package:contact_ui_flutter/manager/contact_ui_callback.dart';
import 'package:contact_ui_flutter/ui/contact_select/contact_select_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_sxt_ui_plugin/bean/ui_options.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/eventbus_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/flutter_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/log/logger.dart';
import 'package:flutter_sxt_ui_plugin/manager/video_calling_listener.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/global_search_page/global_search_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/group_list_page/group_list_page.dart';
import 'package:flutter_sxt_ui_plugin/ui/widget/loading_dialog.dart';
import 'package:flutter_sxt_ui_plugin/utils/sxt_status_listener.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/group/model/group_create_param.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/manager/sxt_manager.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/message/model/session_type.dart';
import 'package:sxt_flutter_plugin/ptt/sxt_ptt_plugin.dart';

class AppManager {
  factory AppManager() => _getInstance();

  static AppManager get instance => _getInstance();
  static AppManager? _instance;

  GlobalKey<NavigatorState>? globalKey = GlobalKey();
  UIOptions uiOptions = UIOptions();
  VideoCallingListener? videoCallingListener;

  AppManager._internal();

  static AppManager _getInstance() {
    if (_instance == null) {
      _instance = AppManager._internal();
    }
    return _instance!;
  }

  init() {
    FlutterManager.instance.init();
    DataManager.instance.init();
    SxtEventBusManager.instance.init();

    setListeners();
  }

  void setListeners() {
    //通讯录模块点击事件
    ContactModuleManager.instance.registerContactUICallback(
        ContactUICallback(onStartChatClicked: (contact) {
      print("onStartChatClicked");
      Navigator.push(
          globalKey!.currentState!.context,
          new CupertinoPageRoute(
              settings: RouteSettings(name: '/ChatPage'),
              builder: (context) {
                SessionEntity sessionEntity = new SessionEntity(
                    code: "${contact.code}@${contact.originCode}",
                    sessionType: SessionType.USER);
                return ChatPage(sessionEntity: sessionEntity);
              }));
    }, onStartVideoCallClicked: (contact) {
      print("onStartVideoCallClicked");
      SxtManager.instance.isCalling().then((value) {
        if (value) {
          ToastUtil.showToast("正在音视频通话中...");
        } else {
          FlutterManager.instance.startVideoCall(contact)?.then((value) {
            if (!value) {
              ToastUtil.showToast("发起视频通话失败");
            }
          }).onError((error, stackTrace) {
            ToastUtil.showToast(stackTrace.toString());
          });
        }
      });
    }, onStartVoiceCallClicked: (contact) {
      print("onStartVoiceCallClicked");
      SxtManager.instance.isCalling().then((value) {
        if (value) {
          ToastUtil.showToast("正在音视频通话中...");
        } else {
          FlutterManager.instance.startVoiceCall(contact)?.then((value) {
            if (!value) {
              ToastUtil.showToast("发起语音通话失败");
            }
          }).onError((error, stackTrace) {
            ToastUtil.showToast(stackTrace.toString());
          });
        }
      });
    }, onGotoGroupListClicked: () {
      print("onGotoGroupListClicked");
      Navigator.push(globalKey!.currentState!.context,
          new CupertinoPageRoute(builder: (context) {
        return GroupListPage();
      }));
    }, goToGlobalSearchPage: () {
      print("goToGlobalSearchPage");
      Navigator.of(
        globalKey!.currentState!.context,
      ).push(CupertinoPageRoute(builder: (context) {
        return GlobalSearchPage();
      }));
    }, onAddButtonClicked: () async {
      print("onAddButtonClicked");
      var data = await Navigator.of(
        globalKey!.currentState!.context,
      ).push(CupertinoPageRoute(builder: (context) {
        return ContactSelectPage(title: "选择联系人");
      }));
      if (data != null) {
        List<Contact> list = data;
        showDialog(
            context: globalKey!.currentState!.context,
            barrierDismissible: false,
            builder: (ctx) => LoadingDialog("创建群组中...", () => {}));

        List<String> userCodes = [];
        list.forEach((element) {
          userCodes.add(element.code! + "@" + element.originCode!);
        });

        GroupCreateParam param = GroupCreateParam();
        param.userCodes = userCodes;
        SxtGroupPlugin.createGroup(param).then((value) {
          Future.delayed((Duration(milliseconds: 500)), () {
            Navigator.popUntil(
              globalKey!.currentState!.context,
              (route) {
                if (!route.willHandlePopInternally &&
                    route is ModalRoute &&
                    route.settings.name == '/MainPage') {
                  return true;
                }
                return false;
              },
            );
            Navigator.push(
                globalKey!.currentState!.context,
                new CupertinoPageRoute(
                    settings: RouteSettings(name: '/ChatPage'),
                    builder: (context) {
                      SessionEntity sessionEntity = new SessionEntity(
                          code: value.data?.groupCode,
                          sessionType: SessionType.GROUP);
                      return ChatPage(sessionEntity: sessionEntity);
                    }));
          });
        }).onError((e, stackTrace) {
          Navigator.pop(globalKey!.currentState!.context);
          if (e is PlatformException) {
            ToastUtil.showToast(e.message ?? "创建群组失败");
          } else {
            ToastUtil.showToast("创建群组失败");
          }
        });
      }
    }, onSettingEmpty: () async {
      StatusChangeLister.getCurrentLoginUser().then((value) {
        if (value == null) return;

        ContactModuleOption contactModuleOption = ContactModuleOption();
        contactModuleOption.userCode = value.code;
        contactModuleOption.deptCode = value.pcode;
        ContactModuleManager.instance
            .setContactModuleOption(contactModuleOption);
      });
    }));

    //音视频事件监听
    /**
     * 5、自己ptt讲话过程中，若来入音视频通话邀请，此时，优先级音视频高，处理结束PTT讲话。（UI层实现）
     * 6、PTT接收方收到邀请音视频邀请，切换PTT激活群组，PTT播放终止处理。（UI层实现）
     */
    videoCallingListener = VideoCallingListener(onStart: () {
      SxtLogger.instance.info("AppManager videoCallingListener onStart ");
      String lastActiveRoomCode = DataManager.instance.lastActiveRoomCode;
      //音视频来时退出对讲激活房间
      if (!StringUtil.isEmpty(lastActiveRoomCode)) {
        SxtPttPlugin.quitAudioRoom(lastActiveRoomCode).then((value) {
          SxtLogger.instance.info("AppManager quitAudioRoom success ");
        }).onError((error, stackTrace) {
          SxtLogger.instance.error("AppManager quitAudioRoom failed ", error);
        });
      }
    }, onStop: () {
      SxtLogger.instance.info("AppManager videoCallingListener onStop ");
      //音视频结束时重新进入上次ptt对讲进入的激活房间
      String lastActiveRoomCode = DataManager.instance.lastActiveRoomCode;
      if (!StringUtil.isEmpty(lastActiveRoomCode)) {
        SxtPttPlugin.joinAudioRoom(lastActiveRoomCode).then((value) {
          SxtLogger.instance.info("AppManager joinAudioRoom success ");
        }).onError((error, stackTrace) {
          SxtLogger.instance.error("AppManager joinAudioRoom failed ", error);
        });
      }
    });
    FlutterManager.instance.addVideoCallingListener(videoCallingListener);
  }

  bool isThisPage(BuildContext context, String pageName) {
    String name = (ModalRoute.of(context)?.settings.name) ?? "";
    return name.contains(pageName);
  }

  clear() {
    DataManager.instance.clear();
    if (null != videoCallingListener) {
      FlutterManager.instance.removeVideoCallingListener(videoCallingListener);
    }
  }
}
