import 'package:flutter/cupertino.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';

class PageHelper {
  static void goToChatPage(BuildContext context, SessionEntity sessionEntity) {
    Navigator.push(
        context,
        new CupertinoPageRoute(
            settings: RouteSettings(name: '/ChatPage'),
            builder: (context) {
              return ChatPage(sessionEntity: sessionEntity, normalBack: true);
            }));
  }
}
