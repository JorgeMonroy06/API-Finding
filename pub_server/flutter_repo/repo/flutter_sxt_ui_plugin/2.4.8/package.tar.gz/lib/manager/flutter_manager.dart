import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:contact_ui_flutter/common/constant.dart';
import 'package:contact_ui_flutter/event/close_event.dart';
import 'package:contact_ui_flutter/manager/contact_module_manager.dart';
import 'package:contact_ui_flutter/manager/eventbus_manager.dart';
import 'package:contact_ui_flutter/ui/contact_select_list/contact_list_select_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_sxt_ui_plugin/bean/file_picker_item.dart';
import 'package:flutter_sxt_ui_plugin/manager/app_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/file_picker_listener.dart';
import 'package:flutter_sxt_ui_plugin/manager/log/logger.dart';
import 'package:flutter_sxt_ui_plugin/manager/login_manager.dart';
import 'package:flutter_sxt_ui_plugin/manager/multimeeting_listener.dart';
import 'package:flutter_sxt_ui_plugin/manager/my_navigator.dart';
import 'package:flutter_sxt_ui_plugin/manager/video_calling_listener.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/chat/chat_page.dart';
import 'package:flutter_sxt_ui_plugin/utils/domain_util.dart';
import 'package:flutter_sxt_ui_plugin/utils/prefrence_util.dart';
import 'package:sxt_flutter_plugin/group/model/get_group_member_param.dart';
import 'package:sxt_flutter_plugin/group/model/group.dart';
import 'package:sxt_flutter_plugin/group/model/group_member.dart';
import 'package:sxt_flutter_plugin/group/sxt_group_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/session_entity.dart';
import 'package:sxt_flutter_plugin/model/sdk_list_job.dart';

class FlutterManager {
  static const NATIVE_TO_FLUTTER_CHANNEL = "com.kedacom.flutter_sxtapp.activity/NATIVE_TO_FLUTTER_CHANNEL";
  static const FLUTTER_TO_NATIVE_CHANNEL = "com.kedacom.flutter_sxtapp.activity/FLUTTER_TO_NATIVE_CHANNEL";

  factory FlutterManager() => _getInstance();

  static FlutterManager get instance => _getInstance();
  static FlutterManager? _instance;

  FlutterManager._internal();

  MethodChannel? _native_to_flutter_methodchannel;
  MethodChannel? _flutter_to_native_methodchannel;

  static FlutterManager _getInstance() {
    if (_instance == null) {
      _instance = FlutterManager._internal();
    }
    return _instance!;
  }

  MultiMeetingListener? multiMeetingListener;
  FilePickerListener? filePickerListener;
  List<VideoCallingListener?>? videoCallingListenerList;

  init() {
    _native_to_flutter_methodchannel = new MethodChannel(NATIVE_TO_FLUTTER_CHANNEL, JSONMethodCodec());
    _flutter_to_native_methodchannel = new MethodChannel(FLUTTER_TO_NATIVE_CHANNEL, JSONMethodCodec());

    _native_to_flutter_methodchannel?.setMethodCallHandler(flutterMethod);

    videoCallingListenerList = [];
  }

  Future<dynamic> flutterMethod(MethodCall methodCall) async {
    switch (methodCall.method) {
      case 'CLOSE_SELECT_CONTACT_PAGE':
        ContactEventBusManager.instance.eventBus?.fire(CloseContactPageEvent());
        break;
      case 'LOGIN':
        LoginManager().login();
        break;
      case 'MULTI_MEETING_SELECT_CONTACT_PAGE':
        Map<String, dynamic> data = methodCall.arguments;
        List<dynamic> selectCodes = data['selectCode'];

        GetGroupMemberParam getGroupMemberParam = GetGroupMemberParam();
        getGroupMemberParam.groupCode = data['groupCode'];
        getGroupMemberParam.count = 10000;
        SxtGroupPlugin.getGroupMember(getGroupMemberParam).then((value) {
          List<GroupMember> groupMemberList = value.data!;
          List<String> code = [];

          groupMemberList.forEach((element) {
            code.add(DomainUtil.toCode(element.code!));
          });
          //TODO 删除一行
          code.remove(ContactModuleManager.instance.getContactModuleOption()!.userCode);
          code.remove(ContactModuleManager.instance.getContactModuleOption()!.userCode);
          Navigator.of(AppManager.instance.globalKey!.currentContext!).push(CupertinoPageRoute(builder: (context) {
            return ContactListSelectPage(
              contactCodeList: code,
              title: "选择联系人",
              limitCount: 8,
              contactSelectCodeList: selectCodes.map((e) {
                return (DomainUtil.toCode(e) as String);
              }).toList(),
            );
          })).then((value) {
            FlutterManager.instance.returnToMultiCalling(value);
          }).onError((error, stackTrace) {
            FlutterManager.instance.returnToMultiCalling([]);
          });
        });
        break;
      case 'GET_CONTACTS':
        List<dynamic> codes = methodCall.arguments;
        List<String> newCodes = [];
        codes.forEach((element) {
          newCodes.add(DomainUtil.toCode(element as String));
        });
        List<Contact> contacts = await DataManager.instance.getContactList(newCodes);
        return contacts;
      case 'GET_CONTACT_AVATAR_BASE_URL':
        String url = (ContactManager.instance.contactSDKOptions!.baseUrl!) + "/$SERVER_NAME/";
        print("GET_CONTACT_AVATAR_BASE_URL $url");
        return url;
      case 'GO_TO_CHAT_PAGE':
        Map<String, dynamic> data = methodCall.arguments;
        SessionEntity sessionEntity = SessionEntity.fromJson(data);
        Navigator.push(
            AppManager.instance.globalKey!.currentContext!,
            new CupertinoPageRoute(
                builder: (context) {
                  return ChatPage(sessionEntity: sessionEntity);
                },
                settings: RouteSettings(name: '/ChatPage')));
        break;
      case 'START_MULTI_MEETING':
        SxtLogger.instance.info("FlutterManager START_MULTI_MEETING ");
        multiMeetingListener?.onStart();
        break;
      case 'STOP_MULTI_MEETING':
        multiMeetingListener?.onStop();
        break;
      case 'UPDATE_MULTI_MEETING':
        multiMeetingListener?.onChanged();
        break;
      case 'START_VIDEO_CALLING':
        videoCallingListenerList?.forEach((element) {
          element?.onStart();
        });
        break;
      case 'END_VIDEO_CALLING':
        videoCallingListenerList?.forEach((element) {
          element?.onStop();
        });
        break;
      case 'IS_SHOW_MSG_NOTIFICATION':
        //是否是消息免打扰
        List<String> codeList = await PreferenceUtil.getMessageFreeList();
        if (codeList.contains(methodCall.arguments)) {
          return false;
        }
        //是否在聊天界面
        if ((MyNavigator.getInstance().getCurrentRoute().settings.name ?? "").contains('/ChatPage') && !MyNavigator.getInstance().appIsHome) {
          return false;
        }
        //是否在会话列表界面
        if ((MyNavigator.getInstance().getCurrentRoute().settings.name ?? "").contains('/MainPage') &&
            MyNavigator.getInstance().mainPageCurrentIndex == 0 &&
            !MyNavigator.getInstance().appIsHome) {
          return false;
        }
        return true;
      case 'ON_OPEN_FILE_RESULT':
        final Map<String, dynamic> data = methodCall.arguments;
        final SDKListJob job = SDKListJob.fromJson(data);
        final List<FilePickerItem> list = [];
        for (var element in job.data!) {
          list.add(FilePickerItem.fromJson(element!));
        }
        filePickerListener?.onPicked(list);
        break;
    }
  }

  Future<dynamic>? startVoiceCall(Contact contact) {
    return _flutter_to_native_methodchannel?.invokeMethod("START_VOICE_CALL", contact);
  }

  Future<dynamic>? startVideoCall(Contact contact) {
    return _flutter_to_native_methodchannel?.invokeMethod("START_VIDEO_CALL", contact);
  }

  Future<dynamic>? startMultiVideoCall(Group group, List<Contact> contactList) {
    Map<String, dynamic> data = {};
    data["group"] = group;
    data["contactList"] = contactList;
    return _flutter_to_native_methodchannel?.invokeMethod("START_MULTI_VIDEO_CALL", data);
  }

  Future<dynamic>? startMultiVoiceCall(Group group, List<Contact> contactList) {
    Map<String, dynamic> data = {};
    data["group"] = group;
    data["contactList"] = contactList;
    return _flutter_to_native_methodchannel?.invokeMethod("START_MULTI_VOICE_CALL", data);
  }

  Future<dynamic>? returnToMultiCalling(List<Contact> contactList) {
    Map<String, dynamic> data = {};
    data["group"] = null;
    data["contactList"] = contactList;
    return _flutter_to_native_methodchannel?.invokeMethod("RETURN_MULTI_CALL", data);
  }

  Future<dynamic>? getMultiMeetingInfo(String groupCode) {
    return _flutter_to_native_methodchannel?.invokeMethod("GET_MULTI_MEETING_INFO", groupCode);
  }

  Future<dynamic>? backToMultiCalling(Map<String, dynamic> data) {
    return _flutter_to_native_methodchannel?.invokeMethod("BACK_TO_MULTI_CALL", data);
  }

  Future<dynamic>? allowGoToChatPage() {
    return _flutter_to_native_methodchannel?.invokeMethod("SDK_METHOD_AllOW_GO_TO_CHAT_PAGE");
  }

  Future<dynamic>? requestFloatWindowPermission() {
    return _flutter_to_native_methodchannel?.invokeMethod("REQUEST_FLOAT_WINDOW_PERMISSION");
  }

  Future<dynamic>? hasFloatWindowPermission() {
    return _flutter_to_native_methodchannel?.invokeMethod("HAS_FLOAT_WINDOW_PERMISSION");
  }

  Future<dynamic>? gotoDesktop() {
    return _flutter_to_native_methodchannel?.invokeMethod("GO_TO_DESKTOP");
  }

  Future<dynamic>? notifyGroupDelete(String? groupCode) {
    return _flutter_to_native_methodchannel?.invokeMethod("NOTIFY_GROUP_DELETE", groupCode);
  }

  void addVideoCallingListener(VideoCallingListener? listener) {
    videoCallingListenerList?.add(listener);
  }

  void removeVideoCallingListener(VideoCallingListener? listener) {
    videoCallingListenerList?.remove(listener);
  }

  void setSpeakerphoneOn(bool isOpen) {
    _flutter_to_native_methodchannel?.invokeMethod("SET_SPEAKER_PHONE_ON", isOpen);
  }

  void requestBlessPermission() {
    _flutter_to_native_methodchannel?.invokeMethod("REQUEST_BLESS_PERMISSION");
  }

  void gotoPermissionGuidePage() {
    _flutter_to_native_methodchannel?.invokeMethod("GO_TO_PERMISSION_GUIDE_PAGE");
  }

  void gotoFilePickPage() {
    _flutter_to_native_methodchannel?.invokeMethod("GO_TO_FILE_PICK_PAGE");
  }

  Future<dynamic>? getVideoDuration(String? path) {
    return _flutter_to_native_methodchannel?.invokeMethod("GET_VIDEO_DURATION", path);
  }
}
