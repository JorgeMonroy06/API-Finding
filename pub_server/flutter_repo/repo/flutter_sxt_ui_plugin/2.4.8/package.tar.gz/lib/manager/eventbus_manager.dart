import 'package:event_bus/event_bus.dart';

class SxtEventBusManager {
  factory SxtEventBusManager() => _getInstance();

  static SxtEventBusManager get instance => _getInstance();
  static SxtEventBusManager? _instance;

  SxtEventBusManager._internal();

  static SxtEventBusManager _getInstance() {
    if (_instance == null) {
      _instance = SxtEventBusManager._internal();
    }
    return _instance!;
  }

  EventBus? eventBus;

  init() {
    eventBus = EventBus();
  }
}
