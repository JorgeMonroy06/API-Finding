import 'package:intl/intl.dart';

class DateTimeUtil {
  static String formatChatTime(int time) {
    return DateFormat("yyyy-MM-dd HH:mm")
        .format(DateTime.fromMillisecondsSinceEpoch(time));
  }

  static String formatDate(DateTime time) {
    return DateFormat("yyyy-MM-dd").format(time);
  }

  static String formatMessageTime(int time) {
    DateTime current = DateTime.now();
    DateTime chatTime = DateTime.fromMillisecondsSinceEpoch(time);
    if (current.year == chatTime.year) {
      if (current.day == chatTime.day) {
        if (chatTime.hour <= 12) {
          return DateFormat("上午 H:mm").format(chatTime);
        } else {
          return DateFormat("下午 H:mm").format(chatTime);
        }
      } else if (chatTime.day == current.day - 1) {
        return DateFormat("昨天 H:mm").format(chatTime);
      } else {
        return DateFormat("M月d日 H:mm").format(chatTime);
      }
    } else {
      return DateFormat("yyyy年M月d日 HH:mm").format(chatTime);
    }
  }

  static String formatMessageTime2(int time) {
    DateTime current = DateTime.now();
    DateTime chatTime = DateTime.fromMillisecondsSinceEpoch(time);
    if (current.year == chatTime.year) {
      if (current.day == chatTime.day) {
        if (chatTime.hour <= 12) {
          return DateFormat("上午 HH:mm").format(chatTime);
        } else {
          return DateFormat("下午 HH:mm").format(chatTime);
        }
      } else if (chatTime.day == current.day - 1) {
        return DateFormat("昨天 HH:mm").format(chatTime);
      } else {
        return DateFormat("yyyy/MM/dd").format(chatTime);
      }
    } else {
      return DateFormat("yyyy/MM/dd").format(chatTime);
    }
  }

  ///  DateTime.Now.ToString("yyyy-MM-dd tt HH:mm:ss")
  static String formatMessageTime1(int time) {
    DateTime current = DateTime.now();
    DateTime chatTime = DateTime.fromMillisecondsSinceEpoch(time);
    if (current.day == chatTime.day) {
      return DateFormat("tt HH:mm").format(chatTime);
    } else if (current.year == chatTime.year) {
      return DateFormat("MM月dd日 HH:mm").format(chatTime);
    } else {
      return DateFormat("yyyy年MM月dd日 HH:mm").format(chatTime);
    }
  }

  /*
   * 秒数转化为时分秒
   */
  static String getDuration(int durationSeconds) {
    int hours = durationSeconds ~/ (60 * 60);
    int leftSeconds = durationSeconds % (60 * 60);
    int minutes = leftSeconds ~/ 60;
    int seconds = leftSeconds % 60;
    String sBuffer = "";
    if (hours != 0) {
      sBuffer += addZeroPrefix(hours);
      sBuffer += ":";
    }
    sBuffer += addZeroPrefix(minutes);
    sBuffer += ":";
    sBuffer += addZeroPrefix(seconds);
    return sBuffer.toString();
  }

  static String addZeroPrefix(int number) {
    if (number < 10) {
      return "0" + number.toString();
    } else {
      return "" + number.toString();
    }
  }

  static int formatLongTime(int time) {
    if (time >= 0) {
      double voiceDuration;
      if (time < 1000) {
        voiceDuration = 1;
      } else if (time % 1000 == 0) {
        voiceDuration = time / 1000;
      } else {
        voiceDuration = time / 1000;
      }
      return voiceDuration.toInt();
    }
    return 0;
  }

  static String fromeLongTime(int longTime) {
    if (longTime < 0) {
      return "";
    }
    int voiceDuration;
    int durationMilliSeconds = longTime;
    if (durationMilliSeconds % 1000 == 0) {
      voiceDuration = durationMilliSeconds ~/ 1000;
    } else {
      voiceDuration = durationMilliSeconds ~/ 1000 + 1;
    }
    return getVoiceTime(voiceDuration);
  }

  static String getVoiceTime(int duration) {
    int d;
    if (duration >= 3600) {
      d = duration ~/ 3600;
      int t = duration - (d * 3600);
      if (t <= 60) {
        return d.toString() + "h" + 0.toString() + "'" + t.toString() + "''";
      }
      int m = (t / 60) as int;
      return d.toString() +
          "h" +
          m.toString() +
          "'" +
          (t - (m * 60)).toString() +
          "''";
    } else if (duration < 3600 && duration >= 60) {
      d = duration ~/ 60;
      return d.toString() + "'" + (duration - (d * 60)).toString() + "''";
    } else if (duration < 60) {
      return duration.toString() + "''";
    } else {
      return "";
    }
  }
}
