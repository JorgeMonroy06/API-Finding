import 'dart:convert';

import 'package:contact_sdk_flutter/contact_sdk.dart';
import 'package:flutter_sxt_ui_plugin/manager/data_manager.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/message.dart';
import 'package:flutter_sxt_ui_plugin/utils/prefrence_util.dart';
import 'package:sxt_flutter_plugin/account/model/sxt_account.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';

import 'domain_util.dart';

class StatusChangeLister {
  StatusChangeLister._();

  static List<int> _jobId = List.empty(growable: true);

  static List<int> getJobId() {
    return _jobId;
  }

  static setJobId(int jobId) {
    _jobId.add(jobId);
  }

  static removeAllJobId() {
    _jobId.clear();
  }

  static Contact? _currentLoginUser;

  static Map<String, List<String>>? _topMessageList;

  static Future<Contact?> getCurrentLoginUser() async {
    if (_currentLoginUser == null) {
      printLog("_currentLoginUser is null and now getting");
      _currentLoginUser = await _getCurrentUser();
    }
    printLog("_currentLoginUser after:${_currentLoginUser?.toJson().toString() ?? "current is  null"}");
    return _currentLoginUser;
  }

  static setCurrentLoginUser(Contact? contact) {
    _currentLoginUser = contact;
  }

  static Future<Contact?> _getCurrentUser() async {
    Contact? contact;
    print("1111 _getCurrentUser step 0");
    SxtAccount account = await SxtAccountPlugin.getCurrentUser();
    print("1111 _getCurrentUser step 1");
    String code = DomainUtil.toCode(account.code);
    print("1111 _getCurrentUser step 2");
    final List<Contact> contacts = await DataManager.instance.getContactList([code]);
    print("1111 _getCurrentUser step 3");
    contact = contacts[0];
    print("1111 _getCurrentUser step 4");
    printLog("1111 _getCurrentUser:${contact.toJson().toString()}");
    return contact;
  }

  static Future<Map<String, List<String>>?> getTopMessageList() async {
    _topMessageList = await PreferenceUtil.getTopMessageList();
    printLog("TopMessageList:${jsonEncode(_topMessageList)}");

    return _topMessageList;
  }

  static setTopMessage(String conversationCode) async {
    printLog("add --${conversationCode}");

    Contact? contact = await getCurrentLoginUser();
    if (contact == null) {
      throw Exception("当前登录用户信息不存在");
    } else {
      Map<String, List<String>> topMessageInfo = await getTopMessageList() ?? Map();
      if (topMessageInfo[contact.code] == null) {
        topMessageInfo[contact.code!] = List.empty(growable: true);
      }
      topMessageInfo[contact.code!]!.add(conversationCode);
      printLog("setTopList--${topMessageInfo.toString()}");

      PreferenceUtil.setTopMessageList(topMessageInfo);
    }
  }

  static Future<bool> isTopMessage(String conversationCode) async {
    printLog("is top${conversationCode}");
    if (await getTopMessageList() == null) {
      return false;
    } else if (await getCurrentLoginUser() == null) {
      throw Exception("当前登录用户信息不存在");
    } else {
      if (_topMessageList!.containsKey(_currentLoginUser!.code!)) {
        return _topMessageList![_currentLoginUser!.code!]?.contains(conversationCode) ?? false;
      } else {
        return false;
      }
    }
  }

  static Future<bool> removeTopMessage(String conversationCode) async {
    printLog("remove --$conversationCode");

    if (await getTopMessageList() == null) {
      return false;
    } else if (await getCurrentLoginUser() == null) {
      throw Exception("当前登录用户信息不存在");
    } else {
      if (_topMessageList!.containsKey(_currentLoginUser!.code!) && _topMessageList![_currentLoginUser!.code!]!.contains(conversationCode)) {
        bool removed = _topMessageList![_currentLoginUser!.code!]!.remove(conversationCode);
        await PreferenceUtil.setTopMessageList(_topMessageList ?? Map());
        return removed;
      } else {
        return false;
      }
    }
  }
}
