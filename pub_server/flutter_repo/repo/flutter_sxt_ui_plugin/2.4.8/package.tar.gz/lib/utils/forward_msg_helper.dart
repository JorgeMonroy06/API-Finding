import 'dart:io';

import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_sxt_ui_plugin/ui/page/forward_msg/forward_msg_page.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/message/model/attachment.dart';
import 'package:sxt_flutter_plugin/message/model/audio_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/file_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/pic_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/video_attachment.dart';

class ForwardMsgHelper {
  static forwardMsg(BuildContext context, Attachment attachment) {
    bool canFav = true;
    if (attachment is AudioAttachment) {
      ToastUtil.showToast("暂不支持转发语音");
      return;
    }
    if (attachment is FileAttachment) {
      String? path = attachment.path;
      canFav = !StringUtil.isEmpty(path) && File(path ?? "").existsSync();
    }
    if (attachment is VideoAttachment) {
      String? path = attachment.path;
      canFav = !StringUtil.isEmpty(path) && File(path ?? "").existsSync();
    }
    if (attachment is PicAttachment) {
      String? path = attachment.path;
      canFav = !StringUtil.isEmpty(path) && File(path ?? "").existsSync();
    }

    if (!canFav) {
      ToastUtil.showToast("请先下载消息附件");
      return;
    }

    Navigator.push(context, CupertinoPageRoute(builder: (context) {
      return ForwardMsgPage(attachment);
    }));
  }
}
