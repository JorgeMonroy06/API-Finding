import 'package:flutter/cupertino.dart';

const PACKAGE_NAME = "flutter_sxt_ui_plugin";

class ImageHelper {
  static String wrapAssets(String url) {
    return "images/" + url;
  }

  static Widget assetImage(String url) {
    return Image.asset(wrapAssets(url),
        package: PACKAGE_NAME, fit: BoxFit.fill);
  }

  static AssetImage getAssetImage(String url) {
    return AssetImage(wrapAssets(url), package: PACKAGE_NAME);
  }
}
