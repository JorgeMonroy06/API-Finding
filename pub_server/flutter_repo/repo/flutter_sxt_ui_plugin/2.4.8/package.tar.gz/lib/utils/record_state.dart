class RecordState {
  bool cancelRecord;
  bool up;

  RecordState({this.cancelRecord = false, this.up = false});

  @override
  String toString() {
    return 'RecordState{cancelRecord: $cancelRecord, up: $up}';
  }

  void resetState() {
    this.cancelRecord = false;
    this.up = false;
  }
}
