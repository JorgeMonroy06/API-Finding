import 'dart:io';

import 'package:contact_ui_flutter/common/string_util.dart';
import 'package:flutter/services.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:sxt_flutter_plugin/favorite/model/favorite_form.dart';
import 'package:sxt_flutter_plugin/favorite/sxt_favorite_plugin.dart';
import 'package:sxt_flutter_plugin/message/model/attachment.dart';
import 'package:sxt_flutter_plugin/message/model/audio_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/file_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/message.dart';
import 'package:sxt_flutter_plugin/message/model/message_type.dart';
import 'package:sxt_flutter_plugin/message/model/pic_attachment.dart';
import 'package:sxt_flutter_plugin/message/model/video_attachment.dart';

class FavMsgHelper {
  static favMsg(Message<Attachment> msg) {
    bool canFav = true;
    if (msg.msgType == MsgType.VOICE_FILE) {
      String? path = (msg.attachment as AudioAttachment).path;
      canFav = !StringUtil.isEmpty(path) && File(path ?? "").existsSync();
    }
    if (msg.msgType == MsgType.OTHERS) {
      String? path = (msg.attachment as FileAttachment).path;
      canFav = !StringUtil.isEmpty(path) && File(path ?? "").existsSync();
    }
    if (msg.msgType == MsgType.VIDEO_FILE) {
      String? path = (msg.attachment as VideoAttachment).path;
      canFav = !StringUtil.isEmpty(path) && File(path ?? "").existsSync();
    }
    if (msg.msgType == MsgType.PICTURE) {
      String? path = (msg.attachment as PicAttachment).path;
      canFav = !StringUtil.isEmpty(path) && File(path ?? "").existsSync();
    }

    if (!canFav) {
      ToastUtil.showToast("请先下载消息附件");
      return;
    }

    FavoriteForm favoriteForm = FavoriteForm();
    favoriteForm.sender = msg.sender;
    favoriteForm.talker = msg.talker;
    favoriteForm.srcSvrId = msg.serverId;
    favoriteForm.msgCode = msg.code;
    SxtFavoritePlugin.addFavorite(favoriteForm).then((value) {
      ToastUtil.showToast("已收藏");
    }).onError((e, stackTrace) {
      if (e is PlatformException) {
        ToastUtil.showToast(e.message ?? "收藏失败");
      } else {
        ToastUtil.showToast("收藏失败");
      }
    });
  }
}
