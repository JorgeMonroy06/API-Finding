import 'dart:async';

import 'package:sxt_flutter_plugin/message/model/conversation.dart';

class IosMessageStreamController {
  StreamController<int> _streamController;

  StreamController get streamController => _streamController;

  IosMessageStreamController._internal({bool sync = false})
      : _streamController = StreamController.broadcast(sync: sync);

  static IosMessageStreamController? _instance;

  factory IosMessageStreamController.getInstance() => _getInstance();

  /// 获取单例内部方法
  static _getInstance() {
    // 只能有一个实例
    if (_instance == null) {
      _instance = IosMessageStreamController._internal();
    }
    return _instance;
  }
}
