import 'dart:async';

class MessageStreamController {
  StreamController<int> _streamController;

  StreamController get streamController => _streamController;

  MessageStreamController._internal({bool sync = false})
      : _streamController = StreamController.broadcast(sync: sync);

  static MessageStreamController? _instance;

  factory MessageStreamController.getInstance() => _getInstance();

  /// 获取单例内部方法
  static _getInstance() {
    // 只能有一个实例
    if (_instance == null) {
      _instance = MessageStreamController._internal();
    }
    return _instance;
  }
}
