class DomainUtil {
  static String toCode(String? domainCode) {
    if (domainCode != null && domainCode.contains("@")) {
      return domainCode.split("@")[0];
    } else {
      return domainCode ?? '';
    }
  }
}
