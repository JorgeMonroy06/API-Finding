import 'package:flutter/material.dart';

class ColorUtil {
  ColorUtil._();

  ///标题背景色
  static const LinearGradient titleGradient = LinearGradient(colors: [
    Color(0xFF5B89D7),
    Color(0xFF2F3281),
  ]);
  static const Color transparentBlack = Color(0x80131D27);
  static const Color backGroundColor = Color(0xFFF5F5F5);
  static const Color dividerColor = Color(0xFFE0E0E0);
  static const Color color333333 = Color(0xFF333333);
  static const Color color99000000 = Color(0x99000000);
  static const Color color677DB1 = Color(0xFF677DB1);
  static const Color color999999 = Color(0xFF999999);
  static const Color hintColorAAAAAA = Color(0xFFAAAAAA);
  static const Color colorFF85152 = Color(0xFFF85152);
  static const Color colorF7F7F7 = Color(0xFFF7F7F7);
  static const Color color3D7DFF = Color(0xFF3D7DFF);
  static const Color colorFFA2A3A7 = Color(0xFFA2A3A7);
  static const Color colorFF0F77FE = Color(0xFF0F77FE);
  static const Color colorFFEE4A37 = Color(0xFFEE4A37);
  static const Color colorFFFFEDED = Color(0xFFFFEDED);
  static const Color colorFFFFFFFF = Color(0xFFFFFFFF);
  static const Color colorFF010101 = Color(0xFF010101);
  static const Color colorFF181818 = Color(0xFF181818);
  static const Color colorFF860102 = Color(0xFF860102);
  static const Color colorFF666666 = Color(0xFF666666);
  static const Color colorFFD74A49 = Color(0xFFD74A49);

  static const COLOR_FFECEDEE = Color(0xFFECEDEE);
  static const COLOR_FFEEEEEE = Color(0xFFEEEEEE);
  static const COLOR_FFF6F7F8 = Color(0xFFF6F7F8);
  static const COLOR_FFE0E0E0 = Color(0xFFE0E0E0);
  static const COLOR_FF6D6D6E = Color(0xFF6D6D6E);
  static const COLOR_FF9A9C9C = Color(0xFF9A9C9C);
  static const COLOR_FFF5F5F5 = Color(0xFFF5F5F5);
  static const COLOR_FFAAAAAA = Color(0xFFAAAAAA);
  static const COLOR_FFCDE8FC = Color(0xFFCDE8FC);
  static const COLOR_FFE2E5E8 = Color(0xFFE2E5E8);
  static const COLOR_FF59637C = Color(0xFF59637C);
  static const COLOR_FF636D8A = Color(0xFF636D8A);
  static const COLOR_33000000 = Color(0x33000000);
  static const COLOR_FF0F77FE = Color(0xFF0F77FE);
  static const COLOR_FF1677FF = Color(0xFF1677FF);
  static const COLOR_FF4C4C4C = Color(0xFF4C4C4C);
  static const COLOR_FFFF4B34 = Color(0xFFFF4B34);
  static const COLOR_FF353F4A = Color(0xFF353F4A);
  static const COLOR_FFBCBCBE = Color(0xFFBCBCBE);
  static const COLOR_FF131D27 = Color(0xFF131D27);
  static const COLOR_F5A5A5A = Color(0xFF5A5A5A);
  static const COLOR_E5E5E5 = Color(0xFFE5E5E5);
  static const Color colorFF131D27 = Color(0xFF131D27);
  static const Color colorFF0A84FF = Color(0xFF0A84FF);
}
