import 'dart:async';

import 'package:sxt_flutter_plugin/group/model/group.dart';

class GroupImageStreamController {
  StreamController<Group> _streamController;

  StreamController get streamController => _streamController;

  GroupImageStreamController._internal({bool sync = false})
      : _streamController = StreamController.broadcast(sync: sync);

  static GroupImageStreamController? _instance;

  factory GroupImageStreamController.getInstance() => _getInstance();

  /// 获取单例内部方法
  static _getInstance() {
    // 只能有一个实例
    if (_instance == null) {
      _instance = GroupImageStreamController._internal();
    }
    return _instance;
  }
}
