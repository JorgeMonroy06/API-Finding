import 'package:fluttertoast/fluttertoast.dart';

class ToastUtil {
  ToastUtil._();

  static showToast(String content) {
    Fluttertoast.showToast(
        msg: content, toastLength: Toast.LENGTH_SHORT, timeInSecForIosWeb: 1);
  }
}
