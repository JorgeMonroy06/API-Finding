import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:sxt_flutter_plugin/account/sxt_account_plugin.dart';

class PreferenceUtil {
  static const _ACCOUNT_KEY = "account";

  static Future<void> setAccount(String account) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    await preferences.setString(_ACCOUNT_KEY, account);
  }

  static Future<String?> getAccount() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    return preferences.getString(_ACCOUNT_KEY);
  }

  static const _PASSWORD_KEY = "password";

  static Future<void> setPwd(String pwd) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    await preferences.setString(_PASSWORD_KEY, pwd);
  }

  static Future<String?> getPwd() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    return preferences.getString(_PASSWORD_KEY);
  }

  static const _ISREMEMBERSECRET_KEY = "is_remember_secret";

  static Future<void> setRememberSecret(bool rememberSecret) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    await preferences.setBool(_ISREMEMBERSECRET_KEY, rememberSecret);
  }

  static Future<bool> isRememberSecret() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    return preferences.getBool(_ISREMEMBERSECRET_KEY) ?? false;
  }

  //消息置顶
  static const MESSAGE_TOP_KEY = "message_top_key";

  static Future<void> setTopMessageList(
      Map<String, List<String>> topMessageMap) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    await preferences.setString(MESSAGE_TOP_KEY, jsonEncode(topMessageMap));
  }

  static Future<Map<String, List<String>>> getTopMessageList() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    Map<String, List<String>> nowData = Map();
    Map<String, dynamic> origin = Map<String, dynamic>.from(
        json.decode(preferences.getString(MESSAGE_TOP_KEY) ?? "{}"));
    origin.keys.forEach((element) {
      List<dynamic> list = origin[element];
      nowData[element] = list.cast<String>();
    });
    return nowData;
  }

  //消息置顶
  static const GLOBAL_SEARCH_HISTORY = "GLOBAL_SEARCH_HISTORY";

  static Future<void> setSearchHistoryList(
      List<String> searchHistoryList) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    await preferences.setString(
        GLOBAL_SEARCH_HISTORY, jsonEncode(searchHistoryList));
  }

  static Future<List<String>> getSearchHistoryList() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    List<String> list = List<String>.from(
        json.decode(preferences.getString(GLOBAL_SEARCH_HISTORY) ?? "[]"));
    return list;
  }

  ///消息铃声提醒
  static const MESSAGE_AWOKE_SOUND = "message_awoke_sound";
  static Future<void> setMessageAwokeOpen(bool open) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    await preferences.setBool(MESSAGE_AWOKE_SOUND, open);
  }

  static Future<bool> getMessageAwokeOpen() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    return preferences.getBool(MESSAGE_AWOKE_SOUND) ?? true;
  }

  // 消息免打扰
  static const messageFreeList = 'message_free_list';

  static Future<bool> setMessageFreeList(List<String> value) async {
    final prefs = await SharedPreferences.getInstance();
    final user = await SxtAccountPlugin.getCurrentUser();
    return await prefs.setStringList(messageFreeList + '@' + user.code!, value);
  }

  static Future<List<String>> getMessageFreeList() async {
    final prefs = await SharedPreferences.getInstance();
    final user = await SxtAccountPlugin.getCurrentUser();
    return prefs.getStringList(messageFreeList + '@' + user.code!) ?? [];
  }

  /// 置顶会话
  static const onTopConversationList = 'on_top_conversation_list';

  static Future<bool> setOnTopConversationList(List<String> value) async {
    final prefs = await SharedPreferences.getInstance();
    final user = await SxtAccountPlugin.getCurrentUser();
    return await prefs.setStringList(
        onTopConversationList + '@' + user.code!, value);
  }

  static Future<List<String>> getOnTopConversationList() async {
    final prefs = await SharedPreferences.getInstance();
    final user = await SxtAccountPlugin.getCurrentUser();
    return prefs.getStringList(onTopConversationList + '@' + user.code!) ?? [];
  }

  /// 强提醒
  static const strongReminder = 'strong_reminder';

  static Future<bool> setStrongReminder(Map<String, dynamic> value) async {
    final prefs = await SharedPreferences.getInstance();
    final user = await SxtAccountPlugin.getCurrentUser();
    return await prefs.setString(
        strongReminder + '@' + user.code!, jsonEncode(value));
  }

  static Future<Map<String, dynamic>> getStrongReminder() async {
    final prefs = await SharedPreferences.getInstance();
    final user = await SxtAccountPlugin.getCurrentUser();
    return jsonDecode(
        prefs.getString(strongReminder + '@' + user.code!) ?? '{}');
  }
}
