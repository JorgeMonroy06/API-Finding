import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter_sxt_ui_plugin/utils/image_helper.dart';
import 'package:flutter_sxt_ui_plugin/utils/toast_util.dart';
import 'package:open_file/open_file.dart';

class FileUtil {
  static List imageType = ["gif", "jpeg", "jpg", "png", 'webp', 'bmp'];
  static List videoType = [
    "mpg",
    "mpeg",
    "mp4",
    "3gp",
    "mov",
    "rm",
    "rmvb",
    "wmv",
    "asf",
    "avi",
    "asx",
    "mpg4",
    "rmvb",
    "wmv",
    "asf",
    "avi",
    "asx",
    "m4u",
    "m4v",
    "mpe"
  ];
  static List docType = [
    "doc",
    "docx",
    "xls",
    "xlsx",
    "pdf",
    "ppt",
  ];
  static List musicType = [
    "aa",
    "aac",
    "aax",
    "aiff",
    "alac",
    "amr",
    "ape",
    "au",
    "awb",
    "dss",
    "flac",
    "gsm",
    "mpc",
    "ogg",
    "rf64",
    "sln",
    "voc",
    "vox",
    "wv",
    "webm",
    "8svx",
    "m4a",
    "mp3"
  ];

  static bool isVideo(String fileType) {
    return videoType.contains(fileType);
  }

  static bool isMusic(String fileType) {
    return musicType.contains(fileType);
  }

  static bool isPDF(String fileType) {
    return fileType == "pdf";
  }

  static bool isXLS(String fileType) {
    return fileType == "xls" || fileType == "xlsx";
  }

  static bool isTXT(String fileType) {
    return fileType == "txt";
  }

  static bool isZIP(String fileType) {
    return fileType == "zip" || fileType == "rar" || fileType == "7z";
  }

  static bool isDOC(String fileType) {
    return fileType == "doc" || fileType == "docx";
  }

  static bool isPPT(String fileType) {
    return fileType == "ppt" || fileType == "pptx";
  }

  static bool isEXE(String fileType) {
    return fileType == "exe";
  }

  static bool isImage(String fileType) {
    return imageType.contains(fileType);
  }

  static bool isDoc(String fileType) {
    return docType.contains(fileType);
  }

  static getFileSize(int bytes) {
    if (bytes <= 0) return "0 B";
    const suffixes = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
    var i = (log(bytes) / log(1024)).floor();
    return ((bytes / pow(1024, i)).toStringAsFixed(2)) + ' ' + suffixes[i];
  }

  static openFile(String path) {
    OpenFile.open(path).then((value) {
      switch (value.type) {
        case ResultType.done:
          break;
        case ResultType.permissionDenied:
          ToastUtil.showToast("未获得访问文件权限");
          break;
        case ResultType.fileNotFound:
          ToastUtil.showToast("文件未找到");
          break;
        case ResultType.noAppToOpen:
          ToastUtil.showToast("不支持打开该文件类型");
          break;
        case ResultType.error:
          ToastUtil.showToast("打开文件失败");
          break;
      }
    }).onError((error, stackTrace) {
      ToastUtil.showToast("打开文件失败");
    });
  }

  static void clearImageCache() {
    var cache = PaintingBinding.instance?.imageCache;
    if (cache != null && (cache.currentSizeBytes >= 55 << 22)) {
      cache.clear();
      cache.clearLiveImages();
    }
  }

  static String getFileSuffix(String fileName) {
    String suffix = "";
    if (fileName.contains(".")) {
      suffix = fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length);
    }
    return suffix.toLowerCase();
  }

  static String getIconByFileType(String fileName) {
    String defaultImg = ImageHelper.wrapAssets("ic_file_default.png");

    final String suffix = getFileSuffix(fileName);
    if (FileUtil.isDOC(suffix)) {
      defaultImg = ImageHelper.wrapAssets("ic_word.png");
    } else if (FileUtil.isPDF(suffix)) {
      defaultImg = ImageHelper.wrapAssets("ic_pdf.png");
    } else if (FileUtil.isPPT(suffix)) {
      defaultImg = ImageHelper.wrapAssets("ic_ppt.png");
    } else if (FileUtil.isTXT(suffix)) {
      defaultImg = ImageHelper.wrapAssets("ic_txt.png");
    } else if (FileUtil.isMusic(suffix)) {
      defaultImg = ImageHelper.wrapAssets("ic_mp3.png");
    } else if (FileUtil.isZIP(suffix)) {
      defaultImg = ImageHelper.wrapAssets("ic_zip.png");
    } else if (FileUtil.isXLS(suffix)) {
      defaultImg = ImageHelper.wrapAssets("ic_xls.png");
    }
    return defaultImg;
  }
}
